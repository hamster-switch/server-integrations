package handler

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/gin-gonic/gin"
)

func TestHamsterSwitchNormalizeBaseURL(t *testing.T) {
	for input, expected := range map[string]string{
		"https://example.com/":            "https://example.com",
		"https://example.com/api/v1":      "https://example.com",
		"https://example.com/v1":          "https://example.com",
		"https://example.com/v1beta":      "https://example.com",
		"https://example.com/base/api/v1": "https://example.com/base",
	} {
		if actual := hamsterSwitchNormalizeBaseURL(input); actual != expected {
			t.Fatalf("normalize %q: got %q want %q", input, actual, expected)
		}
	}
}

func TestHamsterSwitchModelsForGroup(t *testing.T) {
	group := &service.Group{DefaultMappedModel: "fallback-model"}
	models, err := hamsterSwitchModelsForGroup(group)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(models, []string{"fallback-model"}) {
		t.Fatalf("unexpected models: %#v", models)
	}
}

func TestHamsterSwitchIDPartDoesNotExposeGroupName(t *testing.T) {
	if actual := hamsterSwitchIDPart("中文 分组"); actual != "group" {
		t.Fatalf("unexpected identifier: %s", actual)
	}
}

func TestHamsterSwitchProviderIDIncludesGroupID(t *testing.T) {
	first := hamsterSwitchProviderID(10, "same name", "codex")
	second := hamsterSwitchProviderID(11, "same name", "codex")
	if first == second {
		t.Fatalf("provider IDs must differ for same-name groups: %q", first)
	}
	if first != "sub2api-same-name-10-codex" {
		t.Fatalf("unexpected provider ID: %q", first)
	}
}

func TestHamsterTemplateGroupsLoadsRateMultiplier(t *testing.T) {
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	mock.ExpectQuery(`SELECT id, name, platform, models_list_config, default_mapped_model, rate_multiplier\s+FROM groups`).
		WillReturnRows(sqlmock.NewRows([]string{"id", "name", "platform", "models_list_config", "default_mapped_model", "rate_multiplier"}).
			AddRow(int64(7), "codex", "openai", []byte(`{}`), "gpt-5", 1.375))
	apiKeyService := &service.APIKeyService{}
	apiKeyService.SetHamsterConfigSubscriptionDB(db)

	groups, err := NewAPIKeyHandler(apiKeyService).hamsterTemplateGroups(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(groups) != 1 || groups[0].RateMultiplier != 1.375 {
		t.Fatalf("unexpected template groups: %#v", groups)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestHamsterTemplateDefaultPricingUsesGroupMultiplier(t *testing.T) {
	pricing := hamsterTemplateDefaultPricing(0.625)
	if pricing["multiplier"] != 0.625 {
		t.Fatalf("unexpected default pricing: %#v", pricing)
	}
}

func TestHamsterSwitchSubscriptionProviderUsesGroupMultiplier(t *testing.T) {
	group := &service.Group{ID: 8, Name: "priced", Platform: service.PlatformOpenAI, RateMultiplier: 1.375}
	provider := hamsterSwitchSubscriptionProvider(hamsterSwitchLoadedProvider{
		APIKey: &service.APIKey{Key: "sk-subscription"},
		Group:  group,
	}, "codex", []string{"gpt-5"})

	if provider.Pricing["multiplier"] != 1.375 {
		t.Fatalf("subscription provider did not inherit group multiplier: %#v", provider.Pricing)
	}
}

func TestHamsterSwitchServiceErrorDoesNotMisclassifyInternalFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)
	for name, testCase := range map[string]struct {
		err      error
		expected int
	}{
		"validation": {service.ErrHamsterConfigSubscriptionInvalid, http.StatusUnprocessableEntity},
		"changed":    {service.ErrHamsterConfigSubscriptionChanged, http.StatusConflict},
		"disabled":   {service.ErrHamsterConfigSubscriptionDisabled, http.StatusGone},
		"internal":   {errors.New("database unavailable"), http.StatusInternalServerError},
	} {
		t.Run(name, func(t *testing.T) {
			recorder := httptest.NewRecorder()
			context, _ := gin.CreateTestContext(recorder)
			context.Request = httptest.NewRequest(http.MethodGet, "/api/v1/keys/hamster-switch/subscriptions", nil)
			writeHamsterSwitchServiceError(context, testCase.err)
			if recorder.Code != testCase.expected {
				t.Fatalf("got status %d, want %d", recorder.Code, testCase.expected)
			}
		})
	}
}

func TestHamsterSwitchDownloadRejectsLegacyTokenBeforeDatabaseLookup(t *testing.T) {
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodGet, "/api/hamster-switch/subscription.yaml?token=hs_legacy", nil)
	(&APIKeyHandler{}).GetHamsterSwitchSubscription(context)
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("got status %d, want 404", recorder.Code)
	}
}
