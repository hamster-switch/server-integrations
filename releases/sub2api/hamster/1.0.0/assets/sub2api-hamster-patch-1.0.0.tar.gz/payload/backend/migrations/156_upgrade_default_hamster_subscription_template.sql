UPDATE hamster_yaml_template_drafts
SET body = $current_template$format_version: 1
name: {{subscription.name}}
{{#if subscription.description}}
description: {{subscription.description}}
{{/if}}
{{#if subscription.icon}}
icon: {{subscription.icon}}
{{/if}}
{{#if subscription.home_url}}
home_url: {{subscription.home_url}}
{{/if}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    group_name: {{provider.group_name}}
    name: {{provider.name}}
{{#if provider.description}}
    description: {{provider.description}}
{{/if}}
{{#if provider.icon}}
    icon: {{provider.icon}}
{{/if}}
{{#if provider.pricing}}
    pricing: {{provider.pricing}}
{{/if}}
    models: {{provider.models}}
    base_url: {{provider.base_url}}
    default_model: {{provider.default_model}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
$current_template$,
    diagnostics = '[]'::jsonb,
    updated_at = NOW()
WHERE id = 1
  AND body = $legacy_template$format_version: 1
name: {{subscription.name}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    group_name: {{provider.group_name}}
    name: {{provider.name}}
    models: {{provider.models}}
    base_url: {{provider.base_url}}
    default_model: {{provider.default_model}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
$legacy_template$;
