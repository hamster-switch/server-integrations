package migrations

import (
	"regexp"
	"testing"

	"github.com/Wei-Shaw/sub2api/internal/hamsteryaml"
)

func TestDefaultHamsterSubscriptionTemplateMigrationMatchesRuntimeTemplates(t *testing.T) {
	body, err := FS.ReadFile("156_upgrade_default_hamster_subscription_template.sql")
	if err != nil {
		t.Fatal(err)
	}
	extract := func(tag string) string {
		t.Helper()
		pattern := regexp.MustCompile(`(?s)\$` + tag + `\$(.*?)\$` + tag + `\$`)
		match := pattern.FindSubmatch(body)
		if len(match) != 2 {
			t.Fatalf("missing %s dollar-quoted template", tag)
		}
		return string(match[1])
	}

	current := extract("current_template")
	legacy := extract("legacy_template")
	if current != hamsteryaml.DefaultSubscriptionTemplate {
		t.Fatal("migration target template differs from the runtime default")
	}
	if hamsteryaml.UpgradeLegacyDefaultSubscriptionTemplate(legacy) != current {
		t.Fatal("migration legacy template is not recognized by the runtime compatibility path")
	}
}
