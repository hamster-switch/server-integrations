import { flushPromises, mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import SubscriptionManagementView from '../SubscriptionManagementView.vue'

const {
  getTemplateMock,
  getOptionsMock,
  getSettingsMock,
  listMock,
  previewTemplateMock,
  showErrorMock,
  showSuccessMock
} = vi.hoisted(() => ({
  getTemplateMock: vi.fn(),
  getOptionsMock: vi.fn(),
  getSettingsMock: vi.fn(),
  listMock: vi.fn(),
  previewTemplateMock: vi.fn(),
  showErrorMock: vi.fn(),
  showSuccessMock: vi.fn()
}))

vi.mock('@/api/hamsterSwitchSubscriptions', () => ({
  hamsterSwitchSubscriptionsAPI: {
    getTemplate: getTemplateMock,
    getOptions: getOptionsMock,
    getSettings: getSettingsMock,
    list: listMock,
    previewTemplate: previewTemplateMock
  }
}))

vi.mock('@/stores/auth', () => ({
  useAuthStore: () => ({ isAdmin: true })
}))

vi.mock('@/stores/app', () => ({
  useAppStore: () => ({ showError: showErrorMock, showSuccess: showSuccessMock })
}))

vi.mock('@/composables/useClipboard', () => ({
  useClipboard: () => ({ copyToClipboard: vi.fn() })
}))

vi.mock('vue-i18n', async (importOriginal) => {
  const actual = await importOriginal<typeof import('vue-i18n')>()
  return { ...actual, useI18n: () => ({ t: (key: string) => key }) }
})

const templateState = {
  draft: 'format_version: 1',
  presentation: {
    subscription: { name: '' },
    providers: {
      '7': { name: null, icon: '', pricing: null, settings_config: null }
    }
  },
  defaults: {
    name: 'Sub2API',
    description: 'Gateway',
    icon: 'https://example.com/logo.png',
    home_url: 'https://example.com'
  },
  groups: [{
    id: 7,
    name: 'openai_new',
    platform: 'openai',
    app_type: 'codex',
    default_name: 'openai_new',
    default_icon: 'openai',
    default_description: '',
    default_base_url: 'https://example.com/v1',
    default_pricing: { multiplier: 1.375 },
    default_settings_config: {
      auth: { OPENAI_API_KEY: '{{provider.api_key}}' },
      config: 'model_provider = "custom"\nmodel = "gpt-5.5"\n'
    }
  }],
  provider_fields: ['name', 'description', 'icon', 'base_url', 'pricing', 'settings_config'],
  preview: 'format_version: 1',
  diagnostics: [],
  history: []
}

const BaseDialogStub = {
  props: ['show', 'title'],
  template: '<div v-if="show" role="dialog"><slot /><slot name="footer" /></div>'
}

const mountView = () => mount(SubscriptionManagementView, {
  global: {
    stubs: {
      AppLayout: { template: '<div><slot /></div>' },
      TablePageLayout: { template: '<div><slot name="actions" /><slot name="filters" /><slot name="table" /><slot /></div>' },
      DataTable: true,
      Pagination: true,
      BaseDialog: BaseDialogStub,
      ConfirmDialog: true,
      EmptyState: true,
      SearchInput: true,
      GroupBadge: true,
      Icon: true
    }
  }
})

describe('subscription template editor', () => {
  beforeEach(() => {
    getTemplateMock.mockReset()
    getOptionsMock.mockReset()
    getSettingsMock.mockReset()
    listMock.mockReset()
    previewTemplateMock.mockReset()
    showErrorMock.mockReset()
    showSuccessMock.mockReset()

    getTemplateMock.mockResolvedValue(templateState)
    getOptionsMock.mockResolvedValue({ enabled: true, base_url: 'https://example.com', groups: [] })
    getSettingsMock.mockResolvedValue({ hide_api_keys: false })
    listMock.mockResolvedValue({ items: [], total: 0, pages: 0 })
    previewTemplateMock.mockResolvedValue(templateState)
  })

  it('shows icon and pricing controls and fills legacy null or blank values on focus', async () => {
    const wrapper = mountView()
    await flushPromises()
    await wrapper.get('[data-testid="open-template-manager"]').trigger('click')
    await flushPromises()

    const subscriptionName = wrapper.get<HTMLInputElement>('[data-testid="subscription-template-name"]')
    const providerName = wrapper.get<HTMLInputElement>('[data-testid="provider-template-7-name"]')
    const providerIcon = wrapper.get<HTMLInputElement>('[data-testid="provider-template-7-icon"]')
    const pricing = wrapper.get<HTMLInputElement>('[data-testid="provider-template-7-pricing-multiplier"]')

    expect(subscriptionName.element.value).toBe('')
    expect(providerName.element.value).toBe('')
    await subscriptionName.trigger('focus')
    await providerName.trigger('focus')
    await providerIcon.trigger('focus')
    await pricing.trigger('focus')
    await nextTick()

    expect(subscriptionName.element.value).toBe('Sub2API')
    expect(providerName.element.value).toBe('openai_new')
    expect(providerIcon.element.value).toBe('openai')
    expect(pricing.element.value).toBe('1.375')
    wrapper.unmount()
  })

  it('fills settings_config with editable strict JSON', async () => {
    const wrapper = mountView()
    await flushPromises()
    await wrapper.get('[data-testid="open-template-manager"]').trigger('click')
    await flushPromises()

    const settings = wrapper.get<HTMLTextAreaElement>('[data-testid="provider-template-7-settings_config"]')
    expect(settings.element.value).toBe('')
    await settings.trigger('focus')
    await nextTick()

    expect(JSON.parse(settings.element.value)).toEqual(templateState.groups[0].default_settings_config)
    wrapper.unmount()
  })
})
