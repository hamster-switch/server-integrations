import { describe, expect, it } from 'vitest'
import zh from '../locales/zh'
import en from '../locales/en'

const leafKeys = (value: Record<string, unknown>, prefix = ''): string[] => Object.entries(value).flatMap(([key, entry]) => {
  const path = prefix ? `${prefix}.${key}` : key
  return entry && typeof entry === 'object' && !Array.isArray(entry)
    ? leafKeys(entry as Record<string, unknown>, path)
    : [path]
}).sort()

describe('subscription management locale contract', () => {
  it('keeps Chinese and English keys symmetric', () => {
    expect(leafKeys(zh.subscriptionManagement)).toEqual(leafKeys(en.subscriptionManagement))
  })

  it('contains the renamed configuration sections and endpoint help', () => {
    expect(zh.subscriptionManagement.template.subscriptionConfiguration).toBe('订阅配置')
    expect(zh.subscriptionManagement.template.groupConfiguration).toBe('分组配置')
    expect(en.subscriptionManagement.template.subscriptionConfiguration).toBe('Subscription Configuration')
    expect(en.subscriptionManagement.template.groupConfiguration).toBe('Group Configuration')
    expect(en.subscriptionManagement.template.providerDescriptions.base_url).toContain('Endpoint')
  })

  it('localizes the subscription navigation label', () => {
    expect(zh.nav.configSubscriptions).toBe('订阅管理')
    expect(en.nav.configSubscriptions).toBe('Subscription Management')
  })
})
