package service

import (
	"context"
	"errors"
	"regexp"
	"testing"
	"time"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	"github.com/Wei-Shaw/sub2api/internal/config"
)

func expectHamsterSubscriptionInsert(mock sqlmock.Sqlmock) {
	now := time.Now().UTC()
	mock.ExpectQuery(regexp.QuoteMeta("INSERT INTO hamster_config_subscriptions (public_id, user_id, name, status, download_token) VALUES ($1, $2, $3, $4, $5) RETURNING id, created_at, updated_at")).
		WithArgs(sqlmock.AnyArg(), int64(7), "配置订阅", HamsterConfigSubscriptionActive, sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).AddRow(int64(41), now, now))
}

func expectHamsterAPIKeyInsert(mock sqlmock.Sqlmock, keyID int64, group Group, status string) {
	now := time.Now().UTC()
	mock.ExpectQuery("INSERT INTO api_keys").
		WithArgs(int64(7), sqlmock.AnyArg(), sqlmock.AnyArg(), group.ID, status, "null", "null", float64(0), nil, float64(0), float64(0), float64(0)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).AddRow(keyID, now, now))
	mock.ExpectExec("INSERT INTO hamster_config_subscription_providers").
		WithArgs(int64(41), group.ID, keyID, sqlmock.AnyArg(), group.Name, group.Platform).
		WillReturnResult(sqlmock.NewResult(1, 1))
}

func TestCreateHamsterConfigSubscriptionCommitsAllProviders(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	groups := []Group{{ID: 1, Name: "Claude", Platform: "anthropic"}, {ID: 2, Name: "Codex", Platform: "openai"}}
	mock.ExpectBegin()
	expectHamsterSubscriptionInsert(mock)
	expectHamsterAPIKeyInsert(mock, 101, groups[0], StatusAPIKeyActive)
	expectHamsterAPIKeyInsert(mock, 102, groups[1], StatusAPIKeyActive)
	mock.ExpectCommit()
	created, err := service.createHamsterConfigSubscriptionWithGroups(context.Background(), 7, HamsterConfigSubscriptionInput{Name: "配置订阅"}, groups)
	if err != nil {
		t.Fatal(err)
	}
	if len(created.Providers) != 2 || created.DownloadToken[:4] != "hsc_" {
		t.Fatalf("unexpected subscription: %+v", created)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestCreateHamsterConfigSubscriptionRollsBackWhenAnyKeyFails(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	groups := []Group{{ID: 1, Name: "Claude", Platform: "anthropic"}, {ID: 2, Name: "Codex", Platform: "openai"}}
	mock.ExpectBegin()
	expectHamsterSubscriptionInsert(mock)
	expectHamsterAPIKeyInsert(mock, 101, groups[0], StatusAPIKeyActive)
	mock.ExpectQuery("INSERT INTO api_keys").WithArgs(int64(7), sqlmock.AnyArg(), sqlmock.AnyArg(), groups[1].ID, StatusAPIKeyActive, "null", "null", float64(0), nil, float64(0), float64(0), float64(0)).WillReturnError(errors.New("injected key insert failure"))
	mock.ExpectRollback()
	if _, err := service.createHamsterConfigSubscriptionWithGroups(context.Background(), 7, HamsterConfigSubscriptionInput{Name: "配置订阅"}, groups); err == nil {
		t.Fatal("expected create to fail")
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestInsertProviderKeepsDisabledSubscriptionKeyDisabled(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	group := Group{ID: 1, Name: "Claude", Platform: "anthropic"}
	mock.ExpectBegin()
	expectHamsterAPIKeyInsert(mock, 101, group, StatusAPIKeyDisabled)
	mock.ExpectCommit()
	tx, err := db.BeginTx(context.Background(), nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := service.insertHamsterConfigSubscriptionAPIKey(context.Background(), tx, &HamsterConfigSubscription{ID: 41, UserID: 7, PublicID: "public", Status: HamsterConfigSubscriptionDisabled}, group, 0, HamsterConfigSubscriptionInput{}); err != nil {
		t.Fatal(err)
	}
	if err := tx.Commit(); err != nil {
		t.Fatal(err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestGetHamsterConfigSubscriptionDecodesJSONIPRules(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	now := time.Now().UTC()

	mock.ExpectQuery("SELECT id, public_id, user_id, name, status, download_token, created_at, updated_at").
		WithArgs("subscription-id", int64(7)).
		WillReturnRows(sqlmock.NewRows([]string{
			"id", "public_id", "user_id", "name", "status", "download_token", "created_at", "updated_at",
		}).AddRow(int64(41), "subscription-id", int64(7), "Config", HamsterConfigSubscriptionActive, "hsc_token", now, now))
	mock.ExpectQuery("SELECT p.group_id, p.group_name, p.platform, p.position").
		WithArgs(int64(41)).
		WillReturnRows(sqlmock.NewRows([]string{
			"group_id", "group_name", "platform", "position", "id", "user_id", "key", "name", "status",
			"ip_whitelist", "ip_blacklist", "quota", "quota_used", "expires_at", "rate_limit_5h", "rate_limit_1d", "rate_limit_7d",
			"created_at", "updated_at",
		}).AddRow(
			int64(3), "Claude", "anthropic", 0, int64(101), int64(7), "sk-test", "Config - Claude", StatusAPIKeyActive,
			[]byte(`["10.0.0.0/8", "192.168.1.1"]`), []byte(`null`), float64(0), float64(0), nil, float64(0), float64(0), float64(0),
			now, now,
		))

	subscription, err := service.GetHamsterConfigSubscription(context.Background(), 7, "subscription-id")
	if err != nil {
		t.Fatal(err)
	}
	if len(subscription.Providers) != 1 {
		t.Fatalf("unexpected providers: %+v", subscription.Providers)
	}
	key := subscription.Providers[0].APIKey
	if len(key.IPWhitelist) != 2 || key.IPWhitelist[0] != "10.0.0.0/8" || key.IPWhitelist[1] != "192.168.1.1" {
		t.Fatalf("unexpected IP whitelist: %#v", key.IPWhitelist)
	}
	if key.IPBlacklist != nil {
		t.Fatalf("expected nil IP blacklist, got %#v", key.IPBlacklist)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}
