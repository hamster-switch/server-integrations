package hamsteryaml

import (
	"fmt"
	"strings"
)

type SubscriptionPresentation struct {
	Name        *string `json:"name,omitempty"`
	Description *string `json:"description,omitempty"`
	Icon        *string `json:"icon,omitempty"`
	HomeURL     *string `json:"home_url,omitempty"`
}

type ProviderPresentation struct {
	Name            *string         `json:"name,omitempty"`
	Description     *string         `json:"description,omitempty"`
	Icon            *string         `json:"icon,omitempty"`
	WebsiteURL      *string         `json:"website_url,omitempty"`
	Category        *string         `json:"category,omitempty"`
	Notes           *string         `json:"notes,omitempty"`
	Pricing         *map[string]any `json:"pricing,omitempty"`
	Features        *map[string]any `json:"features,omitempty"`
	IconColor       *string         `json:"icon_color,omitempty"`
	SortIndex       *int            `json:"sort_index,omitempty"`
	InFailoverQueue *bool           `json:"in_failover_queue,omitempty"`
}

type TemplatePresentation struct {
	Subscription SubscriptionPresentation        `json:"subscription"`
	Providers    map[string]ProviderPresentation `json:"providers"`
}

func NormalizeTemplatePresentation(value TemplatePresentation) TemplatePresentation {
	if value.Providers == nil {
		value.Providers = map[string]ProviderPresentation{}
	}
	return value
}

func ApplyTemplatePresentation(value TemplatePresentation, options *SubscriptionExportOptions, providers []SubscriptionProviderAccess) {
	value = NormalizeTemplatePresentation(value)
	if options != nil {
		applyOptionalString(value.Subscription.Name, &options.Name)
		applyOptionalString(value.Subscription.Description, &options.Description)
		applyOptionalString(value.Subscription.Icon, &options.Icon)
		applyOptionalString(value.Subscription.HomeURL, &options.HomeURL)
	}
	for index := range providers {
		override, ok := value.Providers[fmt.Sprintf("%d", providers[index].GroupID)]
		if !ok {
			continue
		}
		applyOptionalString(override.Name, &providers[index].Name)
		applyOptionalString(override.Description, &providers[index].Description)
		applyOptionalString(override.Icon, &providers[index].Icon)
		applyOptionalString(override.WebsiteURL, &providers[index].WebsiteURL)
		applyOptionalString(override.Category, &providers[index].Category)
		applyOptionalString(override.Notes, &providers[index].Notes)
		applyOptionalString(override.IconColor, &providers[index].IconColor)
		if override.Pricing != nil {
			providers[index].Pricing = *override.Pricing
		}
		if override.Features != nil {
			providers[index].Features = *override.Features
		}
		if override.SortIndex != nil {
			providers[index].SortIndex = *override.SortIndex
		}
		if override.InFailoverQueue != nil {
			providers[index].InFailoverQueue = *override.InFailoverQueue
		}
	}
}

func applyOptionalString(source *string, target *string) {
	if source != nil {
		*target = strings.TrimSpace(*source)
	}
}

func PlatformIcon(platform string) string {
	switch strings.ToLower(strings.TrimSpace(platform)) {
	case "anthropic":
		return "anthropic"
	case "gemini", "antigravity":
		return "gemini"
	case "grok":
		return "grok"
	case "openai":
		return "openai"
	default:
		return "openai"
	}
}
