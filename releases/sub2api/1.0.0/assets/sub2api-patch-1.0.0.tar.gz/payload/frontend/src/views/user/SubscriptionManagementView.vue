<template>
  <AppLayout>
    <TablePageLayout>
      <template #filters>
        <SearchInput
          v-model="filterSearch"
          :placeholder="ui.searchPlaceholder"
          class="w-full sm:w-72"
          @search="handleSearch"
        />
      </template>

      <template #actions>
        <div class="flex justify-end gap-3">
          <button type="button" class="btn btn-secondary" @click="openTutorial">
            {{ ui.tutorial }}
          </button>
          <button v-if="authStore.isAdmin" type="button" class="btn btn-secondary" @click="openTutorialManager">
            {{ ui.tutorialManagement }}
          </button>
          <button v-if="authStore.isAdmin" type="button" class="btn btn-secondary" @click="openTemplateManager">
            {{ ui.templateManagement }}
          </button>
          <button
            type="button"
            class="btn btn-secondary"
            :disabled="loading"
            :title="ui.refresh"
            @click="loadSubscriptions"
          >
            <Icon name="refresh" size="md" :class="loading ? 'animate-spin' : ''" />
          </button>
          <button type="button" class="btn btn-primary" @click="openCreateModal">
            <Icon name="plus" size="md" class="mr-2" />
            {{ ui.createSubscription }}
          </button>
        </div>
      </template>

      <template #table>
        <DataTable
          :columns="columns"
          :data="subscriptions"
          :loading="loading"
          default-sort-key="created_at"
          default-sort-order="desc"
          row-key="id"
        >
          <template #cell-name="{ row }">
            <div class="flex min-w-0 flex-col">
              <span class="font-medium text-gray-900 dark:text-white">{{ row.name }}</span>
              <span class="mt-0.5 text-xs text-gray-500 dark:text-dark-400">hamster-switch</span>
            </div>
          </template>

          <template #cell-group_names="{ row }">
            <div class="flex max-w-[260px] flex-wrap gap-1.5">
              <span
                v-for="groupName in row.group_names"
                :key="groupName"
                class="rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-700 dark:bg-dark-700 dark:text-dark-200"
              >
                {{ groupName }}
              </span>
            </div>
          </template>

          <template #cell-url="{ row }">
            <div class="flex max-w-[520px] items-center gap-2">
              <code class="code min-w-0 flex-1 truncate text-xs">{{ row.url }}</code>
              <button
                type="button"
                class="rounded-lg p-1 transition-colors hover:bg-gray-100 dark:hover:bg-dark-700"
                :class="copiedSubscriptionId === row.id ? 'text-green-500' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'"
                :title="copiedSubscriptionId === row.id ? ui.copied : ui.copyURL"
                @click="copySubscriptionURL(row)"
              >
                <Icon v-if="copiedSubscriptionId === row.id" name="check" size="sm" :stroke-width="2" />
                <Icon v-else name="clipboard" size="sm" />
              </button>
            </div>
          </template>

          <template #cell-quota="{ row }">
            <span v-if="row.quota > 0" class="text-sm text-gray-700 dark:text-dark-200">
              ${{ numberValue(row.quota_used).toFixed(2) }} / ${{ numberValue(row.quota).toFixed(2) }}
            </span>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.unlimited }}</span>
          </template>

          <template #cell-rate_limit="{ row }">
            <div v-if="hasRateLimit(row)" class="space-y-0.5 text-xs text-gray-600 dark:text-dark-300">
              <div v-if="row.rate_limit_5h > 0">5h: ${{ row.rate_limit_5h.toFixed(2) }}</div>
              <div v-if="row.rate_limit_1d > 0">1d: ${{ row.rate_limit_1d.toFixed(2) }}</div>
              <div v-if="row.rate_limit_7d > 0">7d: ${{ row.rate_limit_7d.toFixed(2) }}</div>
            </div>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.unlimited }}</span>
          </template>

          <template #cell-expires_at="{ value }">
            <span v-if="value" class="text-sm text-gray-500 dark:text-dark-400">
              {{ formatDateTime(value) }}
            </span>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.neverExpires }}</span>
          </template>

          <template #cell-status="{ value }">
            <span :class="['badge', statusClass(value)]">
              {{ statusLabel(value) }}
            </span>
          </template>

          <template #cell-created_at="{ value }">
            <span class="text-sm text-gray-500 dark:text-dark-400">{{ formatDateTime(value) }}</span>
          </template>

          <template #cell-actions="{ row }">
            <div class="flex flex-wrap items-center gap-1">
              <button
                type="button"
                class="btn btn-secondary px-2 py-1 text-xs"
                @click="importIntoHamster(row)"
              >
                {{ ui.importHamster }}
              </button>
              <button
                type="button"
                class="btn btn-secondary px-2 py-1 text-xs"
                @click="openYamlEditor(row)"
              >
                {{ ui.viewYAML }}
              </button>
              <button type="button" class="btn btn-secondary px-2 py-1 text-xs" @click="openEditModal(row)">
                {{ ui.edit }}
              </button>
              <button type="button" class="btn btn-secondary px-2 py-1 text-xs" @click="toggleSubscription(row)">
                {{ row.status === 'disabled' ? ui.enable : ui.disable }}
              </button>
              <button type="button" class="btn btn-danger px-2 py-1 text-xs" @click="requestDelete(row)">
                {{ ui.delete }}
              </button>
            </div>
          </template>

          <template #empty>
            <EmptyState
              :title="ui.emptyTitle"
              :description="ui.emptyDescription"
              :action-text="ui.createSubscription"
              @action="openCreateModal"
            />
          </template>
        </DataTable>
      </template>

      <template #pagination>
        <Pagination
          v-if="pagination.total > 0"
          :page="pagination.page"
          :total="pagination.total"
          :page-size="pagination.page_size"
          @update:page="handlePageChange"
          @update:pageSize="handlePageSizeChange"
        />
      </template>
    </TablePageLayout>

    <BaseDialog :show="showCreateModal" :title="editingSubscriptionId ? ui.editSubscription : ui.createSubscription" width="wide" @close="closeCreateModal">
      <div class="space-y-6">
        <div>
          <label class="input-label">{{ ui.name }}</label>
          <input v-model="form.name" type="text" class="input" placeholder="Hamster Switch" />
        </div>

        <div>
          <div class="mb-2 flex items-center justify-between gap-3">
            <label class="input-label mb-0">{{ ui.groups }}</label>
            <button type="button" class="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400" @click="toggleAllGroups">
              {{ allGroupsSelected ? ui.clearAll : ui.selectAll }}
            </button>
          </div>
          <div class="max-h-60 space-y-2 overflow-y-auto rounded-lg border border-gray-200 p-3 dark:border-dark-600">
            <label
              v-for="group in availableGroups"
              :key="group.id"
              class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-dark-700"
            >
              <input type="checkbox" :checked="form.group_ids.includes(group.id)" @change="toggleGroup(group.id)" />
              <GroupBadge
                :name="group.name"
                :platform="groupPlatform(group.platform)"
                :subscription-type="groupSubscriptionType(group.subscription_type)"
                :rate-multiplier="group.rate_multiplier"
              />
              <span class="text-xs text-gray-500 dark:text-dark-400">
                {{ group.app_type || group.platform }}
              </span>
            </label>
            <div v-if="availableGroups.length === 0" class="py-4 text-center text-sm text-gray-400 dark:text-dark-500">
              {{ ui.noGroups }}
            </div>
          </div>
        </div>

        <div v-if="form.group_ids.length > 0 && !editingSubscriptionId">
          <label class="input-label">{{ ui.customAPIKeys }}</label>
          <div class="space-y-2 rounded-lg border border-gray-200 p-3 dark:border-dark-600">
            <div
              v-for="group in selectedGroups"
              :key="group.id"
              class="grid gap-2 md:grid-cols-[180px_minmax(0,1fr)] md:items-center"
            >
              <div class="text-sm font-medium text-gray-700 dark:text-dark-200">{{ group.name }}</div>
              <input
                v-model="form.custom_api_keys[group.id]"
                type="text"
                class="input"
                :placeholder="ui.autoGeneratePlaceholder"
              />
            </div>
          </div>
          <p class="input-hint">
            {{ ui.customKeyHint }}
          </p>
        </div>

        <div class="space-y-4 rounded-lg border border-gray-200 p-4 dark:border-dark-600">
          <div>
            <label class="input-label mb-0">{{ ui.advancedSettings }}</label>
            <p class="input-hint">{{ ui.advancedHint }}</p>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_ip_restriction" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableIPRestriction }}</span>
          </label>
          <div v-if="form.enable_ip_restriction" class="grid gap-3 md:grid-cols-2">
            <div>
              <label class="input-label">{{ ui.ipWhitelist }}</label>
              <textarea v-model="form.ip_whitelist" class="input min-h-[96px]" :placeholder="ui.ipPlaceholder"></textarea>
            </div>
            <div>
              <label class="input-label">{{ ui.ipBlacklist }}</label>
              <textarea v-model="form.ip_blacklist" class="input min-h-[96px]" :placeholder="ui.ipPlaceholder"></textarea>
            </div>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_quota" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableQuota }}</span>
          </label>
          <div v-if="form.enable_quota">
            <label class="input-label">{{ ui.quotaAmount }}</label>
            <input v-model.number="form.quota" type="number" min="0" step="0.01" class="input" :placeholder="ui.unlimitedPlaceholder" />
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_rate_limit" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableRateLimit }}</span>
          </label>
          <div v-if="form.enable_rate_limit" class="grid gap-3 md:grid-cols-3">
            <div>
              <label class="input-label">{{ ui.limit5h }}</label>
              <input v-model.number="form.rate_limit_5h" type="number" min="0" step="0.01" class="input" />
            </div>
            <div>
              <label class="input-label">{{ ui.limit1d }}</label>
              <input v-model.number="form.rate_limit_1d" type="number" min="0" step="0.01" class="input" />
            </div>
            <div>
              <label class="input-label">{{ ui.limit7d }}</label>
              <input v-model.number="form.rate_limit_7d" type="number" min="0" step="0.01" class="input" />
            </div>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_expiration" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableExpiration }}</span>
          </label>
          <div v-if="form.enable_expiration" class="grid gap-3 md:grid-cols-2">
            <div>
              <label class="input-label">{{ ui.expiryPreset }}</label>
              <select v-model="form.expiration_preset" class="input" @change="applyExpirationPreset">
                <option value="7">{{ ui.days7 }}</option>
                <option value="30">{{ ui.days30 }}</option>
                <option value="90">{{ ui.days90 }}</option>
                <option value="custom">{{ ui.custom }}</option>
              </select>
            </div>
            <div>
              <label class="input-label">{{ ui.expiryDate }}</label>
              <input v-model="form.expiration_date" type="datetime-local" class="input" />
            </div>
          </div>
        </div>
      </div>

      <template #footer>
        <button type="button" class="btn btn-secondary" @click="closeCreateModal">{{ ui.cancel }}</button>
        <button
          type="button"
          class="btn btn-primary"
          :disabled="submitting || form.group_ids.length === 0"
          @click="submitCreate"
        >
          {{ submitting ? ui.saving : (editingSubscriptionId ? ui.save : ui.createSubscription) }}
        </button>
      </template>
    </BaseDialog>

    <BaseDialog :show="showYamlEditor" :title="ui.viewYAML" width="extra-wide" @close="closeYamlEditor">
      <div class="space-y-4">
        <div>
          <label class="input-label">{{ ui.dedicatedKeys }}</label>
          <div class="space-y-1 rounded-lg border border-gray-200 p-3 font-mono text-xs dark:border-dark-600">
            <div v-for="key in editingAPIKeys" :key="key.id" class="flex items-center justify-between gap-2">
              <span>{{ maskApiKey(key.key) }}</span>
              <button type="button" class="text-primary-600" @click="copyDedicatedKey(key.key)">{{ ui.copyKey }}</button>
            </div>
          </div>
        </div>
        <div>
          <label class="input-label">{{ ui.urlAddress }}</label>
          <div class="flex gap-2">
            <input :value="editingYAMLURL" readonly class="input min-w-0 flex-1" />
            <button type="button" class="btn btn-secondary" @click="copyEditingURL">{{ ui.copyURL }}</button>
          </div>
        </div>
        <div>
          <label class="input-label">{{ ui.yamlContent }}</label>
          <textarea v-model="yamlContent" readonly class="input min-h-[420px] font-mono text-xs" spellcheck="false"></textarea>
          <p class="input-hint">{{ ui.yamlHint }}</p>
        </div>
      </div>

      <template #footer>
        <button type="button" class="btn btn-secondary" @click="copyYamlContent">{{ ui.copyYAML }}</button>
        <button type="button" class="btn btn-primary" @click="downloadYamlContent">{{ ui.downloadYAML }}</button>
      </template>
    </BaseDialog>

    <BaseDialog :show="showTutorial" :title="ui.tutorial" width="wide" @close="showTutorial = false">
      <div v-if="tutorialLoading" class="py-10 text-center text-sm text-gray-500">{{ ui.loading }}</div>
      <div v-else class="space-y-5">
        <div v-for="(step, index) in tutorial?.steps || []" :key="step.id" class="rounded-lg border border-gray-200 p-4 dark:border-dark-600">
          <h3 class="font-medium text-gray-900 dark:text-white">{{ index + 1 }}. {{ step.title }}</h3>
          <div class="prose prose-sm mt-3 max-w-none dark:prose-invert" v-html="renderTutorialMarkdown(step.body_md)"></div>
          <div v-if="step.assets?.length" class="mt-4 grid gap-3 sm:grid-cols-2">
            <template v-for="asset in step.assets" :key="asset.id || asset.url">
              <img v-if="tutorialAssetURL(asset.url)" :src="tutorialAssetURL(asset.url)" :alt="step.title" class="max-h-80 w-full rounded-lg border border-gray-200 object-contain dark:border-dark-600" />
            </template>
          </div>
        </div>
      </div>
    </BaseDialog>

    <BaseDialog :show="showTutorialManager" :title="ui.tutorialManagement" width="extra-wide" @close="showTutorialManager = false">
      <div class="grid gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
        <div class="space-y-2">
          <button type="button" class="btn btn-secondary w-full" @click="newTutorialStep">{{ ui.newSiteStep }}</button>
          <button v-for="step in tutorialAdmin?.base.steps || []" :key="step.id" type="button" class="w-full rounded border border-gray-200 p-2 text-left text-sm dark:border-dark-600" @click="editTutorialStep(step.id)">{{ step.title }}</button>
        </div>
        <div class="space-y-3">
          <input v-model="tutorialForm.step_id" class="input" :placeholder="ui.stableStepID" :disabled="tutorialStepExists" />
          <input v-model="tutorialForm.title" class="input" :placeholder="ui.stepTitle" />
          <textarea v-model="tutorialForm.body_md" class="input min-h-[220px] font-mono text-xs" :placeholder="ui.markdownBody"></textarea>
          <div class="grid gap-3 sm:grid-cols-2">
            <input v-model.number="tutorialForm.position" type="number" class="input" :placeholder="ui.position" />
            <input v-model="tutorialExternalURL" class="input" placeholder="https://..." />
          </div>
          <label class="flex items-center gap-2 text-sm"><input v-model="tutorialForm.hidden" type="checkbox" />{{ ui.hideStep }}</label>
          <input type="file" accept="image/png,image/jpeg,image/gif" @change="uploadTutorialImage" />
          <div class="flex gap-2">
            <button type="button" class="btn btn-primary" @click="saveTutorialStep">{{ ui.save }}</button>
            <button v-if="tutorialStepHasOverride" type="button" class="btn btn-danger" @click="removeTutorialStepOverride">{{ ui.removeOverride }}</button>
          </div>
          <div class="border-t border-gray-200 pt-4 dark:border-dark-600">
            <div class="flex gap-2"><button type="button" class="btn btn-secondary" @click="checkTutorialRelease">{{ ui.checkTutorialUpdate }}</button></div>
            <div v-if="tutorialCandidate" class="mt-3 rounded border border-gray-200 p-3 text-sm dark:border-dark-600">
              <p>Release {{ tutorialCandidate.version }}</p>
              <div v-for="conflict in tutorialCandidate.conflicts" :key="conflict.step_id" class="mt-2 flex items-center gap-2">
                <span class="min-w-0 flex-1">{{ conflict.step_id }} · {{ conflict.change }}</span>
                <select v-model="tutorialConflictResolutions[conflict.step_id]" class="input w-44"><option value="">{{ ui.chooseResolution }}</option><option value="keep_site">{{ ui.keepSite }}</option><option value="use_release">{{ ui.useRelease }}</option></select>
              </div>
              <div class="mt-3 flex gap-2"><button type="button" class="btn btn-primary" :disabled="!canAdoptTutorial" @click="adoptTutorialRelease">{{ ui.adoptUpdate }}</button><button type="button" class="btn btn-secondary" @click="rejectTutorialRelease">{{ ui.rejectUpdate }}</button></div>
            </div>
          </div>
        </div>
      </div>
    </BaseDialog>

    <BaseDialog :show="showTemplateManager" :title="ui.templateManagement" width="extra-wide" @close="showTemplateManager = false">
      <div class="space-y-4">
        <textarea v-model="templateDraft" class="input min-h-[420px] font-mono text-xs" spellcheck="false"></textarea>
        <div v-if="templateDiagnostics.length" class="space-y-2">
          <div
            v-for="diagnostic in templateDiagnostics"
            :key="`${diagnostic.code}-${diagnostic.message}`"
            :class="diagnostic.level === 'error' ? 'text-red-600' : 'text-amber-600'"
            class="text-sm"
          >
            {{ diagnostic.code }}: {{ diagnostic.message }}
          </div>
        </div>
        <div v-if="templateHistory.length" class="space-y-2">
          <div v-for="version in templateHistory" :key="version.version" class="flex items-center justify-between rounded border border-gray-200 p-2 text-sm dark:border-dark-600">
            <span>v{{ version.version }} · {{ formatDateTime(version.created_at) }}</span>
            <button v-if="!version.active" type="button" class="btn btn-secondary px-2 py-1 text-xs" @click="rollbackTemplate(version.version)">
              {{ ui.rollback }}
            </button>
          </div>
        </div>
      </div>
      <template #footer>
        <button type="button" class="btn btn-secondary" @click="saveTemplateDraft">{{ ui.saveDraft }}</button>
        <button type="button" class="btn btn-primary" :disabled="templateHasErrors" @click="publishTemplate">{{ ui.publish }}</button>
      </template>
    </BaseDialog>

    <ConfirmDialog
      :show="showDeleteDialog"
      :title="ui.deleteSubscription"
      :message="deleteMessage"
      :confirm-text="ui.delete"
      :cancel-text="ui.cancel"
      :danger="true"
      @confirm="confirmDelete"
      @cancel="cancelDelete"
    />
    <ConfirmDialog
      :show="showPublishWarningsDialog"
      :title="ui.publishWarningsTitle"
      :message="ui.publishWarningsMessage"
      :confirm-text="ui.confirmPublish"
      :cancel-text="ui.cancel"
      @confirm="confirmPublishTemplate"
      @cancel="showPublishWarningsDialog = false"
    />
  </AppLayout>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
import AppLayout from '@/components/layout/AppLayout.vue'
import TablePageLayout from '@/components/layout/TablePageLayout.vue'
import DataTable from '@/components/common/DataTable.vue'
import Pagination from '@/components/common/Pagination.vue'
import BaseDialog from '@/components/common/BaseDialog.vue'
import ConfirmDialog from '@/components/common/ConfirmDialog.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import SearchInput from '@/components/common/SearchInput.vue'
import GroupBadge from '@/components/common/GroupBadge.vue'
import Icon from '@/components/icons/Icon.vue'
import { useClipboard } from '@/composables/useClipboard'
import { getPersistedPageSize } from '@/composables/usePersistedPageSize'
import { useAppStore } from '@/stores/app'
import { useAuthStore } from '@/stores/auth'
import { formatDateTime } from '@/utils/format'
import { maskApiKey } from '@/utils/maskApiKey'
import type { ApiKey, GroupPlatform, SubscriptionType } from '@/types'
import type { Column } from '@/components/common/types'
import {
  hamsterSwitchSubscriptionsAPI,
  type HamsterSwitchGroupOption,
  type ConfigSubscriptionItem,
  type ConfigSubscriptionTutorial,
  type TutorialAdminState,
  type TutorialCandidate,
  type TemplateDiagnostic,
  type YAMLTemplateVersion
} from '@/api/hamsterSwitchSubscriptions'

const appStore = useAppStore()
const authStore = useAuthStore()
const { copyToClipboard } = useClipboard()

const ui = {
  searchPlaceholder: '\u641c\u7d22\u914d\u7f6e\u8ba2\u9605\u3001\u5206\u7ec4\u6216 URL',
  refresh: '\u5237\u65b0',
  createSubscription: '\u521b\u5efa\u914d\u7f6e\u8ba2\u9605',
  editSubscription: '\u7f16\u8f91\u914d\u7f6e\u8ba2\u9605',
  copied: '\u5df2\u590d\u5236',
  copyURL: '\u590d\u5236 URL',
  unlimited: '\u4e0d\u9650\u5236',
  neverExpires: '\u6c38\u4e0d\u8fc7\u671f',
  tutorial: '\u914d\u7f6e\u8ba2\u9605\u6559\u7a0b',
  tutorialManagement: '\u6559\u7a0b\u7ba1\u7406',
  templateManagement: 'YAML \u6a21\u677f\u7ba1\u7406',
  importHamster: '\u5bfc\u5165 Hamster',
  viewYAML: '\u67e5\u770b YAML',
  edit: '\u7f16\u8f91',
  disable: '\u7981\u7528',
  enable: '\u542f\u7528',
  delete: '\u5220\u9664',
  deleteSubscription: '\u5220\u9664\u914d\u7f6e\u8ba2\u9605',
  emptyTitle: '\u6682\u65e0\u914d\u7f6e\u8ba2\u9605',
  emptyDescription: '\u521b\u5efa\u914d\u7f6e\u8ba2\u9605\u540e\uff0c\u53ef\u5728\u8fd9\u91cc\u590d\u5236\u7a33\u5b9a URL \u5e76\u5bfc\u5165 Hamster Switch\u3002',
  name: '\u540d\u79f0',
  groups: '\u5206\u7ec4',
  clearAll: '\u53d6\u6d88\u5168\u9009',
  selectAll: '\u5168\u9009',
  noGroups: '\u6682\u65e0\u53ef\u8ba2\u9605\u7684\u5206\u7ec4',
  customAPIKeys: '\u81ea\u5b9a\u4e49\u5bc6\u94a5',
  autoGeneratePlaceholder: '\u7559\u7a7a\u5219\u81ea\u52a8\u751f\u6210',
  customKeyHint: '\u6bcf\u4e2a\u9009\u4e2d\u5206\u7ec4\u53ef\u914d\u7f6e\u4e00\u4e2a\u72ec\u7acb API \u5bc6\u94a5\uff1b\u7559\u7a7a\u65f6\u6cbf\u7528 API \u5bc6\u94a5\u9875\u9762\u7684\u81ea\u52a8\u751f\u6210\u903b\u8f91\u3002',
  advancedSettings: '\u9ad8\u7ea7\u8bbe\u7f6e',
  advancedHint: 'IP \u9650\u5236\u3001\u989d\u5ea6\u3001\u901f\u7387\u548c\u6709\u6548\u671f\u4f1a\u5e94\u7528\u5230\u672c\u6b21\u8ba2\u9605\u751f\u6210\u7684\u6bcf\u4e2a\u5206\u7ec4\u5bc6\u94a5\u3002',
  enableIPRestriction: '\u542f\u7528 IP \u9650\u5236',
  ipWhitelist: 'IP \u767d\u540d\u5355',
  ipBlacklist: 'IP \u9ed1\u540d\u5355',
  ipPlaceholder: '\u6bcf\u884c\u4e00\u4e2a IP \u6216 CIDR',
  enableQuota: '\u542f\u7528\u989d\u5ea6\u9650\u5236',
  quotaAmount: '\u989d\u5ea6\u91d1\u989d (USD)',
  unlimitedPlaceholder: '0 \u8868\u793a\u4e0d\u9650\u5236',
  enableRateLimit: '\u542f\u7528\u901f\u7387\u9650\u5236',
  limit5h: '5h \u9650\u989d',
  limit1d: '1d \u9650\u989d',
  limit7d: '7d \u9650\u989d',
  enableExpiration: '\u542f\u7528\u5bc6\u94a5\u6709\u6548\u671f',
  expiryPreset: '\u6709\u6548\u671f\u9884\u8bbe',
  expiryDate: '\u6709\u6548\u671f\u65f6\u95f4',
  days7: '7 \u5929',
  days30: '30 \u5929',
  days90: '90 \u5929',
  custom: '\u81ea\u5b9a\u4e49',
  cancel: '\u53d6\u6d88',
  creating: '\u521b\u5efa\u4e2d...',
  saving: '\u4fdd\u5b58\u4e2d...',
  save: '\u4fdd\u5b58',
  urlAddress: 'URL \u5730\u5740',
  yamlContent: 'YAML \u5185\u5bb9',
  yamlHint: '\u6b64\u5904\u663e\u793a\u5f53\u524d\u5df2\u53d1\u5e03\u6a21\u677f\u751f\u6210\u7684\u5b8c\u6574 YAML\u3002',
  dedicatedKeys: '\u8ba2\u9605\u4e13\u7528 API \u5bc6\u94a5',
  copyKey: '\u590d\u5236\u5b8c\u6574\u5bc6\u94a5',
  copyYAML: '\u590d\u5236 YAML',
  downloadYAML: '\u4e0b\u8f7d YAML',
  quota: '\u989d\u5ea6',
  rateLimit: '\u901f\u7387\u9650\u5236',
  expiresAt: '\u6709\u6548\u671f',
  status: '\u72b6\u6001',
  createdAt: '\u521b\u5efa\u65f6\u95f4',
  actions: '\u64cd\u4f5c',
  active: '\u6b63\u5e38',
  quotaExhausted: '\u989d\u5ea6\u8017\u5c3d',
  expired: '\u5df2\u8fc7\u671f',
  inactive: '\u5df2\u7981\u7528',
  loadSubscriptionsFailed: '\u52a0\u8f7d\u8ba2\u9605\u5217\u8868\u5931\u8d25',
  loadGroupsFailed: '\u52a0\u8f7d\u5206\u7ec4\u5931\u8d25',
  selectOneGroup: '\u8bf7\u81f3\u5c11\u9009\u62e9\u4e00\u4e2a\u5206\u7ec4',
  subscriptionCreated: '\u8ba2\u9605\u521b\u5efa\u6210\u529f',
  createFailed: '\u521b\u5efa\u8ba2\u9605\u5931\u8d25',
  urlCopied: 'URL \u5df2\u590d\u5236',
  noAvailableKey: '\u8ba2\u9605\u4e2d\u6ca1\u6709\u53ef\u7528\u7684 API \u5bc6\u94a5',
  loadYAMLFailed: '\u52a0\u8f7d YAML \u5931\u8d25',
  yamlCopied: 'YAML \u5df2\u590d\u5236',
  keyCopied: '\u5b8c\u6574\u5bc6\u94a5\u5df2\u590d\u5236',
  updated: '\u914d\u7f6e\u8ba2\u9605\u5df2\u66f4\u65b0',
  disabled: '\u914d\u7f6e\u8ba2\u9605\u5df2\u7981\u7528',
  enabled: '\u914d\u7f6e\u8ba2\u9605\u5df2\u542f\u7528',
  deleted: '\u914d\u7f6e\u8ba2\u9605\u5df2\u5220\u9664',
  loading: '\u52a0\u8f7d\u4e2d...',
  newSiteStep: '\u65b0\u589e\u7ad9\u70b9\u6b65\u9aa4',
  stableStepID: '\u7a33\u5b9a\u6b65\u9aa4 ID',
  stepTitle: '\u6b65\u9aa4\u6807\u9898',
  markdownBody: 'Markdown \u6b63\u6587',
  position: '\u6392\u5e8f',
  hideStep: '\u9690\u85cf\u8be5\u6b65\u9aa4',
  removeOverride: '\u5220\u9664\u7ad9\u70b9\u8986\u76d6',
  checkTutorialUpdate: '\u68c0\u67e5\u6b63\u5f0f Release',
  chooseResolution: '\u9009\u62e9\u5904\u7406\u65b9\u5f0f',
  keepSite: '\u4fdd\u7559\u7ad9\u70b9\u5185\u5bb9',
  useRelease: '\u4f7f\u7528 Release \u5185\u5bb9',
  adoptUpdate: '\u91c7\u7528\u66f4\u65b0',
  rejectUpdate: '\u62d2\u7edd\u66f4\u65b0',
  saveDraft: '\u4fdd\u5b58\u8349\u7a3f',
  publish: '\u53d1\u5e03',
  rollback: '\u56de\u6eda',
  publishWarningsTitle: '\u786e\u8ba4\u5e26\u8b66\u544a\u53d1\u5e03',
  publishWarningsMessage: '\u6a21\u677f\u5b58\u5728\u975e\u5173\u952e\u8b66\u544a\u3002\u786e\u8ba4\u5df2\u67e5\u770b\u8b66\u544a\u8be6\u60c5\u5e76\u7ee7\u7eed\u53d1\u5e03\u5417\uff1f',
  confirmPublish: '\u786e\u8ba4\u53d1\u5e03'
}

const columns = computed<Column[]>(() => [
  { key: 'name', label: ui.name, sortable: true },
  { key: 'group_names', label: ui.groups, sortable: false },
  { key: 'url', label: ui.urlAddress, sortable: false },
  { key: 'quota', label: ui.quota, sortable: false },
  { key: 'rate_limit', label: ui.rateLimit, sortable: false },
  { key: 'expires_at', label: ui.expiresAt, sortable: true },
  { key: 'status', label: ui.status, sortable: true },
  { key: 'created_at', label: ui.createdAt, sortable: true },
  { key: 'actions', label: ui.actions, sortable: false }
])

const subscriptions = ref<ConfigSubscriptionItem[]>([])
const groupOptions = ref<HamsterSwitchGroupOption[]>([])
const loading = ref(false)
const submitting = ref(false)
const filterSearch = ref('')
const copiedSubscriptionId = ref<string | null>(null)
const showCreateModal = ref(false)
const showYamlEditor = ref(false)
const showTutorial = ref(false)
const showTutorialManager = ref(false)
const showTemplateManager = ref(false)
const showDeleteDialog = ref(false)
const showPublishWarningsDialog = ref(false)
const selectedDeleteSubscription = ref<ConfigSubscriptionItem | null>(null)
const editingSubscriptionId = ref<string | null>(null)
const editingAPIKeys = ref<ApiKey[]>([])
const templateDraft = ref('')
const templateDiagnostics = ref<TemplateDiagnostic[]>([])
const templateHistory = ref<YAMLTemplateVersion[]>([])
const tutorial = ref<ConfigSubscriptionTutorial | null>(null)
const tutorialLoading = ref(false)
const tutorialAdmin = ref<TutorialAdminState | null>(null)
const tutorialCandidate = ref<TutorialCandidate | null>(null)
const tutorialExternalURL = ref('')
const tutorialConflictResolutions = ref<Record<string, '' | 'keep_site' | 'use_release'>>({})
const tutorialForm = ref({ step_id: '', title: '', body_md: '', assets: [] as Array<{ kind: 'site'; id: string }>, optional: false, hidden: false, position: 0 })
const yamlContent = ref('')
const editingYAMLName = ref('')
const editingYAMLURL = ref('')
let abortController: AbortController | null = null

const pagination = ref({
  page: 1,
  page_size: getPersistedPageSize(),
  total: 0,
  pages: 0
})

const form = ref({
  name: '配置订阅',
  group_ids: [] as number[],
  custom_api_keys: {} as Record<number, string>,
  enable_ip_restriction: false,
  ip_whitelist: '',
  ip_blacklist: '',
  enable_quota: false,
  quota: null as number | null,
  enable_rate_limit: false,
  rate_limit_5h: null as number | null,
  rate_limit_1d: null as number | null,
  rate_limit_7d: null as number | null,
  enable_expiration: false,
  expiration_preset: '30' as '7' | '30' | '90' | 'custom',
  expiration_date: ''
})

const availableGroups = computed(() => groupOptions.value.filter((group) => group.available !== false))

const selectedGroups = computed(() => {
  const selected = new Set(form.value.group_ids)
  return availableGroups.value.filter((group) => selected.has(group.id))
})

const allGroupsSelected = computed(() => {
  return availableGroups.value.length > 0 && form.value.group_ids.length === availableGroups.value.length
})

const groupPlatform = (value: string): GroupPlatform => value as GroupPlatform

const groupSubscriptionType = (value: string): SubscriptionType => value as SubscriptionType

const numberValue = (value: number | null | undefined): number => value ?? 0

const hasRateLimit = (row: ConfigSubscriptionItem) => {
  return row.rate_limit_5h > 0 || row.rate_limit_1d > 0 || row.rate_limit_7d > 0
}

const resetForm = () => {
  form.value = {
    name: '配置订阅',
    group_ids: availableGroups.value.map((group) => group.id),
    custom_api_keys: {},
    enable_ip_restriction: false,
    ip_whitelist: '',
    ip_blacklist: '',
    enable_quota: false,
    quota: null,
    enable_rate_limit: false,
    rate_limit_5h: null,
    rate_limit_1d: null,
    rate_limit_7d: null,
    enable_expiration: false,
    expiration_preset: '30',
    expiration_date: formatDateTimeLocal(new Date(Date.now() + 30 * 86400000))
  }
}

const loadOptions = async () => {
  const result = await hamsterSwitchSubscriptionsAPI.getOptions()
  groupOptions.value = result.groups || []
}

const loadSubscriptions = async () => {
  abortController?.abort()
  const controller = new AbortController()
  abortController = controller
  loading.value = true
  try {
    const response = await hamsterSwitchSubscriptionsAPI.list(
      pagination.value.page,
      pagination.value.page_size,
      { search: filterSearch.value || undefined },
      { signal: controller.signal }
    )
    if (controller.signal.aborted) return
    subscriptions.value = response.items
    pagination.value.total = response.total
    pagination.value.pages = response.pages
  } catch (error: any) {
    if (error?.code !== 'ERR_CANCELED') {
      appStore.showError(error?.message || ui.loadSubscriptionsFailed)
    }
  } finally {
    if (abortController === controller) {
      loading.value = false
    }
  }
}

const openCreateModal = async () => {
  if (groupOptions.value.length === 0) {
    try {
      await loadOptions()
    } catch (error: any) {
      appStore.showError(error?.message || ui.loadGroupsFailed)
    }
  }
  editingSubscriptionId.value = null
  resetForm()
  showCreateModal.value = true
}

const closeCreateModal = () => {
  showCreateModal.value = false
  editingSubscriptionId.value = null
}

const openEditModal = (row: ConfigSubscriptionItem) => {
  editingSubscriptionId.value = row.id
  form.value = {
    name: row.name,
    group_ids: row.keys.map((item) => item.group_id),
    custom_api_keys: {},
    enable_ip_restriction: row.ip_whitelist.length > 0 || row.ip_blacklist.length > 0,
    ip_whitelist: row.ip_whitelist.join('\n'),
    ip_blacklist: row.ip_blacklist.join('\n'),
    enable_quota: row.quota > 0,
    quota: row.quota || null,
    enable_rate_limit: hasRateLimit(row),
    rate_limit_5h: row.rate_limit_5h || null,
    rate_limit_1d: row.rate_limit_1d || null,
    rate_limit_7d: row.rate_limit_7d || null,
    enable_expiration: Boolean(row.expires_at),
    expiration_preset: 'custom',
    expiration_date: row.expires_at ? formatDateTimeLocal(new Date(row.expires_at)) : ''
  }
  showCreateModal.value = true
}

const toggleGroup = (groupId: number) => {
  const selected = new Set(form.value.group_ids)
  if (selected.has(groupId)) {
    selected.delete(groupId)
  } else {
    selected.add(groupId)
  }
  form.value.group_ids = [...selected]
}

const toggleAllGroups = () => {
  form.value.group_ids = allGroupsSelected.value ? [] : availableGroups.value.map((group) => group.id)
}

const parseIPList = (value: string): string[] => {
  return value
    .split('\n')
    .map((item) => item.trim())
    .filter(Boolean)
}

const applyExpirationPreset = () => {
  if (form.value.expiration_preset === 'custom') return
  const days = Number(form.value.expiration_preset)
  const date = new Date()
  date.setDate(date.getDate() + days)
  form.value.expiration_date = formatDateTimeLocal(date)
}

const formatDateTimeLocal = (value: Date): string => {
  const pad = (n: number) => n.toString().padStart(2, '0')
  return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}T${pad(value.getHours())}:${pad(value.getMinutes())}`
}

const calculateExpiresInDays = (): number | undefined => {
  if (!form.value.enable_expiration || !form.value.expiration_date) return undefined
  const expiresAt = new Date(form.value.expiration_date)
  const diffDays = Math.ceil((expiresAt.getTime() - Date.now()) / 86400000)
  return diffDays > 0 ? diffDays : 1
}

const buildSubscriptionPayload = () => {
  const customAPIKeys: Record<string, string> = {}
  for (const groupId of form.value.group_ids) {
    const value = String(form.value.custom_api_keys[groupId] || '').trim()
    if (value) customAPIKeys[String(groupId)] = value
  }
  return {
    name: form.value.name,
    group_ids: form.value.group_ids,
    custom_api_keys: Object.keys(customAPIKeys).length > 0 ? customAPIKeys : undefined,
    ip_whitelist: form.value.enable_ip_restriction ? parseIPList(form.value.ip_whitelist) : undefined,
    ip_blacklist: form.value.enable_ip_restriction ? parseIPList(form.value.ip_blacklist) : undefined,
    quota: form.value.enable_quota && form.value.quota && form.value.quota > 0 ? form.value.quota : undefined,
    expires_in_days: calculateExpiresInDays(),
    rate_limit_5h: form.value.enable_rate_limit && form.value.rate_limit_5h && form.value.rate_limit_5h > 0 ? form.value.rate_limit_5h : undefined,
    rate_limit_1d: form.value.enable_rate_limit && form.value.rate_limit_1d && form.value.rate_limit_1d > 0 ? form.value.rate_limit_1d : undefined,
    rate_limit_7d: form.value.enable_rate_limit && form.value.rate_limit_7d && form.value.rate_limit_7d > 0 ? form.value.rate_limit_7d : undefined
  }
}

const submitCreate = async () => {
  if (form.value.group_ids.length === 0) {
    appStore.showError(ui.selectOneGroup)
    return
  }

  submitting.value = true
  try {
    const payload = buildSubscriptionPayload()
    if (editingSubscriptionId.value) {
      await hamsterSwitchSubscriptionsAPI.update(editingSubscriptionId.value, payload)
      appStore.showSuccess(ui.updated)
    } else {
      await hamsterSwitchSubscriptionsAPI.create(payload)
      appStore.showSuccess(ui.subscriptionCreated)
    }
    showCreateModal.value = false
    editingSubscriptionId.value = null
    pagination.value.page = 1
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    submitting.value = false
  }
}

const copySubscriptionURL = async (row: ConfigSubscriptionItem) => {
  const ok = await copyToClipboard(row.url, ui.urlCopied)
  if (ok) {
    copiedSubscriptionId.value = row.id
    setTimeout(() => {
      if (copiedSubscriptionId.value === row.id) {
        copiedSubscriptionId.value = null
      }
    }, 2000)
  }
}

const importIntoHamster = (row: ConfigSubscriptionItem) => {
  const deepLink = `hamster-switch://subscription/import?v=1&url=${encodeURIComponent(row.url)}&name=${encodeURIComponent(row.name)}`
  window.location.href = deepLink
}

const openYamlEditor = async (row: ConfigSubscriptionItem) => {
  try {
    const result = await hamsterSwitchSubscriptionsAPI.getYAML(row.id)
    yamlContent.value = result.yaml
    editingYAMLName.value = result.name || row.name
    editingYAMLURL.value = result.url || row.url
    editingAPIKeys.value = row.api_keys || []
    showYamlEditor.value = true
  } catch (error: any) {
    appStore.showError(error?.message || ui.loadYAMLFailed)
  }
}

const closeYamlEditor = () => {
  showYamlEditor.value = false
  yamlContent.value = ''
  editingYAMLName.value = ''
  editingYAMLURL.value = ''
  editingAPIKeys.value = []
}

const copyEditingURL = async () => {
  await copyToClipboard(editingYAMLURL.value, ui.urlCopied)
}

const copyYamlContent = async () => {
  await copyToClipboard(yamlContent.value, ui.yamlCopied)
}

const copyDedicatedKey = async (key: string) => {
  await copyToClipboard(key, ui.keyCopied)
}

const toggleSubscription = async (row: ConfigSubscriptionItem) => {
  try {
    if (row.status === 'disabled') {
      await hamsterSwitchSubscriptionsAPI.enable(row.id)
      appStore.showSuccess(ui.enabled)
    } else {
      await hamsterSwitchSubscriptionsAPI.disable(row.id)
      appStore.showSuccess(ui.disabled)
    }
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const deleteMessage = computed(() => `确定要删除'${selectedDeleteSubscription.value?.name || ''}'吗？此操作无法撤销。`)

const requestDelete = (row: ConfigSubscriptionItem) => {
  selectedDeleteSubscription.value = row
  showDeleteDialog.value = true
}

const cancelDelete = () => {
  showDeleteDialog.value = false
  selectedDeleteSubscription.value = null
}

const confirmDelete = async () => {
  const selected = selectedDeleteSubscription.value
  if (!selected) return
  try {
    await hamsterSwitchSubscriptionsAPI.delete(selected.id)
    showDeleteDialog.value = false
    selectedDeleteSubscription.value = null
    appStore.showSuccess(ui.deleted)
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const renderTutorialMarkdown = (body: string) => {
  const sanitized = DOMPurify.sanitize(marked.parse(body || '') as string)
  const template = document.createElement('template')
  template.innerHTML = sanitized
  template.content.querySelectorAll('img').forEach((image) => image.remove())
  return template.innerHTML
}

const tutorialAssetURL = (value?: string) => value?.startsWith('/api/hamster-switch/tutorial/images/') ? value : ''

const openTutorial = async () => {
  showTutorial.value = true
  tutorialLoading.value = true
  try {
    tutorial.value = await hamsterSwitchSubscriptionsAPI.getTutorial()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    tutorialLoading.value = false
  }
}

const refreshTutorialAdmin = async () => {
  tutorialAdmin.value = await hamsterSwitchSubscriptionsAPI.getTutorialAdmin()
  tutorialCandidate.value = tutorialAdmin.value.candidate || null
  tutorialConflictResolutions.value = {}
}

const openTutorialManager = async () => {
  try {
    await refreshTutorialAdmin()
    showTutorialManager.value = true
    const first = tutorialAdmin.value?.base.steps[0]
    if (first) editTutorialStep(first.id)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const tutorialStepExists = computed(() => Boolean(
  tutorialAdmin.value?.base.steps.some((step) => step.id === tutorialForm.value.step_id)
))

const tutorialStepHasOverride = computed(() => Boolean(
  tutorialAdmin.value?.overrides.some((step) => step.step_id === tutorialForm.value.step_id)
))

const editTutorialStep = (stepId: string) => {
  const base = tutorialAdmin.value?.base.steps.find((step) => step.id === stepId)
  const override = tutorialAdmin.value?.overrides.find((step) => step.step_id === stepId)
  const source = override || base
  const index = tutorialAdmin.value?.base.steps.findIndex((step) => step.id === stepId) ?? 0
  tutorialForm.value = {
    step_id: stepId,
    title: source?.title || '',
    body_md: source?.body_md || '',
    assets: (source?.assets || []).filter((asset): asset is { kind: 'site'; id: string } => asset.kind === 'site' && Boolean(asset.id)),
    optional: source?.optional || false,
    hidden: override?.hidden || false,
    position: override?.position ?? Math.max(0, index) * 100
  }
  tutorialExternalURL.value = ''
}

const newTutorialStep = () => {
  tutorialForm.value = { step_id: '', title: '', body_md: '', assets: [], optional: false, hidden: false, position: (tutorialAdmin.value?.base.steps.length || 0) * 100 }
  tutorialExternalURL.value = ''
}

const saveTutorialStep = async () => {
  const stepId = tutorialForm.value.step_id.trim()
  if (!stepId) return
  try {
    const assets: Array<{ kind: 'site' | 'external'; id?: string; url?: string }> = [...tutorialForm.value.assets]
    if (tutorialExternalURL.value.trim()) assets.push({ kind: 'external', url: tutorialExternalURL.value.trim() })
    await hamsterSwitchSubscriptionsAPI.saveTutorialOverride(stepId, { ...tutorialForm.value, assets })
    await refreshTutorialAdmin()
    editTutorialStep(stepId)
    appStore.showSuccess(ui.save)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const removeTutorialStepOverride = async () => {
  const stepId = tutorialForm.value.step_id
  try {
    await hamsterSwitchSubscriptionsAPI.deleteTutorialOverride(stepId)
    await refreshTutorialAdmin()
    if (tutorialAdmin.value?.base.steps.some((step) => step.id === stepId)) editTutorialStep(stepId)
    else newTutorialStep()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const uploadTutorialImage = async (event: Event) => {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  try {
    const result = await hamsterSwitchSubscriptionsAPI.uploadTutorialImage(file)
    tutorialForm.value.assets.push({ kind: 'site', id: result.id })
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    input.value = ''
  }
}

const checkTutorialRelease = async () => {
  try {
    tutorialCandidate.value = await hamsterSwitchSubscriptionsAPI.checkTutorialUpdate()
    tutorialConflictResolutions.value = {}
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const canAdoptTutorial = computed(() => Boolean(tutorialCandidate.value) && tutorialCandidate.value!.conflicts.every(
  (conflict) => Boolean(tutorialConflictResolutions.value[conflict.step_id])
))

const adoptTutorialRelease = async () => {
  if (!tutorialCandidate.value || !canAdoptTutorial.value) return
  try {
    await hamsterSwitchSubscriptionsAPI.adoptTutorialUpdate(
      tutorialCandidate.value.version,
      tutorialConflictResolutions.value as Record<string, 'keep_site' | 'use_release'>
    )
    await refreshTutorialAdmin()
    appStore.showSuccess(ui.adoptUpdate)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const rejectTutorialRelease = async () => {
  if (!tutorialCandidate.value) return
  try {
    await hamsterSwitchSubscriptionsAPI.rejectTutorialUpdate(tutorialCandidate.value.version)
    await refreshTutorialAdmin()
    appStore.showSuccess(ui.rejectUpdate)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const templateHasErrors = computed(() => templateDiagnostics.value.some((item) => item.level === 'error'))

const openTemplateManager = async () => {
  try {
    const state = await hamsterSwitchSubscriptionsAPI.getTemplate()
    templateDraft.value = state.draft
    templateDiagnostics.value = state.diagnostics || []
    templateHistory.value = state.history || []
    showTemplateManager.value = true
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const saveTemplateDraft = async () => {
  try {
    const result = await hamsterSwitchSubscriptionsAPI.saveTemplateDraft(templateDraft.value)
    templateDiagnostics.value = result.diagnostics || []
    appStore.showSuccess(ui.saveDraft)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const publishTemplate = async () => {
  try {
    const saved = await hamsterSwitchSubscriptionsAPI.saveTemplateDraft(templateDraft.value)
    templateDiagnostics.value = saved.diagnostics || []
    if (templateHasErrors.value) return
    const hasWarnings = templateDiagnostics.value.some((item) => item.level === 'warning')
    if (hasWarnings) {
      showPublishWarningsDialog.value = true
      return
    }
    await commitTemplatePublish(false)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const commitTemplatePublish = async (acknowledgeWarnings: boolean) => {
  const result = await hamsterSwitchSubscriptionsAPI.publishTemplate(acknowledgeWarnings)
  templateHistory.value = [result.version, ...templateHistory.value.map((item) => ({ ...item, active: false }))]
  showPublishWarningsDialog.value = false
  appStore.showSuccess(ui.publish)
}

const confirmPublishTemplate = async () => {
  try {
    await commitTemplatePublish(true)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const rollbackTemplate = async (version: number) => {
  try {
    await hamsterSwitchSubscriptionsAPI.rollbackTemplate(version)
    await openTemplateManager()
    appStore.showSuccess(ui.rollback)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const downloadYamlContent = () => {
  const blob = new Blob([yamlContent.value], { type: 'application/x-yaml;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  const fileName = `${(editingYAMLName.value || 'hamster-switch').replace(/[\\/:*?"<>|]+/g, '-')}.yaml`
  link.href = url
  link.download = fileName
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

const handleSearch = () => {
  pagination.value.page = 1
  loadSubscriptions()
}

const handlePageChange = (page: number) => {
  pagination.value.page = page
  loadSubscriptions()
}

const handlePageSizeChange = (pageSize: number) => {
  pagination.value.page_size = pageSize
  pagination.value.page = 1
  loadSubscriptions()
}

const statusLabel = (status: string) => {
  if (status === 'active') return ui.active
  if (status === 'quota_exhausted') return ui.quotaExhausted
  if (status === 'expired') return ui.expired
  return ui.inactive
}

const statusClass = (status: string) => {
  if (status === 'active') return 'badge-success'
  if (status === 'quota_exhausted') return 'badge-warning'
  if (status === 'expired') return 'badge-danger'
  return 'badge-gray'
}

onMounted(() => {
  loadSubscriptions()
  loadOptions()
})

onUnmounted(() => {
  abortController?.abort()
})
</script>
