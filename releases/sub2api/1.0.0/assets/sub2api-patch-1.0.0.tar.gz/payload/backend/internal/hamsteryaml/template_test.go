package hamsteryaml

import (
	"strings"
	"testing"
	"time"
)

func TestRenderSubscriptionTemplateUsesClosedContext(t *testing.T) {
	body, diagnostics, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "配置订阅", BaseURL: "https://gateway.example", UpdatedAt: time.Unix(1, 0),
	}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider",
		Models: []string{"gpt-5"}, ClientAPIKey: "sk-client-only", Platform: "openai", GroupID: 1,
	}})
	if err != nil {
		t.Fatal(err)
	}
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			t.Fatalf("unexpected hard diagnostic: %#v", diagnostic)
		}
	}
	if !strings.Contains(string(body), "sk-client-only") {
		t.Fatal("rendered YAML must contain the dedicated client key")
	}
}

func TestValidateSubscriptionTemplateRejectsUnknownToken(t *testing.T) {
	diagnostics := ValidateSubscriptionTemplate(strings.Replace(DefaultSubscriptionTemplate, "{{subscription.name}}", "{{env.SECRET}}", 1))
	for _, diagnostic := range diagnostics {
		if diagnostic.Code == "UNKNOWN_TOKEN" && diagnostic.Level == "error" {
			return
		}
	}
	t.Fatalf("expected unknown-token hard error: %#v", diagnostics)
}

func TestValidateSubscriptionTemplateAllowsWarningsOnlyWithValidYAML(t *testing.T) {
	body := strings.ReplaceAll(DefaultSubscriptionTemplate, "updated_at: {{subscription.updated_at}}\n", "")
	diagnostics := ValidateSubscriptionTemplate(body)
	foundWarning := false
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			t.Fatalf("unexpected hard error: %#v", diagnostic)
		}
		if diagnostic.Code == "MISSING_UPDATED_AT" {
			foundWarning = true
		}
	}
	if !foundWarning {
		t.Fatalf("expected warning: %#v", diagnostics)
	}
}

func TestSubscriptionTemplateSupportsModelsLoopAndSimpleCondition(t *testing.T) {
	template := `format_version: 1
name: {{subscription.name}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    name: {{provider.name}}
    group_name: {{provider.group_name}}
    models:
{{#models}}
      - {{model}}
{{/models}}
    base_url: {{provider.base_url}}
{{#if provider.default_model}}
    default_model: {{provider.default_model}}
{{/if}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
`
	body, diagnostics, err := RenderSubscriptionTemplate(template, SubscriptionExportOptions{Name: "配置订阅", BaseURL: "https://gateway.example"}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider", Models: []string{"gpt-5", "gpt-5-mini"}, ClientAPIKey: "sk-client-only", Platform: "openai", GroupID: 1,
	}})
	if err != nil {
		t.Fatalf("render failed: %v (%#v)", err, diagnostics)
	}
	if !strings.Contains(string(body), "- \"gpt-5\"") || !strings.Contains(string(body), "default_model") {
		t.Fatalf("loop or condition did not render:\n%s", body)
	}
}

func TestValidateSubscriptionTemplateRejectsNestedCondition(t *testing.T) {
	template := strings.Replace(DefaultSubscriptionTemplate, "    name: {{provider.name}}", "{{#if provider.name}}\n{{#if provider.id}}\n    name: {{provider.name}}\n{{/if}}\n{{/if}}", 1)
	for _, diagnostic := range ValidateSubscriptionTemplate(template) {
		if diagnostic.Code == "CONDITION_BLOCK" && diagnostic.Level == "error" {
			return
		}
	}
	t.Fatal("expected nested condition to be a hard error")
}
