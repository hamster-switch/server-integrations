package hamsteryaml

import (
	"encoding/json"
	"reflect"
	"regexp"
	"strings"
	"testing"
	"time"

	"gopkg.in/yaml.v3"
)

func TestRenderSubscriptionTemplateUsesClosedContext(t *testing.T) {
	body, diagnostics, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "配置订阅", BaseURL: "https://gateway.example", UpdatedAt: time.Unix(1, 0),
	}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider",
		Models: []string{"gpt-5"}, ClientAPIKey: "sk-client-only", Platform: "openai", GroupID: 1,
	}})
	if err != nil {
		t.Fatal(err)
	}
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			t.Fatalf("unexpected hard diagnostic: %#v", diagnostic)
		}
	}
	if !strings.Contains(string(body), "sk-client-only") {
		t.Fatal("rendered YAML must contain the dedicated client key")
	}
	if !strings.Contains(string(body), `endpoints: [{"url":"https://gateway.example/v1"}]`) {
		t.Fatalf("rendered endpoint must use the lowercase url field:\n%s", body)
	}
}

func TestSubscriptionTemplateProviderFieldsFollowProviderLoop(t *testing.T) {
	fields := SubscriptionTemplateProviderFields(DefaultSubscriptionTemplate)
	want := []string{"name", "description", "icon", "base_url", "pricing", "settings_config"}
	if !reflect.DeepEqual(fields, want) {
		t.Fatalf("editable fields = %#v, want %#v", fields, want)
	}
}

func TestUpgradeLegacyDefaultSubscriptionTemplatePreservesCustomizedDrafts(t *testing.T) {
	upgraded := UpgradeLegacyDefaultSubscriptionTemplate(legacyDefaultSubscriptionTemplateV1)
	if upgraded != DefaultSubscriptionTemplate {
		t.Fatal("legacy built-in template was not upgraded")
	}
	fields := SubscriptionTemplateProviderFields(upgraded)
	want := []string{"name", "description", "icon", "base_url", "pricing", "settings_config"}
	if !reflect.DeepEqual(fields, want) {
		t.Fatalf("upgraded editable fields = %#v, want %#v", fields, want)
	}

	customized := legacyDefaultSubscriptionTemplateV1 + "# site customization\n"
	if UpgradeLegacyDefaultSubscriptionTemplate(customized) != customized {
		t.Fatal("customized legacy template must not be overwritten")
	}
}

func TestSettingsConfigOverrideRendersStrictJSONAndResolvesAPIKey(t *testing.T) {
	config := "model_provider = \"custom\"\nmodel = \"gpt-5.5\"\npath = \"C:\\\\tmp\"\n\n[model_providers.custom]\nbase_url = \"https://gateway.example/v1\"\n"
	body, diagnostics, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "配置订阅", BaseURL: "https://gateway.example",
	}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider",
		Models: []string{"gpt-5.5"}, ClientAPIKey: "sk-subscription", Platform: "openai", GroupID: 1,
		SettingsConfigExplicit: true, SettingsConfig: map[string]any{
			"auth":   map[string]any{"OPENAI_API_KEY": "{{provider.api_key}}"},
			"config": config,
		},
	}})
	if err != nil {
		t.Fatalf("render failed: %v (%#v)", err, diagnostics)
	}
	match := regexp.MustCompile(`(?m)^    settings_config: (.+)$`).FindSubmatch(body)
	if len(match) != 2 || !json.Valid(match[1]) {
		t.Fatalf("settings_config is not strict inline JSON: %q\n%s", match, body)
	}
	var decoded map[string]any
	if err := json.Unmarshal(match[1], &decoded); err != nil {
		t.Fatal(err)
	}
	auth := decoded["auth"].(map[string]any)
	if auth["OPENAI_API_KEY"] != "sk-subscription" || decoded["config"] != config {
		t.Fatalf("settings_config changed during rendering: %#v", decoded)
	}
}

func TestDefaultCodexSettingsConfigRendersAsStrictJSONObject(t *testing.T) {
	body, diagnostics, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "Configuration subscription", BaseURL: "https://gateway.example",
	}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider",
		Models: []string{"gpt-5.5"}, ClientAPIKey: "sk-subscription", Platform: "openai", GroupID: 1,
		Pricing: map[string]any{"multiplier": 1.0},
	}})
	if err != nil {
		t.Fatalf("render failed: %v (%#v)", err, diagnostics)
	}
	if !strings.Contains(string(body), `pricing: {"multiplier":1}`) {
		t.Fatalf("default group pricing multiplier is missing from rendered YAML:\n%s", body)
	}
	match := regexp.MustCompile(`(?m)^    settings_config: (.+)$`).FindSubmatch(body)
	if len(match) != 2 || len(match[1]) == 0 || match[1][0] != '{' || !json.Valid(match[1]) {
		t.Fatalf("settings_config is not a strict JSON object: %q\n%s", match, body)
	}
	var decoded map[string]any
	if err := json.Unmarshal(match[1], &decoded); err != nil {
		t.Fatal(err)
	}
	config, ok := decoded["config"].(string)
	if !ok || !strings.Contains(config, `model_provider = "custom"`) || !strings.Contains(config, `base_url = "https://gateway.example/v1"`) {
		t.Fatalf("default Codex settings_config was double-encoded or changed: %#v", decoded)
	}
	var yamlDecoded map[string]any
	if err := yaml.Unmarshal(body, &yamlDecoded); err != nil {
		t.Fatal(err)
	}
	providers := yamlDecoded["providers"].([]any)
	if _, ok := providers[0].(map[string]any)["settings_config"].(map[string]any); !ok {
		t.Fatalf("settings_config must remain an object after YAML parsing: %#v", providers[0])
	}
}

func TestSettingsConfigOverrideRejectsUnknownTemplateToken(t *testing.T) {
	_, _, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "配置订阅", BaseURL: "https://gateway.example",
	}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider",
		Models: []string{"gpt-5"}, ClientAPIKey: "sk-subscription",
		SettingsConfigExplicit: true, SettingsConfig: map[string]any{"auth": map[string]any{"OPENAI_API_KEY": "{{env.SECRET}}"}, "config": "model_provider = \"custom\"\nmodel = \"gpt-5\"\n[model_providers.custom]\nbase_url = \"https://gateway.example/v1\""},
	}})
	if err == nil || !strings.Contains(err.Error(), "not allowed") {
		t.Fatalf("expected unknown settings_config token to be rejected, got %v", err)
	}
}

func TestValidateSubscriptionTemplateRejectsUnknownToken(t *testing.T) {
	diagnostics := ValidateSubscriptionTemplate(strings.Replace(DefaultSubscriptionTemplate, "{{subscription.name}}", "{{env.SECRET}}", 1))
	for _, diagnostic := range diagnostics {
		if diagnostic.Code == "UNKNOWN_TOKEN" && diagnostic.Level == "error" {
			return
		}
	}
	t.Fatalf("expected unknown-token hard error: %#v", diagnostics)
}

func TestValidateSubscriptionTemplateAllowsWarningsOnlyWithValidYAML(t *testing.T) {
	body := strings.ReplaceAll(DefaultSubscriptionTemplate, "updated_at: {{subscription.updated_at}}\n", "")
	diagnostics := ValidateSubscriptionTemplate(body)
	foundWarning := false
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			t.Fatalf("unexpected hard error: %#v", diagnostic)
		}
		if diagnostic.Code == "MISSING_UPDATED_AT" {
			foundWarning = true
		}
	}
	if !foundWarning {
		t.Fatalf("expected warning: %#v", diagnostics)
	}
}

func TestSubscriptionTemplateSupportsModelsLoopAndSimpleCondition(t *testing.T) {
	template := `format_version: 1
name: {{subscription.name}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    name: {{provider.name}}
    group_name: {{provider.group_name}}
    models:
{{#models}}
      - {{model}}
{{/models}}
    base_url: {{provider.base_url}}
{{#if provider.default_model}}
    default_model: {{provider.default_model}}
{{/if}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
`
	body, diagnostics, err := RenderSubscriptionTemplate(template, SubscriptionExportOptions{Name: "配置订阅", BaseURL: "https://gateway.example"}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider", Models: []string{"gpt-5", "gpt-5-mini"}, ClientAPIKey: "sk-client-only", Platform: "openai", GroupID: 1,
	}})
	if err != nil {
		t.Fatalf("render failed: %v (%#v)", err, diagnostics)
	}
	if !strings.Contains(string(body), "- \"gpt-5\"") || !strings.Contains(string(body), "default_model") {
		t.Fatalf("loop or condition did not render:\n%s", body)
	}
}

func TestValidateSubscriptionTemplateRejectsNestedCondition(t *testing.T) {
	template := strings.Replace(DefaultSubscriptionTemplate, "    name: {{provider.name}}", "{{#if provider.name}}\n{{#if provider.id}}\n    name: {{provider.name}}\n{{/if}}\n{{/if}}", 1)
	for _, diagnostic := range ValidateSubscriptionTemplate(template) {
		if diagnostic.Code == "CONDITION_BLOCK" && diagnostic.Level == "error" {
			return
		}
	}
	t.Fatal("expected nested condition to be a hard error")
}

func TestDefaultSubscriptionTemplateRendersStructuredFieldsAndKeepsPreviewKeyPlaceholder(t *testing.T) {
	providers := []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "vip", Name: "VIP", Description: "分组说明",
		Icon: "openai", WebsiteURL: "https://example.com/vip", Category: "premium", Notes: "notes",
		Pricing: map[string]any{"input": 1}, Features: map[string]any{"vision": true}, IconColor: "#112233",
		SortIndex: 0, InFailoverQueue: false, Models: []string{"gpt-5"}, ClientAPIKey: "{{provider.api_key}}",
		Platform: "openai", GroupID: 9,
	}}
	body, diagnostics, err := RenderSubscriptionTemplate(DefaultSubscriptionTemplate, SubscriptionExportOptions{
		Name: "站点", Description: "站点说明", Icon: "https://example.com/logo.png",
		HomeURL: "https://example.com", BaseURL: "https://gateway.example", UpdatedAt: time.Unix(1, 0),
	}, providers)
	if err != nil {
		t.Fatalf("render failed: %v (%#v)", err, diagnostics)
	}
	text := string(body)
	for _, expected := range []string{
		`description: "站点说明"`, `icon: "https://example.com/logo.png"`, `home_url: "https://example.com"`,
		`description: "分组说明"`,
		`"OPENAI_API_KEY":"{{provider.api_key}}"`, `endpoints: [{"url":"https://gateway.example/v1"}]`,
	} {
		if !strings.Contains(text, expected) {
			t.Fatalf("rendered template missing %q:\n%s", expected, text)
		}
	}
	for _, removed := range []string{"website_url:", "category:", "notes:", "features:", "icon_color:", "sort_index:", "in_failover_queue:"} {
		if strings.Contains(text, removed) {
			t.Fatalf("default template unexpectedly rendered %q:\n%s", removed, text)
		}
	}
}
