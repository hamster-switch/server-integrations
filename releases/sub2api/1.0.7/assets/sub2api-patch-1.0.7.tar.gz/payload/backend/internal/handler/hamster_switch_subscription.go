package handler

import (
	"errors"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/hamsteryaml"
	"github.com/Wei-Shaw/sub2api/internal/handler/dto"
	"github.com/Wei-Shaw/sub2api/internal/pkg/response"
	middleware2 "github.com/Wei-Shaw/sub2api/internal/server/middleware"
	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/gin-gonic/gin"
)

type createHamsterSwitchSubscriptionRequest struct {
	Name          string            `json:"name"`
	GroupIDs      []int64           `json:"group_ids"`
	CustomAPIKeys map[string]string `json:"custom_api_keys"`
	IPWhitelist   []string          `json:"ip_whitelist"`
	IPBlacklist   []string          `json:"ip_blacklist"`
	Quota         *float64          `json:"quota"`
	ExpiresInDays *int              `json:"expires_in_days"`
	RateLimit5h   *float64          `json:"rate_limit_5h"`
	RateLimit1d   *float64          `json:"rate_limit_1d"`
	RateLimit7d   *float64          `json:"rate_limit_7d"`
}

type hamsterSwitchProviderPreview struct {
	ID           string   `json:"id"`
	AppType      string   `json:"app_type"`
	GroupID      int64    `json:"group_id"`
	GroupName    string   `json:"group_name"`
	Name         string   `json:"name"`
	Platform     string   `json:"platform"`
	Models       []string `json:"models"`
	ModelsCount  int      `json:"models_count"`
	DefaultModel string   `json:"default_model"`
	BaseURL      string   `json:"base_url"`
	Warnings     []string `json:"warnings"`
}

type hamsterSwitchAPIKeyGroup struct {
	APIKeyID  int64  `json:"api_key_id"`
	GroupID   int64  `json:"group_id"`
	GroupName string `json:"group_name"`
}

type hamsterSwitchSubscriptionListItem struct {
	ID          string                         `json:"id"`
	Name        string                         `json:"name"`
	URL         string                         `json:"url"`
	Status      string                         `json:"status"`
	Keys        []hamsterSwitchAPIKeyGroup     `json:"keys"`
	APIKeys     []dto.APIKey                   `json:"api_keys"`
	GroupNames  []string                       `json:"group_names"`
	Providers   []hamsterSwitchProviderPreview `json:"providers"`
	Warnings    []string                       `json:"warnings"`
	IPWhitelist []string                       `json:"ip_whitelist"`
	IPBlacklist []string                       `json:"ip_blacklist"`
	Quota       float64                        `json:"quota"`
	QuotaUsed   float64                        `json:"quota_used"`
	RateLimit5h float64                        `json:"rate_limit_5h"`
	RateLimit1d float64                        `json:"rate_limit_1d"`
	RateLimit7d float64                        `json:"rate_limit_7d"`
	ExpiresAt   *time.Time                     `json:"expires_at"`
	CreatedAt   time.Time                      `json:"created_at"`
	UpdatedAt   time.Time                      `json:"updated_at"`
}

func (h *APIKeyHandler) GetHamsterSwitchSubscriptionOptions(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	groups, err := h.apiKeyService.GetAvailableGroups(c.Request.Context(), subject.UserID)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	items := make([]gin.H, 0, len(groups))
	for i := range groups {
		items = append(items, hamsterSwitchGroupOption(&groups[i]))
	}
	response.Success(c, gin.H{"enabled": true, "base_url": hamsterSwitchBaseURL(c), "groups": items})
}

func (h *APIKeyHandler) PreviewHamsterSwitchSubscription(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req createHamsterSwitchSubscriptionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	groups, err := h.hamsterSwitchSelectedGroups(c, subject.UserID, req.GroupIDs)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	providers, warnings, err := hamsterSwitchPreviewGroups(groups, hamsterSwitchBaseURL(c))
	if err != nil {
		response.Error(c, http.StatusUnprocessableEntity, err.Error())
		return
	}
	response.Success(c, gin.H{"providers": providers, "warnings": warnings})
}

func (h *APIKeyHandler) CreateHamsterSwitchSubscription(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req createHamsterSwitchSubscriptionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	created, err := h.apiKeyService.CreateHamsterConfigSubscription(c.Request.Context(), subject.UserID, hamsterSwitchServiceInput(req))
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	item, err := h.hamsterSwitchSubscriptionItem(c, created)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Created(c, item)
}

func (h *APIKeyHandler) ListHamsterSwitchSubscriptions(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	page, pageSize := response.ParsePagination(c)
	result, err := h.apiKeyService.ListHamsterConfigSubscriptions(c.Request.Context(), subject.UserID, c.Query("search"), page, pageSize)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	items := make([]hamsterSwitchSubscriptionListItem, 0, len(result.Items))
	for i := range result.Items {
		item, err := h.hamsterSwitchSubscriptionItem(c, &result.Items[i])
		if err != nil {
			response.ErrorFrom(c, err)
			return
		}
		items = append(items, *item)
	}
	response.Paginated(c, items, result.Total, page, pageSize)
}

func (h *APIKeyHandler) GetHamsterSwitchSubscriptionDetail(c *gin.Context) {
	subscription, ok := h.ownedHamsterSwitchSubscription(c)
	if !ok {
		return
	}
	item, err := h.hamsterSwitchSubscriptionItem(c, subscription)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, item)
}

func (h *APIKeyHandler) UpdateHamsterSwitchSubscription(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req createHamsterSwitchSubscriptionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	updated, err := h.apiKeyService.UpdateHamsterConfigSubscription(c.Request.Context(), subject.UserID, c.Param("id"), hamsterSwitchServiceInput(req))
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	item, err := h.hamsterSwitchSubscriptionItem(c, updated)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, item)
}

func (h *APIKeyHandler) DisableHamsterSwitchSubscription(c *gin.Context) {
	h.setHamsterSwitchSubscriptionEnabled(c, false)
}

func (h *APIKeyHandler) EnableHamsterSwitchSubscription(c *gin.Context) {
	h.setHamsterSwitchSubscriptionEnabled(c, true)
}

func (h *APIKeyHandler) setHamsterSwitchSubscriptionEnabled(c *gin.Context, enabled bool) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	updated, err := h.apiKeyService.SetHamsterConfigSubscriptionEnabled(c.Request.Context(), subject.UserID, c.Param("id"), enabled)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	item, err := h.hamsterSwitchSubscriptionItem(c, updated)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, item)
}

func (h *APIKeyHandler) DeleteHamsterSwitchSubscription(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	if err := h.apiKeyService.DeleteHamsterConfigSubscription(c.Request.Context(), subject.UserID, c.Param("id")); err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	response.Success(c, gin.H{"message": "configuration subscription deleted successfully"})
}

func (h *APIKeyHandler) GetHamsterSwitchSubscriptionYAML(c *gin.Context) {
	subscription, ok := h.ownedHamsterSwitchSubscription(c)
	if !ok {
		return
	}
	data, diagnostics, err := h.hamsterSwitchSubscriptionYAML(c, subscription)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	item, err := h.hamsterSwitchSubscriptionItem(c, subscription)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"id": subscription.PublicID, "name": subscription.Name, "url": item.URL, "yaml": string(data), "diagnostics": diagnostics})
}

// GetHamsterSwitchSubscription is the public, stable URL download endpoint.
// The token stays in the query string so the normal path-only access log never records it.
func (h *APIKeyHandler) GetHamsterSwitchSubscription(c *gin.Context) {
	token := strings.TrimSpace(c.Query("token"))
	if !strings.HasPrefix(token, "hsc_") {
		response.NotFound(c, "configuration subscription not found")
		return
	}
	subscription, err := h.apiKeyService.GetHamsterConfigSubscriptionByToken(c.Request.Context(), token)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	if subscription.Status == service.HamsterConfigSubscriptionDisabled {
		response.Error(c, http.StatusGone, "configuration subscription is disabled")
		return
	}
	data, _, err := h.hamsterSwitchSubscriptionYAML(c, subscription)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	c.Header("Content-Type", "application/x-yaml; charset=utf-8")
	c.Header("Content-Disposition", `inline; filename="hamster-switch.yaml"`)
	c.Header("Cache-Control", "private, no-store")
	c.String(http.StatusOK, string(data))
}

func (h *APIKeyHandler) GetHamsterSwitchYAMLTemplate(c *gin.Context) {
	state, err := h.getHamsterYAMLTemplateState(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, state)
}

func (h *APIKeyHandler) SaveHamsterSwitchYAMLTemplateDraft(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req struct {
		Body string `json:"body"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	diagnostics, err := h.saveHamsterYAMLTemplateDraft(c.Request.Context(), subject.UserID, req.Body)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"diagnostics": diagnostics})
}

func (h *APIKeyHandler) PublishHamsterSwitchYAMLTemplate(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req struct {
		AcknowledgeWarnings bool `json:"acknowledge_warnings"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	version, diagnostics, err := h.publishHamsterYAMLTemplate(c.Request.Context(), subject.UserID, req.AcknowledgeWarnings)
	if err != nil {
		if errors.Is(err, errHamsterYAMLTemplateUnpublishable) {
			response.Error(c, http.StatusUnprocessableEntity, strings.TrimPrefix(err.Error(), errHamsterYAMLTemplateUnpublishable.Error()+": "))
		} else {
			response.ErrorFrom(c, err)
		}
		return
	}
	response.Success(c, gin.H{"version": version, "diagnostics": diagnostics})
}

func (h *APIKeyHandler) RollbackHamsterSwitchYAMLTemplate(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	target, err := strconv.ParseInt(c.Param("version"), 10, 64)
	if err != nil || target <= 0 {
		response.BadRequest(c, "invalid template version")
		return
	}
	version, err := h.rollbackHamsterYAMLTemplate(c.Request.Context(), subject.UserID, target)
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return
	}
	response.Success(c, version)
}

func (h *APIKeyHandler) ownedHamsterSwitchSubscription(c *gin.Context) (*service.HamsterConfigSubscription, bool) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return nil, false
	}
	item, err := h.apiKeyService.GetHamsterConfigSubscription(c.Request.Context(), subject.UserID, c.Param("id"))
	if err != nil {
		writeHamsterSwitchServiceError(c, err)
		return nil, false
	}
	return item, true
}

func (h *APIKeyHandler) hamsterSwitchSubscriptionItem(c *gin.Context, subscription *service.HamsterConfigSubscription) (*hamsterSwitchSubscriptionListItem, error) {
	entries, apiKeys, err := h.hamsterSwitchSubscriptionEntries(c, subscription)
	if err != nil {
		return nil, err
	}
	providers, warnings, err := hamsterSwitchProviderPreviews(entries, hamsterSwitchBaseURL(c))
	if err != nil {
		warnings = append(warnings, err.Error())
	}
	item := &hamsterSwitchSubscriptionListItem{
		ID: subscription.PublicID, Name: subscription.Name, Status: subscription.Status,
		URL:     hamsterSwitchJoinURLPath(hamsterSwitchBaseURL(c), "/api/hamster-switch/subscription.yaml") + "?token=" + subscription.DownloadToken,
		APIKeys: apiKeys, Providers: providers, Warnings: warnings, CreatedAt: subscription.CreatedAt, UpdatedAt: subscription.UpdatedAt,
	}
	for _, entry := range entries {
		item.Keys = append(item.Keys, hamsterSwitchAPIKeyGroup{APIKeyID: entry.APIKey.ID, GroupID: entry.Group.ID, GroupName: entry.Group.Name})
		item.GroupNames = append(item.GroupNames, entry.Group.Name)
		item.QuotaUsed += entry.APIKey.QuotaUsed
		if subscription.Status == service.HamsterConfigSubscriptionActive {
			if entry.APIKey.IsExpired() {
				item.Status = "expired"
			} else if entry.APIKey.IsQuotaExhausted() && item.Status == service.HamsterConfigSubscriptionActive {
				item.Status = "quota_exhausted"
			}
		}
	}
	if len(entries) > 0 {
		first := entries[0].APIKey
		item.IPWhitelist, item.IPBlacklist = first.IPWhitelist, first.IPBlacklist
		item.Quota, item.RateLimit5h, item.RateLimit1d, item.RateLimit7d = first.Quota, first.RateLimit5h, first.RateLimit1d, first.RateLimit7d
		item.ExpiresAt = first.ExpiresAt
	}
	if subscription.Status == service.HamsterConfigSubscriptionActive {
		for _, entry := range entries {
			if entry.APIKey.IsExpired() {
				item.Status = service.StatusAPIKeyExpired
				break
			}
			if entry.APIKey.IsQuotaExhausted() {
				item.Status = service.StatusAPIKeyQuotaExhausted
				break
			}
			if entry.APIKey.Status != service.StatusAPIKeyActive {
				item.Status = service.HamsterConfigSubscriptionDisabled
				break
			}
		}
	}
	return item, nil
}

type hamsterSwitchLoadedProvider struct {
	APIKey *service.APIKey
	Group  *service.Group
}

func (h *APIKeyHandler) hamsterSwitchSubscriptionEntries(c *gin.Context, subscription *service.HamsterConfigSubscription) ([]hamsterSwitchLoadedProvider, []dto.APIKey, error) {
	entries := make([]hamsterSwitchLoadedProvider, 0, len(subscription.Providers))
	apiKeys := make([]dto.APIKey, 0, len(subscription.Providers))
	for _, provider := range subscription.Providers {
		key, err := h.apiKeyService.GetByID(c.Request.Context(), provider.APIKey.ID)
		if err != nil {
			return nil, nil, err
		}
		if key.UserID != subscription.UserID || key.Group == nil || key.GroupID == nil || *key.GroupID != provider.GroupID {
			return nil, nil, errors.New("configuration subscription provider ownership changed")
		}
		entries = append(entries, hamsterSwitchLoadedProvider{APIKey: key, Group: key.Group})
		apiKeys = append(apiKeys, *dto.APIKeyFromService(key))
	}
	return entries, apiKeys, nil
}

func (h *APIKeyHandler) hamsterSwitchSubscriptionYAML(c *gin.Context, subscription *service.HamsterConfigSubscription) ([]byte, []hamsteryaml.TemplateDiagnostic, error) {
	if subscription.Status == service.HamsterConfigSubscriptionDisabled {
		return nil, nil, service.ErrHamsterConfigSubscriptionDisabled
	}
	entries, _, err := h.hamsterSwitchSubscriptionEntries(c, subscription)
	if err != nil {
		return nil, nil, err
	}
	providers := make([]hamsteryaml.SubscriptionProviderAccess, 0, len(entries))
	for _, entry := range entries {
		if entry.APIKey.Status != service.StatusAPIKeyActive {
			return nil, nil, service.ErrHamsterConfigSubscriptionDisabled
		}
		if entry.APIKey.IsExpired() {
			return nil, nil, service.ErrAPIKeyExpired
		}
		if entry.APIKey.IsQuotaExhausted() {
			return nil, nil, service.ErrAPIKeyQuotaExhausted
		}
		appType, err := hamsterSwitchAppTypeForPlatform(entry.Group.Platform)
		if err != nil {
			return nil, nil, err
		}
		models, err := hamsterSwitchModelsForGroup(entry.Group)
		if err != nil {
			return nil, nil, err
		}
		providers = append(providers, hamsteryaml.SubscriptionProviderAccess{
			ID: hamsterSwitchProviderID(entry.Group.ID, entry.Group.Name, appType), AppType: appType,
			GroupName: entry.Group.Name, Name: fmt.Sprintf("sub2api %s %s", entry.Group.Name, appType),
			Models: models, ClientAPIKey: entry.APIKey.Key, GroupID: entry.Group.ID, Platform: entry.Group.Platform,
		})
	}
	template, err := h.currentHamsterYAMLTemplate(c.Request.Context())
	if err != nil {
		return nil, nil, err
	}
	return hamsteryaml.RenderSubscriptionTemplate(template, hamsteryaml.SubscriptionExportOptions{
		Name: subscription.Name, BaseURL: hamsterSwitchBaseURL(c), UpdatedAt: subscription.UpdatedAt,
	}, providers)
}

func hamsterSwitchServiceInput(req createHamsterSwitchSubscriptionRequest) service.HamsterConfigSubscriptionInput {
	input := service.HamsterConfigSubscriptionInput{
		Name: req.Name, GroupIDs: req.GroupIDs, CustomAPIKeys: req.CustomAPIKeys,
		IPWhitelist: req.IPWhitelist, IPBlacklist: req.IPBlacklist, ExpiresInDays: req.ExpiresInDays,
	}
	if req.Quota != nil {
		input.Quota = *req.Quota
	}
	if req.RateLimit5h != nil {
		input.RateLimit5h = *req.RateLimit5h
	}
	if req.RateLimit1d != nil {
		input.RateLimit1d = *req.RateLimit1d
	}
	if req.RateLimit7d != nil {
		input.RateLimit7d = *req.RateLimit7d
	}
	return input
}

func writeHamsterSwitchServiceError(c *gin.Context, err error) {
	switch {
	case errors.Is(err, service.ErrHamsterConfigSubscriptionNotFound):
		response.NotFound(c, "configuration subscription not found")
	case errors.Is(err, service.ErrHamsterConfigSubscriptionDisabled):
		response.Error(c, http.StatusGone, "configuration subscription is disabled")
	case errors.Is(err, service.ErrAPIKeyExpired):
		response.Error(c, http.StatusForbidden, err.Error())
	case errors.Is(err, service.ErrAPIKeyQuotaExhausted):
		response.Error(c, http.StatusTooManyRequests, err.Error())
	case errors.Is(err, service.ErrAPIKeyExists):
		response.Error(c, http.StatusConflict, err.Error())
	case errors.Is(err, service.ErrHamsterConfigSubscriptionChanged):
		response.Error(c, http.StatusConflict, err.Error())
	case errors.Is(err, service.ErrHamsterConfigSubscriptionInvalid):
		response.Error(c, http.StatusUnprocessableEntity, strings.TrimPrefix(err.Error(), service.ErrHamsterConfigSubscriptionInvalid.Error()+": "))
	default:
		response.ErrorFrom(c, err)
	}
}

func (h *APIKeyHandler) hamsterSwitchSelectedGroups(c *gin.Context, userID int64, groupIDs []int64) ([]service.Group, error) {
	if len(groupIDs) == 0 {
		return nil, fmt.Errorf("%w: at least one group_id is required", service.ErrHamsterConfigSubscriptionInvalid)
	}
	available, err := h.apiKeyService.GetAvailableGroups(c.Request.Context(), userID)
	if err != nil {
		return nil, err
	}
	byID := make(map[int64]service.Group, len(available))
	for _, group := range available {
		byID[group.ID] = group
	}
	seen := map[int64]bool{}
	groups := make([]service.Group, 0, len(groupIDs))
	for _, id := range groupIDs {
		if id <= 0 || seen[id] {
			return nil, fmt.Errorf("%w: group_ids must be positive and unique", service.ErrHamsterConfigSubscriptionInvalid)
		}
		group, ok := byID[id]
		if !ok {
			return nil, fmt.Errorf("%w: group %d is not available for this user", service.ErrHamsterConfigSubscriptionInvalid, id)
		}
		seen[id] = true
		groups = append(groups, group)
	}
	return groups, nil
}

func hamsterSwitchGroupOption(group *service.Group) gin.H {
	appType, appErr := hamsterSwitchAppTypeForPlatform(group.Platform)
	models, modelErr := hamsterSwitchModelsForGroup(group)
	warnings := hamsterSwitchPlatformWarnings(group.Platform, appType)
	if appErr != nil {
		warnings = append(warnings, appErr.Error())
	}
	if modelErr != nil {
		warnings = append(warnings, modelErr.Error())
	}
	defaultModel := ""
	if len(models) > 0 {
		defaultModel = models[0]
	}
	return gin.H{"id": group.ID, "name": group.Name, "platform": group.Platform, "app_type": appType,
		"models_count": len(models), "default_model": defaultModel, "available": appErr == nil && modelErr == nil,
		"warnings": warnings, "subscription_type": group.SubscriptionType, "rate_multiplier": group.RateMultiplier}
}

func hamsterSwitchPreviewGroups(groups []service.Group, baseURL string) ([]hamsterSwitchProviderPreview, []string, error) {
	entries := make([]hamsterSwitchLoadedProvider, 0, len(groups))
	for i := range groups {
		entries = append(entries, hamsterSwitchLoadedProvider{Group: &groups[i]})
	}
	return hamsterSwitchProviderPreviews(entries, baseURL)
}

func hamsterSwitchProviderPreviews(entries []hamsterSwitchLoadedProvider, baseURL string) ([]hamsterSwitchProviderPreview, []string, error) {
	if strings.TrimSpace(baseURL) == "" {
		return nil, nil, errors.New("HAMSTER_SWITCH_BASE_URL or request host is required")
	}
	var providers []hamsterSwitchProviderPreview
	var warnings []string
	for _, entry := range entries {
		group := entry.Group
		appType, err := hamsterSwitchAppTypeForPlatform(group.Platform)
		if err != nil {
			return nil, warnings, err
		}
		models, err := hamsterSwitchModelsForGroup(group)
		if err != nil {
			return nil, warnings, err
		}
		providerWarnings := hamsterSwitchPlatformWarnings(group.Platform, appType)
		warnings = append(warnings, providerWarnings...)
		providers = append(providers, hamsterSwitchProviderPreview{
			ID: hamsterSwitchProviderID(group.ID, group.Name, appType), AppType: appType,
			GroupID: group.ID, GroupName: group.Name, Name: fmt.Sprintf("sub2api %s %s", group.Name, appType),
			Platform: group.Platform, Models: models, ModelsCount: len(models), DefaultModel: models[0],
			BaseURL: hamsterSwitchJoinURLPath(baseURL, hamsterSwitchAPIPath(appType)), Warnings: providerWarnings,
		})
	}
	if len(providers) == 0 {
		return nil, warnings, errors.New("at least one Hamster Switch provider is required")
	}
	return providers, warnings, nil
}

func hamsterSwitchAppTypeForPlatform(platform string) (string, error) {
	switch strings.TrimSpace(platform) {
	case service.PlatformAnthropic:
		return "claude", nil
	case service.PlatformOpenAI, service.PlatformGrok:
		return "codex", nil
	case service.PlatformGemini, service.PlatformAntigravity:
		return "gemini", nil
	default:
		return "", fmt.Errorf("group platform %q is not supported by Hamster Switch", platform)
	}
}

func hamsterSwitchModelsForGroup(group *service.Group) ([]string, error) {
	if group == nil {
		return nil, errors.New("group is required")
	}
	if len(group.ModelsListConfig.Models) > 0 {
		return group.ModelsListConfig.Models, nil
	}
	if model := strings.TrimSpace(group.DefaultMappedModel); model != "" {
		return []string{model}, nil
	}
	return nil, fmt.Errorf("group %q must configure models_list_config.models or default_mapped_model for Hamster Switch", group.Name)
}

func hamsterSwitchPlatformWarnings(platform, appType string) []string {
	switch strings.TrimSpace(platform) {
	case service.PlatformGrok:
		if appType == "codex" {
			return []string{"grok platform is exported as Codex; verify OpenAI Responses compatibility before production use"}
		}
	case service.PlatformAntigravity:
		if appType == "gemini" {
			return []string{"antigravity platform is exported as Gemini; verify request semantics before production use"}
		}
	}
	return []string{}
}

func hamsterSwitchAPIPath(appType string) string {
	if appType == "gemini" {
		return "/v1beta"
	}
	return "/v1"
}

func hamsterSwitchBaseURL(c *gin.Context) string {
	if configured := hamsterSwitchNormalizeBaseURL(os.Getenv("HAMSTER_SWITCH_BASE_URL")); configured != "" {
		return configured
	}
	proto := hamsterSwitchFirstHeaderValue(c.GetHeader("X-Forwarded-Proto"))
	if proto == "" {
		if c.Request != nil && c.Request.TLS != nil {
			proto = "https"
		} else {
			proto = "http"
		}
	}
	host := hamsterSwitchFirstHeaderValue(c.GetHeader("X-Forwarded-Host"))
	if host == "" && c.Request != nil {
		host = c.Request.Host
	}
	if host == "" {
		return ""
	}
	return hamsterSwitchNormalizeBaseURL(proto + "://" + host)
}

func hamsterSwitchNormalizeBaseURL(value string) string {
	baseURL := strings.TrimRight(strings.TrimSpace(value), "/")
	lower := strings.ToLower(baseURL)
	for _, suffix := range []string{"/api/v1", "/v1beta", "/v1"} {
		if strings.HasSuffix(lower, suffix) {
			return strings.TrimRight(baseURL[:len(baseURL)-len(suffix)], "/")
		}
	}
	return baseURL
}

func hamsterSwitchFirstHeaderValue(value string) string {
	if comma := strings.Index(value, ","); comma >= 0 {
		value = value[:comma]
	}
	return strings.TrimSpace(value)
}

func hamsterSwitchJoinURLPath(baseURL, path string) string {
	return strings.TrimRight(strings.TrimSpace(baseURL), "/") + "/" + strings.TrimLeft(strings.TrimSpace(path), "/")
}

func hamsterSwitchProviderID(groupID int64, groupName, appType string) string {
	return fmt.Sprintf("sub2api-%s-%d-%s", hamsterSwitchIDPart(groupName), groupID, appType)
}

func hamsterSwitchIDPart(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	var builder strings.Builder
	lastDash := false
	for _, char := range value {
		if (char >= 'a' && char <= 'z') || (char >= '0' && char <= '9') {
			builder.WriteRune(char)
			lastDash = false
			continue
		}
		if !lastDash {
			builder.WriteByte('-')
			lastDash = true
		}
	}
	cleaned := strings.Trim(builder.String(), "-")
	if cleaned == "" {
		return "group"
	}
	return cleaned
}
