package hamsteryaml

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

const DefaultSubscriptionTemplate = `format_version: 1
name: {{subscription.name}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    group_name: {{provider.group_name}}
    name: {{provider.name}}
    models: {{provider.models}}
    base_url: {{provider.base_url}}
    default_model: {{provider.default_model}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
`

type TemplateDiagnostic struct {
	Level   string `json:"level"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

var hamsterTemplateToken = regexp.MustCompile(`\{\{\s*([^{}]+?)\s*\}\}`)
var hamsterTemplateIfBlock = regexp.MustCompile(`(?s)\{\{#if\s+([a-z0-9_.]+)\}\}(.*?)\{\{/if\}\}`)
var hamsterTemplateModelsBlock = regexp.MustCompile(`(?s)\{\{#models\}\}(.*?)\{\{/models\}\}`)

var hamsterTemplateVariables = map[string]bool{
	"subscription.name":        true,
	"subscription.updated_at":  true,
	"provider.id":              true,
	"provider.app_type":        true,
	"provider.group_name":      true,
	"provider.name":            true,
	"provider.models":          true,
	"provider.base_url":        true,
	"provider.default_model":   true,
	"provider.settings_config": true,
	"provider.endpoints":       true,
	"provider.meta":            true,
}

func ValidateSubscriptionTemplate(body string) []TemplateDiagnostic {
	body = strings.TrimSpace(body)
	var diagnostics []TemplateDiagnostic
	addHard := func(code, message string) {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "error", Code: code, Message: message})
	}
	if body == "" {
		return []TemplateDiagnostic{{Level: "error", Code: "EMPTY_TEMPLATE", Message: "template body is empty"}}
	}
	if len(body) > 256<<10 {
		addHard("TEMPLATE_TOO_LARGE", "template body exceeds 256 KiB")
	}
	if strings.Count(body, "{{#providers}}") != 1 || strings.Count(body, "{{/providers}}") != 1 {
		addHard("PROVIDER_LOOP", "template must contain exactly one closed providers loop")
	}
	start := strings.Index(body, "{{#providers}}")
	end := strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		addHard("PROVIDER_LOOP_ORDER", "providers loop is not properly closed")
	}
	if strings.Count(body, "{{#if ") != strings.Count(body, "{{/if}}") || len(hamsterTemplateIfBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#if ") {
		addHard("CONDITION_BLOCK", "simple conditions must be closed and cannot be nested")
	}
	if strings.Count(body, "{{#models}}") != strings.Count(body, "{{/models}}") || len(hamsterTemplateModelsBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#models}}") {
		addHard("MODELS_LOOP", "models loops must be closed and cannot be nested")
	}
	for _, match := range hamsterTemplateIfBlock.FindAllStringSubmatch(body, -1) {
		if !hamsterTemplateVariables[match[1]] {
			addHard("INVALID_CONDITION", fmt.Sprintf("condition variable %q is not allowed", match[1]))
		}
	}
	if start >= 0 && end > start {
		outside := body[:start] + body[end+len("{{/providers}}"):]
		if strings.Contains(outside, "{{#models}}") || strings.Contains(outside, "{{/models}}") {
			addHard("MODELS_LOOP_SCOPE", "models loops are allowed only inside the providers loop")
		}
	}
	for _, match := range hamsterTemplateToken.FindAllStringSubmatch(body, -1) {
		token := strings.TrimSpace(match[1])
		if token == "#providers" || token == "/providers" || token == "#models" || token == "/models" || token == "model" || token == "/if" || strings.HasPrefix(token, "#if ") || hamsterTemplateVariables[token] {
			continue
		}
		addHard("UNKNOWN_TOKEN", fmt.Sprintf("template token %q is not allowed", token))
	}
	for _, required := range []string{
		"subscription.name", "provider.id", "provider.app_type", "provider.models",
		"provider.settings_config", "provider.base_url",
	} {
		if required == "provider.models" && strings.Contains(body, "{{#models}}") {
			continue
		}
		if !strings.Contains(body, "{{"+required+"}}") {
			addHard("MISSING_REQUIRED_TOKEN", fmt.Sprintf("required token %q is missing", required))
		}
	}
	if !strings.Contains(body, "{{subscription.updated_at}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_UPDATED_AT", Message: "template does not expose the subscription update time"})
	}
	if !strings.Contains(body, "{{provider.meta}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_PROVIDER_META", Message: "template omits provider metadata and capability warnings"})
	}
	if hasTemplateErrors(diagnostics) {
		return diagnostics
	}
	sample := subscriptionExport{
		FormatVersion: 1,
		Name:          "template validation",
		UpdatedAt:     time.Unix(0, 0).UTC().Format(time.RFC3339),
		Providers: []providerExport{{
			ID: "sample", AppType: "codex", GroupName: "default", Name: "sample",
			Models: []string{"sample-model"}, BaseURL: "https://example.invalid/v1", DefaultModel: "sample-model",
			SettingsConfig: map[string]any{"auth": map[string]string{"OPENAI_API_KEY": "sk-template-validation"}},
			Endpoints:      []endpointExport{{URL: "https://example.invalid/v1"}}, Meta: map[string]any{"gateway_type": "sub2api"},
		}},
	}
	rendered, err := renderSubscriptionTemplate(body, sample)
	if err != nil {
		addHard("RENDER_FAILED", err.Error())
		return diagnostics
	}
	var decoded map[string]any
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		addHard("INVALID_YAML", fmt.Sprintf("rendered template is not valid YAML: %v", err))
		return diagnostics
	}
	if decoded["format_version"] != 1 {
		addHard("FORMAT_VERSION", "rendered YAML must contain format_version: 1")
	}
	providers, ok := decoded["providers"].([]any)
	if !ok || len(providers) != 1 {
		addHard("PROVIDERS_SHAPE", "rendered YAML must contain one provider for each loop item")
	}
	return diagnostics
}

func RenderSubscriptionTemplate(body string, options SubscriptionExportOptions, providers []SubscriptionProviderAccess) ([]byte, []TemplateDiagnostic, error) {
	diagnostics := ValidateSubscriptionTemplate(body)
	if hasTemplateErrors(diagnostics) {
		return nil, diagnostics, errors.New("configuration template contains hard errors")
	}
	baseURL := strings.TrimRight(strings.TrimSpace(options.BaseURL), "/")
	if baseURL == "" {
		return nil, diagnostics, errors.New("HAMSTER_SWITCH_BASE_URL or request host is required")
	}
	name := strings.TrimSpace(options.Name)
	if name == "" {
		name = "sub2api 配置订阅"
	}
	sub := subscriptionExport{FormatVersion: 1, Name: name, Providers: []providerExport{}}
	if !options.UpdatedAt.IsZero() {
		sub.UpdatedAt = options.UpdatedAt.UTC().Format(time.RFC3339)
	}
	for index, provider := range providers {
		exported, err := exportSubscriptionProvider(provider, index, baseURL)
		if err != nil {
			return nil, diagnostics, err
		}
		sub.Providers = append(sub.Providers, exported)
	}
	if len(sub.Providers) == 0 {
		return nil, diagnostics, errors.New("at least one Hamster Switch provider is required")
	}
	rendered, err := renderSubscriptionTemplate(body, sub)
	if err != nil {
		return nil, diagnostics, err
	}
	var decoded subscription
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		return nil, diagnostics, fmt.Errorf("render configuration subscription template: %w", err)
	}
	if _, err := convertSubscription(decoded); err != nil {
		return nil, diagnostics, fmt.Errorf("validate rendered configuration subscription: %w", err)
	}
	return rendered, diagnostics, nil
}

func renderSubscriptionTemplate(body string, sub subscriptionExport) ([]byte, error) {
	start := strings.Index(body, "{{#providers}}")
	end := strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		return nil, errors.New("providers loop is not properly closed")
	}
	loopStart := start + len("{{#providers}}")
	loop := body[loopStart:end]
	var renderedLoop strings.Builder
	for _, provider := range sub.Providers {
		values := map[string]any{
			"provider.id": provider.ID, "provider.app_type": provider.AppType,
			"provider.group_name": provider.GroupName, "provider.name": provider.Name,
			"provider.models": provider.Models, "provider.base_url": provider.BaseURL,
			"provider.default_model": provider.DefaultModel, "provider.settings_config": provider.SettingsConfig,
			"provider.endpoints": provider.Endpoints, "provider.meta": provider.Meta,
		}
		part, err := renderHamsterTemplateIfBlocks(loop, values)
		if err == nil {
			part, err = renderHamsterTemplateModelsBlocks(part, provider.Models, values)
		}
		if err == nil {
			part, err = replaceHamsterTemplateVariables(part, values)
		}
		if err != nil {
			return nil, err
		}
		renderedLoop.WriteString(part)
	}
	combined := body[:start] + renderedLoop.String() + body[end+len("{{/providers}}"):]
	subscriptionValues := map[string]any{"subscription.name": sub.Name, "subscription.updated_at": sub.UpdatedAt}
	combined, err := renderHamsterTemplateIfBlocks(combined, subscriptionValues)
	if err != nil {
		return nil, err
	}
	return bytesFromTemplateResult(replaceHamsterTemplateVariables(combined, subscriptionValues))
}

func renderHamsterTemplateModelsBlocks(body string, models []string, providerValues map[string]any) (string, error) {
	var renderErr error
	result := hamsterTemplateModelsBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := hamsterTemplateModelsBlock.FindStringSubmatch(block)
		if len(match) != 2 {
			renderErr = errors.New("models loop is invalid")
			return block
		}
		var rendered strings.Builder
		for _, model := range models {
			values := make(map[string]any, len(providerValues)+1)
			for key, value := range providerValues {
				values[key] = value
			}
			values["model"] = model
			part, err := replaceHamsterTemplateVariables(match[1], values)
			if err != nil {
				renderErr = err
				return block
			}
			rendered.WriteString(part)
		}
		return rendered.String()
	})
	return result, renderErr
}

func renderHamsterTemplateIfBlocks(body string, values map[string]any) (string, error) {
	var renderErr error
	result := hamsterTemplateIfBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := hamsterTemplateIfBlock.FindStringSubmatch(block)
		if len(match) != 3 {
			renderErr = errors.New("condition block is invalid")
			return block
		}
		value, ok := values[match[1]]
		if !ok {
			renderErr = fmt.Errorf("condition variable %q is not available in this context", match[1])
			return block
		}
		if hamsterTemplateTruthy(value) {
			return match[2]
		}
		return ""
	})
	return result, renderErr
}

func hamsterTemplateTruthy(value any) bool {
	switch typed := value.(type) {
	case nil:
		return false
	case bool:
		return typed
	case string:
		return strings.TrimSpace(typed) != ""
	case []string:
		return len(typed) > 0
	case []endpointExport:
		return len(typed) > 0
	case map[string]any:
		return len(typed) > 0
	default:
		return true
	}
}

func replaceHamsterTemplateVariables(body string, values map[string]any) (string, error) {
	var replaceErr error
	result := hamsterTemplateToken.ReplaceAllStringFunc(body, func(match string) string {
		parts := hamsterTemplateToken.FindStringSubmatch(match)
		token := strings.TrimSpace(parts[1])
		if strings.HasPrefix(token, "#") || strings.HasPrefix(token, "/") {
			replaceErr = fmt.Errorf("unexpected template directive %q", token)
			return match
		}
		value, ok := values[token]
		if !ok {
			replaceErr = fmt.Errorf("template token %q is not available in this context", token)
			return match
		}
		encoded, err := json.Marshal(value)
		if err != nil {
			replaceErr = err
			return match
		}
		return string(encoded)
	})
	return result, replaceErr
}

func bytesFromTemplateResult(value string, err error) ([]byte, error) {
	if err != nil {
		return nil, err
	}
	return []byte(value), nil
}

func hasTemplateErrors(diagnostics []TemplateDiagnostic) bool {
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			return true
		}
	}
	return false
}
