package handler

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/hamsteryaml"
)

type hamsterYAMLTemplateVersion struct {
	Version            int64                            `json:"version"`
	Body               string                           `json:"body"`
	Warnings           []hamsteryaml.TemplateDiagnostic `json:"warnings"`
	WarningConfirmedBy *int64                           `json:"warning_confirmed_by,omitempty"`
	WarningConfirmedAt *time.Time                       `json:"warning_confirmed_at,omitempty"`
	CreatedBy          *int64                           `json:"created_by,omitempty"`
	CreatedAt          time.Time                        `json:"created_at"`
	Active             bool                             `json:"active"`
}

type hamsterYAMLTemplateState struct {
	Draft       string                           `json:"draft"`
	Diagnostics []hamsteryaml.TemplateDiagnostic `json:"diagnostics"`
	Current     *hamsterYAMLTemplateVersion      `json:"current,omitempty"`
	History     []hamsterYAMLTemplateVersion     `json:"history"`
}

var errHamsterYAMLTemplateUnpublishable = errors.New("YAML template cannot be published")

func (h *APIKeyHandler) hamsterContentDB() (*sql.DB, error) {
	db := h.apiKeyService.HamsterConfigSubscriptionDB()
	if db == nil {
		return nil, errors.New("configuration subscription database is unavailable")
	}
	return db, nil
}

func (h *APIKeyHandler) currentHamsterYAMLTemplate(ctx context.Context) (string, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return "", err
	}
	var body string
	err = db.QueryRowContext(ctx, `SELECT body FROM hamster_yaml_template_versions WHERE active ORDER BY version DESC LIMIT 1`).Scan(&body)
	if errors.Is(err, sql.ErrNoRows) {
		return hamsteryaml.DefaultSubscriptionTemplate, nil
	}
	return body, err
}

func (h *APIKeyHandler) getHamsterYAMLTemplateState(ctx context.Context) (*hamsterYAMLTemplateState, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	state := &hamsterYAMLTemplateState{Draft: hamsteryaml.DefaultSubscriptionTemplate, History: []hamsterYAMLTemplateVersion{}}
	var diagnosticsJSON []byte
	err = db.QueryRowContext(ctx, `SELECT body, diagnostics FROM hamster_yaml_template_drafts WHERE id = 1`).Scan(&state.Draft, &diagnosticsJSON)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return nil, err
	}
	if len(diagnosticsJSON) > 0 {
		_ = json.Unmarshal(diagnosticsJSON, &state.Diagnostics)
	} else {
		state.Diagnostics = hamsteryaml.ValidateSubscriptionTemplate(state.Draft)
	}
	rows, err := db.QueryContext(ctx, `
		SELECT version, body, warnings, warning_confirmed_by, warning_confirmed_at, created_by, created_at, active
		FROM hamster_yaml_template_versions ORDER BY version DESC LIMIT 50`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var version hamsterYAMLTemplateVersion
		var warningsJSON []byte
		if err := rows.Scan(&version.Version, &version.Body, &warningsJSON, &version.WarningConfirmedBy,
			&version.WarningConfirmedAt, &version.CreatedBy, &version.CreatedAt, &version.Active); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(warningsJSON, &version.Warnings)
		state.History = append(state.History, version)
		if version.Active {
			copy := version
			state.Current = &copy
		}
	}
	return state, rows.Err()
}

func (h *APIKeyHandler) saveHamsterYAMLTemplateDraft(ctx context.Context, adminID int64, body string) ([]hamsteryaml.TemplateDiagnostic, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	diagnostics := hamsteryaml.ValidateSubscriptionTemplate(body)
	encoded, err := json.Marshal(diagnostics)
	if err != nil {
		return nil, err
	}
	_, err = db.ExecContext(ctx, `
		INSERT INTO hamster_yaml_template_drafts (id, body, diagnostics, updated_by, updated_at)
		VALUES (1, $1, $2::jsonb, $3, NOW())
		ON CONFLICT (id) DO UPDATE SET body = EXCLUDED.body, diagnostics = EXCLUDED.diagnostics,
			updated_by = EXCLUDED.updated_by, updated_at = NOW()`, body, string(encoded), adminID)
	return diagnostics, err
}

func (h *APIKeyHandler) publishHamsterYAMLTemplate(ctx context.Context, adminID int64, acknowledgeWarnings bool) (*hamsterYAMLTemplateVersion, []hamsteryaml.TemplateDiagnostic, error) {
	state, err := h.getHamsterYAMLTemplateState(ctx)
	if err != nil {
		return nil, nil, err
	}
	diagnostics := hamsteryaml.ValidateSubscriptionTemplate(state.Draft)
	var warnings []hamsteryaml.TemplateDiagnostic
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			return nil, diagnostics, fmt.Errorf("%w: template contains hard errors", errHamsterYAMLTemplateUnpublishable)
		}
		if diagnostic.Level == "warning" {
			warnings = append(warnings, diagnostic)
		}
	}
	if len(warnings) > 0 && !acknowledgeWarnings {
		return nil, diagnostics, fmt.Errorf("%w: template warnings require explicit confirmation", errHamsterYAMLTemplateUnpublishable)
	}
	version, err := h.publishHamsterYAMLTemplateBody(ctx, adminID, state.Draft, warnings, acknowledgeWarnings)
	return version, diagnostics, err
}

func (h *APIKeyHandler) rollbackHamsterYAMLTemplate(ctx context.Context, adminID, targetVersion int64) (*hamsterYAMLTemplateVersion, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	var body string
	var warningsJSON []byte
	if err := db.QueryRowContext(ctx, `SELECT body, warnings FROM hamster_yaml_template_versions WHERE version = $1`, targetVersion).Scan(&body, &warningsJSON); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("template version %d not found", targetVersion)
		}
		return nil, err
	}
	var warnings []hamsteryaml.TemplateDiagnostic
	_ = json.Unmarshal(warningsJSON, &warnings)
	return h.publishHamsterYAMLTemplateBody(ctx, adminID, body, warnings, len(warnings) > 0)
}

func (h *APIKeyHandler) publishHamsterYAMLTemplateBody(ctx context.Context, adminID int64, body string, warnings []hamsteryaml.TemplateDiagnostic, acknowledged bool) (*hamsterYAMLTemplateVersion, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() { _ = tx.Rollback() }()
	if _, err := tx.ExecContext(ctx, `SELECT pg_advisory_xact_lock(614728341922)`); err != nil {
		return nil, err
	}
	var next int64
	if err := tx.QueryRowContext(ctx, `SELECT COALESCE(MAX(version), 0) + 1 FROM hamster_yaml_template_versions`).Scan(&next); err != nil {
		return nil, err
	}
	warningsJSON, _ := json.Marshal(warnings)
	if _, err := tx.ExecContext(ctx, `UPDATE hamster_yaml_template_versions SET active = FALSE WHERE active`); err != nil {
		return nil, err
	}
	version := &hamsterYAMLTemplateVersion{Version: next, Body: body, Warnings: warnings, CreatedBy: &adminID, Active: true}
	var confirmedBy any
	var confirmedAt any
	if acknowledged && len(warnings) > 0 {
		now := time.Now().UTC()
		version.WarningConfirmedBy = &adminID
		version.WarningConfirmedAt = &now
		confirmedBy, confirmedAt = adminID, now
	}
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO hamster_yaml_template_versions (
			version, body, warnings, warning_confirmed_by, warning_confirmed_at, created_by, active
		) VALUES ($1, $2, $3::jsonb, $4, $5, $6, TRUE) RETURNING created_at`,
		next, body, string(warningsJSON), confirmedBy, confirmedAt, adminID).Scan(&version.CreatedAt); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return version, nil
}
