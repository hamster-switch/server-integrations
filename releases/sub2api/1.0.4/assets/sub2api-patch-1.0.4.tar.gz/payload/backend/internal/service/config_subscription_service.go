package service

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"strings"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/pkg/ip"
)

const (
	HamsterConfigSubscriptionActive    = "active"
	HamsterConfigSubscriptionDisabled  = "disabled"
	hamsterConfigSubscriptionMaxGroups = 50
)

var (
	ErrHamsterConfigSubscriptionNotFound = errors.New("configuration subscription not found")
	ErrHamsterConfigSubscriptionDisabled = errors.New("configuration subscription is disabled")
	ErrHamsterConfigSubscriptionInvalid  = errors.New("invalid configuration subscription")
	ErrHamsterConfigSubscriptionChanged  = errors.New("configuration subscription changed; reload and retry")
)

func invalidHamsterConfigSubscription(format string, args ...any) error {
	return fmt.Errorf("%w: %s", ErrHamsterConfigSubscriptionInvalid, fmt.Sprintf(format, args...))
}

type HamsterConfigSubscriptionInput struct {
	Name          string
	GroupIDs      []int64
	CustomAPIKeys map[string]string
	IPWhitelist   []string
	IPBlacklist   []string
	Quota         float64
	ExpiresInDays *int
	RateLimit5h   float64
	RateLimit1d   float64
	RateLimit7d   float64
}

type HamsterConfigSubscriptionProvider struct {
	GroupID   int64
	GroupName string
	Platform  string
	Position  int
	APIKey    *APIKey
}

type HamsterConfigSubscription struct {
	ID            int64
	PublicID      string
	UserID        int64
	Name          string
	Status        string
	DownloadToken string
	CreatedAt     time.Time
	UpdatedAt     time.Time
	Providers     []HamsterConfigSubscriptionProvider
}

type HamsterConfigSubscriptionPage struct {
	Items []HamsterConfigSubscription
	Total int64
}

func (s *APIKeyService) SetHamsterConfigSubscriptionDB(db *sql.DB) {
	s.hamsterConfigSubscriptionDB = db
}

func (s *APIKeyService) HamsterConfigSubscriptionDB() *sql.DB {
	return s.hamsterConfigSubscriptionDB
}

func (s *APIKeyService) CreateHamsterConfigSubscription(ctx context.Context, userID int64, input HamsterConfigSubscriptionInput) (*HamsterConfigSubscription, error) {
	groups, input, err := s.validateHamsterConfigSubscriptionInput(ctx, userID, input)
	if err != nil {
		return nil, err
	}
	return s.createHamsterConfigSubscriptionWithGroups(ctx, userID, input, groups)
}

func (s *APIKeyService) createHamsterConfigSubscriptionWithGroups(ctx context.Context, userID int64, input HamsterConfigSubscriptionInput, groups []Group) (*HamsterConfigSubscription, error) {
	if s.hamsterConfigSubscriptionDB == nil {
		return nil, errors.New("configuration subscription database is unavailable")
	}

	publicID, err := randomHamsterSubscriptionHex(16)
	if err != nil {
		return nil, err
	}
	tokenBytes := make([]byte, 32)
	if _, err := rand.Read(tokenBytes); err != nil {
		return nil, fmt.Errorf("generate configuration subscription token: %w", err)
	}
	downloadToken := "hsc_" + base64.RawURLEncoding.EncodeToString(tokenBytes)

	tx, err := s.hamsterConfigSubscriptionDB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() { _ = tx.Rollback() }()

	subscription := &HamsterConfigSubscription{
		PublicID:      publicID,
		UserID:        userID,
		Name:          input.Name,
		Status:        HamsterConfigSubscriptionActive,
		DownloadToken: downloadToken,
	}
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO hamster_config_subscriptions (public_id, user_id, name, status, download_token)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, created_at, updated_at`,
		publicID, userID, input.Name, subscription.Status, downloadToken,
	).Scan(&subscription.ID, &subscription.CreatedAt, &subscription.UpdatedAt); err != nil {
		return nil, fmt.Errorf("create configuration subscription: %w", err)
	}

	for position, group := range groups {
		key, err := s.insertHamsterConfigSubscriptionAPIKey(ctx, tx, subscription, group, position, input)
		if err != nil {
			return nil, err
		}
		subscription.Providers = append(subscription.Providers, HamsterConfigSubscriptionProvider{
			GroupID: group.ID, GroupName: group.Name, Platform: group.Platform, Position: position, APIKey: key,
		})
	}
	if err := tx.Commit(); err != nil {
		return nil, fmt.Errorf("commit configuration subscription: %w", err)
	}
	return subscription, nil
}

func (s *APIKeyService) ListHamsterConfigSubscriptions(ctx context.Context, userID int64, search string, page, pageSize int) (*HamsterConfigSubscriptionPage, error) {
	if s.hamsterConfigSubscriptionDB == nil {
		return nil, errors.New("configuration subscription database is unavailable")
	}
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}
	search = strings.TrimSpace(search)
	like := "%" + search + "%"
	var total int64
	if err := s.hamsterConfigSubscriptionDB.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM hamster_config_subscriptions
		WHERE user_id = $1 AND deleted_at IS NULL AND ($2 = '' OR name ILIKE $3)`,
		userID, search, like,
	).Scan(&total); err != nil {
		return nil, err
	}
	rows, err := s.hamsterConfigSubscriptionDB.QueryContext(ctx, `
		SELECT public_id FROM hamster_config_subscriptions
		WHERE user_id = $1 AND deleted_at IS NULL AND ($2 = '' OR name ILIKE $3)
		ORDER BY created_at DESC, id DESC LIMIT $4 OFFSET $5`,
		userID, search, like, pageSize, (page-1)*pageSize,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	result := &HamsterConfigSubscriptionPage{Total: total, Items: make([]HamsterConfigSubscription, 0, len(ids))}
	for _, id := range ids {
		item, err := s.GetHamsterConfigSubscription(ctx, userID, id)
		if err != nil {
			return nil, err
		}
		result.Items = append(result.Items, *item)
	}
	return result, nil
}

func (s *APIKeyService) GetHamsterConfigSubscription(ctx context.Context, userID int64, publicID string) (*HamsterConfigSubscription, error) {
	return s.loadHamsterConfigSubscription(ctx, `public_id = $1 AND user_id = $2`, publicID, userID)
}

func (s *APIKeyService) GetHamsterConfigSubscriptionByToken(ctx context.Context, token string) (*HamsterConfigSubscription, error) {
	return s.loadHamsterConfigSubscription(ctx, `download_token = $1`, strings.TrimSpace(token))
}

func (s *APIKeyService) UpdateHamsterConfigSubscription(ctx context.Context, userID int64, publicID string, input HamsterConfigSubscriptionInput) (*HamsterConfigSubscription, error) {
	groups, input, err := s.validateHamsterConfigSubscriptionInput(ctx, userID, input)
	if err != nil {
		return nil, err
	}
	current, err := s.GetHamsterConfigSubscription(ctx, userID, publicID)
	if err != nil {
		return nil, err
	}
	tx, err := s.hamsterConfigSubscriptionDB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() { _ = tx.Rollback() }()
	var lockedID int64
	var lockedStatus string
	var lockedUpdatedAt time.Time
	if err := tx.QueryRowContext(ctx, `
		SELECT id, status, updated_at FROM hamster_config_subscriptions
		WHERE id = $1 AND user_id = $2 AND deleted_at IS NULL FOR UPDATE`, current.ID, userID,
	).Scan(&lockedID, &lockedStatus, &lockedUpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrHamsterConfigSubscriptionNotFound
		}
		return nil, err
	}
	if !lockedUpdatedAt.Equal(current.UpdatedAt) {
		return nil, ErrHamsterConfigSubscriptionChanged
	}
	current.Status = lockedStatus

	existing := make(map[int64]HamsterConfigSubscriptionProvider, len(current.Providers))
	for _, provider := range current.Providers {
		existing[provider.GroupID] = provider
	}
	kept := make(map[int64]bool, len(groups))
	for position, group := range groups {
		kept[group.ID] = true
		if provider, ok := existing[group.ID]; ok {
			if _, err := tx.ExecContext(ctx, `
				UPDATE hamster_config_subscription_providers
				SET position = $1, group_name = $2, platform = $3
				WHERE subscription_id = $4 AND group_id = $5`,
				position, group.Name, group.Platform, current.ID, group.ID,
			); err != nil {
				return nil, err
			}
			if err := s.updateHamsterConfigSubscriptionAPIKey(ctx, tx, provider.APIKey.ID, current, input); err != nil {
				return nil, err
			}
			continue
		}
		if _, err := s.insertHamsterConfigSubscriptionAPIKey(ctx, tx, current, group, position, input); err != nil {
			return nil, err
		}
	}
	for groupID, provider := range existing {
		if kept[groupID] {
			continue
		}
		if err := deleteHamsterConfigSubscriptionAPIKeyTx(ctx, tx, provider.APIKey.ID); err != nil {
			return nil, err
		}
		if _, err := tx.ExecContext(ctx, `
			DELETE FROM hamster_config_subscription_providers
			WHERE subscription_id = $1 AND group_id = $2`, current.ID, groupID,
		); err != nil {
			return nil, err
		}
	}
	if _, err := tx.ExecContext(ctx, `
		UPDATE hamster_config_subscriptions SET name = $1, updated_at = NOW()
		WHERE id = $2`, input.Name, current.ID,
	); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	s.invalidateHamsterConfigSubscriptionKeys(ctx, current)
	return s.GetHamsterConfigSubscription(ctx, userID, publicID)
}

func (s *APIKeyService) SetHamsterConfigSubscriptionEnabled(ctx context.Context, userID int64, publicID string, enabled bool) (*HamsterConfigSubscription, error) {
	current, err := s.GetHamsterConfigSubscription(ctx, userID, publicID)
	if err != nil {
		return nil, err
	}
	status := HamsterConfigSubscriptionDisabled
	keyStatus := StatusAPIKeyDisabled
	if enabled {
		status = HamsterConfigSubscriptionActive
		keyStatus = StatusAPIKeyActive
	}
	tx, err := s.hamsterConfigSubscriptionDB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() { _ = tx.Rollback() }()
	result, err := tx.ExecContext(ctx, `
		UPDATE hamster_config_subscriptions SET status = $1, updated_at = NOW()
		WHERE id = $2 AND user_id = $3 AND deleted_at IS NULL`, status, current.ID, userID,
	)
	if err != nil {
		return nil, err
	}
	affected, _ := result.RowsAffected()
	if affected != 1 {
		return nil, ErrHamsterConfigSubscriptionNotFound
	}
	if _, err := tx.ExecContext(ctx, `
		UPDATE api_keys SET status = $1, updated_at = NOW()
		WHERE id IN (
			SELECT api_key_id FROM hamster_config_subscription_providers WHERE subscription_id = $2
		) AND deleted_at IS NULL`, keyStatus, current.ID,
	); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	s.invalidateHamsterConfigSubscriptionKeys(ctx, current)
	return s.GetHamsterConfigSubscription(ctx, userID, publicID)
}

func (s *APIKeyService) DeleteHamsterConfigSubscription(ctx context.Context, userID int64, publicID string) error {
	current, err := s.GetHamsterConfigSubscription(ctx, userID, publicID)
	if err != nil {
		return err
	}
	tx, err := s.hamsterConfigSubscriptionDB.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() { _ = tx.Rollback() }()
	var locked int64
	if err := tx.QueryRowContext(ctx, `
		SELECT id FROM hamster_config_subscriptions
		WHERE id = $1 AND user_id = $2 AND deleted_at IS NULL FOR UPDATE`, current.ID, userID,
	).Scan(&locked); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return ErrHamsterConfigSubscriptionNotFound
		}
		return err
	}
	rows, err := tx.QueryContext(ctx, `
		SELECT k.id, k.key FROM hamster_config_subscription_providers p
		JOIN api_keys k ON k.id = p.api_key_id
		WHERE p.subscription_id = $1 AND k.deleted_at IS NULL
		ORDER BY k.id FOR UPDATE`, current.ID)
	if err != nil {
		return err
	}
	type keyReference struct {
		id  int64
		key string
	}
	var keys []keyReference
	for rows.Next() {
		var item keyReference
		if err := rows.Scan(&item.id, &item.key); err != nil {
			_ = rows.Close()
			return err
		}
		keys = append(keys, item)
	}
	if err := rows.Err(); err != nil {
		_ = rows.Close()
		return err
	}
	if err := rows.Close(); err != nil {
		return err
	}
	for _, key := range keys {
		if err := deleteHamsterConfigSubscriptionAPIKeyTx(ctx, tx, key.id); err != nil {
			return err
		}
	}
	if _, err := tx.ExecContext(ctx, `
		UPDATE hamster_config_subscriptions SET status = 'disabled', deleted_at = NOW(), updated_at = NOW()
		WHERE id = $1`, current.ID,
	); err != nil {
		return err
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	for _, key := range keys {
		s.InvalidateAuthCacheByKey(ctx, key.key)
		s.lastUsedTouchL1.Delete(key.id)
	}
	return nil
}

func (s *APIKeyService) validateHamsterConfigSubscriptionInput(ctx context.Context, userID int64, input HamsterConfigSubscriptionInput) ([]Group, HamsterConfigSubscriptionInput, error) {
	input.Name = strings.TrimSpace(input.Name)
	if input.Name == "" {
		input.Name = "配置订阅"
	}
	if len([]rune(input.Name)) > 120 {
		return nil, input, invalidHamsterConfigSubscription("configuration subscription name is too long")
	}
	input.Name = html.EscapeString(input.Name)
	if len(input.GroupIDs) == 0 || len(input.GroupIDs) > hamsterConfigSubscriptionMaxGroups {
		return nil, input, invalidHamsterConfigSubscription("configuration subscription requires 1-%d groups", hamsterConfigSubscriptionMaxGroups)
	}
	if invalid := ip.ValidateIPPatterns(input.IPWhitelist); len(invalid) > 0 {
		return nil, input, invalidHamsterConfigSubscription("invalid IP whitelist: %v", invalid)
	}
	if invalid := ip.ValidateIPPatterns(input.IPBlacklist); len(invalid) > 0 {
		return nil, input, invalidHamsterConfigSubscription("invalid IP blacklist: %v", invalid)
	}
	available, err := s.GetAvailableGroups(ctx, userID)
	if err != nil {
		return nil, input, err
	}
	byID := make(map[int64]Group, len(available))
	for _, group := range available {
		byID[group.ID] = group
	}
	seen := make(map[int64]bool, len(input.GroupIDs))
	groups := make([]Group, 0, len(input.GroupIDs))
	for _, id := range input.GroupIDs {
		if id <= 0 || seen[id] {
			return nil, input, invalidHamsterConfigSubscription("configuration subscription group IDs must be positive and unique")
		}
		group, ok := byID[id]
		if !ok {
			return nil, input, invalidHamsterConfigSubscription("group %d is not available for this user", id)
		}
		seen[id] = true
		groups = append(groups, group)
		if custom := strings.TrimSpace(input.CustomAPIKeys[fmt.Sprintf("%d", id)]); custom != "" {
			if err := s.ValidateCustomKey(custom); err != nil {
				return nil, input, invalidHamsterConfigSubscription("%v", err)
			}
			exists, err := s.apiKeyRepo.ExistsByKey(ctx, custom)
			if err != nil {
				return nil, input, err
			}
			if exists {
				return nil, input, ErrAPIKeyExists
			}
		}
	}
	return groups, input, nil
}

func (s *APIKeyService) insertHamsterConfigSubscriptionAPIKey(ctx context.Context, tx *sql.Tx, subscription *HamsterConfigSubscription, group Group, position int, input HamsterConfigSubscriptionInput) (*APIKey, error) {
	key := strings.TrimSpace(input.CustomAPIKeys[fmt.Sprintf("%d", group.ID)])
	if key == "" {
		var err error
		key, err = s.GenerateKey()
		if err != nil {
			return nil, err
		}
	}
	whitelist, _ := json.Marshal(input.IPWhitelist)
	blacklist, _ := json.Marshal(input.IPBlacklist)
	var expiresAt *time.Time
	if input.ExpiresInDays != nil && *input.ExpiresInDays > 0 {
		value := time.Now().AddDate(0, 0, *input.ExpiresInDays)
		expiresAt = &value
	}
	keyStatus := StatusAPIKeyActive
	if subscription.Status == HamsterConfigSubscriptionDisabled {
		keyStatus = StatusAPIKeyDisabled
	}
	apiKey := &APIKey{
		UserID: subscription.UserID, Key: key, Name: hamsterConfigSubscriptionAPIKeyName(subscription.PublicID, group.Name),
		GroupID: &group.ID, Status: keyStatus, IPWhitelist: input.IPWhitelist, IPBlacklist: input.IPBlacklist,
		Quota: input.Quota, ExpiresAt: expiresAt, RateLimit5h: input.RateLimit5h, RateLimit1d: input.RateLimit1d, RateLimit7d: input.RateLimit7d,
	}
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO api_keys (
			user_id, key, name, group_id, status, ip_whitelist, ip_blacklist,
			quota, quota_used, expires_at, rate_limit_5h, rate_limit_1d, rate_limit_7d,
			usage_5h, usage_1d, usage_7d, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8, 0, $9, $10, $11, $12, 0, 0, 0, NOW(), NOW())
		RETURNING id, created_at, updated_at`,
		apiKey.UserID, apiKey.Key, apiKey.Name, group.ID, apiKey.Status, string(whitelist), string(blacklist),
		apiKey.Quota, apiKey.ExpiresAt, apiKey.RateLimit5h, apiKey.RateLimit1d, apiKey.RateLimit7d,
	).Scan(&apiKey.ID, &apiKey.CreatedAt, &apiKey.UpdatedAt); err != nil {
		return nil, fmt.Errorf("create configuration subscription API key: %w", err)
	}
	apiKey.Group = &group
	if _, err := tx.ExecContext(ctx, `
		INSERT INTO hamster_config_subscription_providers
			(subscription_id, group_id, api_key_id, position, group_name, platform)
		VALUES ($1, $2, $3, $4, $5, $6)`,
		subscription.ID, group.ID, apiKey.ID, position, group.Name, group.Platform,
	); err != nil {
		return nil, fmt.Errorf("link configuration subscription provider: %w", err)
	}
	return apiKey, nil
}

func (s *APIKeyService) updateHamsterConfigSubscriptionAPIKey(ctx context.Context, tx *sql.Tx, keyID int64, subscription *HamsterConfigSubscription, input HamsterConfigSubscriptionInput) error {
	whitelist, _ := json.Marshal(input.IPWhitelist)
	blacklist, _ := json.Marshal(input.IPBlacklist)
	var expiresAt *time.Time
	if input.ExpiresInDays != nil && *input.ExpiresInDays > 0 {
		value := time.Now().AddDate(0, 0, *input.ExpiresInDays)
		expiresAt = &value
	}
	status := StatusAPIKeyActive
	if subscription.Status == HamsterConfigSubscriptionDisabled {
		status = StatusAPIKeyDisabled
	}
	result, err := tx.ExecContext(ctx, `
		UPDATE api_keys SET status = $1, ip_whitelist = $2::jsonb, ip_blacklist = $3::jsonb,
			quota = $4, expires_at = $5, rate_limit_5h = $6, rate_limit_1d = $7, rate_limit_7d = $8,
			updated_at = NOW()
		WHERE id = $9 AND user_id = $10 AND deleted_at IS NULL`,
		status, string(whitelist), string(blacklist), input.Quota, expiresAt,
		input.RateLimit5h, input.RateLimit1d, input.RateLimit7d, keyID, subscription.UserID,
	)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected != 1 {
		return ErrAPIKeyNotFound
	}
	return nil
}

func (s *APIKeyService) loadHamsterConfigSubscription(ctx context.Context, predicate string, args ...any) (*HamsterConfigSubscription, error) {
	if s.hamsterConfigSubscriptionDB == nil {
		return nil, errors.New("configuration subscription database is unavailable")
	}
	query := `SELECT id, public_id, user_id, name, status, download_token, created_at, updated_at
		FROM hamster_config_subscriptions WHERE ` + predicate + ` AND deleted_at IS NULL`
	item := &HamsterConfigSubscription{}
	if err := s.hamsterConfigSubscriptionDB.QueryRowContext(ctx, query, args...).Scan(
		&item.ID, &item.PublicID, &item.UserID, &item.Name, &item.Status, &item.DownloadToken, &item.CreatedAt, &item.UpdatedAt,
	); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrHamsterConfigSubscriptionNotFound
		}
		return nil, err
	}
	rows, err := s.hamsterConfigSubscriptionDB.QueryContext(ctx, `
		SELECT p.group_id, p.group_name, p.platform, p.position,
			k.id, k.user_id, k.key, k.name, k.status, k.ip_whitelist, k.ip_blacklist,
			k.quota, k.quota_used, k.expires_at, k.rate_limit_5h, k.rate_limit_1d, k.rate_limit_7d,
			k.created_at, k.updated_at
		FROM hamster_config_subscription_providers p
		JOIN api_keys k ON k.id = p.api_key_id
		WHERE p.subscription_id = $1 AND k.deleted_at IS NULL
		ORDER BY p.position, p.group_id`, item.ID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		provider := HamsterConfigSubscriptionProvider{APIKey: &APIKey{}}
		if err := rows.Scan(
			&provider.GroupID, &provider.GroupName, &provider.Platform, &provider.Position,
			&provider.APIKey.ID, &provider.APIKey.UserID, &provider.APIKey.Key, &provider.APIKey.Name, &provider.APIKey.Status,
			&provider.APIKey.IPWhitelist, &provider.APIKey.IPBlacklist, &provider.APIKey.Quota, &provider.APIKey.QuotaUsed,
			&provider.APIKey.ExpiresAt, &provider.APIKey.RateLimit5h, &provider.APIKey.RateLimit1d, &provider.APIKey.RateLimit7d,
			&provider.APIKey.CreatedAt, &provider.APIKey.UpdatedAt,
		); err != nil {
			return nil, err
		}
		provider.APIKey.GroupID = &provider.GroupID
		provider.APIKey.Group = &Group{ID: provider.GroupID, Name: provider.GroupName, Platform: provider.Platform, Hydrated: true}
		item.Providers = append(item.Providers, provider)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(item.Providers) == 0 {
		return nil, errors.New("configuration subscription has no providers")
	}
	return item, nil
}

func deleteHamsterConfigSubscriptionAPIKeyTx(ctx context.Context, tx *sql.Tx, keyID int64) error {
	if _, err := tx.ExecContext(ctx, `
		INSERT INTO deleted_api_key_audits (key, api_key_id, user_id, key_name, deleted_at)
		SELECT key, id, user_id, name, NOW() FROM api_keys
		WHERE id = $1 AND deleted_at IS NULL`, keyID,
	); err != nil {
		return err
	}
	tombstone := fmt.Sprintf("__deleted__%d__%d", keyID, time.Now().UnixNano())
	result, err := tx.ExecContext(ctx, `
		UPDATE api_keys SET key = $1, status = $2, deleted_at = NOW(), updated_at = NOW()
		WHERE id = $3 AND deleted_at IS NULL`, tombstone, StatusAPIKeyDisabled, keyID,
	)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected != 1 {
		return ErrAPIKeyNotFound
	}
	return nil
}

func (s *APIKeyService) invalidateHamsterConfigSubscriptionKeys(ctx context.Context, subscription *HamsterConfigSubscription) {
	if subscription == nil {
		return
	}
	for _, provider := range subscription.Providers {
		if provider.APIKey != nil {
			s.InvalidateAuthCacheByKey(ctx, provider.APIKey.Key)
			s.lastUsedTouchL1.Delete(provider.APIKey.ID)
		}
	}
}

func hamsterConfigSubscriptionAPIKeyName(publicID, groupName string) string {
	value := fmt.Sprintf("配置订阅 %s %s", publicID, strings.TrimSpace(groupName))
	if len([]rune(value)) > 100 {
		value = string([]rune(value)[:100])
	}
	return value
}

func randomHamsterSubscriptionHex(size int) (string, error) {
	value := make([]byte, size)
	if _, err := rand.Read(value); err != nil {
		return "", err
	}
	return hex.EncodeToString(value), nil
}
