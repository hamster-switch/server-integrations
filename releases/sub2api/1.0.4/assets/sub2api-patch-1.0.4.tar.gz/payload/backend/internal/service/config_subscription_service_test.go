package service

import (
	"context"
	"errors"
	"regexp"
	"testing"
	"time"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	"github.com/Wei-Shaw/sub2api/internal/config"
)

func expectHamsterSubscriptionInsert(mock sqlmock.Sqlmock) {
	now := time.Now().UTC()
	mock.ExpectQuery(regexp.QuoteMeta("INSERT INTO hamster_config_subscriptions (public_id, user_id, name, status, download_token) VALUES ($1, $2, $3, $4, $5) RETURNING id, created_at, updated_at")).
		WithArgs(sqlmock.AnyArg(), int64(7), "配置订阅", HamsterConfigSubscriptionActive, sqlmock.AnyArg()).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).AddRow(int64(41), now, now))
}

func expectHamsterAPIKeyInsert(mock sqlmock.Sqlmock, keyID int64, group Group, status string) {
	now := time.Now().UTC()
	mock.ExpectQuery("INSERT INTO api_keys").
		WithArgs(int64(7), sqlmock.AnyArg(), sqlmock.AnyArg(), group.ID, status, "null", "null", float64(0), nil, float64(0), float64(0), float64(0)).
		WillReturnRows(sqlmock.NewRows([]string{"id", "created_at", "updated_at"}).AddRow(keyID, now, now))
	mock.ExpectExec("INSERT INTO hamster_config_subscription_providers").
		WithArgs(int64(41), group.ID, keyID, sqlmock.AnyArg(), group.Name, group.Platform).
		WillReturnResult(sqlmock.NewResult(1, 1))
}

func TestCreateHamsterConfigSubscriptionCommitsAllProviders(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	groups := []Group{{ID: 1, Name: "Claude", Platform: "anthropic"}, {ID: 2, Name: "Codex", Platform: "openai"}}
	mock.ExpectBegin()
	expectHamsterSubscriptionInsert(mock)
	expectHamsterAPIKeyInsert(mock, 101, groups[0], StatusAPIKeyActive)
	expectHamsterAPIKeyInsert(mock, 102, groups[1], StatusAPIKeyActive)
	mock.ExpectCommit()
	created, err := service.createHamsterConfigSubscriptionWithGroups(context.Background(), 7, HamsterConfigSubscriptionInput{Name: "配置订阅"}, groups)
	if err != nil {
		t.Fatal(err)
	}
	if len(created.Providers) != 2 || created.DownloadToken[:4] != "hsc_" {
		t.Fatalf("unexpected subscription: %+v", created)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestCreateHamsterConfigSubscriptionRollsBackWhenAnyKeyFails(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	groups := []Group{{ID: 1, Name: "Claude", Platform: "anthropic"}, {ID: 2, Name: "Codex", Platform: "openai"}}
	mock.ExpectBegin()
	expectHamsterSubscriptionInsert(mock)
	expectHamsterAPIKeyInsert(mock, 101, groups[0], StatusAPIKeyActive)
	mock.ExpectQuery("INSERT INTO api_keys").WithArgs(int64(7), sqlmock.AnyArg(), sqlmock.AnyArg(), groups[1].ID, StatusAPIKeyActive, "null", "null", float64(0), nil, float64(0), float64(0), float64(0)).WillReturnError(errors.New("injected key insert failure"))
	mock.ExpectRollback()
	if _, err := service.createHamsterConfigSubscriptionWithGroups(context.Background(), 7, HamsterConfigSubscriptionInput{Name: "配置订阅"}, groups); err == nil {
		t.Fatal("expected create to fail")
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}

func TestInsertProviderKeepsDisabledSubscriptionKeyDisabled(t *testing.T) {
	db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherRegexp))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	service := &APIKeyService{hamsterConfigSubscriptionDB: db, cfg: &config.Config{}}
	group := Group{ID: 1, Name: "Claude", Platform: "anthropic"}
	mock.ExpectBegin()
	expectHamsterAPIKeyInsert(mock, 101, group, StatusAPIKeyDisabled)
	mock.ExpectCommit()
	tx, err := db.BeginTx(context.Background(), nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := service.insertHamsterConfigSubscriptionAPIKey(context.Background(), tx, &HamsterConfigSubscription{ID: 41, UserID: 7, PublicID: "public", Status: HamsterConfigSubscriptionDisabled}, group, 0, HamsterConfigSubscriptionInput{}); err != nil {
		t.Fatal(err)
	}
	if err := tx.Commit(); err != nil {
		t.Fatal(err)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatal(err)
	}
}
