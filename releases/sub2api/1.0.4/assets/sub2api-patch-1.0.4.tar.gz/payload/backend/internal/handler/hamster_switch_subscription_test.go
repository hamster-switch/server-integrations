package handler

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"

	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/gin-gonic/gin"
)

func TestHamsterSwitchNormalizeBaseURL(t *testing.T) {
	for input, expected := range map[string]string{
		"https://example.com/":            "https://example.com",
		"https://example.com/api/v1":      "https://example.com",
		"https://example.com/v1":          "https://example.com",
		"https://example.com/v1beta":      "https://example.com",
		"https://example.com/base/api/v1": "https://example.com/base",
	} {
		if actual := hamsterSwitchNormalizeBaseURL(input); actual != expected {
			t.Fatalf("normalize %q: got %q want %q", input, actual, expected)
		}
	}
}

func TestHamsterSwitchModelsForGroup(t *testing.T) {
	group := &service.Group{DefaultMappedModel: "fallback-model"}
	models, err := hamsterSwitchModelsForGroup(group)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(models, []string{"fallback-model"}) {
		t.Fatalf("unexpected models: %#v", models)
	}
}

func TestHamsterSwitchIDPartDoesNotExposeGroupName(t *testing.T) {
	if actual := hamsterSwitchIDPart("中文 分组"); actual != "group" {
		t.Fatalf("unexpected identifier: %s", actual)
	}
}

func TestHamsterSwitchServiceErrorDoesNotMisclassifyInternalFailure(t *testing.T) {
	gin.SetMode(gin.TestMode)
	for name, testCase := range map[string]struct {
		err      error
		expected int
	}{
		"validation": {service.ErrHamsterConfigSubscriptionInvalid, http.StatusUnprocessableEntity},
		"changed":    {service.ErrHamsterConfigSubscriptionChanged, http.StatusConflict},
		"disabled":   {service.ErrHamsterConfigSubscriptionDisabled, http.StatusGone},
		"internal":   {errors.New("database unavailable"), http.StatusInternalServerError},
	} {
		t.Run(name, func(t *testing.T) {
			recorder := httptest.NewRecorder()
			context, _ := gin.CreateTestContext(recorder)
			context.Request = httptest.NewRequest(http.MethodGet, "/api/v1/keys/hamster-switch/subscriptions", nil)
			writeHamsterSwitchServiceError(context, testCase.err)
			if recorder.Code != testCase.expected {
				t.Fatalf("got status %d, want %d", recorder.Code, testCase.expected)
			}
		})
	}
}

func TestHamsterSwitchDownloadRejectsLegacyTokenBeforeDatabaseLookup(t *testing.T) {
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodGet, "/api/hamster-switch/subscription.yaml?token=hs_legacy", nil)
	(&APIKeyHandler{}).GetHamsterSwitchSubscription(context)
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("got status %d, want 404", recorder.Code)
	}
}
