package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/dialect"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
)

// These schemas keep Ent's model catalogue aligned with migration 154. Runtime
// lifecycle operations intentionally use one sql.Tx so subscription, provider
// and API-key changes share the same transaction boundary.

type HamsterConfigSubscription struct{ ent.Schema }

func (HamsterConfigSubscription) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_config_subscriptions"}}
}
func (HamsterConfigSubscription) Fields() []ent.Field {
	return []ent.Field{
		field.String("public_id").MaxLen(32).Unique(), field.Int64("user_id"), field.String("name").MaxLen(120),
		field.String("status").MaxLen(16).Default("active"), field.String("download_token").MaxLen(96).Unique(),
		field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
		field.Time("updated_at").Default(time.Now).UpdateDefault(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
		field.Time("deleted_at").Optional().Nillable().SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}
func (HamsterConfigSubscription) Indexes() []ent.Index {
	return []ent.Index{index.Fields("user_id", "created_at"), index.Fields("deleted_at")}
}

type HamsterConfigSubscriptionProvider struct{ ent.Schema }

func (HamsterConfigSubscriptionProvider) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_config_subscription_providers"}, field.ID("subscription_id", "group_id")}
}
func (HamsterConfigSubscriptionProvider) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("subscription_id"), field.Int64("group_id"), field.Int64("api_key_id").Unique(), field.Int("position").Default(0),
		field.String("group_name").MaxLen(100), field.String("platform").MaxLen(50), field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}
func (HamsterConfigSubscriptionProvider) Indexes() []ent.Index {
	return []ent.Index{index.Fields("subscription_id", "group_id").Unique(), index.Fields("subscription_id", "position")}
}

type HamsterYAMLTemplateDraft struct{ ent.Schema }

func (HamsterYAMLTemplateDraft) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_yaml_template_drafts"}}
}
func (HamsterYAMLTemplateDraft) Fields() []ent.Field {
	return []ent.Field{
		field.Int("id").Default(1), field.String("body").SchemaType(map[string]string{dialect.Postgres: "text"}),
		field.JSON("diagnostics", []map[string]any{}).Optional(), field.Int64("updated_by").Optional().Nillable(),
		field.Time("updated_at").Default(time.Now).UpdateDefault(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}

type HamsterYAMLTemplateVersion struct{ ent.Schema }

func (HamsterYAMLTemplateVersion) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_yaml_template_versions"}}
}
func (HamsterYAMLTemplateVersion) Fields() []ent.Field {
	return []ent.Field{
		field.Int64("version").Unique(), field.String("body").SchemaType(map[string]string{dialect.Postgres: "text"}), field.JSON("warnings", []map[string]any{}).Optional(),
		field.Int64("warning_confirmed_by").Optional().Nillable(), field.Time("warning_confirmed_at").Optional().Nillable().SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
		field.Int64("created_by").Optional().Nillable(), field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}), field.Bool("active").Default(false),
	}
}
func (HamsterYAMLTemplateVersion) Indexes() []ent.Index { return []ent.Index{index.Fields("active")} }

type HamsterTutorialSnapshot struct{ ent.Schema }

func (HamsterTutorialSnapshot) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_tutorial_snapshots"}}
}
func (HamsterTutorialSnapshot) Fields() []ent.Field {
	return []ent.Field{
		field.String("version").MaxLen(64).Unique(), field.JSON("body", map[string]any{}), field.String("source").MaxLen(16), field.Bool("active").Default(false),
		field.Int64("created_by").Optional().Nillable(), field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}
func (HamsterTutorialSnapshot) Indexes() []ent.Index { return []ent.Index{index.Fields("active")} }

type HamsterTutorialSiteOverride struct{ ent.Schema }

func (HamsterTutorialSiteOverride) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_tutorial_site_overrides"}}
}
func (HamsterTutorialSiteOverride) Fields() []ent.Field {
	return []ent.Field{
		field.String("id").StorageKey("step_id").MaxLen(80), field.JSON("body", map[string]any{}), field.String("base_version").MaxLen(64), field.Int64("updated_by").Optional().Nillable(),
		field.Time("updated_at").Default(time.Now).UpdateDefault(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}

type HamsterTutorialCandidate struct{ ent.Schema }

func (HamsterTutorialCandidate) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_tutorial_candidates"}}
}
func (HamsterTutorialCandidate) Fields() []ent.Field {
	return []ent.Field{
		field.String("id").StorageKey("version").MaxLen(64), field.JSON("body", map[string]any{}), field.JSON("conflicts", []map[string]any{}).Optional(),
		field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}

type HamsterTutorialImage struct{ ent.Schema }

func (HamsterTutorialImage) Annotations() []schema.Annotation {
	return []schema.Annotation{entsql.Annotation{Table: "hamster_tutorial_images"}}
}
func (HamsterTutorialImage) Fields() []ent.Field {
	return []ent.Field{
		field.String("id").MaxLen(64), field.String("local_name").MaxLen(80).Unique(), field.String("media_type").MaxLen(32),
		field.Int64("size_bytes"), field.Int("width"), field.Int("height"), field.String("source_url").Optional().Nillable().SchemaType(map[string]string{dialect.Postgres: "text"}),
		field.Int64("created_by").Optional().Nillable(), field.Time("created_at").Default(time.Now).SchemaType(map[string]string{dialect.Postgres: "timestamptz"}),
	}
}
