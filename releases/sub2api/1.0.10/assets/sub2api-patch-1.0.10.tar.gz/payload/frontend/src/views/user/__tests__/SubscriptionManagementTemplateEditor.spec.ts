import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const source = readFileSync(
  resolve(process.cwd(), 'src/views/user/SubscriptionManagementView.vue'),
  'utf8'
)

describe('subscription template editor', () => {
  it('uses the group pricing multiplier and exposes it as a numeric input', () => {
    expect(source).toContain('group.default_pricing')
    expect(source).toContain('type="number" min="0" step="0.001"')
    expect(source).toContain("override.pricing = {")
    expect(source).toContain('delete pricing.multiplier')
  })

  it('fills defaults into editable controls when they receive focus', () => {
    expect(source).toContain('@focus="fillSubscriptionTemplateDefault(field.key)"')
    expect(source).toContain('@focus="fillProviderTemplateDefault(group, field.key)"')
    expect(source).toContain('@focus="fillProviderPricingMultiplierDefault(group)"')
    expect(source).toContain('@focus="fillProviderJSONDefault(group, field.key)"')
  })
})
