CREATE TABLE IF NOT EXISTS hamster_config_subscriptions (
    id              BIGSERIAL PRIMARY KEY,
    public_id       VARCHAR(32) NOT NULL UNIQUE,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name            VARCHAR(120) NOT NULL,
    status          VARCHAR(16) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active', 'disabled')),
    download_token  VARCHAR(96) NOT NULL UNIQUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_hamster_config_subscriptions_user_created
    ON hamster_config_subscriptions (user_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS hamster_config_subscription_providers (
    subscription_id BIGINT NOT NULL REFERENCES hamster_config_subscriptions(id) ON DELETE CASCADE,
    group_id         BIGINT NOT NULL REFERENCES groups(id) ON DELETE RESTRICT,
    api_key_id       BIGINT NOT NULL REFERENCES api_keys(id) ON DELETE RESTRICT,
    position         INTEGER NOT NULL DEFAULT 0,
    group_name       VARCHAR(100) NOT NULL,
    platform         VARCHAR(50) NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (subscription_id, group_id),
    UNIQUE (api_key_id)
);

CREATE INDEX IF NOT EXISTS idx_hamster_config_subscription_providers_subscription
    ON hamster_config_subscription_providers (subscription_id, position);

CREATE TABLE IF NOT EXISTS hamster_yaml_template_drafts (
    id              SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    body            TEXT NOT NULL,
    diagnostics     JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hamster_yaml_template_versions (
    id                  BIGSERIAL PRIMARY KEY,
    version             BIGINT NOT NULL UNIQUE,
    body                TEXT NOT NULL,
    warnings            JSONB NOT NULL DEFAULT '[]'::jsonb,
    warning_confirmed_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    warning_confirmed_at TIMESTAMPTZ,
    created_by          BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active              BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_hamster_yaml_template_one_active
    ON hamster_yaml_template_versions (active)
    WHERE active;

CREATE TABLE IF NOT EXISTS hamster_tutorial_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    version         VARCHAR(64) NOT NULL UNIQUE,
    body            JSONB NOT NULL,
    source          VARCHAR(16) NOT NULL CHECK (source IN ('builtin', 'release', 'site')),
    active          BOOLEAN NOT NULL DEFAULT FALSE,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_hamster_tutorial_one_active
    ON hamster_tutorial_snapshots (active)
    WHERE active;

CREATE TABLE IF NOT EXISTS hamster_tutorial_site_overrides (
    step_id         VARCHAR(80) PRIMARY KEY,
    body            JSONB NOT NULL,
    base_version    VARCHAR(64) NOT NULL,
    updated_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hamster_tutorial_candidates (
    version         VARCHAR(64) PRIMARY KEY,
    body            JSONB NOT NULL,
    conflicts       JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hamster_tutorial_images (
    id              VARCHAR(64) PRIMARY KEY,
    local_name      VARCHAR(80) NOT NULL UNIQUE,
    media_type      VARCHAR(32) NOT NULL,
    size_bytes      BIGINT NOT NULL,
    width           INTEGER NOT NULL,
    height          INTEGER NOT NULL,
    source_url      TEXT,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
