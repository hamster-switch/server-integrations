ALTER TABLE hamster_yaml_template_drafts
    ADD COLUMN IF NOT EXISTS presentation JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE hamster_yaml_template_versions
    ADD COLUMN IF NOT EXISTS presentation JSONB NOT NULL DEFAULT '{}'::jsonb;

INSERT INTO settings (key, value, updated_at)
VALUES ('hide_hamster_subscription_api_keys', 'false', NOW())
ON CONFLICT (key) DO NOTHING;

CREATE INDEX IF NOT EXISTS idx_hamster_config_subscription_providers_api_key
    ON hamster_config_subscription_providers (api_key_id);
