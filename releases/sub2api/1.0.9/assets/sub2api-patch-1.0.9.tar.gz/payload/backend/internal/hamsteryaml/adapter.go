package hamsteryaml

import (
	"fmt"
	"os"
	"strings"

	"github.com/Wei-Shaw/sub2api/internal/service"
	"gopkg.in/yaml.v3"
)

type subscription struct {
	FormatVersion      int        `yaml:"format_version"`
	FormatVersionCamel int        `yaml:"formatVersion"`
	Name               string     `yaml:"name"`
	Providers          []provider `yaml:"providers"`
}

type provider struct {
	ID                  string         `yaml:"id"`
	AppType             string         `yaml:"app_type"`
	AppTypeCamel        string         `yaml:"appType"`
	GroupName           string         `yaml:"group_name"`
	GroupNameCamel      string         `yaml:"groupName"`
	Name                string         `yaml:"name"`
	Description         string         `yaml:"description"`
	Notes               string         `yaml:"notes"`
	Models              []string       `yaml:"models"`
	SettingsConfig      map[string]any `yaml:"settings_config"`
	SettingsConfigCamel map[string]any `yaml:"settingsConfig"`
	Endpoints           []endpoint     `yaml:"endpoints"`
}

type endpoint struct {
	URL string `yaml:"url"`
}

// LoadCreateAccountRequestsFile reads Hamster Switch subscription YAML from disk.
func LoadCreateAccountRequestsFile(path string) ([]service.CreateAccountRequest, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read hamster switch config: %w", err)
	}
	return ParseCreateAccountRequests(data)
}

// ParseCreateAccountRequests converts Hamster Switch subscription YAML into
// sub2api account create requests.
func ParseCreateAccountRequests(data []byte) ([]service.CreateAccountRequest, error) {
	if len(data) == 0 {
		return nil, fmt.Errorf("hamster switch config payload is empty")
	}

	var sub subscription
	if err := yaml.Unmarshal(data, &sub); err != nil {
		return nil, fmt.Errorf("parse hamster switch config: %w", err)
	}
	return convertSubscription(sub)
}

func convertSubscription(sub subscription) ([]service.CreateAccountRequest, error) {
	if version := sub.version(); version != 1 {
		return nil, fmt.Errorf("unsupported hamster switch format_version %d", version)
	}
	if strings.TrimSpace(sub.Name) == "" {
		return nil, fmt.Errorf("hamster switch config missing name")
	}
	if len(sub.Providers) == 0 {
		return nil, fmt.Errorf("hamster switch config must include at least one provider")
	}

	requests := make([]service.CreateAccountRequest, 0, len(sub.Providers))
	for index, provider := range sub.Providers {
		request, err := convertProvider(provider, index)
		if err != nil {
			return nil, err
		}
		requests = append(requests, request)
	}
	return requests, nil
}

func convertProvider(provider provider, index int) (service.CreateAccountRequest, error) {
	appType := provider.appType()
	if appType == "" {
		return service.CreateAccountRequest{}, fmt.Errorf("provider %s missing app_type", provider.label(index))
	}
	models := orderModels(provider.Models, defaultModel(provider))
	if len(models) == 0 {
		return service.CreateAccountRequest{}, fmt.Errorf("provider %s must include at least one model", provider.label(index))
	}
	settings := provider.settingsConfig()
	if settings == nil {
		return service.CreateAccountRequest{}, fmt.Errorf("provider %s missing settings_config", provider.label(index))
	}

	apiKey, apiKeyHint := apiKey(provider)
	if apiKey == "" {
		return service.CreateAccountRequest{}, fmt.Errorf("provider %s missing API key (%s)", provider.label(index), apiKeyHint)
	}

	platform, err := platform(appType)
	if err != nil {
		return service.CreateAccountRequest{}, fmt.Errorf("provider %s: %w", provider.label(index), err)
	}

	credentials := map[string]any{
		"api_key":       apiKey,
		"model_mapping": modelMapping(models),
	}
	if value := baseURL(provider); value != "" {
		credentials["base_url"] = value
	}

	extra := map[string]any{}
	if provider.ID != "" {
		extra["hamster_provider_id"] = provider.ID
	}
	if groupName := provider.groupName(); groupName != "" {
		extra["hamster_group_name"] = groupName
	}
	if defaultModel := defaultModel(provider); defaultModel != "" {
		extra["hamster_default_model"] = defaultModel
	}

	name := strings.TrimSpace(provider.Name)
	if name == "" {
		name = strings.TrimSpace(provider.ID)
	}
	notes := strings.TrimSpace(provider.Notes)
	if notes == "" {
		notes = strings.TrimSpace(provider.Description)
	}

	return service.CreateAccountRequest{
		Name:        name,
		Notes:       optionalString(notes),
		Platform:    platform,
		Type:        service.AccountTypeAPIKey,
		Credentials: credentials,
		Extra:       extra,
		Concurrency: 1,
		Priority:    50,
	}, nil
}

func platform(appType string) (string, error) {
	switch appType {
	case "claude":
		return service.PlatformAnthropic, nil
	case "codex":
		return service.PlatformOpenAI, nil
	case "gemini":
		return service.PlatformGemini, nil
	default:
		return "", fmt.Errorf("unsupported app_type %q", appType)
	}
}

func (s subscription) version() int {
	if s.FormatVersion != 0 {
		return s.FormatVersion
	}
	return s.FormatVersionCamel
}

func (p provider) appType() string {
	if strings.TrimSpace(p.AppType) != "" {
		return strings.TrimSpace(p.AppType)
	}
	return strings.TrimSpace(p.AppTypeCamel)
}

func (p provider) groupName() string {
	if strings.TrimSpace(p.GroupName) != "" {
		return strings.TrimSpace(p.GroupName)
	}
	return strings.TrimSpace(p.GroupNameCamel)
}

func (p provider) settingsConfig() map[string]any {
	if p.SettingsConfig != nil {
		return p.SettingsConfig
	}
	return p.SettingsConfigCamel
}

func (p provider) label(index int) string {
	if strings.TrimSpace(p.ID) != "" {
		return fmt.Sprintf("%q", strings.TrimSpace(p.ID))
	}
	if strings.TrimSpace(p.Name) != "" {
		return fmt.Sprintf("%q", strings.TrimSpace(p.Name))
	}
	return fmt.Sprintf("#%d", index+1)
}

func apiKey(provider provider) (string, string) {
	settings := provider.settingsConfig()
	switch provider.appType() {
	case "claude":
		return firstNestedString(settings, "env", "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"),
			"expected settings_config.env.ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN"
	case "codex":
		key := firstNestedString(settings, "auth", "OPENAI_API_KEY")
		if key == "" {
			key = firstNestedString(settings, "env", "OPENAI_API_KEY")
		}
		return key, "expected settings_config.auth.OPENAI_API_KEY or settings_config.env.OPENAI_API_KEY"
	case "gemini":
		return firstNestedString(settings, "env", "GEMINI_API_KEY", "GOOGLE_API_KEY"),
			"expected settings_config.env.GEMINI_API_KEY or GOOGLE_API_KEY"
	default:
		return "", "unsupported app_type"
	}
}

func baseURL(provider provider) string {
	settings := provider.settingsConfig()
	switch provider.appType() {
	case "claude":
		if value := firstNestedString(settings, "env", "ANTHROPIC_BASE_URL"); value != "" {
			return value
		}
	case "codex":
		if value := parseConfigString(settings, "base_url"); value != "" {
			return value
		}
		if value := firstNestedString(settings, "env", "OPENAI_BASE_URL"); value != "" {
			return value
		}
	case "gemini":
		if value := firstNestedString(settings, "env", "GOOGLE_GEMINI_BASE_URL", "GEMINI_BASE_URL"); value != "" {
			return value
		}
	}
	return firstEndpoint(provider)
}

func defaultModel(provider provider) string {
	settings := provider.settingsConfig()
	switch provider.appType() {
	case "claude":
		return firstNestedString(settings, "env", "ANTHROPIC_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL")
	case "codex":
		if value := parseConfigString(settings, "model"); value != "" {
			return value
		}
		return firstNestedString(settings, "env", "OPENAI_MODEL")
	case "gemini":
		return firstNestedString(settings, "env", "GEMINI_MODEL")
	default:
		return ""
	}
}

func firstEndpoint(provider provider) string {
	for _, endpoint := range provider.Endpoints {
		if value := strings.TrimSpace(endpoint.URL); value != "" {
			return value
		}
	}
	return ""
}

func firstNestedString(settings map[string]any, section string, keys ...string) string {
	sectionMap := asMap(settings[section])
	if sectionMap == nil {
		return ""
	}
	for _, key := range keys {
		if value := asString(sectionMap[key]); value != "" {
			return value
		}
	}
	return ""
}

func parseConfigString(settings map[string]any, key string) string {
	config := asString(settings["config"])
	if config == "" {
		return ""
	}
	prefix := key + "="
	spacedPrefix := key + " ="
	for _, line := range strings.Split(config, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "#") || line == "" {
			continue
		}
		if !strings.HasPrefix(line, prefix) && !strings.HasPrefix(line, spacedPrefix) {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		return strings.Trim(strings.TrimSpace(parts[1]), `"'`)
	}
	return ""
}

func asMap(value any) map[string]any {
	switch typed := value.(type) {
	case map[string]any:
		return typed
	case map[any]any:
		result := make(map[string]any, len(typed))
		for key, value := range typed {
			if str, ok := key.(string); ok {
				result[str] = value
			}
		}
		return result
	default:
		return nil
	}
}

func asString(value any) string {
	if str, ok := value.(string); ok {
		return strings.TrimSpace(str)
	}
	return ""
}

func cleanModels(models []string) []string {
	cleaned := make([]string, 0, len(models))
	seen := make(map[string]struct{}, len(models))
	for _, model := range models {
		model = strings.TrimSpace(model)
		if model == "" {
			continue
		}
		if _, ok := seen[model]; ok {
			continue
		}
		seen[model] = struct{}{}
		cleaned = append(cleaned, model)
	}
	return cleaned
}

func orderModels(models []string, defaultModel string) []string {
	cleaned := cleanModels(models)
	defaultModel = strings.TrimSpace(defaultModel)
	if defaultModel == "" {
		return cleaned
	}

	ordered := make([]string, 0, len(cleaned))
	for _, model := range cleaned {
		if model == defaultModel {
			ordered = append(ordered, model)
			break
		}
	}
	if len(ordered) == 0 {
		return cleaned
	}
	for _, model := range cleaned {
		if model != defaultModel {
			ordered = append(ordered, model)
		}
	}
	return ordered
}

func modelMapping(models []string) map[string]any {
	result := make(map[string]any, len(models))
	for _, model := range models {
		result[model] = model
	}
	return result
}

func optionalString(value string) *string {
	if value == "" {
		return nil
	}
	return &value
}
