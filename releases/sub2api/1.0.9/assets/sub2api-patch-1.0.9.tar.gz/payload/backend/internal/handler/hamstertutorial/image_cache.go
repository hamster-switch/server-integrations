package hamstertutorial

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type Resolver interface {
	LookupIPAddr(context.Context, string) ([]net.IPAddr, error)
}
type ImageCache struct {
	root                string
	resolver            Resolver
	maxBytes, maxPixels int64
	timeout             time.Duration
}
type ImageEntry struct {
	ID, LocalName, MediaType string
	Size                     int64
	Width, Height            int
}

func NewImageCache(root string) (*ImageCache, error) {
	absolute, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(absolute, 0o700); err != nil {
		return nil, err
	}
	return &ImageCache{root: filepath.Clean(absolute), resolver: net.DefaultResolver, maxBytes: 8 << 20, maxPixels: 20_000_000, timeout: 15 * time.Second}, nil
}

func (c *ImageCache) StoreUpload(reader io.Reader, declared string) (ImageEntry, error) {
	body, err := readLimited(reader, c.maxBytes)
	if err != nil {
		return ImageEntry{}, err
	}
	return c.store(body, declared)
}

func (c *ImageCache) Fetch(ctx context.Context, rawURL string) (ImageEntry, error) {
	ctx, cancel := context.WithTimeout(ctx, c.timeout)
	defer cancel()
	if err := c.validateURL(ctx, rawURL); err != nil {
		return ImageEntry{}, err
	}
	transport := &http.Transport{ForceAttemptHTTP2: true, TLSHandshakeTimeout: 10 * time.Second, ResponseHeaderTimeout: c.timeout, DialContext: c.safeDial}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: c.timeout, CheckRedirect: func(request *http.Request, via []*http.Request) error {
		if len(via) >= 5 {
			return errors.New("external image exceeded redirect limit")
		}
		return c.validateURL(request.Context(), request.URL.String())
	}}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return ImageEntry{}, err
	}
	request.Header.Set("Accept", "image/png,image/jpeg,image/gif")
	request.Header.Set("User-Agent", "sub2api-hamster-image-cache")
	response, err := client.Do(request)
	if err != nil {
		return ImageEntry{}, fmt.Errorf("fetch external image: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return ImageEntry{}, fmt.Errorf("external image returned HTTP %d", response.StatusCode)
	}
	body, err := readLimited(response.Body, c.maxBytes)
	if err != nil {
		return ImageEntry{}, err
	}
	return c.store(body, response.Header.Get("Content-Type"))
}

func (c *ImageCache) Path(localName string) (string, error) {
	if filepath.Base(localName) != localName {
		return "", errors.New("invalid image name")
	}
	path := filepath.Join(c.root, localName)
	if relative, err := filepath.Rel(c.root, path); err != nil || strings.HasPrefix(relative, "..") {
		return "", errors.New("image path escaped cache")
	}
	if _, err := os.Stat(path); err != nil {
		return "", err
	}
	return path, nil
}

func (c *ImageCache) validateURL(ctx context.Context, rawURL string) error {
	parsed, err := url.Parse(rawURL)
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" || parsed.User != nil || parsed.Fragment != "" {
		return errors.New("external image URL must be absolute HTTPS without userinfo or fragment")
	}
	addresses, err := c.resolver.LookupIPAddr(ctx, parsed.Hostname())
	if err != nil || len(addresses) == 0 {
		return errors.New("external image host could not be resolved")
	}
	for _, address := range addresses {
		if !publicIP(address.IP) {
			return errors.New("external image host resolved to a blocked address")
		}
	}
	return nil
}

func (c *ImageCache) safeDial(ctx context.Context, network, address string) (net.Conn, error) {
	host, port, err := net.SplitHostPort(address)
	if err != nil {
		return nil, err
	}
	addresses, err := c.resolver.LookupIPAddr(ctx, host)
	if err != nil || len(addresses) == 0 {
		return nil, errors.New("image host DNS lookup failed during connection")
	}
	for _, address := range addresses {
		if !publicIP(address.IP) {
			return nil, errors.New("image host DNS changed to a blocked address")
		}
	}
	dialer := net.Dialer{Timeout: c.timeout, KeepAlive: 15 * time.Second}
	return dialer.DialContext(ctx, network, net.JoinHostPort(addresses[0].IP.String(), port))
}

func (c *ImageCache) store(body []byte, declared string) (ImageEntry, error) {
	mediaType := http.DetectContentType(body)
	extension := map[string]string{"image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif"}[mediaType]
	if extension == "" {
		return ImageEntry{}, fmt.Errorf("unsupported image MIME %q", mediaType)
	}
	declared = strings.ToLower(strings.TrimSpace(strings.Split(declared, ";")[0]))
	if declared != "" && declared != "application/octet-stream" && declared != mediaType {
		return ImageEntry{}, errors.New("declared image MIME does not match content")
	}
	config, _, err := image.DecodeConfig(bytes.NewReader(body))
	if err != nil || config.Width <= 0 || config.Height <= 0 || int64(config.Width) > c.maxPixels/int64(config.Height) {
		return ImageEntry{}, errors.New("image dimensions are invalid or exceed pixel limit")
	}
	digest := sha256.Sum256(body)
	id := hex.EncodeToString(digest[:])
	name := id + extension
	path := filepath.Join(c.root, name)
	if _, err := os.Stat(path); errors.Is(err, os.ErrNotExist) {
		temporary := path + fmt.Sprintf(".tmp-%d", time.Now().UnixNano())
		if err := os.WriteFile(temporary, body, 0o600); err != nil {
			return ImageEntry{}, err
		}
		if err := os.Rename(temporary, path); err != nil {
			_ = os.Remove(temporary)
			return ImageEntry{}, err
		}
	} else if err != nil {
		return ImageEntry{}, err
	}
	return ImageEntry{ID: id, LocalName: name, MediaType: mediaType, Size: int64(len(body)), Width: config.Width, Height: config.Height}, nil
}

func readLimited(reader io.Reader, limit int64) ([]byte, error) {
	body, err := io.ReadAll(io.LimitReader(reader, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(body)) > limit {
		return nil, errors.New("image exceeds byte limit")
	}
	return body, nil
}

func publicIP(ip net.IP) bool {
	if ip == nil || !ip.IsGlobalUnicast() || ip.IsUnspecified() || ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() || ip.IsMulticast() {
		return false
	}
	for _, network := range blockedNetworks {
		if network.Contains(ip) {
			return false
		}
	}
	return true
}

var blockedNetworks = func() []*net.IPNet {
	values := []string{"0.0.0.0/8", "100.64.0.0/10", "192.0.0.0/24", "192.0.2.0/24", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "240.0.0.0/4", "2001:db8::/32"}
	result := make([]*net.IPNet, 0, len(values))
	for _, value := range values {
		_, network, _ := net.ParseCIDR(value)
		result = append(result, network)
	}
	return result
}()
