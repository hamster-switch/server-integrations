package hamstertutorial

import (
	"context"
	"encoding/base64"
	"net"
	"strings"
	"testing"
)

type fixedResolver []net.IPAddr

func (r fixedResolver) LookupIPAddr(context.Context, string) ([]net.IPAddr, error) { return r, nil }

func TestTutorialValidationRejectsExternalHTTP(t *testing.T) {
	tutorial := Tutorial{SchemaVersion: 1, ID: "configuration-subscription-guide-zh-cn", Version: "1.0.0", Locale: "zh-CN", Title: "配置订阅教程", Steps: []Step{{ID: "import-url", Title: "导入", BodyMD: "正文", Assets: []AssetRef{{Kind: "external", URL: "http://example.com/a.png"}}}}}
	if err := tutorial.Validate(); err == nil {
		t.Fatal("expected insecure external URL to be rejected")
	}
}

func TestManifestRejectsInvalidSignature(t *testing.T) {
	if _, err := verifyManifest([]byte(`{"schema_version":1}`), []byte("invalid")); err == nil {
		t.Fatal("expected signature verification failure")
	}
}

func TestImageCacheBlocksPrivateAddressAndStoresValidatedUpload(t *testing.T) {
	cache, err := NewImageCache(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	cache.resolver = fixedResolver{{IP: net.ParseIP("127.0.0.1")}}
	if err := cache.validateURL(context.Background(), "https://example.test/image.png"); err == nil {
		t.Fatal("expected loopback address to be blocked")
	}
	pngBody, err := base64.StdEncoding.DecodeString("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=")
	if err != nil {
		t.Fatal(err)
	}
	entry, err := cache.StoreUpload(strings.NewReader(string(pngBody)), "image/png")
	if err != nil {
		t.Fatal(err)
	}
	if entry.Width != 1 || entry.Height != 1 || entry.MediaType != "image/png" {
		t.Fatalf("unexpected entry: %+v", entry)
	}
	if _, err := cache.Path("../" + entry.LocalName); err == nil {
		t.Fatal("expected traversal to be rejected")
	}
}
