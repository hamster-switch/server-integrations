package handler

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/hamsteryaml"
	"github.com/Wei-Shaw/sub2api/internal/service"
)

type hamsterYAMLTemplateVersion struct {
	Version            int64                            `json:"version"`
	Body               string                           `json:"body"`
	Presentation       hamsteryaml.TemplatePresentation `json:"presentation"`
	Warnings           []hamsteryaml.TemplateDiagnostic `json:"warnings"`
	WarningConfirmedBy *int64                           `json:"warning_confirmed_by,omitempty"`
	WarningConfirmedAt *time.Time                       `json:"warning_confirmed_at,omitempty"`
	CreatedBy          *int64                           `json:"created_by,omitempty"`
	CreatedAt          time.Time                        `json:"created_at"`
	Active             bool                             `json:"active"`
}

type hamsterYAMLTemplateState struct {
	Draft          string                              `json:"draft"`
	Presentation   hamsteryaml.TemplatePresentation    `json:"presentation"`
	Defaults       hamsterTemplateSubscriptionDefaults `json:"defaults"`
	Groups         []hamsterTemplateGroupState         `json:"groups"`
	ProviderFields []string                            `json:"provider_fields"`
	Preview        string                              `json:"preview"`
	Diagnostics    []hamsteryaml.TemplateDiagnostic    `json:"diagnostics"`
	Current        *hamsterYAMLTemplateVersion         `json:"current,omitempty"`
	History        []hamsterYAMLTemplateVersion        `json:"history"`
}

type hamsterTemplateSubscriptionDefaults struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Icon        string `json:"icon"`
	HomeURL     string `json:"home_url"`
}

type hamsterTemplateGroupState struct {
	ID                    int64                             `json:"id"`
	Name                  string                            `json:"name"`
	Platform              string                            `json:"platform"`
	DefaultName           string                            `json:"default_name"`
	DefaultIcon           string                            `json:"default_icon"`
	Description           string                            `json:"default_description"`
	DefaultSettingsConfig map[string]any                    `json:"default_settings_config"`
	Override              *hamsteryaml.ProviderPresentation `json:"override,omitempty"`
}

var errHamsterYAMLTemplateUnpublishable = errors.New("YAML template cannot be published")

func (h *APIKeyHandler) hamsterContentDB() (*sql.DB, error) {
	db := h.apiKeyService.HamsterConfigSubscriptionDB()
	if db == nil {
		return nil, errors.New("configuration subscription database is unavailable")
	}
	return db, nil
}

func (h *APIKeyHandler) currentHamsterYAMLTemplate(ctx context.Context) (string, hamsteryaml.TemplatePresentation, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return "", hamsteryaml.TemplatePresentation{}, err
	}
	var body string
	var presentationJSON []byte
	err = db.QueryRowContext(ctx, `SELECT body, presentation FROM hamster_yaml_template_versions WHERE active ORDER BY version DESC LIMIT 1`).Scan(&body, &presentationJSON)
	if errors.Is(err, sql.ErrNoRows) {
		return hamsteryaml.DefaultSubscriptionTemplate, hamsteryaml.NormalizeTemplatePresentation(hamsteryaml.TemplatePresentation{}), nil
	}
	if err != nil {
		return "", hamsteryaml.TemplatePresentation{}, err
	}
	presentation := hamsteryaml.TemplatePresentation{}
	if len(presentationJSON) > 0 {
		if err := json.Unmarshal(presentationJSON, &presentation); err != nil {
			return "", hamsteryaml.TemplatePresentation{}, err
		}
	}
	return body, hamsteryaml.NormalizeTemplatePresentation(presentation), nil
}

func (h *APIKeyHandler) getHamsterYAMLTemplateState(ctx context.Context, baseURL string) (*hamsterYAMLTemplateState, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	state := &hamsterYAMLTemplateState{
		Draft: hamsteryaml.DefaultSubscriptionTemplate, Presentation: hamsteryaml.NormalizeTemplatePresentation(hamsteryaml.TemplatePresentation{}),
		History: []hamsterYAMLTemplateVersion{}, Groups: []hamsterTemplateGroupState{},
	}
	var diagnosticsJSON []byte
	var presentationJSON []byte
	err = db.QueryRowContext(ctx, `SELECT body, presentation, diagnostics FROM hamster_yaml_template_drafts WHERE id = 1`).Scan(&state.Draft, &presentationJSON, &diagnosticsJSON)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return nil, err
	}
	// Diagnostics are recomputed so group lifecycle and current token rules cannot leave stale draft warnings behind.
	_ = diagnosticsJSON
	state.Diagnostics = hamsteryaml.ValidateSubscriptionTemplate(state.Draft)
	if len(presentationJSON) > 0 {
		if err := json.Unmarshal(presentationJSON, &state.Presentation); err != nil {
			return nil, err
		}
	}
	state.Presentation = hamsteryaml.NormalizeTemplatePresentation(state.Presentation)
	rows, err := db.QueryContext(ctx, `
		SELECT version, body, presentation, warnings, warning_confirmed_by, warning_confirmed_at, created_by, created_at, active
		FROM hamster_yaml_template_versions ORDER BY version DESC LIMIT 50`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var version hamsterYAMLTemplateVersion
		var versionPresentationJSON, warningsJSON []byte
		if err := rows.Scan(&version.Version, &version.Body, &versionPresentationJSON, &warningsJSON, &version.WarningConfirmedBy,
			&version.WarningConfirmedAt, &version.CreatedBy, &version.CreatedAt, &version.Active); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(warningsJSON, &version.Warnings)
		_ = json.Unmarshal(versionPresentationJSON, &version.Presentation)
		version.Presentation = hamsteryaml.NormalizeTemplatePresentation(version.Presentation)
		state.History = append(state.History, version)
		if version.Active {
			copy := version
			state.Current = &copy
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if err := h.populateHamsterTemplateState(ctx, state, baseURL); err != nil {
		return nil, err
	}
	return state, nil
}

func (h *APIKeyHandler) saveHamsterYAMLTemplateDraft(ctx context.Context, adminID int64, body string, presentation hamsteryaml.TemplatePresentation) ([]hamsteryaml.TemplateDiagnostic, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	diagnostics := hamsteryaml.ValidateSubscriptionTemplate(body)
	presentation, presentationDiagnostics, err := h.normalizeHamsterTemplatePresentation(ctx, presentation)
	diagnostics = append(diagnostics, presentationDiagnostics...)
	if err != nil {
		return nil, err
	}
	encoded, err := json.Marshal(diagnostics)
	if err != nil {
		return nil, err
	}
	presentationJSON, err := json.Marshal(presentation)
	if err != nil {
		return nil, err
	}
	_, err = db.ExecContext(ctx, `
		INSERT INTO hamster_yaml_template_drafts (id, body, presentation, diagnostics, updated_by, updated_at)
		VALUES (1, $1, $2::jsonb, $3::jsonb, $4, NOW())
		ON CONFLICT (id) DO UPDATE SET body = EXCLUDED.body, presentation = EXCLUDED.presentation,
			diagnostics = EXCLUDED.diagnostics, updated_by = EXCLUDED.updated_by, updated_at = NOW()`,
		body, string(presentationJSON), string(encoded), adminID)
	return diagnostics, err
}

func (h *APIKeyHandler) publishHamsterYAMLTemplate(ctx context.Context, adminID int64, acknowledgeWarnings bool, baseURL string) (*hamsterYAMLTemplateVersion, []hamsteryaml.TemplateDiagnostic, error) {
	state, err := h.getHamsterYAMLTemplateState(ctx, baseURL)
	if err != nil {
		return nil, nil, err
	}
	diagnostics := state.Diagnostics
	var warnings []hamsteryaml.TemplateDiagnostic
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			return nil, diagnostics, fmt.Errorf("%w: template contains hard errors", errHamsterYAMLTemplateUnpublishable)
		}
		if diagnostic.Level == "warning" {
			warnings = append(warnings, diagnostic)
		}
	}
	if len(warnings) > 0 && !acknowledgeWarnings {
		return nil, diagnostics, fmt.Errorf("%w: template warnings require explicit confirmation", errHamsterYAMLTemplateUnpublishable)
	}
	version, err := h.publishHamsterYAMLTemplateBody(ctx, adminID, state.Draft, state.Presentation, warnings, acknowledgeWarnings)
	return version, diagnostics, err
}

func (h *APIKeyHandler) rollbackHamsterYAMLTemplate(ctx context.Context, adminID, targetVersion int64) (*hamsterYAMLTemplateVersion, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	var body string
	var presentationJSON, warningsJSON []byte
	if err := db.QueryRowContext(ctx, `SELECT body, presentation, warnings FROM hamster_yaml_template_versions WHERE version = $1`, targetVersion).Scan(&body, &presentationJSON, &warningsJSON); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("template version %d not found", targetVersion)
		}
		return nil, err
	}
	var warnings []hamsteryaml.TemplateDiagnostic
	_ = json.Unmarshal(warningsJSON, &warnings)
	presentation := hamsteryaml.TemplatePresentation{}
	_ = json.Unmarshal(presentationJSON, &presentation)
	return h.publishHamsterYAMLTemplateBody(ctx, adminID, body, presentation, warnings, len(warnings) > 0)
}

func (h *APIKeyHandler) publishHamsterYAMLTemplateBody(ctx context.Context, adminID int64, body string, presentation hamsteryaml.TemplatePresentation, warnings []hamsteryaml.TemplateDiagnostic, acknowledged bool) (*hamsterYAMLTemplateVersion, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer func() { _ = tx.Rollback() }()
	if _, err := tx.ExecContext(ctx, `SELECT pg_advisory_xact_lock(614728341922)`); err != nil {
		return nil, err
	}
	var next int64
	if err := tx.QueryRowContext(ctx, `SELECT COALESCE(MAX(version), 0) + 1 FROM hamster_yaml_template_versions`).Scan(&next); err != nil {
		return nil, err
	}
	warningsJSON, _ := json.Marshal(warnings)
	presentationJSON, _ := json.Marshal(hamsteryaml.NormalizeTemplatePresentation(presentation))
	if _, err := tx.ExecContext(ctx, `UPDATE hamster_yaml_template_versions SET active = FALSE WHERE active`); err != nil {
		return nil, err
	}
	version := &hamsterYAMLTemplateVersion{Version: next, Body: body, Presentation: hamsteryaml.NormalizeTemplatePresentation(presentation), Warnings: warnings, CreatedBy: &adminID, Active: true}
	var confirmedBy any
	var confirmedAt any
	if acknowledged && len(warnings) > 0 {
		now := time.Now().UTC()
		version.WarningConfirmedBy = &adminID
		version.WarningConfirmedAt = &now
		confirmedBy, confirmedAt = adminID, now
	}
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO hamster_yaml_template_versions (
			version, body, presentation, warnings, warning_confirmed_by, warning_confirmed_at, created_by, active
		) VALUES ($1, $2, $3::jsonb, $4::jsonb, $5, $6, $7, TRUE) RETURNING created_at`,
		next, body, string(presentationJSON), string(warningsJSON), confirmedBy, confirmedAt, adminID).Scan(&version.CreatedAt); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return version, nil
}

func (h *APIKeyHandler) hamsterTemplateDefaults(ctx context.Context, requestBaseURL string) (hamsterTemplateSubscriptionDefaults, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return hamsterTemplateSubscriptionDefaults{}, err
	}
	values := map[string]string{}
	rows, err := db.QueryContext(ctx, `SELECT key, value FROM settings WHERE key IN ('site_name','site_logo','site_subtitle','api_base_url')`)
	if err != nil {
		return hamsterTemplateSubscriptionDefaults{}, err
	}
	defer rows.Close()
	for rows.Next() {
		var key, value string
		if err := rows.Scan(&key, &value); err != nil {
			return hamsterTemplateSubscriptionDefaults{}, err
		}
		values[key] = strings.TrimSpace(value)
	}
	if err := rows.Err(); err != nil {
		return hamsterTemplateSubscriptionDefaults{}, err
	}
	name := values[service.SettingKeySiteName]
	if name == "" {
		name = "Sub2API"
	}
	homeURL := hamsterSwitchNormalizeBaseURL(values[service.SettingKeyAPIBaseURL])
	if homeURL == "" {
		homeURL = hamsterSwitchNormalizeBaseURL(requestBaseURL)
	}
	return hamsterTemplateSubscriptionDefaults{
		Name: name, Description: values[service.SettingKeySiteSubtitle],
		Icon: values[service.SettingKeySiteLogo], HomeURL: homeURL,
	}, nil
}

func (h *APIKeyHandler) hamsterTemplateGroups(ctx context.Context) ([]service.Group, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	rows, err := db.QueryContext(ctx, `
		SELECT id, name, platform, models_list_config, default_mapped_model
		FROM groups WHERE deleted_at IS NULL AND status = 'active'
		ORDER BY sort_order, id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	groups := []service.Group{}
	for rows.Next() {
		var group service.Group
		var modelsJSON []byte
		if err := rows.Scan(&group.ID, &group.Name, &group.Platform, &modelsJSON, &group.DefaultMappedModel); err != nil {
			return nil, err
		}
		if len(modelsJSON) > 0 {
			if err := json.Unmarshal(modelsJSON, &group.ModelsListConfig); err != nil {
				return nil, fmt.Errorf("decode group %d models_list_config: %w", group.ID, err)
			}
		}
		groups = append(groups, group)
	}
	return groups, rows.Err()
}

func (h *APIKeyHandler) normalizeHamsterTemplatePresentation(ctx context.Context, presentation hamsteryaml.TemplatePresentation) (hamsteryaml.TemplatePresentation, []hamsteryaml.TemplateDiagnostic, error) {
	presentation = hamsteryaml.NormalizeTemplatePresentation(presentation)
	groups, err := h.hamsterTemplateGroups(ctx)
	if err != nil {
		return presentation, nil, err
	}
	valid := make(map[string]bool, len(groups))
	for _, group := range groups {
		valid[fmt.Sprintf("%d", group.ID)] = true
	}
	diagnostics := []hamsteryaml.TemplateDiagnostic{}
	for groupID := range presentation.Providers {
		if valid[groupID] {
			continue
		}
		delete(presentation.Providers, groupID)
		diagnostics = append(diagnostics, hamsteryaml.TemplateDiagnostic{
			Level: "warning", Code: "REMOVED_GROUP_OVERRIDE",
			Message: fmt.Sprintf("removed template override for unavailable group %s", groupID),
		})
	}
	return presentation, diagnostics, nil
}

func (h *APIKeyHandler) populateHamsterTemplateState(ctx context.Context, state *hamsterYAMLTemplateState, baseURL string) error {
	defaults, err := h.hamsterTemplateDefaults(ctx, baseURL)
	if err != nil {
		return err
	}
	groups, err := h.hamsterTemplateGroups(ctx)
	if err != nil {
		return err
	}
	presentation, presentationDiagnostics, err := h.normalizeHamsterTemplatePresentation(ctx, state.Presentation)
	if err != nil {
		return err
	}
	state.Presentation = presentation
	state.Defaults = defaults
	state.ProviderFields = hamsteryaml.SubscriptionTemplateProviderFields(state.Draft)
	state.Diagnostics = appendHamsterTemplateDiagnostics(state.Diagnostics, presentationDiagnostics...)
	providers := make([]hamsteryaml.SubscriptionProviderAccess, 0, len(groups))
	for _, group := range groups {
		groupID := fmt.Sprintf("%d", group.ID)
		var override *hamsteryaml.ProviderPresentation
		if value, ok := presentation.Providers[groupID]; ok {
			copy := value
			override = &copy
		}
		appType, appErr := hamsterSwitchAppTypeForPlatform(group.Platform)
		models, modelErr := hamsterSwitchModelsForGroup(&group)
		if appErr != nil || modelErr != nil {
			continue
		}
		apiBaseURL := hamsterSwitchJoinURLPath(baseURL, hamsterSwitchAPIPath(appType))
		defaultSettingsConfig := hamsteryaml.DefaultSubscriptionSettingsConfig(appType, "{{provider.api_key}}", apiBaseURL, models[0])
		state.Groups = append(state.Groups, hamsterTemplateGroupState{
			ID: group.ID, Name: group.Name, Platform: group.Platform, DefaultName: group.Name,
			DefaultIcon: hamsteryaml.PlatformIcon(group.Platform), Description: "", Override: override,
			DefaultSettingsConfig: defaultSettingsConfig,
		})
		providers = append(providers, hamsteryaml.SubscriptionProviderAccess{
			ID: hamsterSwitchProviderID(group.ID, group.Name, appType), AppType: appType,
			GroupName: group.Name, Name: group.Name, Description: "", Icon: hamsteryaml.PlatformIcon(group.Platform),
			Models: models, ClientAPIKey: "{{provider.api_key}}", GroupID: group.ID, Platform: group.Platform,
			SettingsConfig: defaultSettingsConfig,
		})
	}
	if len(providers) == 0 {
		state.Diagnostics = append(state.Diagnostics, hamsteryaml.TemplateDiagnostic{Level: "warning", Code: "NO_PREVIEW_PROVIDERS", Message: "no active group can be rendered in the template preview"})
		return nil
	}
	options := hamsteryaml.SubscriptionExportOptions{
		Name: defaults.Name, Description: defaults.Description, Icon: defaults.Icon,
		HomeURL: defaults.HomeURL, BaseURL: baseURL, UpdatedAt: time.Now().UTC(),
	}
	hamsteryaml.ApplyTemplatePresentation(presentation, &options, providers)
	rendered, diagnostics, err := hamsteryaml.RenderSubscriptionTemplate(state.Draft, options, providers)
	state.Diagnostics = appendHamsterTemplateDiagnostics(state.Diagnostics, diagnostics...)
	if err != nil {
		state.Diagnostics = appendHamsterTemplateDiagnostics(state.Diagnostics, hamsteryaml.TemplateDiagnostic{
			Level: "error", Code: "RENDER_FAILED", Message: err.Error(),
		})
		return nil
	}
	state.Preview = string(rendered)
	return nil
}

func appendHamsterTemplateDiagnostics(existing []hamsteryaml.TemplateDiagnostic, additions ...hamsteryaml.TemplateDiagnostic) []hamsteryaml.TemplateDiagnostic {
	seen := make(map[string]struct{}, len(existing)+len(additions))
	for _, diagnostic := range existing {
		seen[diagnostic.Level+"\x00"+diagnostic.Code+"\x00"+diagnostic.Message] = struct{}{}
	}
	for _, diagnostic := range additions {
		key := diagnostic.Level + "\x00" + diagnostic.Code + "\x00" + diagnostic.Message
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		existing = append(existing, diagnostic)
	}
	return existing
}
