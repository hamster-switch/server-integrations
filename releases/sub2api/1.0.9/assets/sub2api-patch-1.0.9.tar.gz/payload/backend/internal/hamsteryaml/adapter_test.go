package hamsteryaml

import (
	"strings"
	"testing"

	"github.com/Wei-Shaw/sub2api/internal/service"
)

const fullYAML = `
format_version: 1
name: Gateway Example
providers:
  - id: claude-main
    app_type: claude
    group_name: default
    name: Claude Main
    models:
      - claude-3-5-sonnet-20241022
      - claude-3-opus-20240229
    settings_config:
      env:
        ANTHROPIC_API_KEY: sk-ant-example
        ANTHROPIC_BASE_URL: https://claude.example/v1
        ANTHROPIC_MODEL: claude-3-opus-20240229
  - id: codex-main
    app_type: codex
    group_name: default
    name: Codex Main
    models:
      - gpt-5
      - gpt-5-mini
    settings_config:
      auth:
        OPENAI_API_KEY: sk-openai-example
      config: |
        model_provider = "custom"
        model = "gpt-5"
        [model_providers.custom]
        base_url = "https://codex.example/v1"
  - id: gemini-main
    app_type: gemini
    group_name: research
    name: Gemini Main
    models:
      - gemini-2.5-pro
    settings_config:
      env:
        GEMINI_API_KEY: gemini-example
        GOOGLE_GEMINI_BASE_URL: https://gemini.example
        GEMINI_MODEL: gemini-2.5-pro
`

func TestParseCreateAccountRequests(t *testing.T) {
	requests, err := ParseCreateAccountRequests([]byte(fullYAML))
	if err != nil {
		t.Fatalf("ParseCreateAccountRequests() error = %v", err)
	}

	if len(requests) != 3 {
		t.Fatalf("expected three requests, got %d", len(requests))
	}
	if requests[0].Platform != service.PlatformAnthropic {
		t.Fatalf("unexpected claude platform: %q", requests[0].Platform)
	}
	if requests[1].Platform != service.PlatformOpenAI {
		t.Fatalf("unexpected codex platform: %q", requests[1].Platform)
	}
	if requests[2].Platform != service.PlatformGemini {
		t.Fatalf("unexpected gemini platform: %q", requests[2].Platform)
	}
	if requests[0].Credentials["base_url"] != "https://claude.example/v1" {
		t.Fatalf("unexpected claude base url: %#v", requests[0].Credentials["base_url"])
	}
	mapping, ok := requests[0].Credentials["model_mapping"].(map[string]any)
	if !ok {
		t.Fatalf("expected model_mapping map, got %#v", requests[0].Credentials["model_mapping"])
	}
	if mapping["claude-3-opus-20240229"] != "claude-3-opus-20240229" {
		t.Fatalf("missing default claude model mapping: %#v", mapping)
	}
	if requests[1].Extra["hamster_default_model"] != "gpt-5" {
		t.Fatalf("unexpected codex default model: %#v", requests[1].Extra["hamster_default_model"])
	}
	if requests[2].Extra["hamster_group_name"] != "research" {
		t.Fatalf("unexpected gemini group: %#v", requests[2].Extra["hamster_group_name"])
	}
}

func TestParseCreateAccountRequestsMissingAPIKey(t *testing.T) {
	input := `
format_version: 1
name: Missing Key
providers:
  - id: claude-missing
    app_type: claude
    group_name: default
    name: Claude Missing
    models: [claude-3-5-sonnet-20241022]
    settings_config:
      env:
        ANTHROPIC_BASE_URL: https://claude.example/v1
`
	_, err := ParseCreateAccountRequests([]byte(input))
	if err == nil {
		t.Fatal("expected missing API key error")
	}
	if !strings.Contains(err.Error(), "ANTHROPIC_API_KEY") {
		t.Fatalf("expected ANTHROPIC_API_KEY hint, got %v", err)
	}
}

func TestParseCreateAccountRequestsMultipleProvidersAndModels(t *testing.T) {
	input := `
format_version: 1
name: Multi Provider
providers:
  - id: gemini-a
    app_type: gemini
    group_name: default
    name: Gemini A
    models: [gemini-2.5-pro, gemini-2.5-flash]
    settings_config:
      env:
        GEMINI_API_KEY: gemini-a
  - id: gemini-b
    app_type: gemini
    group_name: default
    name: Gemini B
    models: [gemini-2.5-flash]
    settings_config:
      env:
        GEMINI_API_KEY: gemini-b
`
	requests, err := ParseCreateAccountRequests([]byte(input))
	if err != nil {
		t.Fatalf("ParseCreateAccountRequests() error = %v", err)
	}
	if len(requests) != 2 {
		t.Fatalf("expected two requests, got %d", len(requests))
	}
	mapping, ok := requests[0].Credentials["model_mapping"].(map[string]any)
	if !ok {
		t.Fatalf("expected model_mapping map, got %#v", requests[0].Credentials["model_mapping"])
	}
	if len(mapping) != 2 {
		t.Fatalf("expected two model mappings, got %d", len(mapping))
	}
}
