package hamstertutorial

import (
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

const (
	PublicKeyBase64   = "7Hd2E2OF8wLrBrrYJXwBHCE+Y0SfgjzOAZI9VCZ2r2c="
	defaultReleaseAPI = "https://api.github.com/repos/hamster-switch/managed-content"
)

var (
	idPattern      = regexp.MustCompile(`^[a-z0-9]+(?:[._-][a-z0-9]+)*$`)
	versionPattern = regexp.MustCompile(`^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z]+(?:[.-][0-9A-Za-z]+)*)?$`)
)

type AssetRef struct {
	Kind string `json:"kind"`
	ID   string `json:"id,omitempty"`
	URL  string `json:"url,omitempty"`
}

type Step struct {
	ID       string     `json:"id"`
	Title    string     `json:"title"`
	BodyMD   string     `json:"body_md"`
	Assets   []AssetRef `json:"assets,omitempty"`
	Optional bool       `json:"optional,omitempty"`
}

type Tutorial struct {
	SchemaVersion int    `json:"schema_version"`
	ID            string `json:"id"`
	Version       string `json:"version"`
	Locale        string `json:"locale"`
	Title         string `json:"title"`
	Steps         []Step `json:"steps"`
}

func (t Tutorial) Validate() error {
	if t.SchemaVersion != 1 || !idPattern.MatchString(t.ID) || !versionPattern.MatchString(t.Version) || strings.TrimSpace(t.Title) == "" {
		return errors.New("invalid tutorial metadata")
	}
	if t.Locale != "zh-CN" && t.Locale != "en-US" {
		return fmt.Errorf("unsupported tutorial locale %q", t.Locale)
	}
	if len(t.Steps) == 0 {
		return errors.New("tutorial requires at least one step")
	}
	seen := map[string]bool{}
	for _, step := range t.Steps {
		if !idPattern.MatchString(step.ID) || strings.TrimSpace(step.Title) == "" || strings.TrimSpace(step.BodyMD) == "" || seen[step.ID] {
			return fmt.Errorf("invalid tutorial step %q", step.ID)
		}
		seen[step.ID] = true
		for _, asset := range step.Assets {
			switch asset.Kind {
			case "release", "site":
				if !idPattern.MatchString(asset.ID) || asset.URL != "" {
					return fmt.Errorf("step %s has invalid local asset", step.ID)
				}
			case "external":
				parsed, err := url.Parse(asset.URL)
				if err != nil || parsed.Scheme != "https" || parsed.Host == "" || asset.ID != "" {
					return fmt.Errorf("step %s has invalid external asset", step.ID)
				}
			default:
				return fmt.Errorf("step %s has unsupported asset kind", step.ID)
			}
		}
	}
	return nil
}

type ManifestAsset struct {
	ID          string `json:"id"`
	Path        string `json:"path"`
	ReleaseName string `json:"release_name"`
	Type        string `json:"type"`
	Version     string `json:"version"`
	SHA256      string `json:"sha256"`
	MediaType   string `json:"media_type"`
}

type Manifest struct {
	SchemaVersion int             `json:"schema_version"`
	ReleaseID     string          `json:"release_id"`
	Version       string          `json:"version"`
	PublishedAt   time.Time       `json:"published_at"`
	DSLVersion    string          `json:"dsl_version"`
	Assets        []ManifestAsset `json:"assets"`
}

type Snapshot struct {
	Version  string
	Tutorial Tutorial
	Images   map[string]ImageAsset
}

type ImageAsset struct {
	ID        string
	MediaType string
	Body      []byte
}

type releaseAsset struct {
	Name string `json:"name"`
	URL  string `json:"browser_download_url"`
}
type release struct {
	Tag        string         `json:"tag_name"`
	Draft      bool           `json:"draft"`
	Prerelease bool           `json:"prerelease"`
	Assets     []releaseAsset `json:"assets"`
}

type ReleaseClient struct {
	HTTP    *http.Client
	BaseURL string
}

func NewReleaseClient() ReleaseClient {
	return ReleaseClient{HTTP: &http.Client{Timeout: 45 * time.Second}, BaseURL: defaultReleaseAPI}
}

func (c ReleaseClient) FetchLatest(ctx context.Context) (Snapshot, error) {
	body, err := c.get(ctx, c.BaseURL+"/releases?per_page=100", 4<<20)
	if err != nil {
		return Snapshot{}, err
	}
	var releases []release
	if err := json.Unmarshal(body, &releases); err != nil {
		return Snapshot{}, err
	}
	for _, item := range releases {
		if !item.Draft && !item.Prerelease && strings.HasPrefix(item.Tag, "content-v") {
			return c.fetchRelease(ctx, item)
		}
	}
	return Snapshot{}, errors.New("no formal content-v Release is available")
}

func (c ReleaseClient) fetchRelease(ctx context.Context, item release) (Snapshot, error) {
	assets := map[string]releaseAsset{}
	for _, asset := range item.Assets {
		assets[asset.Name] = asset
	}
	manifestRef, okManifest := assets["manifest.json"]
	signatureRef, okSignature := assets["manifest.json.sig"]
	if !okManifest || !okSignature {
		return Snapshot{}, errors.New("formal Release is missing signed manifest assets")
	}
	manifestBytes, err := c.get(ctx, manifestRef.URL, 4<<20)
	if err != nil {
		return Snapshot{}, err
	}
	signatureBytes, err := c.get(ctx, signatureRef.URL, 4096)
	if err != nil {
		return Snapshot{}, err
	}
	manifest, err := verifyManifest(manifestBytes, signatureBytes)
	if err != nil {
		return Snapshot{}, err
	}
	if item.Tag != "content-v"+manifest.Version {
		return Snapshot{}, errors.New("Release tag does not match signed manifest version")
	}
	result := Snapshot{Version: manifest.Version, Images: map[string]ImageAsset{}}
	foundTutorial := false
	var total int64
	for _, declared := range manifest.Assets {
		ref, ok := assets[declared.ReleaseName]
		if !ok {
			return Snapshot{}, fmt.Errorf("Release asset %q is missing", declared.ReleaseName)
		}
		limit := int64(32 << 20)
		if declared.Type == "image" {
			limit = 8 << 20
		}
		body, err := c.get(ctx, ref.URL, limit)
		if err != nil {
			return Snapshot{}, err
		}
		digest := sha256.Sum256(body)
		if hex.EncodeToString(digest[:]) != declared.SHA256 {
			return Snapshot{}, fmt.Errorf("Release asset %q failed SHA-256 verification", declared.ReleaseName)
		}
		total += int64(len(body))
		if total > 256<<20 {
			return Snapshot{}, errors.New("managed-content snapshot exceeds 256 MiB")
		}
		if declared.Type == "image" {
			result.Images[declared.ID] = ImageAsset{ID: declared.ID, MediaType: declared.MediaType, Body: body}
			continue
		}
		if declared.Type != "tutorial" {
			continue
		}
		var tutorial Tutorial
		if err := json.Unmarshal(body, &tutorial); err != nil {
			return Snapshot{}, err
		}
		if tutorial.ID == "configuration-subscription-guide-zh-cn" {
			if err := tutorial.Validate(); err != nil {
				return Snapshot{}, err
			}
			result.Tutorial, foundTutorial = tutorial, true
		}
	}
	if !foundTutorial {
		return Snapshot{}, errors.New("formal Release has no configuration subscription tutorial")
	}
	return result, nil
}

func verifyManifest(body, signatureBody []byte) (Manifest, error) {
	publicKey, err := base64.StdEncoding.DecodeString(PublicKeyBase64)
	if err != nil || len(publicKey) != ed25519.PublicKeySize {
		return Manifest{}, errors.New("embedded managed-content public key is invalid")
	}
	signature, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(signatureBody)))
	if err != nil || len(signature) != ed25519.SignatureSize || !ed25519.Verify(ed25519.PublicKey(publicKey), body, signature) {
		return Manifest{}, errors.New("managed-content manifest signature verification failed")
	}
	var manifest Manifest
	if err := json.Unmarshal(body, &manifest); err != nil {
		return Manifest{}, err
	}
	if manifest.SchemaVersion != 1 || manifest.DSLVersion != "hamster-template/v1" || !idPattern.MatchString(manifest.ReleaseID) || !versionPattern.MatchString(manifest.Version) || manifest.PublishedAt.IsZero() || len(manifest.Assets) == 0 {
		return Manifest{}, errors.New("signed managed-content manifest is invalid")
	}
	seenID, seenName := map[string]bool{}, map[string]bool{}
	for _, asset := range manifest.Assets {
		validType := asset.Type == "tutorial" || asset.Type == "template-metadata" || asset.Type == "template" || asset.Type == "image"
		if !idPattern.MatchString(asset.ID) || strings.TrimSpace(asset.Path) == "" || strings.Contains(asset.Path, "..") || asset.ReleaseName == "" || strings.ContainsAny(asset.ReleaseName, "/\\") || !validType || !versionPattern.MatchString(asset.Version) || len(asset.SHA256) != 64 || asset.MediaType == "" || seenID[asset.ID] || seenName[asset.ReleaseName] {
			return Manifest{}, fmt.Errorf("signed managed-content asset %q is invalid", asset.ID)
		}
		if _, err := hex.DecodeString(asset.SHA256); err != nil {
			return Manifest{}, fmt.Errorf("signed managed-content asset %q has invalid digest", asset.ID)
		}
		seenID[asset.ID], seenName[asset.ReleaseName] = true, true
	}
	return manifest, nil
}

func (c ReleaseClient) get(ctx context.Context, endpoint string, limit int64) ([]byte, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Accept", "application/vnd.github+json")
	request.Header.Set("User-Agent", "sub2api-hamster-managed-content")
	response, err := c.HTTP.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return nil, fmt.Errorf("managed-content Release returned HTTP %d", response.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(body)) > limit {
		return nil, errors.New("managed-content Release asset exceeds size limit")
	}
	return body, nil
}
