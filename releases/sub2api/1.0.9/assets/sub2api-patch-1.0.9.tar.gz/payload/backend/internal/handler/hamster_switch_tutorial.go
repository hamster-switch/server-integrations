package handler

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/Wei-Shaw/sub2api/internal/handler/hamstertutorial"
	"github.com/Wei-Shaw/sub2api/internal/pkg/response"
	middleware2 "github.com/Wei-Shaw/sub2api/internal/server/middleware"
	"github.com/gin-gonic/gin"
)

type hamsterTutorialOverride struct {
	StepID   string                     `json:"step_id"`
	Title    string                     `json:"title"`
	BodyMD   string                     `json:"body_md"`
	Assets   []hamstertutorial.AssetRef `json:"assets,omitempty"`
	Optional bool                       `json:"optional,omitempty"`
	Hidden   bool                       `json:"hidden,omitempty"`
	Position int                        `json:"position"`
}

type hamsterTutorialConflict struct {
	StepID string `json:"step_id"`
	Change string `json:"change"`
}

func builtinHamsterTutorial() hamstertutorial.Tutorial {
	return hamstertutorial.Tutorial{SchemaVersion: 1, ID: "configuration-subscription-guide-zh-cn", Version: "0.0.0", Locale: "zh-CN", Title: "配置订阅教程", Steps: []hamstertutorial.Step{{ID: "site-content-pending", Title: "教程内容待维护", BodyMD: "站点管理员尚未发布配置订阅教程内容。"}}}
}

func (h *APIKeyHandler) GetHamsterSwitchTutorial(c *gin.Context) {
	if _, ok := middleware2.GetAuthSubjectFromContext(c); !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	tutorial, err := h.mergedHamsterTutorial(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, tutorial)
}

func (h *APIKeyHandler) GetHamsterSwitchTutorialAdmin(c *gin.Context) {
	if _, ok := middleware2.GetAuthSubjectFromContext(c); !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	base, err := h.currentHamsterTutorial(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	overrides, err := h.hamsterTutorialOverrides(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	if base.Steps == nil {
		base.Steps = []hamstertutorial.Step{}
	}
	if overrides == nil {
		overrides = []hamsterTutorialOverride{}
	}
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	var candidateVersion string
	var candidateBody, conflictsBody []byte
	err = db.QueryRowContext(c.Request.Context(), `SELECT version, body, conflicts FROM hamster_tutorial_candidates ORDER BY created_at DESC LIMIT 1`).Scan(&candidateVersion, &candidateBody, &conflictsBody)
	var candidate any
	if err == nil {
		var body hamstertutorial.Tutorial
		var conflicts []hamsterTutorialConflict
		if err := json.Unmarshal(candidateBody, &body); err != nil {
			response.ErrorFrom(c, err)
			return
		}
		if err := json.Unmarshal(conflictsBody, &conflicts); err != nil {
			response.ErrorFrom(c, err)
			return
		}
		if body.Steps == nil {
			body.Steps = []hamstertutorial.Step{}
		}
		if conflicts == nil {
			conflicts = []hamsterTutorialConflict{}
		}
		candidate = gin.H{"version": candidateVersion, "tutorial": body, "conflicts": conflicts}
	} else if !errors.Is(err, sql.ErrNoRows) {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"base": base, "overrides": overrides, "candidate": candidate})
}

func (h *APIKeyHandler) CheckHamsterSwitchTutorialUpdate(c *gin.Context) {
	if _, ok := middleware2.GetAuthSubjectFromContext(c); !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	snapshot, err := hamstertutorial.NewReleaseClient().FetchLatest(c.Request.Context())
	if err != nil {
		response.Error(c, http.StatusBadGateway, err.Error())
		return
	}
	for _, step := range snapshot.Tutorial.Steps {
		for _, asset := range step.Assets {
			if asset.Kind == "release" {
				if _, ok := snapshot.Images[asset.ID]; !ok {
					response.Error(c, http.StatusBadGateway, "signed tutorial references a missing Release image")
					return
				}
			}
		}
	}
	if err := h.storeHamsterReleaseImages(c.Request.Context(), snapshot); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	current, err := h.currentHamsterTutorial(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	overrides, err := h.hamsterTutorialOverrides(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	conflicts := tutorialConflicts(current, snapshot.Tutorial, overrides)
	body, _ := json.Marshal(snapshot.Tutorial)
	conflictBody, _ := json.Marshal(conflicts)
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	tx, err := db.BeginTx(c.Request.Context(), nil)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	defer func() { _ = tx.Rollback() }()
	if _, err = tx.ExecContext(c.Request.Context(), `SELECT pg_advisory_xact_lock(614728341923)`); err == nil {
		_, err = tx.ExecContext(c.Request.Context(), `DELETE FROM hamster_tutorial_candidates WHERE version <> $1`, snapshot.Version)
	}
	if err == nil {
		_, err = tx.ExecContext(c.Request.Context(), `INSERT INTO hamster_tutorial_candidates (version, body, conflicts, created_at) VALUES ($1, $2::jsonb, $3::jsonb, NOW()) ON CONFLICT (version) DO UPDATE SET body=EXCLUDED.body, conflicts=EXCLUDED.conflicts, created_at=NOW()`, snapshot.Version, string(body), string(conflictBody))
	}
	if err == nil {
		err = tx.Commit()
	}
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"version": snapshot.Version, "tutorial": snapshot.Tutorial, "conflicts": conflicts, "changed": tutorialChanged(current, snapshot.Tutorial)})
}

func (h *APIKeyHandler) AdoptHamsterSwitchTutorialUpdate(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req struct {
		Version     string            `json:"version"`
		Resolutions map[string]string `json:"resolutions"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	tx, err := db.BeginTx(c.Request.Context(), nil)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	defer func() { _ = tx.Rollback() }()
	if _, err := tx.ExecContext(c.Request.Context(), `SELECT pg_advisory_xact_lock(614728341923)`); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	var body, conflictsBody []byte
	if err := tx.QueryRowContext(c.Request.Context(), `SELECT body, conflicts FROM hamster_tutorial_candidates WHERE version=$1 FOR UPDATE`, req.Version).Scan(&body, &conflictsBody); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			response.NotFound(c, "tutorial candidate not found")
		} else {
			response.ErrorFrom(c, err)
		}
		return
	}
	var conflicts []hamsterTutorialConflict
	if err := json.Unmarshal(conflictsBody, &conflicts); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	for _, conflict := range conflicts {
		if req.Resolutions[conflict.StepID] != "keep_site" && req.Resolutions[conflict.StepID] != "use_release" {
			response.Error(c, http.StatusConflict, "every tutorial conflict requires an explicit resolution")
			return
		}
	}
	for _, conflict := range conflicts {
		if req.Resolutions[conflict.StepID] == "use_release" {
			if _, err := tx.ExecContext(c.Request.Context(), `DELETE FROM hamster_tutorial_site_overrides WHERE step_id=$1`, conflict.StepID); err != nil {
				response.ErrorFrom(c, err)
				return
			}
		}
	}
	if _, err := tx.ExecContext(c.Request.Context(), `UPDATE hamster_tutorial_snapshots SET active=FALSE WHERE active`); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	if _, err := tx.ExecContext(c.Request.Context(), `INSERT INTO hamster_tutorial_snapshots (version, body, source, active, created_by) VALUES ($1,$2::jsonb,'release',TRUE,$3) ON CONFLICT (version) DO UPDATE SET body=EXCLUDED.body, source='release', active=TRUE, created_by=EXCLUDED.created_by, created_at=NOW()`, req.Version, string(body), subject.UserID); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	if _, err := tx.ExecContext(c.Request.Context(), `DELETE FROM hamster_tutorial_candidates WHERE version=$1`, req.Version); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	if err := tx.Commit(); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"version": req.Version})
}

func (h *APIKeyHandler) RejectHamsterSwitchTutorialUpdate(c *gin.Context) {
	if _, ok := middleware2.GetAuthSubjectFromContext(c); !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var req struct {
		Version string `json:"version"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	tx, err := db.BeginTx(c.Request.Context(), nil)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	defer func() { _ = tx.Rollback() }()
	if _, err = tx.ExecContext(c.Request.Context(), `SELECT pg_advisory_xact_lock(614728341923)`); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	result, err := tx.ExecContext(c.Request.Context(), `DELETE FROM hamster_tutorial_candidates WHERE version=$1`, req.Version)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	affected, _ := result.RowsAffected()
	if affected != 1 {
		response.NotFound(c, "tutorial candidate not found")
		return
	}
	if err := tx.Commit(); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, nil)
}

func (h *APIKeyHandler) SaveHamsterSwitchTutorialOverride(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	var override hamsterTutorialOverride
	if err := c.ShouldBindJSON(&override); err != nil {
		response.BadRequest(c, "Invalid request: "+err.Error())
		return
	}
	override.StepID = c.Param("stepId")
	if err := validateTutorialOverride(override); err != nil {
		response.Error(c, http.StatusUnprocessableEntity, err.Error())
		return
	}
	for index, asset := range override.Assets {
		if asset.Kind == "external" {
			entry, err := h.cacheHamsterExternalImage(c.Request.Context(), subject.UserID, asset.URL)
			if err != nil {
				response.Error(c, http.StatusUnprocessableEntity, err.Error())
				return
			}
			override.Assets[index] = hamstertutorial.AssetRef{Kind: "site", ID: entry.ID}
		}
	}
	base, err := h.currentHamsterTutorial(c.Request.Context())
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	body, _ := json.Marshal(override)
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	_, err = db.ExecContext(c.Request.Context(), `INSERT INTO hamster_tutorial_site_overrides (step_id,body,base_version,updated_by,updated_at) VALUES ($1,$2::jsonb,$3,$4,NOW()) ON CONFLICT(step_id) DO UPDATE SET body=EXCLUDED.body,base_version=EXCLUDED.base_version,updated_by=EXCLUDED.updated_by,updated_at=NOW()`, override.StepID, string(body), base.Version, subject.UserID)
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, override)
}

func (h *APIKeyHandler) DeleteHamsterSwitchTutorialOverride(c *gin.Context) {
	if _, ok := middleware2.GetAuthSubjectFromContext(c); !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	_, err = db.ExecContext(c.Request.Context(), `DELETE FROM hamster_tutorial_site_overrides WHERE step_id=$1`, c.Param("stepId"))
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, nil)
}

func (h *APIKeyHandler) UploadHamsterSwitchTutorialImage(c *gin.Context) {
	subject, ok := middleware2.GetAuthSubjectFromContext(c)
	if !ok {
		response.Unauthorized(c, "User not authenticated")
		return
	}
	c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, 9<<20)
	file, err := c.FormFile("file")
	if err != nil {
		response.BadRequest(c, "image file is required")
		return
	}
	opened, err := file.Open()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	defer opened.Close()
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	entry, err := cache.StoreUpload(opened, file.Header.Get("Content-Type"))
	if err != nil {
		response.Error(c, http.StatusUnprocessableEntity, err.Error())
		return
	}
	if err := h.recordHamsterTutorialImage(c.Request.Context(), entry.ID, entry, "", subject.UserID); err != nil {
		response.ErrorFrom(c, err)
		return
	}
	response.Success(c, gin.H{"id": entry.ID, "url": "/api/hamster-switch/tutorial/images/" + entry.ID})
}

func (h *APIKeyHandler) GetHamsterSwitchTutorialImage(c *gin.Context) {
	db, err := h.hamsterContentDB()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	var localName, mediaType string
	if err := db.QueryRowContext(c.Request.Context(), `SELECT local_name,media_type FROM hamster_tutorial_images WHERE id=$1`, c.Param("id")).Scan(&localName, &mediaType); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			response.NotFound(c, "tutorial image not found")
		} else {
			response.ErrorFrom(c, err)
		}
		return
	}
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		response.ErrorFrom(c, err)
		return
	}
	path, err := cache.Path(localName)
	if err != nil {
		response.NotFound(c, "tutorial image not found")
		return
	}
	c.Header("Cache-Control", "public, max-age=31536000, immutable")
	c.Header("Content-Type", mediaType)
	c.File(path)
}

func (h *APIKeyHandler) currentHamsterTutorial(ctx context.Context) (hamstertutorial.Tutorial, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return hamstertutorial.Tutorial{}, err
	}
	var body []byte
	err = db.QueryRowContext(ctx, `SELECT body FROM hamster_tutorial_snapshots WHERE active ORDER BY created_at DESC LIMIT 1`).Scan(&body)
	if errors.Is(err, sql.ErrNoRows) {
		return builtinHamsterTutorial(), nil
	}
	if err != nil {
		return hamstertutorial.Tutorial{}, err
	}
	var result hamstertutorial.Tutorial
	if err := json.Unmarshal(body, &result); err != nil {
		return hamstertutorial.Tutorial{}, err
	}
	return result, result.Validate()
}

func (h *APIKeyHandler) mergedHamsterTutorial(ctx context.Context) (hamstertutorial.Tutorial, error) {
	base, err := h.currentHamsterTutorial(ctx)
	if err != nil {
		return base, err
	}
	overrides, err := h.hamsterTutorialOverrides(ctx)
	if err != nil {
		return base, err
	}
	byID := map[string]hamsterTutorialOverride{}
	for _, override := range overrides {
		byID[override.StepID] = override
	}
	steps := []struct {
		step     hamstertutorial.Step
		position int
	}{}
	seen := map[string]bool{}
	for index, step := range base.Steps {
		seen[step.ID] = true
		position := index * 100
		if override, ok := byID[step.ID]; ok {
			if override.Hidden {
				continue
			}
			step.Title, step.BodyMD, step.Assets, step.Optional = override.Title, override.BodyMD, override.Assets, override.Optional
			position = override.Position
		}
		steps = append(steps, struct {
			step     hamstertutorial.Step
			position int
		}{step, position})
	}
	for _, override := range overrides {
		if seen[override.StepID] || override.Hidden {
			continue
		}
		steps = append(steps, struct {
			step     hamstertutorial.Step
			position int
		}{hamstertutorial.Step{ID: override.StepID, Title: override.Title, BodyMD: override.BodyMD, Assets: override.Assets, Optional: override.Optional}, override.Position})
	}
	sort.SliceStable(steps, func(i, j int) bool { return steps[i].position < steps[j].position })
	base.Steps = nil
	for _, item := range steps {
		for index, asset := range item.step.Assets {
			if asset.Kind == "release" || asset.Kind == "site" {
				item.step.Assets[index].URL = "/api/hamster-switch/tutorial/images/" + asset.ID
			}
		}
		base.Steps = append(base.Steps, item.step)
	}
	return base, nil
}

func (h *APIKeyHandler) hamsterTutorialOverrides(ctx context.Context) ([]hamsterTutorialOverride, error) {
	db, err := h.hamsterContentDB()
	if err != nil {
		return nil, err
	}
	rows, err := db.QueryContext(ctx, `SELECT body FROM hamster_tutorial_site_overrides ORDER BY step_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []hamsterTutorialOverride{}
	for rows.Next() {
		var body []byte
		if err := rows.Scan(&body); err != nil {
			return nil, err
		}
		var item hamsterTutorialOverride
		if err := json.Unmarshal(body, &item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}
	return result, rows.Err()
}

func tutorialConflicts(current, next hamstertutorial.Tutorial, overrides []hamsterTutorialOverride) []hamsterTutorialConflict {
	old := map[string]hamstertutorial.Step{}
	fresh := map[string]hamstertutorial.Step{}
	for _, s := range current.Steps {
		old[s.ID] = s
	}
	for _, s := range next.Steps {
		fresh[s.ID] = s
	}
	var result []hamsterTutorialConflict
	for _, o := range overrides {
		a, aok := old[o.StepID]
		b, bok := fresh[o.StepID]
		change := ""
		if aok && !bok {
			change = "deleted"
		} else if aok && bok {
			aj, _ := json.Marshal(a)
			bj, _ := json.Marshal(b)
			if string(aj) != string(bj) {
				change = "modified"
			}
		}
		if change != "" {
			result = append(result, hamsterTutorialConflict{StepID: o.StepID, Change: change})
		}
	}
	sort.Slice(result, func(i, j int) bool { return result[i].StepID < result[j].StepID })
	return result
}
func tutorialChanged(current, next hamstertutorial.Tutorial) bool {
	a, _ := json.Marshal(current)
	b, _ := json.Marshal(next)
	return string(a) != string(b)
}
func validateTutorialOverride(o hamsterTutorialOverride) error {
	if strings.TrimSpace(o.StepID) == "" || strings.TrimSpace(o.Title) == "" || strings.TrimSpace(o.BodyMD) == "" {
		return errors.New("step_id, title and body_md are required")
	}
	test := hamstertutorial.Tutorial{SchemaVersion: 1, ID: "site-override-validation", Version: "0.0.0", Locale: "zh-CN", Title: "validation", Steps: []hamstertutorial.Step{{ID: o.StepID, Title: o.Title, BodyMD: o.BodyMD, Assets: o.Assets}}}
	return test.Validate()
}

func hamsterTutorialImageCache() (*hamstertutorial.ImageCache, error) {
	root := strings.TrimSpace(os.Getenv("HAMSTER_SWITCH_CONTENT_DIR"))
	if root == "" {
		root = filepath.Join("data", "hamster-switch")
	}
	return hamstertutorial.NewImageCache(filepath.Join(root, "tutorial-images"))
}
func (h *APIKeyHandler) recordHamsterTutorialImage(ctx context.Context, id string, entry hamstertutorial.ImageEntry, source string, userID int64) error {
	db, err := h.hamsterContentDB()
	if err != nil {
		return err
	}
	_, err = db.ExecContext(ctx, `INSERT INTO hamster_tutorial_images(id,local_name,media_type,size_bytes,width,height,source_url,created_by)VALUES($1,$2,$3,$4,$5,$6,NULLIF($7,''),NULLIF($8,0))ON CONFLICT(id)DO UPDATE SET local_name=EXCLUDED.local_name,media_type=EXCLUDED.media_type,size_bytes=EXCLUDED.size_bytes,width=EXCLUDED.width,height=EXCLUDED.height,source_url=EXCLUDED.source_url`, id, entry.LocalName, entry.MediaType, entry.Size, entry.Width, entry.Height, source, userID)
	return err
}
func (h *APIKeyHandler) cacheHamsterExternalImage(ctx context.Context, userID int64, source string) (hamstertutorial.ImageEntry, error) {
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		return hamstertutorial.ImageEntry{}, err
	}
	entry, err := cache.Fetch(ctx, source)
	if err != nil {
		return entry, err
	}
	return entry, h.recordHamsterTutorialImage(ctx, entry.ID, entry, source, userID)
}
func (h *APIKeyHandler) storeHamsterReleaseImages(ctx context.Context, snapshot hamstertutorial.Snapshot) error {
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		return err
	}
	for id, image := range snapshot.Images {
		entry, err := cache.StoreUpload(bytes.NewReader(image.Body), image.MediaType)
		if err != nil {
			return fmt.Errorf("release image %s: %w", id, err)
		}
		if err := h.recordHamsterTutorialImage(ctx, id, entry, "", 0); err != nil {
			return err
		}
	}
	return nil
}
