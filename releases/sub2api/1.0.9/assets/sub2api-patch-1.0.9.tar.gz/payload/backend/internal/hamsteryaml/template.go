package hamsteryaml

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

const hamsterTemplateAPIKeyPlaceholder = "{{provider.api_key}}"
const hamsterTemplateAPIKeySentinel = "__HAMSTER_SWITCH_PROVIDER_API_KEY_PLACEHOLDER__"

const DefaultSubscriptionTemplate = `format_version: 1
name: {{subscription.name}}
{{#if subscription.description}}
description: {{subscription.description}}
{{/if}}
{{#if subscription.icon}}
icon: {{subscription.icon}}
{{/if}}
{{#if subscription.home_url}}
home_url: {{subscription.home_url}}
{{/if}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    group_name: {{provider.group_name}}
    name: {{provider.name}}
{{#if provider.description}}
    description: {{provider.description}}
{{/if}}
{{#if provider.icon}}
    icon: {{provider.icon}}
{{/if}}
{{#if provider.website_url}}
    website_url: {{provider.website_url}}
{{/if}}
{{#if provider.category}}
    category: {{provider.category}}
{{/if}}
{{#if provider.notes}}
    notes: {{provider.notes}}
{{/if}}
{{#if provider.pricing}}
    pricing: {{provider.pricing}}
{{/if}}
{{#if provider.features}}
    features: {{provider.features}}
{{/if}}
{{#if provider.icon_color}}
    icon_color: {{provider.icon_color}}
{{/if}}
{{#if provider.sort_index}}
    sort_index: {{provider.sort_index}}
{{/if}}
{{#if provider.in_failover_queue}}
    in_failover_queue: {{provider.in_failover_queue}}
{{/if}}
    models: {{provider.models}}
    base_url: {{provider.base_url}}
    default_model: {{provider.default_model}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
`

type TemplateDiagnostic struct {
	Level   string `json:"level"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

var hamsterTemplateToken = regexp.MustCompile(`\{\{\s*([^{}]+?)\s*\}\}`)
var hamsterTemplateIfBlock = regexp.MustCompile(`(?s)\{\{#if\s+([a-z0-9_.]+)\}\}(.*?)\{\{/if\}\}`)
var hamsterTemplateModelsBlock = regexp.MustCompile(`(?s)\{\{#models\}\}(.*?)\{\{/models\}\}`)

var hamsterTemplateVariables = map[string]bool{
	"subscription.name":          true,
	"subscription.description":   true,
	"subscription.icon":          true,
	"subscription.home_url":      true,
	"subscription.updated_at":    true,
	"provider.id":                true,
	"provider.app_type":          true,
	"provider.group_name":        true,
	"provider.name":              true,
	"provider.description":       true,
	"provider.icon":              true,
	"provider.website_url":       true,
	"provider.category":          true,
	"provider.notes":             true,
	"provider.pricing":           true,
	"provider.features":          true,
	"provider.icon_color":        true,
	"provider.sort_index":        true,
	"provider.in_failover_queue": true,
	"provider.api_key":           true,
	"provider.models":            true,
	"provider.base_url":          true,
	"provider.default_model":     true,
	"provider.settings_config":   true,
	"provider.endpoints":         true,
	"provider.meta":              true,
}

var editableProviderTemplateFields = []string{
	"name", "description", "icon", "website_url", "category", "notes",
	"pricing", "features", "settings_config", "icon_color", "sort_index", "in_failover_queue",
}

// SubscriptionTemplateProviderFields returns presentation fields that are
// actually referenced by the provider loop in the current template body.
func SubscriptionTemplateProviderFields(body string) []string {
	start := strings.Index(body, "{{#providers}}")
	end := strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		return []string{}
	}
	loop := body[start+len("{{#providers}}") : end]
	fields := make([]string, 0, len(editableProviderTemplateFields))
	for _, field := range editableProviderTemplateFields {
		token := "provider." + field
		if strings.Contains(loop, "{{"+token+"}}") || strings.Contains(loop, "{{#if "+token+"}}") {
			fields = append(fields, field)
		}
	}
	return fields
}

func ValidateSubscriptionTemplate(body string) []TemplateDiagnostic {
	body = strings.TrimSpace(body)
	var diagnostics []TemplateDiagnostic
	addHard := func(code, message string) {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "error", Code: code, Message: message})
	}
	if body == "" {
		return []TemplateDiagnostic{{Level: "error", Code: "EMPTY_TEMPLATE", Message: "template body is empty"}}
	}
	if len(body) > 256<<10 {
		addHard("TEMPLATE_TOO_LARGE", "template body exceeds 256 KiB")
	}
	if strings.Count(body, "{{#providers}}") != 1 || strings.Count(body, "{{/providers}}") != 1 {
		addHard("PROVIDER_LOOP", "template must contain exactly one closed providers loop")
	}
	start := strings.Index(body, "{{#providers}}")
	end := strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		addHard("PROVIDER_LOOP_ORDER", "providers loop is not properly closed")
	}
	if strings.Count(body, "{{#if ") != strings.Count(body, "{{/if}}") || len(hamsterTemplateIfBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#if ") {
		addHard("CONDITION_BLOCK", "simple conditions must be closed and cannot be nested")
	}
	if strings.Count(body, "{{#models}}") != strings.Count(body, "{{/models}}") || len(hamsterTemplateModelsBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#models}}") {
		addHard("MODELS_LOOP", "models loops must be closed and cannot be nested")
	}
	for _, match := range hamsterTemplateIfBlock.FindAllStringSubmatch(body, -1) {
		if !hamsterTemplateVariables[match[1]] {
			addHard("INVALID_CONDITION", fmt.Sprintf("condition variable %q is not allowed", match[1]))
		}
	}
	if start >= 0 && end > start {
		outside := body[:start] + body[end+len("{{/providers}}"):]
		if strings.Contains(outside, "{{#models}}") || strings.Contains(outside, "{{/models}}") {
			addHard("MODELS_LOOP_SCOPE", "models loops are allowed only inside the providers loop")
		}
	}
	for _, match := range hamsterTemplateToken.FindAllStringSubmatch(body, -1) {
		token := strings.TrimSpace(match[1])
		if token == "#providers" || token == "/providers" || token == "#models" || token == "/models" || token == "model" || token == "/if" || strings.HasPrefix(token, "#if ") || hamsterTemplateVariables[token] {
			continue
		}
		addHard("UNKNOWN_TOKEN", fmt.Sprintf("template token %q is not allowed", token))
	}
	for _, required := range []string{
		"subscription.name", "provider.id", "provider.app_type", "provider.models",
		"provider.settings_config", "provider.base_url",
	} {
		if required == "provider.models" && strings.Contains(body, "{{#models}}") {
			continue
		}
		if !strings.Contains(body, "{{"+required+"}}") {
			addHard("MISSING_REQUIRED_TOKEN", fmt.Sprintf("required token %q is missing", required))
		}
	}
	if !strings.Contains(body, "{{subscription.updated_at}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_UPDATED_AT", Message: "template does not expose the subscription update time"})
	}
	if !strings.Contains(body, "{{provider.meta}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_PROVIDER_META", Message: "template omits provider metadata and capability warnings"})
	}
	if hasTemplateErrors(diagnostics) {
		return diagnostics
	}
	sample := subscriptionExport{
		FormatVersion: 1,
		Name:          "template validation",
		Description:   "template description",
		Icon:          "openai",
		HomeURL:       "https://example.invalid",
		UpdatedAt:     time.Unix(0, 0).UTC().Format(time.RFC3339),
		Providers: []providerExport{{
			ID: "sample", AppType: "codex", GroupName: "default", Name: "sample",
			Description: "sample provider", Icon: "openai", WebsiteURL: "https://example.invalid",
			Category: "AI", Notes: "sample", Pricing: map[string]any{"currency": "USD"},
			Features: map[string]any{"streaming": true}, IconColor: "#111111", SortIndex: 1,
			InFailoverQueue: true, APIKey: "{{provider.api_key}}",
			Models: []string{"sample-model"}, BaseURL: "https://example.invalid/v1", DefaultModel: "sample-model",
			SettingsConfig: map[string]any{"auth": map[string]string{"OPENAI_API_KEY": "sk-template-validation"}},
			Endpoints:      []endpointExport{{URL: "https://example.invalid/v1"}}, Meta: map[string]any{"gateway_type": "sub2api"},
		}},
	}
	rendered, err := renderSubscriptionTemplate(body, sample)
	if err != nil {
		addHard("RENDER_FAILED", err.Error())
		return diagnostics
	}
	var decoded map[string]any
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		addHard("INVALID_YAML", fmt.Sprintf("rendered template is not valid YAML: %v", err))
		return diagnostics
	}
	if decoded["format_version"] != 1 {
		addHard("FORMAT_VERSION", "rendered YAML must contain format_version: 1")
	}
	providers, ok := decoded["providers"].([]any)
	if !ok || len(providers) != 1 {
		addHard("PROVIDERS_SHAPE", "rendered YAML must contain one provider for each loop item")
	}
	return diagnostics
}

func RenderSubscriptionTemplate(body string, options SubscriptionExportOptions, providers []SubscriptionProviderAccess) ([]byte, []TemplateDiagnostic, error) {
	diagnostics := ValidateSubscriptionTemplate(body)
	if hasTemplateErrors(diagnostics) {
		return nil, diagnostics, errors.New("configuration template contains hard errors")
	}
	baseURL := strings.TrimRight(strings.TrimSpace(options.BaseURL), "/")
	if baseURL == "" {
		return nil, diagnostics, errors.New("HAMSTER_SWITCH_BASE_URL or request host is required")
	}
	name := strings.TrimSpace(options.Name)
	if name == "" {
		name = "sub2api 配置订阅"
	}
	sub := subscriptionExport{
		FormatVersion: 1, Name: name, Description: strings.TrimSpace(options.Description),
		Icon: strings.TrimSpace(options.Icon), HomeURL: strings.TrimSpace(options.HomeURL),
		Providers: []providerExport{},
	}
	if !options.UpdatedAt.IsZero() {
		sub.UpdatedAt = options.UpdatedAt.UTC().Format(time.RFC3339)
	}
	for index, provider := range providers {
		if provider.ClientAPIKey == hamsterTemplateAPIKeyPlaceholder {
			provider.ClientAPIKey = hamsterTemplateAPIKeySentinel
		}
		exported, err := exportSubscriptionProvider(provider, index, baseURL)
		if err != nil {
			return nil, diagnostics, err
		}
		sub.Providers = append(sub.Providers, exported)
	}
	if len(sub.Providers) == 0 {
		return nil, diagnostics, errors.New("at least one Hamster Switch provider is required")
	}
	rendered, err := renderSubscriptionTemplate(body, sub)
	if err != nil {
		return nil, diagnostics, err
	}
	rendered = []byte(strings.ReplaceAll(string(rendered), hamsterTemplateAPIKeySentinel, hamsterTemplateAPIKeyPlaceholder))
	var decoded subscription
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		return nil, diagnostics, fmt.Errorf("render configuration subscription template: %w", err)
	}
	if _, err := convertSubscription(decoded); err != nil {
		return nil, diagnostics, fmt.Errorf("validate rendered configuration subscription: %w", err)
	}
	return rendered, diagnostics, nil
}

func renderSubscriptionTemplate(body string, sub subscriptionExport) ([]byte, error) {
	start := strings.Index(body, "{{#providers}}")
	end := strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		return nil, errors.New("providers loop is not properly closed")
	}
	loopStart := start + len("{{#providers}}")
	loop := body[loopStart:end]
	var renderedLoop strings.Builder
	for _, provider := range sub.Providers {
		values := map[string]any{
			"provider.id": provider.ID, "provider.app_type": provider.AppType,
			"provider.group_name": provider.GroupName, "provider.name": provider.Name,
			"provider.description": provider.Description, "provider.icon": provider.Icon,
			"provider.website_url": provider.WebsiteURL, "provider.category": provider.Category,
			"provider.notes": provider.Notes, "provider.pricing": provider.Pricing,
			"provider.features": provider.Features, "provider.icon_color": provider.IconColor,
			"provider.sort_index": provider.SortIndex, "provider.in_failover_queue": provider.InFailoverQueue,
			"provider.api_key": provider.APIKey,
			"provider.models":  provider.Models, "provider.base_url": provider.BaseURL,
			"provider.default_model": provider.DefaultModel, "provider.settings_config": provider.SettingsConfig,
			"provider.endpoints": provider.Endpoints, "provider.meta": provider.Meta,
		}
		part, err := renderHamsterTemplateIfBlocks(loop, values)
		if err == nil {
			part, err = renderHamsterTemplateModelsBlocks(part, provider.Models, values)
		}
		if err == nil {
			part, err = replaceHamsterTemplateVariables(part, values)
		}
		if err != nil {
			return nil, err
		}
		renderedLoop.WriteString(part)
	}
	combined := body[:start] + renderedLoop.String() + body[end+len("{{/providers}}"):]
	subscriptionValues := map[string]any{
		"subscription.name": sub.Name, "subscription.description": sub.Description,
		"subscription.icon": sub.Icon, "subscription.home_url": sub.HomeURL,
		"subscription.updated_at": sub.UpdatedAt,
	}
	combined, err := renderHamsterTemplateIfBlocks(combined, subscriptionValues)
	if err != nil {
		return nil, err
	}
	return bytesFromTemplateResult(replaceHamsterTemplateVariables(combined, subscriptionValues))
}

func renderHamsterTemplateModelsBlocks(body string, models []string, providerValues map[string]any) (string, error) {
	var renderErr error
	result := hamsterTemplateModelsBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := hamsterTemplateModelsBlock.FindStringSubmatch(block)
		if len(match) != 2 {
			renderErr = errors.New("models loop is invalid")
			return block
		}
		var rendered strings.Builder
		for _, model := range models {
			values := make(map[string]any, len(providerValues)+1)
			for key, value := range providerValues {
				values[key] = value
			}
			values["model"] = model
			part, err := replaceHamsterTemplateVariables(match[1], values)
			if err != nil {
				renderErr = err
				return block
			}
			rendered.WriteString(part)
		}
		return rendered.String()
	})
	return result, renderErr
}

func renderHamsterTemplateIfBlocks(body string, values map[string]any) (string, error) {
	var renderErr error
	result := hamsterTemplateIfBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := hamsterTemplateIfBlock.FindStringSubmatch(block)
		if len(match) != 3 {
			renderErr = errors.New("condition block is invalid")
			return block
		}
		value, ok := values[match[1]]
		if !ok {
			renderErr = fmt.Errorf("condition variable %q is not available in this context", match[1])
			return block
		}
		if hamsterTemplateTruthy(value) {
			return match[2]
		}
		return ""
	})
	return result, renderErr
}

func hamsterTemplateTruthy(value any) bool {
	switch typed := value.(type) {
	case nil:
		return false
	case bool:
		return typed
	case string:
		return strings.TrimSpace(typed) != ""
	case []string:
		return len(typed) > 0
	case []endpointExport:
		return len(typed) > 0
	case map[string]any:
		return len(typed) > 0
	case int:
		return typed != 0
	case int64:
		return typed != 0
	case float64:
		return typed != 0
	default:
		return true
	}
}

func replaceHamsterTemplateVariables(body string, values map[string]any) (string, error) {
	var replaceErr error
	result := hamsterTemplateToken.ReplaceAllStringFunc(body, func(match string) string {
		parts := hamsterTemplateToken.FindStringSubmatch(match)
		token := strings.TrimSpace(parts[1])
		if strings.HasPrefix(token, "#") || strings.HasPrefix(token, "/") {
			replaceErr = fmt.Errorf("unexpected template directive %q", token)
			return match
		}
		value, ok := values[token]
		if !ok {
			replaceErr = fmt.Errorf("template token %q is not available in this context", token)
			return match
		}
		encoded, err := json.Marshal(value)
		if err != nil {
			replaceErr = err
			return match
		}
		return string(encoded)
	})
	return result, replaceErr
}

func bytesFromTemplateResult(value string, err error) ([]byte, error) {
	if err != nil {
		return nil, err
	}
	return []byte(value), nil
}

func hasTemplateErrors(diagnostics []TemplateDiagnostic) bool {
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			return true
		}
	}
	return false
}
