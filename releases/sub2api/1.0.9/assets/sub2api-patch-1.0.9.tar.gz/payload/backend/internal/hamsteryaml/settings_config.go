package hamsteryaml

import (
	"fmt"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"github.com/pelletier/go-toml/v2"
)

var codexModelProviderPattern = regexp.MustCompile(`(?m)^\s*model_provider\s*=\s*"([^"]+)"\s*(?:#.*)?$`)
var codexProviderSectionPattern = regexp.MustCompile(`^\s*\[model_providers\.([A-Za-z0-9_-]+)\]\s*(?:#.*)?$`)
var codexBaseURLPattern = regexp.MustCompile(`^(\s*base_url\s*=\s*)"(?:[^"\\]|\\.)*"(\s*(?:#.*)?)$`)

func NormalizeProviderBaseURL(value string) (string, error) {
	value = strings.TrimRight(strings.TrimSpace(value), "/")
	parsed, err := url.Parse(value)
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil {
		return "", fmt.Errorf("base_url must be an absolute HTTP(S) URL without credentials")
	}
	return value, nil
}

func ExtractSettingsConfigBaseURL(appType string, settings map[string]any) (string, error) {
	switch appType {
	case "claude":
		return settingsEnvironmentURL(settings, "ANTHROPIC_BASE_URL")
	case "gemini":
		if value, ok := settingsEnvironmentURLOptional(settings, "GOOGLE_GEMINI_BASE_URL"); ok {
			return value, nil
		}
		return settingsEnvironmentURL(settings, "GEMINI_BASE_URL")
	case "codex":
		config, ok := settings["config"].(string)
		if !ok || strings.TrimSpace(config) == "" {
			return "", fmt.Errorf("settings_config.config must be a non-empty TOML string")
		}
		if err := validateCodexTOML(config); err != nil {
			return "", err
		}
		provider := "custom"
		if match := codexModelProviderPattern.FindStringSubmatch(config); len(match) == 2 {
			provider = match[1]
		}
		lines := strings.Split(config, "\n")
		inProvider := false
		for _, line := range lines {
			if section := codexProviderSectionPattern.FindStringSubmatch(strings.TrimSuffix(line, "\r")); len(section) == 2 {
				inProvider = section[1] == provider
				continue
			}
			if strings.HasPrefix(strings.TrimSpace(line), "[") {
				inProvider = false
			}
			if inProvider {
				if match := codexBaseURLPattern.FindStringSubmatch(strings.TrimSuffix(line, "\r")); len(match) == 3 {
					value, err := strconv.Unquote(strings.TrimSpace(strings.TrimSuffix(strings.TrimPrefix(match[0], match[1]), match[2])))
					if err != nil {
						return "", fmt.Errorf("settings_config.config base_url is invalid: %w", err)
					}
					return NormalizeProviderBaseURL(value)
				}
			}
		}
		return "", fmt.Errorf("settings_config.config must define base_url for model provider %q", provider)
	default:
		return "", fmt.Errorf("unsupported Hamster Switch app_type %q", appType)
	}
}

func SyncSettingsConfigBaseURL(appType string, settings map[string]any, baseURL string) (map[string]any, error) {
	baseURL, err := NormalizeProviderBaseURL(baseURL)
	if err != nil {
		return nil, err
	}
	result := cloneStringAnyMap(settings)
	switch appType {
	case "claude":
		setSettingsEnvironmentURL(result, "ANTHROPIC_BASE_URL", baseURL)
	case "gemini":
		setSettingsEnvironmentURL(result, "GOOGLE_GEMINI_BASE_URL", baseURL)
		if _, ok := settingsEnvironmentURLOptional(result, "GEMINI_BASE_URL"); ok {
			setSettingsEnvironmentURL(result, "GEMINI_BASE_URL", baseURL)
		}
	case "codex":
		config, ok := result["config"].(string)
		if !ok || strings.TrimSpace(config) == "" {
			return nil, fmt.Errorf("settings_config.config must be a non-empty TOML string")
		}
		if err := validateCodexTOML(config); err != nil {
			return nil, err
		}
		provider := "custom"
		if match := codexModelProviderPattern.FindStringSubmatch(config); len(match) == 2 {
			provider = match[1]
		}
		lines := strings.Split(config, "\n")
		inProvider, replaced := false, false
		for index, line := range lines {
			ending := ""
			plain := line
			if strings.HasSuffix(plain, "\r") {
				plain, ending = strings.TrimSuffix(plain, "\r"), "\r"
			}
			if section := codexProviderSectionPattern.FindStringSubmatch(plain); len(section) == 2 {
				inProvider = section[1] == provider
				continue
			}
			if strings.HasPrefix(strings.TrimSpace(plain), "[") {
				inProvider = false
			}
			if inProvider {
				if match := codexBaseURLPattern.FindStringSubmatch(plain); len(match) == 3 {
					lines[index] = match[1] + strconv.Quote(baseURL) + match[2] + ending
					replaced = true
					break
				}
			}
		}
		if !replaced {
			return nil, fmt.Errorf("settings_config.config must define base_url for model provider %q", provider)
		}
		result["config"] = strings.Join(lines, "\n")
		if err := validateCodexTOML(result["config"].(string)); err != nil {
			return nil, err
		}
	default:
		return nil, fmt.Errorf("unsupported Hamster Switch app_type %q", appType)
	}
	return result, nil
}

func validateCodexTOML(config string) error {
	var decoded map[string]any
	if err := toml.Unmarshal([]byte(config), &decoded); err != nil {
		return fmt.Errorf("settings_config.config must contain valid TOML: %w", err)
	}
	return nil
}

func settingsEnvironmentURL(settings map[string]any, key string) (string, error) {
	value, ok := settingsEnvironmentURLOptional(settings, key)
	if !ok {
		return "", fmt.Errorf("settings_config.env.%s must be a string", key)
	}
	return NormalizeProviderBaseURL(value)
}

func settingsEnvironmentURLOptional(settings map[string]any, key string) (string, bool) {
	env, ok := settings["env"].(map[string]any)
	if !ok {
		return "", false
	}
	value, ok := env[key].(string)
	return value, ok
}

func setSettingsEnvironmentURL(settings map[string]any, key, value string) {
	env, ok := settings["env"].(map[string]any)
	if !ok {
		env = map[string]any{}
		settings["env"] = env
	}
	env[key] = value
}

func cloneStringAnyMap(value map[string]any) map[string]any {
	result := make(map[string]any, len(value))
	for key, item := range value {
		switch typed := item.(type) {
		case map[string]any:
			result[key] = cloneStringAnyMap(typed)
		case []any:
			copy := make([]any, len(typed))
			for index, entry := range typed {
				if nested, ok := entry.(map[string]any); ok {
					copy[index] = cloneStringAnyMap(nested)
				} else {
					copy[index] = entry
				}
			}
			result[key] = copy
		default:
			result[key] = item
		}
	}
	return result
}
