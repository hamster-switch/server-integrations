package hamsteryaml

import (
	"fmt"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

type SubscriptionExportOptions struct {
	Name         string
	Description  string
	Icon         string
	HomeURL      string
	BaseURL      string
	ClientAPIKey string
	ClaudeModels []string
	CodexModels  []string
	GeminiModels []string
	UpdatedAt    time.Time
}

type SubscriptionProviderAccess struct {
	ID                     string
	AppType                string
	GroupName              string
	Name                   string
	Models                 []string
	ClientAPIKey           string
	GroupID                int64
	Platform               string
	Description            string
	Icon                   string
	BaseURL                string
	BaseURLExplicit        bool
	WebsiteURL             string
	Category               string
	Notes                  string
	Pricing                map[string]any
	Features               map[string]any
	SettingsConfig         map[string]any
	SettingsConfigExplicit bool
	IconColor              string
	SortIndex              int
	InFailoverQueue        bool
}

type subscriptionExport struct {
	FormatVersion int              `yaml:"format_version"`
	Name          string           `yaml:"name"`
	Description   string           `yaml:"description,omitempty"`
	Icon          string           `yaml:"icon,omitempty"`
	HomeURL       string           `yaml:"home_url,omitempty"`
	UpdatedAt     string           `yaml:"updated_at,omitempty"`
	Providers     []providerExport `yaml:"providers"`
}

type providerExport struct {
	ID              string           `yaml:"id"`
	AppType         string           `yaml:"app_type"`
	GroupName       string           `yaml:"group_name"`
	Name            string           `yaml:"name"`
	Description     string           `yaml:"description,omitempty"`
	Icon            string           `yaml:"icon,omitempty"`
	WebsiteURL      string           `yaml:"website_url,omitempty"`
	Category        string           `yaml:"category,omitempty"`
	Notes           string           `yaml:"notes,omitempty"`
	Pricing         map[string]any   `yaml:"pricing,omitempty"`
	Features        map[string]any   `yaml:"features,omitempty"`
	IconColor       string           `yaml:"icon_color,omitempty"`
	SortIndex       int              `yaml:"sort_index,omitempty"`
	InFailoverQueue bool             `yaml:"in_failover_queue,omitempty"`
	APIKey          string           `yaml:"-"`
	Models          []string         `yaml:"models"`
	BaseURL         string           `yaml:"base_url,omitempty"`
	DefaultModel    string           `yaml:"default_model,omitempty"`
	SettingsConfig  map[string]any   `yaml:"settings_config"`
	Endpoints       []endpointExport `yaml:"endpoints,omitempty"`
	Meta            map[string]any   `yaml:"meta,omitempty"`
}

type endpointExport struct {
	URL string `yaml:"url" json:"url"`
}

func BuildSubscriptionYAML(options SubscriptionExportOptions) ([]byte, error) {
	clientAPIKey := strings.TrimSpace(options.ClientAPIKey)
	if clientAPIKey == "" {
		return nil, fmt.Errorf("HAMSTER_SWITCH_CLIENT_API_KEY is required")
	}

	providers := []SubscriptionProviderAccess{}
	providers = appendSubscriptionProviderAccess(providers, "claude", "sub2api-claude", "default", "sub2api Claude", options.ClaudeModels, clientAPIKey)
	providers = appendSubscriptionProviderAccess(providers, "codex", "sub2api-codex", "default", "sub2api Codex", options.CodexModels, clientAPIKey)
	providers = appendSubscriptionProviderAccess(providers, "gemini", "sub2api-gemini", "default", "sub2api Gemini", options.GeminiModels, clientAPIKey)
	if len(providers) == 0 {
		return nil, fmt.Errorf("at least one of HAMSTER_SWITCH_CLAUDE_MODELS, HAMSTER_SWITCH_CODEX_MODELS, HAMSTER_SWITCH_GEMINI_MODELS is required")
	}
	return BuildSubscriptionYAMLFromProviders(options, providers)
}

func BuildSubscriptionYAMLFromProviders(options SubscriptionExportOptions, providers []SubscriptionProviderAccess) ([]byte, error) {
	baseURL := strings.TrimRight(strings.TrimSpace(options.BaseURL), "/")
	if baseURL == "" {
		return nil, fmt.Errorf("HAMSTER_SWITCH_BASE_URL or request host is required")
	}

	name := strings.TrimSpace(options.Name)
	if name == "" {
		name = "sub2api Hamster Switch"
	}

	sub := subscriptionExport{
		FormatVersion: 1,
		Name:          name,
		Description:   strings.TrimSpace(options.Description),
		Icon:          strings.TrimSpace(options.Icon),
		HomeURL:       strings.TrimSpace(options.HomeURL),
		Providers:     []providerExport{},
	}
	if !options.UpdatedAt.IsZero() {
		sub.UpdatedAt = options.UpdatedAt.UTC().Format(time.RFC3339)
	}

	for index, provider := range providers {
		exported, err := exportSubscriptionProvider(provider, index, baseURL)
		if err != nil {
			return nil, err
		}
		sub.Providers = append(sub.Providers, exported)
	}
	if len(sub.Providers) == 0 {
		return nil, fmt.Errorf("at least one Hamster Switch provider is required")
	}

	return yaml.Marshal(sub)
}

func SplitSubscriptionModels(value string) []string {
	parts := strings.FieldsFunc(value, func(r rune) bool {
		return r == ',' || r == '\n' || r == '\r'
	})
	return cleanModels(parts)
}

func appendSubscriptionProviderAccess(providers []SubscriptionProviderAccess, appType string, id string, groupName string, name string, models []string, clientAPIKey string) []SubscriptionProviderAccess {
	models = cleanModels(models)
	if len(models) == 0 {
		return providers
	}
	return append(providers, SubscriptionProviderAccess{
		ID:           id,
		AppType:      appType,
		GroupName:    groupName,
		Name:         name,
		Models:       models,
		ClientAPIKey: clientAPIKey,
	})
}

func appendSubscriptionProvider(providers []providerExport, appType string, id string, name string, models []string, baseURL string, clientAPIKey string) []providerExport {
	models = cleanModels(models)
	if len(models) == 0 {
		return providers
	}
	apiBaseURL := joinSubscriptionURLPath(baseURL, subscriptionAPIPath(appType))
	return append(providers, providerExport{
		ID:             id,
		AppType:        appType,
		GroupName:      "default",
		Name:           name,
		Models:         models,
		BaseURL:        apiBaseURL,
		DefaultModel:   models[0],
		SettingsConfig: DefaultSubscriptionSettingsConfig(appType, clientAPIKey, apiBaseURL, models[0]),
		Endpoints:      []endpointExport{{URL: apiBaseURL}},
		Meta:           subscriptionMeta(SubscriptionProviderAccess{AppType: appType, GroupName: "default"}, appType),
	})
}

func exportSubscriptionProvider(provider SubscriptionProviderAccess, index int, baseURL string) (providerExport, error) {
	appType := strings.TrimSpace(provider.AppType)
	if appType != "claude" && appType != "codex" && appType != "gemini" {
		return providerExport{}, fmt.Errorf("unsupported Hamster Switch app_type %q", appType)
	}
	groupName := strings.TrimSpace(provider.GroupName)
	if groupName == "" {
		return providerExport{}, fmt.Errorf("Hamster Switch provider group_name is required")
	}
	clientAPIKey := strings.TrimSpace(provider.ClientAPIKey)
	if clientAPIKey == "" {
		return providerExport{}, fmt.Errorf("Hamster Switch API key for group %q is required", groupName)
	}
	models := cleanModels(provider.Models)
	if len(models) == 0 {
		return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q must include at least one model", groupName)
	}
	id := strings.TrimSpace(provider.ID)
	if id == "" {
		id = fmt.Sprintf("sub2api-%s-%s-%d", exportIDPart(groupName), appType, index+1)
	}
	name := strings.TrimSpace(provider.Name)
	if name == "" {
		name = fmt.Sprintf("sub2api %s %s", groupName, appType)
	}
	apiBaseURL := joinSubscriptionURLPath(baseURL, subscriptionAPIPath(appType))
	if strings.TrimSpace(provider.BaseURL) != "" {
		var err error
		apiBaseURL, err = NormalizeProviderBaseURL(provider.BaseURL)
		if err != nil {
			return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q has invalid base_url: %w", groupName, err)
		}
	}
	settingsConfig := provider.SettingsConfig
	if provider.SettingsConfigExplicit {
		settingsBaseURL, err := ExtractSettingsConfigBaseURL(appType, settingsConfig)
		if err != nil {
			return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q has invalid settings_config: %w", groupName, err)
		}
		if provider.BaseURLExplicit && settingsBaseURL != apiBaseURL {
			return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q has mismatched base_url and settings_config endpoint", groupName)
		}
		apiBaseURL = settingsBaseURL
	}
	if settingsConfig == nil || (provider.BaseURLExplicit && !provider.SettingsConfigExplicit) {
		settingsConfig = DefaultSubscriptionSettingsConfig(appType, clientAPIKey, apiBaseURL, models[0])
	} else {
		var err error
		settingsConfig, err = SyncSettingsConfigBaseURL(appType, settingsConfig, apiBaseURL)
		if err != nil {
			return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q has invalid settings_config: %w", groupName, err)
		}
		resolved, err := resolveSettingsConfigTokens(settingsConfig, clientAPIKey)
		if err != nil {
			return providerExport{}, fmt.Errorf("Hamster Switch provider for group %q has invalid settings_config: %w", groupName, err)
		}
		settingsConfig = resolved
	}
	return providerExport{
		ID:              id,
		AppType:         appType,
		GroupName:       groupName,
		Name:            name,
		Description:     strings.TrimSpace(provider.Description),
		Icon:            strings.TrimSpace(provider.Icon),
		WebsiteURL:      strings.TrimSpace(provider.WebsiteURL),
		Category:        strings.TrimSpace(provider.Category),
		Notes:           strings.TrimSpace(provider.Notes),
		Pricing:         provider.Pricing,
		Features:        provider.Features,
		IconColor:       strings.TrimSpace(provider.IconColor),
		SortIndex:       provider.SortIndex,
		InFailoverQueue: provider.InFailoverQueue,
		APIKey:          clientAPIKey,
		Models:          models,
		BaseURL:         apiBaseURL,
		DefaultModel:    models[0],
		SettingsConfig:  settingsConfig,
		Endpoints:       []endpointExport{{URL: apiBaseURL}},
		Meta:            subscriptionMeta(provider, appType),
	}, nil
}

func subscriptionAPIPath(appType string) string {
	if appType == "gemini" {
		return "/v1beta"
	}
	return "/v1"
}

func subscriptionMeta(provider SubscriptionProviderAccess, appType string) map[string]any {
	warnings := subscriptionWarnings(provider.Platform, appType)
	meta := map[string]any{
		"gateway_type":     "sub2api",
		"issuer":           "sub2api",
		"auth_mode":        "api_key",
		"gateway_group":    strings.TrimSpace(provider.GroupName),
		"gateway_platform": strings.TrimSpace(provider.Platform),
		"capabilities":     subscriptionCapabilities(appType),
		"warnings":         warnings,
	}
	if provider.GroupID > 0 {
		meta["gateway_group_id"] = provider.GroupID
	}
	return meta
}

func subscriptionWarnings(platform string, appType string) []string {
	switch strings.ToLower(strings.TrimSpace(platform)) {
	case "grok":
		if appType == "codex" {
			return []string{"grok platform is exported as Codex; verify OpenAI Responses compatibility before production use"}
		}
	case "antigravity":
		if appType == "gemini" {
			return []string{"antigravity platform is exported as Gemini; verify request semantics before production use"}
		}
	}
	return []string{}
}

func subscriptionCapabilities(appType string) []string {
	switch appType {
	case "claude":
		return []string{"anthropic-messages"}
	case "codex":
		return []string{"responses"}
	case "gemini":
		return []string{"gemini-native"}
	default:
		return []string{}
	}
}

func DefaultSubscriptionSettingsConfig(appType string, clientAPIKey string, baseURL string, defaultModel string) map[string]any {
	switch appType {
	case "claude":
		return map[string]any{
			"env": map[string]any{
				"ANTHROPIC_API_KEY":  clientAPIKey,
				"ANTHROPIC_BASE_URL": baseURL,
				"ANTHROPIC_MODEL":    defaultModel,
			},
		}
	case "codex":
		return map[string]any{
			"auth": map[string]any{
				"OPENAI_API_KEY": clientAPIKey,
			},
			"config": fmt.Sprintf("model_provider = \"custom\"\nmodel = %q\n\n[model_providers.custom]\nname = \"sub2api\"\nbase_url = %q\nwire_api = \"responses\"\nrequires_openai_auth = true\n", defaultModel, baseURL),
		}
	case "gemini":
		return map[string]any{
			"env": map[string]any{
				"GEMINI_API_KEY":         clientAPIKey,
				"GOOGLE_GEMINI_BASE_URL": baseURL,
				"GEMINI_MODEL":           defaultModel,
			},
		}
	default:
		return map[string]any{}
	}
}

func resolveSettingsConfigTokens(settings map[string]any, clientAPIKey string) (map[string]any, error) {
	resolved, err := resolveSettingsConfigValue(settings, clientAPIKey)
	if err != nil {
		return nil, err
	}
	return resolved.(map[string]any), nil
}

func ValidateSettingsConfigTokens(settings map[string]any) error {
	_, err := resolveSettingsConfigTokens(settings, hamsterTemplateAPIKeyPlaceholder)
	return err
}

func resolveSettingsConfigValue(value any, clientAPIKey string) (any, error) {
	switch typed := value.(type) {
	case map[string]any:
		result := make(map[string]any, len(typed))
		for key, nested := range typed {
			resolved, err := resolveSettingsConfigValue(nested, clientAPIKey)
			if err != nil {
				return nil, err
			}
			result[key] = resolved
		}
		return result, nil
	case []any:
		result := make([]any, len(typed))
		for index, nested := range typed {
			resolved, err := resolveSettingsConfigValue(nested, clientAPIKey)
			if err != nil {
				return nil, err
			}
			result[index] = resolved
		}
		return result, nil
	case string:
		for _, match := range hamsterTemplateToken.FindAllStringSubmatch(typed, -1) {
			if strings.TrimSpace(match[1]) != "provider.api_key" {
				return nil, fmt.Errorf("template token %q is not allowed", strings.TrimSpace(match[1]))
			}
		}
		return strings.ReplaceAll(typed, hamsterTemplateAPIKeyPlaceholder, clientAPIKey), nil
	default:
		return value, nil
	}
}

func joinSubscriptionURLPath(baseURL string, path string) string {
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	path = "/" + strings.TrimLeft(strings.TrimSpace(path), "/")
	if baseURL == "" {
		return path
	}
	return baseURL + path
}

func exportIDPart(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	var builder strings.Builder
	lastDash := false
	for _, r := range value {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			builder.WriteRune(r)
			lastDash = false
			continue
		}
		if !lastDash {
			builder.WriteByte('-')
			lastDash = true
		}
	}
	cleaned := strings.Trim(builder.String(), "-")
	if cleaned == "" {
		return "group"
	}
	return cleaned
}
