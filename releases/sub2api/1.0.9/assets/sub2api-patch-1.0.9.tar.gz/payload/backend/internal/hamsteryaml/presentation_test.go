package hamsteryaml

import "testing"

func stringPointer(value string) *string { return &value }
func intPointer(value int) *int          { return &value }
func boolPointer(value bool) *bool       { return &value }

func TestApplyTemplatePresentationPreservesDefaultAndExplicitEmptyValues(t *testing.T) {
	options := SubscriptionExportOptions{
		Name: "站点名称", Description: "站点说明", Icon: "site-logo", HomeURL: "https://example.com",
	}
	providers := []SubscriptionProviderAccess{{
		GroupID: 7, Name: "默认分组名", Description: "", Icon: "openai", SortIndex: 9, InFailoverQueue: true,
	}}
	pricing := map[string]any{"input": 1.25}
	features := map[string]any{"vision": true}
	settingsConfig := map[string]any{"auth": map[string]any{"OPENAI_API_KEY": "{{provider.api_key}}"}}

	ApplyTemplatePresentation(TemplatePresentation{
		Subscription: SubscriptionPresentation{
			Description: stringPointer(""),
		},
		Providers: map[string]ProviderPresentation{
			"7": {
				Name: stringPointer("自定义分组"), Description: stringPointer(""), Icon: stringPointer("custom"),
				Pricing: &pricing, Features: &features, SettingsConfig: &settingsConfig,
				SortIndex: intPointer(0), InFailoverQueue: boolPointer(false),
			},
		},
	}, &options, providers)

	if options.Name != "站点名称" || options.Description != "" || options.Icon != "site-logo" {
		t.Fatalf("subscription defaults or explicit empty value lost: %#v", options)
	}
	provider := providers[0]
	if provider.Name != "自定义分组" || provider.Description != "" || provider.Icon != "custom" {
		t.Fatalf("provider string overrides not applied: %#v", provider)
	}
	if provider.SortIndex != 0 || provider.InFailoverQueue || provider.Pricing["input"] != 1.25 || provider.Features["vision"] != true {
		t.Fatalf("provider structured overrides not applied: %#v", provider)
	}
	if provider.SettingsConfig["auth"].(map[string]any)["OPENAI_API_KEY"] != "{{provider.api_key}}" {
		t.Fatalf("provider settings_config override not applied: %#v", provider.SettingsConfig)
	}
}

func TestPlatformIconUsesStableFallback(t *testing.T) {
	tests := map[string]string{
		"anthropic":        "anthropic",
		"gemini":           "gemini",
		"antigravity":      "gemini",
		"grok":             "grok",
		"openai":           "openai",
		"unknown-platform": "openai",
	}
	for platform, expected := range tests {
		if actual := PlatformIcon(platform); actual != expected {
			t.Fatalf("PlatformIcon(%q) = %q, want %q", platform, actual, expected)
		}
	}
}
