package hamsteryaml

import (
	"encoding/json"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"
)

func TestSyncSettingsConfigBaseURLForAllApplications(t *testing.T) {
	tests := []struct {
		appType  string
		settings map[string]any
	}{
		{appType: "claude", settings: DefaultSubscriptionSettingsConfig("claude", "{{provider.api_key}}", "https://old.example/v1", "claude-sonnet")},
		{appType: "gemini", settings: DefaultSubscriptionSettingsConfig("gemini", "{{provider.api_key}}", "https://old.example/v1beta", "gemini-2.5-pro")},
		{appType: "codex", settings: map[string]any{
			"auth":   map[string]any{"OPENAI_API_KEY": "{{provider.api_key}}"},
			"config": "model_provider = \"custom\"\nmodel = \"gpt-5.5\"\n\n[model_providers.custom]\nname = \"sub2api\"\nbase_url = \"https://old.example/v1\"\nwire_api = \"responses\"\nrequires_openai_auth = true\n",
		}},
	}
	for _, test := range tests {
		t.Run(test.appType, func(t *testing.T) {
			updated, err := SyncSettingsConfigBaseURL(test.appType, test.settings, "https://new.example/api")
			if err != nil {
				t.Fatal(err)
			}
			endpoint, err := ExtractSettingsConfigBaseURL(test.appType, updated)
			if err != nil {
				t.Fatal(err)
			}
			if endpoint != "https://new.example/api" {
				t.Fatalf("endpoint = %q", endpoint)
			}
			if test.appType == "codex" && (!strings.Contains(updated["config"].(string), "model = \"gpt-5.5\"") || !strings.Contains(updated["config"].(string), "wire_api = \"responses\"")) {
				t.Fatalf("Codex configuration was not preserved: %s", updated["config"])
			}
		})
	}
}

func TestSettingsConfigEndpointControlsBaseURLAndStrictJSONYAML(t *testing.T) {
	settings := DefaultSubscriptionSettingsConfig("claude", "{{provider.api_key}}", "https://custom.example/v1", "claude-sonnet")
	body, err := BuildSubscriptionYAMLFromProviders(SubscriptionExportOptions{Name: "Site", BaseURL: "https://default.example"}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "claude", GroupName: "default", Name: "Provider", Models: []string{"claude-sonnet"}, ClientAPIKey: "sk-test",
		SettingsConfig: settings, SettingsConfigExplicit: true,
	}})
	if err != nil {
		t.Fatal(err)
	}
	var decoded map[string]any
	if err := yaml.Unmarshal(body, &decoded); err != nil {
		t.Fatal(err)
	}
	providers := decoded["providers"].([]any)
	provider := providers[0].(map[string]any)
	if provider["base_url"] != "https://custom.example/v1" {
		t.Fatalf("base_url = %#v", provider["base_url"])
	}
	encoded, err := json.Marshal(provider["settings_config"])
	if err != nil || !json.Valid(encoded) {
		t.Fatalf("settings_config cannot round-trip as strict JSON: %s (%v)", encoded, err)
	}
	endpoints := provider["endpoints"].([]any)
	if endpoints[0].(map[string]any)["url"] != provider["base_url"] {
		t.Fatalf("endpoint and base_url diverged: %#v", provider)
	}
}

func TestBaseURLOverrideRegeneratesSettingsConfig(t *testing.T) {
	body, err := BuildSubscriptionYAMLFromProviders(SubscriptionExportOptions{Name: "Site", BaseURL: "https://default.example"}, []SubscriptionProviderAccess{{
		ID: "provider", AppType: "codex", GroupName: "default", Name: "Provider", Models: []string{"gpt-5.5"}, ClientAPIKey: "sk-test",
		BaseURL: "https://custom.example/responses", BaseURLExplicit: true,
	}})
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(body), `base_url: https://custom.example/responses`) || !strings.Contains(string(body), `base_url = "https://custom.example/responses"`) {
		t.Fatalf("base_url was not synchronized into YAML and settings_config:\n%s", body)
	}
}
