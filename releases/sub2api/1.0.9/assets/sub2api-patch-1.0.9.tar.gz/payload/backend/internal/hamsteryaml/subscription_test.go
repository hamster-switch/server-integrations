package hamsteryaml

import (
	"strings"
	"testing"
	"time"

	"gopkg.in/yaml.v3"
)

func TestBuildSubscriptionYAML(t *testing.T) {
	data, err := BuildSubscriptionYAML(SubscriptionExportOptions{
		Name:         "sub2api exported",
		BaseURL:      "https://gateway.example.com/",
		ClientAPIKey: "client-key",
		ClaudeModels: []string{"claude-sonnet", "claude-opus"},
		CodexModels:  []string{"gpt-5", "gpt-5-mini"},
		GeminiModels: []string{"gemini-2.5-pro"},
		UpdatedAt:    time.Date(2026, 6, 28, 1, 2, 3, 0, time.UTC),
	})
	if err != nil {
		t.Fatalf("BuildSubscriptionYAML returned error: %v", err)
	}

	var sub subscriptionExport
	if err := yaml.Unmarshal(data, &sub); err != nil {
		t.Fatalf("exported YAML should parse: %v\n%s", err, string(data))
	}
	if sub.FormatVersion != 1 {
		t.Fatalf("format version = %d, want 1", sub.FormatVersion)
	}
	if len(sub.Providers) != 3 {
		t.Fatalf("provider count = %d, want 3", len(sub.Providers))
	}
	if sub.Providers[0].BaseURL != "https://gateway.example.com/v1" {
		t.Fatalf("base_url = %q, want https://gateway.example.com/v1", sub.Providers[0].BaseURL)
	}
	if sub.Providers[0].DefaultModel != "claude-sonnet" {
		t.Fatalf("default_model = %q, want claude-sonnet", sub.Providers[0].DefaultModel)
	}
	if sub.Providers[0].Meta["gateway_type"] != "sub2api" {
		t.Fatalf("gateway_type meta = %#v, want sub2api", sub.Providers[0].Meta["gateway_type"])
	}

	text := string(data)
	for _, want := range []string{"client-key", "https://gateway.example.com/v1", "https://gateway.example.com/v1beta"} {
		if !strings.Contains(text, want) {
			t.Fatalf("exported YAML missing %q:\n%s", want, text)
		}
	}
}

func TestBuildSubscriptionYAMLMissingClientKey(t *testing.T) {
	_, err := BuildSubscriptionYAML(SubscriptionExportOptions{
		BaseURL:      "https://gateway.example.com",
		ClaudeModels: []string{"claude-sonnet"},
	})
	if err == nil || !strings.Contains(err.Error(), "HAMSTER_SWITCH_CLIENT_API_KEY") {
		t.Fatalf("expected missing client key error, got %v", err)
	}
}

func TestBuildSubscriptionYAMLMultipleProviders(t *testing.T) {
	data, err := BuildSubscriptionYAML(SubscriptionExportOptions{
		BaseURL:      "https://gateway.example.com",
		ClientAPIKey: "client-key",
		ClaudeModels: []string{"claude-sonnet"},
		CodexModels:  []string{"gpt-5"},
	})
	if err != nil {
		t.Fatalf("BuildSubscriptionYAML returned error: %v", err)
	}

	var sub subscriptionExport
	if err := yaml.Unmarshal(data, &sub); err != nil {
		t.Fatalf("exported YAML should parse: %v", err)
	}
	if len(sub.Providers) != 2 {
		t.Fatalf("provider count = %d, want 2", len(sub.Providers))
	}
}

func TestBuildSubscriptionYAMLFromProviders(t *testing.T) {
	data, err := BuildSubscriptionYAMLFromProviders(SubscriptionExportOptions{
		BaseURL: "https://gateway.example.com",
	}, []SubscriptionProviderAccess{
		{
			ID:           "sub2api-vip-codex",
			AppType:      "codex",
			GroupName:    "vip",
			Name:         "sub2api vip Codex",
			Models:       []string{"gpt-5"},
			ClientAPIKey: "vip-key",
			GroupID:      10,
			Platform:     "grok",
		},
		{
			ID:           "sub2api-default-claude",
			AppType:      "claude",
			GroupName:    "default",
			Name:         "sub2api default Claude",
			Models:       []string{"claude-sonnet"},
			ClientAPIKey: "default-key",
		},
	})
	if err != nil {
		t.Fatalf("BuildSubscriptionYAMLFromProviders returned error: %v", err)
	}

	var sub subscriptionExport
	if err := yaml.Unmarshal(data, &sub); err != nil {
		t.Fatalf("exported YAML should parse: %v", err)
	}
	if len(sub.Providers) != 2 {
		t.Fatalf("provider count = %d, want 2", len(sub.Providers))
	}
	if sub.Providers[0].Meta["gateway_group_id"] != 10 {
		t.Fatalf("group id meta = %#v, want 10", sub.Providers[0].Meta["gateway_group_id"])
	}
	warnings, ok := sub.Providers[0].Meta["warnings"].([]any)
	if !ok || len(warnings) == 0 {
		t.Fatalf("expected grok warning, got %#v", sub.Providers[0].Meta["warnings"])
	}
	text := string(data)
	for _, want := range []string{"vip-key", "default-key", "group_name: vip", "group_name: default"} {
		if !strings.Contains(text, want) {
			t.Fatalf("exported YAML missing %q:\n%s", want, text)
		}
	}
}

func TestBuildSubscriptionYAMLFromProvidersMissingGroupKey(t *testing.T) {
	_, err := BuildSubscriptionYAMLFromProviders(SubscriptionExportOptions{
		BaseURL: "https://gateway.example.com",
	}, []SubscriptionProviderAccess{
		{
			AppType:   "codex",
			GroupName: "vip",
			Models:    []string{"gpt-5"},
		},
	})
	if err == nil || !strings.Contains(err.Error(), "group \"vip\"") {
		t.Fatalf("expected missing group key error, got %v", err)
	}
}

func TestSplitSubscriptionModels(t *testing.T) {
	models := SplitSubscriptionModels("gpt-5, gpt-5-mini\ngpt-5")
	if len(models) != 2 || models[0] != "gpt-5" || models[1] != "gpt-5-mini" {
		t.Fatalf("unexpected models: %#v", models)
	}
}
