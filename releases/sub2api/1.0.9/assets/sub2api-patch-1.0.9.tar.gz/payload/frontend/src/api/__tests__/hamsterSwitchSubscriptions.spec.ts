import { describe, expect, it } from 'vitest'

import { normalizeTutorialAdminState } from '@/api/hamsterSwitchSubscriptions'

describe('normalizeTutorialAdminState', () => {
  it('normalizes a completely null admin response into render-safe collections', () => {
    const state = normalizeTutorialAdminState(null)

    expect(state.base.steps).toEqual([])
    expect(state.overrides).toEqual([])
    expect(state.candidate).toBeNull()
  })

  it('normalizes null nested collections returned by legacy data', () => {
    const state = normalizeTutorialAdminState({
      base: { steps: null },
      overrides: null,
      candidate: {
        version: '1.2.3',
        tutorial: { steps: null },
        conflicts: null
      }
    } as never)

    expect(state.base.steps).toEqual([])
    expect(state.overrides).toEqual([])
    expect(state.candidate?.tutorial.steps).toEqual([])
    expect(state.candidate?.conflicts).toEqual([])
  })
})

