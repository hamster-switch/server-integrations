<template>
  <AppLayout>
    <TablePageLayout>
      <template #filters>
        <SearchInput
          v-model="filterSearch"
          :placeholder="ui.searchPlaceholder"
          class="w-full sm:w-72"
          @search="handleSearch"
        />
      </template>

      <template #actions>
        <div class="flex justify-end gap-3">
          <label v-if="authStore.isAdmin" class="flex items-center gap-2 rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-700 dark:border-dark-600 dark:text-dark-200">
            <input
              v-model="hideSubscriptionAPIKeys"
              type="checkbox"
              :disabled="savingSubscriptionSettings"
              @change="saveSubscriptionSettings"
            />
            {{ ui.hideAPIKeyDisplay }}
          </label>
          <button type="button" class="btn btn-secondary" @click="openTutorial">
            {{ ui.tutorial }}
          </button>
          <button v-if="authStore.isAdmin" type="button" class="btn btn-secondary" @click="openTutorialManager">
            {{ ui.tutorialManagement }}
          </button>
          <button v-if="authStore.isAdmin" type="button" class="btn btn-secondary" @click="openTemplateManager">
            {{ ui.templateManagement }}
          </button>
          <button
            type="button"
            class="btn btn-secondary"
            :disabled="loading"
            :title="ui.refresh"
            @click="loadSubscriptions"
          >
            <Icon name="refresh" size="md" :class="loading ? 'animate-spin' : ''" />
          </button>
          <button type="button" class="btn btn-primary" @click="openCreateModal">
            <Icon name="plus" size="md" class="mr-2" />
            {{ ui.createSubscription }}
          </button>
        </div>
      </template>

      <template #table>
        <DataTable
          :columns="columns"
          :data="subscriptions"
          :loading="loading"
          default-sort-key="created_at"
          default-sort-order="desc"
          row-key="id"
        >
          <template #cell-name="{ row }">
            <div class="flex min-w-0 flex-col">
              <span class="font-medium text-gray-900 dark:text-white">{{ row.name }}</span>
              <span class="mt-0.5 text-xs text-gray-500 dark:text-dark-400">hamster-switch</span>
            </div>
          </template>

          <template #cell-group_names="{ row }">
            <div class="flex max-w-[260px] flex-wrap gap-1.5">
              <span
                v-for="groupName in row.group_names"
                :key="groupName"
                class="rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-700 dark:bg-dark-700 dark:text-dark-200"
              >
                {{ groupName }}
              </span>
            </div>
          </template>

          <template #cell-url="{ row }">
            <div class="flex max-w-[520px] items-center gap-2">
              <code class="code min-w-0 flex-1 truncate text-xs">{{ row.url }}</code>
              <button
                type="button"
                class="rounded-lg p-1 transition-colors hover:bg-gray-100 dark:hover:bg-dark-700"
                :class="copiedSubscriptionId === row.id ? 'text-green-500' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'"
                :title="copiedSubscriptionId === row.id ? ui.copied : ui.copyURL"
                @click="copySubscriptionURL(row)"
              >
                <Icon v-if="copiedSubscriptionId === row.id" name="check" size="sm" :stroke-width="2" />
                <Icon v-else name="clipboard" size="sm" />
              </button>
            </div>
          </template>

          <template #cell-quota="{ row }">
            <span v-if="row.quota > 0" class="text-sm text-gray-700 dark:text-dark-200">
              ${{ numberValue(row.quota_used).toFixed(2) }} / ${{ numberValue(row.quota).toFixed(2) }}
            </span>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.unlimited }}</span>
          </template>

          <template #cell-rate_limit="{ row }">
            <div v-if="hasRateLimit(row)" class="space-y-0.5 text-xs text-gray-600 dark:text-dark-300">
              <div v-if="row.rate_limit_5h > 0">5h: ${{ row.rate_limit_5h.toFixed(2) }}</div>
              <div v-if="row.rate_limit_1d > 0">1d: ${{ row.rate_limit_1d.toFixed(2) }}</div>
              <div v-if="row.rate_limit_7d > 0">7d: ${{ row.rate_limit_7d.toFixed(2) }}</div>
            </div>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.unlimited }}</span>
          </template>

          <template #cell-expires_at="{ value }">
            <span v-if="value" class="text-sm text-gray-500 dark:text-dark-400">
              {{ formatDateTime(value) }}
            </span>
            <span v-else class="text-sm text-gray-400 dark:text-dark-500">{{ ui.neverExpires }}</span>
          </template>

          <template #cell-status="{ value }">
            <span :class="['badge', statusClass(value)]">
              {{ statusLabel(value) }}
            </span>
          </template>

          <template #cell-created_at="{ value }">
            <span class="text-sm text-gray-500 dark:text-dark-400">{{ formatDateTime(value) }}</span>
          </template>

          <template #cell-actions="{ row }">
            <div class="flex flex-wrap items-center gap-1">
              <button
                type="button"
                class="btn btn-secondary px-2 py-1 text-xs"
                @click="authStore.isAdmin ? openYamlEditor(row) : openUseSubscription(row)"
              >
                {{ authStore.isAdmin ? ui.viewYAML : ui.useSubscription }}
              </button>
              <button type="button" class="btn btn-secondary px-2 py-1 text-xs" @click="openEditModal(row)">
                {{ ui.edit }}
              </button>
              <button type="button" class="btn btn-secondary px-2 py-1 text-xs" @click="toggleSubscription(row)">
                {{ row.status === 'disabled' ? ui.enable : ui.disable }}
              </button>
              <button type="button" class="btn btn-danger px-2 py-1 text-xs" @click="requestDelete(row)">
                {{ ui.delete }}
              </button>
            </div>
          </template>

          <template #empty>
            <EmptyState
              :title="ui.emptyTitle"
              :description="ui.emptyDescription"
              :action-text="ui.createSubscription"
              @action="openCreateModal"
            />
          </template>
        </DataTable>
      </template>

      <template #pagination>
        <Pagination
          v-if="pagination.total > 0"
          :page="pagination.page"
          :total="pagination.total"
          :page-size="pagination.page_size"
          @update:page="handlePageChange"
          @update:pageSize="handlePageSizeChange"
        />
      </template>
    </TablePageLayout>

    <BaseDialog :show="showCreateModal" :title="editingSubscriptionId ? ui.editSubscription : ui.createSubscription" width="wide" @close="closeCreateModal">
      <div class="space-y-6">
        <div>
          <label class="input-label">{{ ui.name }}</label>
          <input v-model="form.name" type="text" class="input" placeholder="Hamster Switch" />
        </div>

        <div>
          <div class="mb-2 flex items-center justify-between gap-3">
            <label class="input-label mb-0">{{ ui.groups }}</label>
            <button type="button" class="text-sm text-primary-600 hover:text-primary-700 dark:text-primary-400" @click="toggleAllGroups">
              {{ allGroupsSelected ? ui.clearAll : ui.selectAll }}
            </button>
          </div>
          <div class="max-h-60 space-y-2 overflow-y-auto rounded-lg border border-gray-200 p-3 dark:border-dark-600">
            <label
              v-for="group in availableGroups"
              :key="group.id"
              class="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-dark-700"
            >
              <input type="checkbox" :checked="form.group_ids.includes(group.id)" @change="toggleGroup(group.id)" />
              <GroupBadge
                :name="group.name"
                :platform="groupPlatform(group.platform)"
                :subscription-type="groupSubscriptionType(group.subscription_type)"
                :rate-multiplier="group.rate_multiplier"
              />
              <span class="text-xs text-gray-500 dark:text-dark-400">
                {{ group.app_type || group.platform }}
              </span>
            </label>
            <div v-if="availableGroups.length === 0" class="py-4 text-center text-sm text-gray-400 dark:text-dark-500">
              {{ ui.noGroups }}
            </div>
          </div>
        </div>

        <div v-if="customKeyGroups.length > 0">
          <label class="input-label">{{ ui.customAPIKeys }}</label>
          <div class="space-y-2 rounded-lg border border-gray-200 p-3 dark:border-dark-600">
            <div
              v-for="group in customKeyGroups"
              :key="group.id"
              class="grid gap-2 md:grid-cols-[180px_minmax(0,1fr)] md:items-center"
            >
              <div class="text-sm font-medium text-gray-700 dark:text-dark-200">{{ group.name }}</div>
              <input
                v-model="form.custom_api_keys[group.id]"
                type="text"
                class="input"
                :placeholder="ui.autoGeneratePlaceholder"
              />
            </div>
          </div>
          <p class="input-hint">
            {{ ui.customKeyHint }}
          </p>
        </div>
        <p v-if="editingSubscriptionId && existingSelectedGroups.length" class="input-hint">
          {{ ui.existingKeysUnchanged }}
        </p>

        <div class="space-y-4 rounded-lg border border-gray-200 p-4 dark:border-dark-600">
          <div>
            <label class="input-label mb-0">{{ ui.advancedSettings }}</label>
            <p class="input-hint">{{ ui.advancedHint }}</p>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_ip_restriction" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableIPRestriction }}</span>
          </label>
          <div v-if="form.enable_ip_restriction" class="grid gap-3 md:grid-cols-2">
            <div>
              <label class="input-label">{{ ui.ipWhitelist }}</label>
              <textarea v-model="form.ip_whitelist" class="input min-h-[96px]" :placeholder="ui.ipPlaceholder"></textarea>
            </div>
            <div>
              <label class="input-label">{{ ui.ipBlacklist }}</label>
              <textarea v-model="form.ip_blacklist" class="input min-h-[96px]" :placeholder="ui.ipPlaceholder"></textarea>
            </div>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_quota" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableQuota }}</span>
          </label>
          <div v-if="form.enable_quota">
            <label class="input-label">{{ ui.quotaAmount }}</label>
            <input v-model.number="form.quota" type="number" min="0" step="0.01" class="input" :placeholder="ui.unlimitedPlaceholder" />
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_rate_limit" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableRateLimit }}</span>
          </label>
          <div v-if="form.enable_rate_limit" class="grid gap-3 md:grid-cols-3">
            <div>
              <label class="input-label">{{ ui.limit5h }}</label>
              <input v-model.number="form.rate_limit_5h" type="number" min="0" step="0.01" class="input" />
            </div>
            <div>
              <label class="input-label">{{ ui.limit1d }}</label>
              <input v-model.number="form.rate_limit_1d" type="number" min="0" step="0.01" class="input" />
            </div>
            <div>
              <label class="input-label">{{ ui.limit7d }}</label>
              <input v-model.number="form.rate_limit_7d" type="number" min="0" step="0.01" class="input" />
            </div>
          </div>

          <label class="flex items-center gap-2">
            <input v-model="form.enable_expiration" type="checkbox" />
            <span class="text-sm text-gray-700 dark:text-dark-200">{{ ui.enableExpiration }}</span>
          </label>
          <div v-if="form.enable_expiration" class="grid gap-3 md:grid-cols-2">
            <div>
              <label class="input-label">{{ ui.expiryPreset }}</label>
              <select v-model="form.expiration_preset" class="input" @change="applyExpirationPreset">
                <option value="7">{{ ui.days7 }}</option>
                <option value="30">{{ ui.days30 }}</option>
                <option value="90">{{ ui.days90 }}</option>
                <option value="custom">{{ ui.custom }}</option>
              </select>
            </div>
            <div>
              <label class="input-label">{{ ui.expiryDate }}</label>
              <input v-model="form.expiration_date" type="datetime-local" class="input" />
            </div>
          </div>
        </div>
      </div>

      <template #footer>
        <button type="button" class="btn btn-secondary" @click="closeCreateModal">{{ ui.cancel }}</button>
        <button
          type="button"
          class="btn btn-primary"
          :disabled="submitting || form.group_ids.length === 0"
          @click="submitCreate"
        >
          {{ submitting ? ui.saving : (editingSubscriptionId ? ui.save : ui.createSubscription) }}
        </button>
      </template>
    </BaseDialog>

    <BaseDialog :show="showYamlEditor" :title="ui.viewYAML" width="extra-wide" @close="closeYamlEditor">
      <div class="space-y-4">
        <div>
          <label class="input-label">{{ ui.dedicatedKeys }}</label>
          <div class="space-y-1 rounded-lg border border-gray-200 p-3 font-mono text-xs dark:border-dark-600">
            <div v-for="key in editingAPIKeys" :key="key.id" class="flex items-center justify-between gap-2">
              <span>{{ maskApiKey(key.key) }}</span>
              <button type="button" class="text-primary-600" @click="copyDedicatedKey(key.key)">{{ ui.copyKey }}</button>
            </div>
          </div>
        </div>
        <div>
          <label class="input-label">{{ ui.urlAddress }}</label>
          <div class="flex gap-2">
            <input :value="editingYAMLURL" readonly class="input min-w-0 flex-1" />
            <button type="button" class="btn btn-secondary" @click="copyEditingURL">{{ ui.copyURL }}</button>
          </div>
        </div>
        <div>
          <label class="input-label">{{ ui.yamlContent }}</label>
          <textarea v-model="yamlContent" readonly class="input min-h-[420px] font-mono text-xs" spellcheck="false"></textarea>
          <p class="input-hint">{{ ui.yamlHint }}</p>
        </div>
      </div>

      <template #footer>
        <button type="button" class="btn btn-secondary" @click="copyYamlContent">{{ ui.copyYAML }}</button>
        <button type="button" class="btn btn-primary" @click="downloadYamlContent">{{ ui.downloadYAML }}</button>
      </template>
    </BaseDialog>

    <BaseDialog :show="showTutorial" :title="ui.tutorial" width="wide" @close="showTutorial = false">
      <div v-if="tutorialLoading" class="py-10 text-center text-sm text-gray-500">{{ ui.loading }}</div>
      <div v-else class="space-y-5">
        <div v-if="tutorialSubscriptionURL" class="rounded-lg border border-primary-200 bg-primary-50 p-4 dark:border-primary-800 dark:bg-primary-950/30">
          <label class="input-label">{{ ui.urlAddress }}</label>
          <div class="flex gap-2">
            <input :value="tutorialSubscriptionURL" readonly class="input min-w-0 flex-1" />
            <button type="button" class="btn btn-primary" @click="copyTutorialSubscriptionURL">{{ ui.copyURL }}</button>
          </div>
          <p class="input-hint">{{ ui.keepSubscriptionURLSecret }}</p>
        </div>
        <div v-for="(step, index) in tutorial?.steps || []" :key="step.id" class="rounded-lg border border-gray-200 p-4 dark:border-dark-600">
          <h3 class="font-medium text-gray-900 dark:text-white">{{ index + 1 }}. {{ step.title }}</h3>
          <div class="prose prose-sm mt-3 max-w-none dark:prose-invert" v-html="renderTutorialMarkdown(step.body_md)"></div>
          <div v-if="step.assets?.length" class="mt-4 grid gap-3 sm:grid-cols-2">
            <template v-for="asset in step.assets" :key="asset.id || asset.url">
              <img v-if="tutorialAssetURL(asset.url)" :src="tutorialAssetURL(asset.url)" :alt="step.title" class="max-h-80 w-full rounded-lg border border-gray-200 object-contain dark:border-dark-600" />
            </template>
          </div>
        </div>
      </div>
    </BaseDialog>

    <BaseDialog :show="showTutorialManager" :title="ui.tutorialManagement" width="extra-wide" @close="showTutorialManager = false">
      <div class="grid gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
        <div class="space-y-2">
          <button type="button" class="btn btn-secondary w-full" @click="newTutorialStep">{{ ui.newSiteStep }}</button>
          <button v-for="step in tutorialAdmin?.base.steps || []" :key="step.id" type="button" class="w-full rounded border border-gray-200 p-2 text-left text-sm dark:border-dark-600" @click="editTutorialStep(step.id)">{{ step.title }}</button>
        </div>
        <div class="space-y-3">
          <input v-model="tutorialForm.step_id" class="input" :placeholder="ui.stableStepID" :disabled="tutorialStepExists" />
          <input v-model="tutorialForm.title" class="input" :placeholder="ui.stepTitle" />
          <textarea v-model="tutorialForm.body_md" class="input min-h-[220px] font-mono text-xs" :placeholder="ui.markdownBody"></textarea>
          <div class="grid gap-3 sm:grid-cols-2">
            <input v-model.number="tutorialForm.position" type="number" class="input" :placeholder="ui.position" />
            <input v-model="tutorialExternalURL" class="input" placeholder="https://..." />
          </div>
          <label class="flex items-center gap-2 text-sm"><input v-model="tutorialForm.hidden" type="checkbox" />{{ ui.hideStep }}</label>
          <input type="file" accept="image/png,image/jpeg,image/gif" @change="uploadTutorialImage" />
          <div class="flex gap-2">
            <button type="button" class="btn btn-primary" @click="saveTutorialStep">{{ ui.save }}</button>
            <button v-if="tutorialStepHasOverride" type="button" class="btn btn-danger" @click="removeTutorialStepOverride">{{ ui.removeOverride }}</button>
          </div>
          <div class="border-t border-gray-200 pt-4 dark:border-dark-600">
            <div class="flex gap-2"><button type="button" class="btn btn-secondary" @click="checkTutorialRelease">{{ ui.checkTutorialUpdate }}</button></div>
            <div v-if="tutorialCandidate" class="mt-3 rounded border border-gray-200 p-3 text-sm dark:border-dark-600">
              <p>Release {{ tutorialCandidate.version }}</p>
              <div v-for="conflict in tutorialCandidate.conflicts" :key="conflict.step_id" class="mt-2 flex items-center gap-2">
                <span class="min-w-0 flex-1">{{ conflict.step_id }} · {{ conflict.change }}</span>
                <select v-model="tutorialConflictResolutions[conflict.step_id]" class="input w-44"><option value="">{{ ui.chooseResolution }}</option><option value="keep_site">{{ ui.keepSite }}</option><option value="use_release">{{ ui.useRelease }}</option></select>
              </div>
              <div class="mt-3 flex gap-2"><button type="button" class="btn btn-primary" :disabled="!canAdoptTutorial" @click="adoptTutorialRelease">{{ ui.adoptUpdate }}</button><button type="button" class="btn btn-secondary" @click="rejectTutorialRelease">{{ ui.rejectUpdate }}</button></div>
            </div>
          </div>
        </div>
      </div>
    </BaseDialog>

    <BaseDialog :show="showTemplateManager" :title="templateUI.management" width="extra-wide" @close="showTemplateManager = false">
      <div class="space-y-4">
        <section class="card p-4">
          <h3 class="mb-4 font-medium">{{ templateUI.subscriptionConfiguration }}</h3>
          <div class="grid gap-4 md:grid-cols-2">
            <label v-for="field in subscriptionTemplateFields" :key="field.key" class="space-y-1 text-sm">
              <span>{{ field.label }}</span>
              <input class="input w-full" :placeholder="subscriptionTemplateDefault(field.key)" :value="subscriptionTemplateValue(field.key)" @input="setSubscriptionTemplateValue(field.key, ($event.target as HTMLInputElement).value)" />
              <span class="input-hint block">{{ templateUI.subscriptionDescriptions[field.key] }}</span>
            </label>
          </div>
        </section>

        <section class="card p-4">
          <h3 class="mb-4 font-medium">{{ templateUI.groupConfiguration }}</h3>
          <div v-if="templateGroups.length" class="space-y-2">
            <details v-for="group in templateGroups" :key="group.id" class="rounded border border-gray-200 p-3 dark:border-dark-600">
              <summary class="cursor-pointer font-medium">
                {{ group.name }}
                <span class="ml-2 text-xs font-normal text-gray-500">{{ group.platform }}</span>
              </summary>
              <div class="mt-4 grid gap-4 md:grid-cols-2">
                <label v-for="field in visibleProviderTemplateStringFields" :key="field.key" class="space-y-1 text-sm">
                  <span>{{ field.label }}</span>
                  <input class="input w-full" :placeholder="providerTemplateDefault(group, field.key)" :value="providerTemplateValue(group.id, field.key)" @input="setProviderTemplateValue(group, field.key, ($event.target as HTMLInputElement).value)" />
                  <span class="input-hint block">{{ templateUI.providerDescriptions[field.key] }}</span>
                  <span v-if="field.key === 'base_url' && templateEndpointErrors[group.id]" class="text-xs text-red-600">{{ templateEndpointErrors[group.id] }}</span>
                </label>

                <label v-for="field in visibleProviderTemplateJSONFields" :key="field.key" class="space-y-1 text-sm md:col-span-2">
                  <span>{{ field.label }}</span>
                  <textarea class="input min-h-28 w-full font-mono text-xs" :placeholder="providerJSONDefault(group, field.key)" :value="providerJSONDraft(group.id, field.key)" @input="setProviderJSONDraft(group, field.key, ($event.target as HTMLTextAreaElement).value)"></textarea>
                  <span class="input-hint block">
                    {{ templateUI.providerDescriptions[field.key] }}
                    <code v-if="field.key === 'settings_config'" v-pre>{{provider.api_key}}</code>
                  </span>
                  <span v-if="templateJSONErrors[providerJSONDraftKey(group.id, field.key)]" class="text-xs text-red-600">{{ templateJSONErrors[providerJSONDraftKey(group.id, field.key)] }}</span>
                </label>
              </div>
            </details>
          </div>
          <p v-else class="text-sm text-gray-500">{{ templateUI.noGroups }}</p>
        </section>

        <details class="card p-4">
          <summary class="cursor-pointer font-medium">{{ templateUI.advancedLayout }}</summary>
          <p class="input-hint my-3">{{ templateUI.advancedHint }} <code v-pre>{{provider.api_key}}</code></p>
          <textarea v-model="templateDraft" class="input min-h-[420px] w-full font-mono text-xs" spellcheck="false"></textarea>
        </details>

        <section class="card space-y-2 p-4">
          <div class="flex items-center justify-between">
            <h3 class="font-medium">{{ templateUI.fullPreview }}</h3>
            <span v-if="templatePreviewLoading" class="text-xs text-gray-500">{{ templateUI.previewRefreshing }}</span>
          </div>
          <textarea :value="templatePreview" class="input min-h-[360px] w-full font-mono text-xs" readonly spellcheck="false"></textarea>
        </section>

        <div v-if="visibleTemplateDiagnostics.length" class="space-y-2">
          <div v-for="diagnostic in visibleTemplateDiagnostics" :key="`${diagnostic.code}-${diagnostic.message}`" :class="diagnostic.level === 'error' ? 'text-red-600' : 'text-amber-600'" class="text-sm">
            {{ diagnostic.code }}: {{ diagnostic.message }}
          </div>
        </div>
      </div>
      <template #footer>
        <button type="button" class="btn btn-secondary" @click="saveTemplateDraft">{{ templateUI.saveDraft }}</button>
        <button type="button" class="btn btn-primary" :disabled="templateHasErrors" @click="publishTemplate">{{ templateUI.publish }}</button>
      </template>
    </BaseDialog>

    <ConfirmDialog
      :show="showDeleteDialog"
      :title="ui.deleteSubscription"
      :message="deleteMessage"
      :confirm-text="ui.delete"
      :cancel-text="ui.cancel"
      :danger="true"
      @confirm="confirmDelete"
      @cancel="cancelDelete"
    />
    <ConfirmDialog
      :show="showPublishWarningsDialog"
      :title="templateUI.publishWarningsTitle"
      :message="templateUI.publishWarningsMessage"
      :confirm-text="templateUI.confirmPublish"
      :cancel-text="templateUI.cancel"
      @confirm="confirmPublishTemplate"
      @cancel="showPublishWarningsDialog = false"
    />
  </AppLayout>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { marked } from 'marked'
import DOMPurify from 'dompurify'
import AppLayout from '@/components/layout/AppLayout.vue'
import TablePageLayout from '@/components/layout/TablePageLayout.vue'
import DataTable from '@/components/common/DataTable.vue'
import Pagination from '@/components/common/Pagination.vue'
import BaseDialog from '@/components/common/BaseDialog.vue'
import ConfirmDialog from '@/components/common/ConfirmDialog.vue'
import EmptyState from '@/components/common/EmptyState.vue'
import SearchInput from '@/components/common/SearchInput.vue'
import GroupBadge from '@/components/common/GroupBadge.vue'
import Icon from '@/components/icons/Icon.vue'
import { useClipboard } from '@/composables/useClipboard'
import { getPersistedPageSize } from '@/composables/usePersistedPageSize'
import { useAppStore } from '@/stores/app'
import { useAuthStore } from '@/stores/auth'
import { formatDateTime } from '@/utils/format'
import { maskApiKey } from '@/utils/maskApiKey'
import { extractSettingsEndpoint, syncSettingsEndpoint } from '@/utils/hamsterSwitchSettings'
import type { ApiKey, GroupPlatform, SubscriptionType } from '@/types'
import type { Column } from '@/components/common/types'
import {
  hamsterSwitchSubscriptionsAPI,
  type HamsterSwitchGroupOption,
  type ConfigSubscriptionItem,
  type ConfigSubscriptionTutorial,
  type TutorialAdminState,
  type TutorialCandidate,
  type TemplateDiagnostic,
  type SubscriptionTemplatePresentationState,
  type SubscriptionTemplateDefaults,
  type SubscriptionTemplateGroup,
  type ProviderTemplatePresentation
} from '@/api/hamsterSwitchSubscriptions'

const appStore = useAppStore()
const authStore = useAuthStore()
const { copyToClipboard } = useClipboard()
const { t } = useI18n()

const ui = new Proxy({} as Record<string, string>, {
  get: (_target, key) => t(`subscriptionManagement.${String(key)}`)
})

const templateUI = computed(() => ({
  management: t('subscriptionManagement.template.management'),
  subscriptionConfiguration: t('subscriptionManagement.template.subscriptionConfiguration'),
  groupConfiguration: t('subscriptionManagement.template.groupConfiguration'),
  noGroups: t('subscriptionManagement.template.noGroups'),
  advancedLayout: t('subscriptionManagement.template.advancedLayout'),
  advancedHint: t('subscriptionManagement.template.advancedHint'),
  fullPreview: t('subscriptionManagement.template.fullPreview'),
  previewRefreshing: t('subscriptionManagement.template.previewRefreshing'),
  saveDraft: t('subscriptionManagement.template.saveDraft'),
  publish: t('subscriptionManagement.template.publish'),
  jsonObjectRequired: t('subscriptionManagement.template.jsonObjectRequired'),
  invalidJSON: t('subscriptionManagement.template.invalidJSON'),
  invalidEndpoint: t('subscriptionManagement.template.invalidEndpoint'),
  publishWarningsTitle: t('subscriptionManagement.template.publishWarningsTitle'),
  publishWarningsMessage: t('subscriptionManagement.template.publishWarningsMessage'),
  confirmPublish: t('subscriptionManagement.template.confirmPublish'),
  cancel: t('subscriptionManagement.template.cancel'),
  subscriptionDescriptions: {
    name: t('subscriptionManagement.template.subscriptionDescriptions.name'),
    description: t('subscriptionManagement.template.subscriptionDescriptions.description'),
    icon: t('subscriptionManagement.template.subscriptionDescriptions.icon'),
    home_url: t('subscriptionManagement.template.subscriptionDescriptions.home_url')
  },
  providerDescriptions: {
    name: t('subscriptionManagement.template.providerDescriptions.name'),
    description: t('subscriptionManagement.template.providerDescriptions.description'),
    icon: t('subscriptionManagement.template.providerDescriptions.icon'),
    base_url: t('subscriptionManagement.template.providerDescriptions.base_url'),
    pricing: t('subscriptionManagement.template.providerDescriptions.pricing'),
    settings_config: t('subscriptionManagement.template.providerDescriptions.settings_config')
  }
}))

const columns = computed<Column[]>(() => [
  { key: 'name', label: ui.name, sortable: true },
  { key: 'group_names', label: ui.groups, sortable: false },
  { key: 'url', label: ui.urlAddress, sortable: false },
  { key: 'quota', label: ui.quota, sortable: false },
  { key: 'rate_limit', label: ui.rateLimit, sortable: false },
  { key: 'expires_at', label: ui.expiresAt, sortable: true },
  { key: 'status', label: ui.status, sortable: true },
  { key: 'created_at', label: ui.createdAt, sortable: true },
  { key: 'actions', label: ui.actions, sortable: false }
])

const subscriptions = ref<ConfigSubscriptionItem[]>([])
const groupOptions = ref<HamsterSwitchGroupOption[]>([])
const loading = ref(false)
const submitting = ref(false)
const savingSubscriptionSettings = ref(false)
const hideSubscriptionAPIKeys = ref(false)
const filterSearch = ref('')
const copiedSubscriptionId = ref<string | null>(null)
const showCreateModal = ref(false)
const showYamlEditor = ref(false)
const showTutorial = ref(false)
const showTutorialManager = ref(false)
const showTemplateManager = ref(false)
const showDeleteDialog = ref(false)
const showPublishWarningsDialog = ref(false)
const selectedDeleteSubscription = ref<ConfigSubscriptionItem | null>(null)
const editingSubscriptionId = ref<string | null>(null)
const editingUpdatedAt = ref<string | null>(null)
const existingGroupIDs = ref<number[]>([])
const editingAPIKeys = ref<ApiKey[]>([])
const templateDraft = ref('')
const templatePresentation = ref<SubscriptionTemplatePresentationState>({ subscription: {}, providers: {} })
const templateDefaults = ref<SubscriptionTemplateDefaults>({ name: '', description: '', icon: '', home_url: '' })
const templateGroups = ref<SubscriptionTemplateGroup[]>([])
const templateProviderFields = ref<string[]>([])
const templatePreview = ref('')
const templatePreviewLoading = ref(false)
const templateDiagnostics = ref<TemplateDiagnostic[]>([])
const templateJSONDrafts = ref<Record<string, string>>({})
const templateJSONErrors = ref<Record<string, string>>({})
const templateEndpointErrors = ref<Record<number, string>>({})
const tutorial = ref<ConfigSubscriptionTutorial | null>(null)
const tutorialSubscriptionURL = ref('')
const tutorialLoading = ref(false)
const tutorialAdmin = ref<TutorialAdminState | null>(null)
const tutorialCandidate = ref<TutorialCandidate | null>(null)
const tutorialExternalURL = ref('')
const tutorialConflictResolutions = ref<Record<string, '' | 'keep_site' | 'use_release'>>({})
const tutorialForm = ref({ step_id: '', title: '', body_md: '', assets: [] as Array<{ kind: 'site'; id: string }>, optional: false, hidden: false, position: 0 })
const yamlContent = ref('')
const editingYAMLName = ref('')
const editingYAMLURL = ref('')
let abortController: AbortController | null = null

const pagination = ref({
  page: 1,
  page_size: getPersistedPageSize(),
  total: 0,
  pages: 0
})

const form = ref({
  name: t('subscriptionManagement.defaultSubscriptionName'),
  group_ids: [] as number[],
  custom_api_keys: {} as Record<number, string>,
  enable_ip_restriction: false,
  ip_whitelist: '',
  ip_blacklist: '',
  enable_quota: false,
  quota: null as number | null,
  enable_rate_limit: false,
  rate_limit_5h: null as number | null,
  rate_limit_1d: null as number | null,
  rate_limit_7d: null as number | null,
  enable_expiration: false,
  expiration_preset: '30' as '7' | '30' | '90' | 'custom',
  expiration_date: ''
})

const availableGroups = computed(() => groupOptions.value.filter((group) => group.available !== false))

const selectedGroups = computed(() => {
  const selected = new Set(form.value.group_ids)
  return availableGroups.value.filter((group) => selected.has(group.id))
})

const customKeyGroups = computed(() => {
  if (!editingSubscriptionId.value) return selectedGroups.value
  const existing = new Set(existingGroupIDs.value)
  return selectedGroups.value.filter((group) => !existing.has(group.id))
})

const existingSelectedGroups = computed(() => {
  const existing = new Set(existingGroupIDs.value)
  return selectedGroups.value.filter((group) => existing.has(group.id))
})

const allGroupsSelected = computed(() => {
  return availableGroups.value.length > 0 && form.value.group_ids.length === availableGroups.value.length
})

const groupPlatform = (value: string): GroupPlatform => value as GroupPlatform

const groupSubscriptionType = (value: string): SubscriptionType => value as SubscriptionType

const numberValue = (value: number | null | undefined): number => value ?? 0

const hasRateLimit = (row: ConfigSubscriptionItem) => {
  return row.rate_limit_5h > 0 || row.rate_limit_1d > 0 || row.rate_limit_7d > 0
}

const resetForm = () => {
  form.value = {
    name: t('subscriptionManagement.defaultSubscriptionName'),
    group_ids: availableGroups.value.map((group) => group.id),
    custom_api_keys: {},
    enable_ip_restriction: false,
    ip_whitelist: '',
    ip_blacklist: '',
    enable_quota: false,
    quota: null,
    enable_rate_limit: false,
    rate_limit_5h: null,
    rate_limit_1d: null,
    rate_limit_7d: null,
    enable_expiration: false,
    expiration_preset: '30',
    expiration_date: formatDateTimeLocal(new Date(Date.now() + 30 * 86400000))
  }
}

const loadOptions = async () => {
  const result = await hamsterSwitchSubscriptionsAPI.getOptions()
  groupOptions.value = result.groups || []
}

const loadSubscriptions = async () => {
  abortController?.abort()
  const controller = new AbortController()
  abortController = controller
  loading.value = true
  try {
    const response = await hamsterSwitchSubscriptionsAPI.list(
      pagination.value.page,
      pagination.value.page_size,
      { search: filterSearch.value || undefined },
      { signal: controller.signal }
    )
    if (controller.signal.aborted) return
    subscriptions.value = response.items
    pagination.value.total = response.total
    pagination.value.pages = response.pages
  } catch (error: any) {
    if (error?.code !== 'ERR_CANCELED') {
      appStore.showError(error?.message || ui.loadSubscriptionsFailed)
    }
  } finally {
    if (abortController === controller) {
      loading.value = false
    }
  }
}

const openCreateModal = async () => {
  if (groupOptions.value.length === 0) {
    try {
      await loadOptions()
    } catch (error: any) {
      appStore.showError(error?.message || ui.loadGroupsFailed)
    }
  }
  editingSubscriptionId.value = null
  editingUpdatedAt.value = null
  existingGroupIDs.value = []
  resetForm()
  showCreateModal.value = true
}

const closeCreateModal = () => {
  showCreateModal.value = false
  editingSubscriptionId.value = null
  editingUpdatedAt.value = null
  existingGroupIDs.value = []
}

const openEditModal = async (row: ConfigSubscriptionItem) => {
  let detail = row
  try {
    detail = await hamsterSwitchSubscriptionsAPI.get(row.id)
  } catch (error: any) {
    appStore.showError(error?.message || ui.loadSubscriptionsFailed)
    return
  }
  editingSubscriptionId.value = detail.id
  editingUpdatedAt.value = detail.updated_at
  existingGroupIDs.value = detail.keys.map((item) => item.group_id)
  form.value = {
    name: detail.name,
    group_ids: [...existingGroupIDs.value],
    custom_api_keys: {},
    enable_ip_restriction: detail.ip_whitelist.length > 0 || detail.ip_blacklist.length > 0,
    ip_whitelist: detail.ip_whitelist.join('\n'),
    ip_blacklist: detail.ip_blacklist.join('\n'),
    enable_quota: detail.quota > 0,
    quota: detail.quota || null,
    enable_rate_limit: hasRateLimit(detail),
    rate_limit_5h: detail.rate_limit_5h || null,
    rate_limit_1d: detail.rate_limit_1d || null,
    rate_limit_7d: detail.rate_limit_7d || null,
    enable_expiration: Boolean(detail.expires_at),
    expiration_preset: 'custom',
    expiration_date: detail.expires_at ? formatDateTimeLocal(new Date(detail.expires_at)) : ''
  }
  showCreateModal.value = true
}

const toggleGroup = (groupId: number) => {
  const selected = new Set(form.value.group_ids)
  if (selected.has(groupId)) {
    selected.delete(groupId)
  } else {
    selected.add(groupId)
  }
  form.value.group_ids = [...selected]
}

const toggleAllGroups = () => {
  form.value.group_ids = allGroupsSelected.value ? [] : availableGroups.value.map((group) => group.id)
}

const parseIPList = (value: string): string[] => {
  return value
    .split('\n')
    .map((item) => item.trim())
    .filter(Boolean)
}

const applyExpirationPreset = () => {
  if (form.value.expiration_preset === 'custom') return
  const days = Number(form.value.expiration_preset)
  const date = new Date()
  date.setDate(date.getDate() + days)
  form.value.expiration_date = formatDateTimeLocal(date)
}

const formatDateTimeLocal = (value: Date): string => {
  const pad = (n: number) => n.toString().padStart(2, '0')
  return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}T${pad(value.getHours())}:${pad(value.getMinutes())}`
}

const calculateExpiresAt = (): string | null => {
  if (!form.value.enable_expiration || !form.value.expiration_date) return null
  return new Date(form.value.expiration_date).toISOString()
}

const buildSubscriptionPayload = () => {
  const customAPIKeys: Record<string, string> = {}
  for (const groupId of form.value.group_ids) {
    const value = String(form.value.custom_api_keys[groupId] || '').trim()
    if (value) customAPIKeys[String(groupId)] = value
  }
  return {
    name: form.value.name,
    group_ids: form.value.group_ids,
    custom_api_keys: Object.keys(customAPIKeys).length > 0 ? customAPIKeys : undefined,
    ip_whitelist: form.value.enable_ip_restriction ? parseIPList(form.value.ip_whitelist) : [],
    ip_blacklist: form.value.enable_ip_restriction ? parseIPList(form.value.ip_blacklist) : [],
    quota: form.value.enable_quota && form.value.quota && form.value.quota > 0 ? form.value.quota : 0,
    expires_at: calculateExpiresAt(),
    updated_at: editingUpdatedAt.value || undefined,
    rate_limit_5h: form.value.enable_rate_limit && form.value.rate_limit_5h && form.value.rate_limit_5h > 0 ? form.value.rate_limit_5h : 0,
    rate_limit_1d: form.value.enable_rate_limit && form.value.rate_limit_1d && form.value.rate_limit_1d > 0 ? form.value.rate_limit_1d : 0,
    rate_limit_7d: form.value.enable_rate_limit && form.value.rate_limit_7d && form.value.rate_limit_7d > 0 ? form.value.rate_limit_7d : 0
  }
}

const submitCreate = async () => {
  if (form.value.group_ids.length === 0) {
    appStore.showError(ui.selectOneGroup)
    return
  }

  submitting.value = true
  try {
    const payload = buildSubscriptionPayload()
    if (editingSubscriptionId.value) {
      await hamsterSwitchSubscriptionsAPI.update(editingSubscriptionId.value, payload)
      appStore.showSuccess(ui.updated)
    } else {
      await hamsterSwitchSubscriptionsAPI.create(payload)
      appStore.showSuccess(ui.subscriptionCreated)
    }
    showCreateModal.value = false
    editingSubscriptionId.value = null
    pagination.value.page = 1
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    submitting.value = false
  }
}

const copySubscriptionURL = async (row: ConfigSubscriptionItem) => {
  const ok = await copyToClipboard(row.url, ui.urlCopied)
  if (ok) {
    copiedSubscriptionId.value = row.id
    setTimeout(() => {
      if (copiedSubscriptionId.value === row.id) {
        copiedSubscriptionId.value = null
      }
    }, 2000)
  }
}

const openYamlEditor = async (row: ConfigSubscriptionItem) => {
  try {
    const result = await hamsterSwitchSubscriptionsAPI.getYAML(row.id)
    yamlContent.value = result.yaml
    editingYAMLName.value = result.name || row.name
    editingYAMLURL.value = result.url || row.url
    editingAPIKeys.value = row.api_keys || []
    showYamlEditor.value = true
  } catch (error: any) {
    appStore.showError(error?.message || ui.loadYAMLFailed)
  }
}

const closeYamlEditor = () => {
  showYamlEditor.value = false
  yamlContent.value = ''
  editingYAMLName.value = ''
  editingYAMLURL.value = ''
  editingAPIKeys.value = []
}

const copyEditingURL = async () => {
  await copyToClipboard(editingYAMLURL.value, ui.urlCopied)
}

const copyYamlContent = async () => {
  await copyToClipboard(yamlContent.value, ui.yamlCopied)
}

const copyDedicatedKey = async (key: string) => {
  await copyToClipboard(key, ui.keyCopied)
}

const toggleSubscription = async (row: ConfigSubscriptionItem) => {
  try {
    if (row.status === 'disabled') {
      await hamsterSwitchSubscriptionsAPI.enable(row.id)
      appStore.showSuccess(ui.enabled)
    } else {
      await hamsterSwitchSubscriptionsAPI.disable(row.id)
      appStore.showSuccess(ui.disabled)
    }
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const deleteMessage = computed(() => t('subscriptionManagement.deleteConfirmation', { name: selectedDeleteSubscription.value?.name || '' }))

const requestDelete = (row: ConfigSubscriptionItem) => {
  selectedDeleteSubscription.value = row
  showDeleteDialog.value = true
}

const cancelDelete = () => {
  showDeleteDialog.value = false
  selectedDeleteSubscription.value = null
}

const confirmDelete = async () => {
  const selected = selectedDeleteSubscription.value
  if (!selected) return
  try {
    await hamsterSwitchSubscriptionsAPI.delete(selected.id)
    showDeleteDialog.value = false
    selectedDeleteSubscription.value = null
    appStore.showSuccess(ui.deleted)
    await loadSubscriptions()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const renderTutorialMarkdown = (body: string) => {
  const sanitized = DOMPurify.sanitize(marked.parse(body || '') as string)
  const template = document.createElement('template')
  template.innerHTML = sanitized
  template.content.querySelectorAll('img').forEach((image) => image.remove())
  return template.innerHTML
}

const tutorialAssetURL = (value?: string) => value?.startsWith('/api/hamster-switch/tutorial/images/') ? value : ''

const openTutorial = async () => {
  tutorialSubscriptionURL.value = ''
  showTutorial.value = true
  tutorialLoading.value = true
  try {
    tutorial.value = await hamsterSwitchSubscriptionsAPI.getTutorial()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    tutorialLoading.value = false
  }
}

const openUseSubscription = async (row: ConfigSubscriptionItem) => {
  tutorialSubscriptionURL.value = row.url
  await openTutorialWithCurrentURL()
}

const openTutorialWithCurrentURL = async () => {
  showTutorial.value = true
  tutorialLoading.value = true
  try {
    tutorial.value = await hamsterSwitchSubscriptionsAPI.getTutorial()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    tutorialLoading.value = false
  }
}

const copyTutorialSubscriptionURL = async () => {
  await copyToClipboard(tutorialSubscriptionURL.value, ui.urlCopied)
}

const loadSubscriptionSettings = async () => {
  if (!authStore.isAdmin) return
  const result = await hamsterSwitchSubscriptionsAPI.getSettings()
  hideSubscriptionAPIKeys.value = result.hide_api_keys
}

const saveSubscriptionSettings = async () => {
  if (!authStore.isAdmin) return
  savingSubscriptionSettings.value = true
  const desired = hideSubscriptionAPIKeys.value
  try {
    const result = await hamsterSwitchSubscriptionsAPI.updateSettings(desired)
    hideSubscriptionAPIKeys.value = result.hide_api_keys
  } catch (error: any) {
    hideSubscriptionAPIKeys.value = !desired
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    savingSubscriptionSettings.value = false
  }
}

const refreshTutorialAdmin = async () => {
  tutorialAdmin.value = await hamsterSwitchSubscriptionsAPI.getTutorialAdmin()
  tutorialCandidate.value = tutorialAdmin.value.candidate || null
  tutorialConflictResolutions.value = {}
}

const openTutorialManager = async () => {
  try {
    await refreshTutorialAdmin()
    showTutorialManager.value = true
    const first = tutorialAdmin.value?.base.steps[0]
    if (first) editTutorialStep(first.id)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const tutorialStepExists = computed(() => Boolean(
  tutorialAdmin.value?.base.steps.some((step) => step.id === tutorialForm.value.step_id)
))

const tutorialStepHasOverride = computed(() => Boolean(
  tutorialAdmin.value?.overrides.some((step) => step.step_id === tutorialForm.value.step_id)
))

const editTutorialStep = (stepId: string) => {
  const base = tutorialAdmin.value?.base.steps.find((step) => step.id === stepId)
  const override = tutorialAdmin.value?.overrides.find((step) => step.step_id === stepId)
  const source = override || base
  const index = tutorialAdmin.value?.base.steps.findIndex((step) => step.id === stepId) ?? 0
  tutorialForm.value = {
    step_id: stepId,
    title: source?.title || '',
    body_md: source?.body_md || '',
    assets: (source?.assets || []).filter((asset): asset is { kind: 'site'; id: string } => asset.kind === 'site' && Boolean(asset.id)),
    optional: source?.optional || false,
    hidden: override?.hidden || false,
    position: override?.position ?? Math.max(0, index) * 100
  }
  tutorialExternalURL.value = ''
}

const newTutorialStep = () => {
  tutorialForm.value = { step_id: '', title: '', body_md: '', assets: [], optional: false, hidden: false, position: (tutorialAdmin.value?.base.steps.length || 0) * 100 }
  tutorialExternalURL.value = ''
}

const saveTutorialStep = async () => {
  const stepId = tutorialForm.value.step_id.trim()
  if (!stepId) return
  try {
    const assets: Array<{ kind: 'site' | 'external'; id?: string; url?: string }> = [...tutorialForm.value.assets]
    if (tutorialExternalURL.value.trim()) assets.push({ kind: 'external', url: tutorialExternalURL.value.trim() })
    await hamsterSwitchSubscriptionsAPI.saveTutorialOverride(stepId, { ...tutorialForm.value, assets })
    await refreshTutorialAdmin()
    editTutorialStep(stepId)
    appStore.showSuccess(ui.save)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const removeTutorialStepOverride = async () => {
  const stepId = tutorialForm.value.step_id
  try {
    await hamsterSwitchSubscriptionsAPI.deleteTutorialOverride(stepId)
    await refreshTutorialAdmin()
    if (tutorialAdmin.value?.base.steps.some((step) => step.id === stepId)) editTutorialStep(stepId)
    else newTutorialStep()
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const uploadTutorialImage = async (event: Event) => {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  try {
    const result = await hamsterSwitchSubscriptionsAPI.uploadTutorialImage(file)
    tutorialForm.value.assets.push({ kind: 'site', id: result.id })
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  } finally {
    input.value = ''
  }
}

const checkTutorialRelease = async () => {
  try {
    tutorialCandidate.value = await hamsterSwitchSubscriptionsAPI.checkTutorialUpdate()
    tutorialConflictResolutions.value = {}
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const canAdoptTutorial = computed(() => Boolean(tutorialCandidate.value) && tutorialCandidate.value!.conflicts.every(
  (conflict) => Boolean(tutorialConflictResolutions.value[conflict.step_id])
))

const adoptTutorialRelease = async () => {
  if (!tutorialCandidate.value || !canAdoptTutorial.value) return
  try {
    await hamsterSwitchSubscriptionsAPI.adoptTutorialUpdate(
      tutorialCandidate.value.version,
      tutorialConflictResolutions.value as Record<string, 'keep_site' | 'use_release'>
    )
    await refreshTutorialAdmin()
    appStore.showSuccess(ui.adoptUpdate)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const rejectTutorialRelease = async () => {
  if (!tutorialCandidate.value) return
  try {
    await hamsterSwitchSubscriptionsAPI.rejectTutorialUpdate(tutorialCandidate.value.version)
    await refreshTutorialAdmin()
    appStore.showSuccess(ui.rejectUpdate)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

type SubscriptionTemplateFieldKey = 'name' | 'description' | 'icon' | 'home_url'
type ProviderTemplateStringFieldKey = 'name' | 'description' | 'icon' | 'base_url'
type ProviderTemplateJSONFieldKey = 'pricing' | 'settings_config'

const subscriptionTemplateFields = [
  { key: 'name', label: 'name' },
  { key: 'description', label: 'description' },
  { key: 'icon', label: 'icon' },
  { key: 'home_url', label: 'home_url' }
] as const

const providerTemplateStringFields = [
  { key: 'name', label: 'name' },
  { key: 'description', label: 'description' },
  { key: 'icon', label: 'icon' },
  { key: 'base_url', label: 'base_url' }
] as const

const providerTemplateJSONFields = [
  { key: 'pricing', label: 'pricing' },
  { key: 'settings_config', label: 'settings_config' }
] as const

const providerTemplateFieldEnabled = (key: keyof ProviderTemplatePresentation) => templateProviderFields.value.includes(key)
const visibleProviderTemplateStringFields = computed(() => providerTemplateStringFields.filter((field) => providerTemplateFieldEnabled(field.key)))
const visibleProviderTemplateJSONFields = computed(() => providerTemplateJSONFields.filter((field) => providerTemplateFieldEnabled(field.key)))

const hasOwn = (value: object, key: PropertyKey) => Object.prototype.hasOwnProperty.call(value, key)

const normalizeTemplatePresentation = (
  value?: Partial<SubscriptionTemplatePresentationState> | null
): SubscriptionTemplatePresentationState => ({
  subscription: { ...(value?.subscription || {}) },
  providers: { ...(value?.providers || {}) }
})

const subscriptionTemplateDefault = (key: SubscriptionTemplateFieldKey) => templateDefaults.value[key] || ''

const subscriptionTemplateValue = (key: SubscriptionTemplateFieldKey) => {
  return templatePresentation.value.subscription[key] ?? ''
}

const setSubscriptionTemplateValue = (key: SubscriptionTemplateFieldKey, value: string) => {
  if (value === '') delete templatePresentation.value.subscription[key]
  else templatePresentation.value.subscription[key] = value
}

const getProviderTemplateOverride = (groupID: number) => templatePresentation.value.providers[String(groupID)]

const ensureProviderTemplateOverride = (groupID: number): ProviderTemplatePresentation => {
  const key = String(groupID)
  if (!templatePresentation.value.providers[key]) templatePresentation.value.providers[key] = {}
  return templatePresentation.value.providers[key]
}

const cleanupProviderTemplateOverride = (groupID: number) => {
  const key = String(groupID)
  if (Object.keys(templatePresentation.value.providers[key] || {}).length === 0) {
    delete templatePresentation.value.providers[key]
  }
}

const providerTemplateDefault = (group: SubscriptionTemplateGroup, key: ProviderTemplateStringFieldKey) => {
  if (key === 'name') return group.default_name
  if (key === 'description') return group.default_description
  if (key === 'icon') return group.default_icon
  if (key === 'base_url') return group.default_base_url
  return ''
}

const providerTemplateValue = (groupID: number, key: keyof ProviderTemplatePresentation) => {
  const value = getProviderTemplateOverride(groupID)?.[key]
  return value === undefined || value === null ? '' : String(value)
}

const endpointIsValid = (value: string) => {
  try {
    const parsed = new URL(value)
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && Boolean(parsed.host) && !parsed.username && !parsed.password
  } catch {
    return false
  }
}

const setProviderTemplateValue = (group: SubscriptionTemplateGroup, key: ProviderTemplateStringFieldKey, value: string) => {
  const override = ensureProviderTemplateOverride(group.id)
  if (value === '') delete override[key]
  else override[key] = value
  if (key === 'base_url') {
    if (value === '') {
      delete templateEndpointErrors.value[group.id]
      delete override.settings_config
      delete templateJSONDrafts.value[providerJSONDraftKey(group.id, 'settings_config')]
    } else {
      if (!endpointIsValid(value)) {
        templateEndpointErrors.value[group.id] = templateUI.value.invalidEndpoint
        return
      }
      delete templateEndpointErrors.value[group.id]
      const settings = syncSettingsEndpoint(group.app_type, override.settings_config || group.default_settings_config, value)
      override.settings_config = settings
      templateJSONDrafts.value[providerJSONDraftKey(group.id, 'settings_config')] = JSON.stringify(settings, null, 2)
    }
  }
  cleanupProviderTemplateOverride(group.id)
}

const providerJSONDraftKey = (groupID: number, key: ProviderTemplateJSONFieldKey) => `${groupID}:${key}`

const providerJSONDraft = (groupID: number, key: ProviderTemplateJSONFieldKey) => {
  const draftKey = providerJSONDraftKey(groupID, key)
  if (hasOwn(templateJSONDrafts.value, draftKey)) return templateJSONDrafts.value[draftKey]
  const value = getProviderTemplateOverride(groupID)?.[key]
  if (value !== undefined) return JSON.stringify(value, null, 2)
  return ''
}

const providerJSONDefault = (group: SubscriptionTemplateGroup, key: ProviderTemplateJSONFieldKey) => JSON.stringify(
  key === 'settings_config' ? group.default_settings_config : {}, null, 2
)

const setProviderJSONDraft = (group: SubscriptionTemplateGroup, key: ProviderTemplateJSONFieldKey, value: string) => {
  const draftKey = providerJSONDraftKey(group.id, key)
  templateJSONDrafts.value[draftKey] = value
  if (value.trim() === '') {
    const override = getProviderTemplateOverride(group.id)
    if (override) {
      delete override[key]
    }
    cleanupProviderTemplateOverride(group.id)
    delete templateJSONErrors.value[draftKey]
    return
  }
  try {
    const parsed = JSON.parse(value)
    if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error(templateUI.value.jsonObjectRequired)
    const override = ensureProviderTemplateOverride(group.id)
    override[key] = parsed as Record<string, unknown>
    if (key === 'settings_config') {
      const endpoint = extractSettingsEndpoint(group.app_type, parsed as Record<string, unknown>)
      if (!endpoint || !endpointIsValid(endpoint)) throw new Error(templateUI.value.invalidEndpoint)
      override.base_url = endpoint
      delete templateEndpointErrors.value[group.id]
    }
    delete templateJSONErrors.value[draftKey]
  } catch (error: any) {
    templateJSONErrors.value[draftKey] = error?.message || templateUI.value.invalidJSON
  }
}

const resetTemplateJSONDrafts = () => {
  templateJSONDrafts.value = {}
  templateJSONErrors.value = {}
  templateEndpointErrors.value = {}
  for (const group of templateGroups.value) {
    for (const field of providerTemplateJSONFields) {
      const value = getProviderTemplateOverride(group.id)?.[field.key]
      if (value !== undefined) templateJSONDrafts.value[providerJSONDraftKey(group.id, field.key)] = JSON.stringify(value, null, 2)
    }
  }
}

const templateJSONDiagnostics = computed<TemplateDiagnostic[]>(() => Object.entries(templateJSONErrors.value).map(([key, message]) => ({
  level: 'error',
  code: `INVALID_JSON_${key.replace(':', '_').toUpperCase()}`,
  message
})))
const templateEndpointDiagnostics = computed<TemplateDiagnostic[]>(() => Object.entries(templateEndpointErrors.value).map(([key, message]) => ({
  level: 'error', code: `INVALID_ENDPOINT_${key}`, message
})))
const templateLocalDiagnostics = computed(() => [...templateJSONDiagnostics.value, ...templateEndpointDiagnostics.value])
const templateAllDiagnostics = computed(() => [...templateDiagnostics.value, ...templateLocalDiagnostics.value])
const visibleTemplateDiagnostics = computed(() => templateAllDiagnostics.value.filter((item) => item.code !== 'GROUP_PREVIEW_SKIPPED'))
const templateHasErrors = computed(() => templateAllDiagnostics.value.some((item) => item.level === 'error'))

let templatePreviewTimer: ReturnType<typeof setTimeout> | null = null
let templatePreviewRequestID = 0

const refreshTemplatePreview = async () => {
  if (!showTemplateManager.value || templateLocalDiagnostics.value.length) return
  const requestID = ++templatePreviewRequestID
  templatePreviewLoading.value = true
  try {
    const state = await hamsterSwitchSubscriptionsAPI.previewTemplate(templateDraft.value, templatePresentation.value)
    if (requestID !== templatePreviewRequestID) return
    templatePreview.value = state.preview || ''
    templateDiagnostics.value = state.diagnostics || []
    templateDefaults.value = state.defaults
    templateGroups.value = state.groups || []
    templateProviderFields.value = state.provider_fields || []
  } catch (error: any) {
    if (requestID !== templatePreviewRequestID) return
    templateDiagnostics.value = [{ level: 'error', code: 'PREVIEW_FAILED', message: error?.message || ui.createFailed }]
  } finally {
    if (requestID === templatePreviewRequestID) templatePreviewLoading.value = false
  }
}

watch([templateDraft, templatePresentation], () => {
  if (!showTemplateManager.value) return
  if (templatePreviewTimer) clearTimeout(templatePreviewTimer)
  templatePreviewTimer = setTimeout(refreshTemplatePreview, 450)
}, { deep: true })

const openTemplateManager = async () => {
  try {
    const state = await hamsterSwitchSubscriptionsAPI.getTemplate()
    templateDraft.value = state.draft
    templatePresentation.value = normalizeTemplatePresentation(state.presentation)
    templateDefaults.value = state.defaults
    templateGroups.value = state.groups || []
    templateProviderFields.value = state.provider_fields || []
    templatePreview.value = state.preview || ''
    templateDiagnostics.value = state.diagnostics || []
    resetTemplateJSONDrafts()
    showTemplateManager.value = true
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const saveTemplateDraft = async () => {
  try {
    if (templateLocalDiagnostics.value.length) return
    const result = await hamsterSwitchSubscriptionsAPI.saveTemplateDraft(templateDraft.value, templatePresentation.value)
    templatePresentation.value = normalizeTemplatePresentation(result.presentation)
    templateDefaults.value = result.defaults
    templateGroups.value = result.groups || []
    templateProviderFields.value = result.provider_fields || []
    templatePreview.value = result.preview || ''
    templateDiagnostics.value = result.diagnostics || []
    resetTemplateJSONDrafts()
    appStore.showSuccess(ui.saveDraft)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const publishTemplate = async () => {
  try {
    if (templateLocalDiagnostics.value.length) return
    const saved = await hamsterSwitchSubscriptionsAPI.saveTemplateDraft(templateDraft.value, templatePresentation.value)
    templatePresentation.value = normalizeTemplatePresentation(saved.presentation)
    templateProviderFields.value = saved.provider_fields || []
    templatePreview.value = saved.preview || ''
    templateDiagnostics.value = saved.diagnostics || []
    if (templateHasErrors.value) return
    const hasWarnings = templateDiagnostics.value.some((item) => item.level === 'warning')
    if (hasWarnings) {
      showPublishWarningsDialog.value = true
      return
    }
    await commitTemplatePublish(false)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const commitTemplatePublish = async (acknowledgeWarnings: boolean) => {
  await hamsterSwitchSubscriptionsAPI.publishTemplate(acknowledgeWarnings)
  showPublishWarningsDialog.value = false
  appStore.showSuccess(ui.publish)
}

const confirmPublishTemplate = async () => {
  try {
    await commitTemplatePublish(true)
  } catch (error: any) {
    appStore.showError(error?.message || ui.createFailed)
  }
}

const downloadYamlContent = () => {
  const blob = new Blob([yamlContent.value], { type: 'application/x-yaml;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  const fileName = `${(editingYAMLName.value || 'hamster-switch').replace(/[\\/:*?"<>|]+/g, '-')}.yaml`
  link.href = url
  link.download = fileName
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

const handleSearch = () => {
  pagination.value.page = 1
  loadSubscriptions()
}

const handlePageChange = (page: number) => {
  pagination.value.page = page
  loadSubscriptions()
}

const handlePageSizeChange = (pageSize: number) => {
  pagination.value.page_size = pageSize
  pagination.value.page = 1
  loadSubscriptions()
}

const statusLabel = (status: string) => {
  if (status === 'active') return ui.active
  if (status === 'quota_exhausted') return ui.quotaExhausted
  if (status === 'expired') return ui.expired
  return ui.inactive
}

const statusClass = (status: string) => {
  if (status === 'active') return 'badge-success'
  if (status === 'quota_exhausted') return 'badge-warning'
  if (status === 'expired') return 'badge-danger'
  return 'badge-gray'
}

onMounted(() => {
  loadSubscriptions()
  loadOptions()
  loadSubscriptionSettings()
})

onUnmounted(() => {
  abortController?.abort()
  if (templatePreviewTimer) clearTimeout(templatePreviewTimer)
})
</script>
