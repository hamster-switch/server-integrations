import { apiClient } from './client'
import type { ApiKey, PaginatedResponse } from '@/types'

export interface HamsterSwitchProviderPreview {
  id: string
  app_type: 'claude' | 'codex' | 'gemini'
  group_id: number
  group_name: string
  name: string
  platform: string
  models: string[]
  models_count: number
  default_model: string
  base_url: string
  warnings: string[]
}

export interface HamsterSwitchGroupOption {
  id: number
  name: string
  platform: string
  app_type: string
  models_count: number
  default_model: string
  available: boolean
  warnings: string[]
  subscription_type: string
  rate_multiplier: number
}

export interface HamsterSwitchOptionsResponse {
  enabled: boolean
  base_url: string
  groups: HamsterSwitchGroupOption[]
}

export interface ConfigSubscriptionPayload {
  name: string
  group_ids: number[]
  custom_api_keys?: Record<string, string>
  ip_whitelist?: string[]
  ip_blacklist?: string[]
  quota?: number
  expires_in_days?: number
  expires_at?: string | null
  updated_at?: string
  rate_limit_5h?: number
  rate_limit_1d?: number
  rate_limit_7d?: number
}

export interface ConfigSubscriptionItem {
  id: string
  name: string
  url: string
  status: 'active' | 'disabled' | 'quota_exhausted' | 'expired'
  keys: Array<{ api_key_id: number; group_id: number; group_name: string }>
  api_keys: ApiKey[]
  group_names: string[]
  providers: HamsterSwitchProviderPreview[]
  warnings: string[]
  ip_whitelist: string[]
  ip_blacklist: string[]
  quota: number
  quota_used: number
  rate_limit_5h: number
  rate_limit_1d: number
  rate_limit_7d: number
  expires_at: string | null
  created_at: string
  updated_at: string
}

export interface HamsterSwitchYAMLResponse {
  id: string
  name: string
  url: string
  yaml: string
  diagnostics: TemplateDiagnostic[]
}

export interface TemplateDiagnostic {
  level: 'error' | 'warning'
  code: string
  message: string
}

export interface SubscriptionTemplatePresentation {
  name?: string
  description?: string
  icon?: string
  home_url?: string
}

export interface ProviderTemplatePresentation {
  name?: string
  description?: string
  icon?: string
  base_url?: string
  pricing?: Record<string, unknown>
  settings_config?: Record<string, unknown>
}

export interface SubscriptionTemplatePresentationState {
  subscription: SubscriptionTemplatePresentation
  providers: Record<string, ProviderTemplatePresentation>
}

export interface SubscriptionTemplateDefaults {
  name: string
  description: string
  icon: string
  home_url: string
}

export interface SubscriptionTemplateGroup {
  id: number
  name: string
  platform: string
  app_type: 'claude' | 'codex' | 'gemini'
  default_name: string
  default_icon: string
  default_description: string
  default_base_url: string
  default_settings_config: Record<string, unknown>
  override?: ProviderTemplatePresentation
}

export interface YAMLTemplateVersion {
  version: number
  body: string
  presentation: SubscriptionTemplatePresentationState
  warnings: TemplateDiagnostic[]
  warning_confirmed_by?: number
  warning_confirmed_at?: string
  created_by?: number
  created_at: string
  active: boolean
}

export interface YAMLTemplateState {
  draft: string
  presentation: SubscriptionTemplatePresentationState
  defaults: SubscriptionTemplateDefaults
  groups: SubscriptionTemplateGroup[]
  provider_fields: string[]
  preview: string
  diagnostics: TemplateDiagnostic[]
  current?: YAMLTemplateVersion
  history: YAMLTemplateVersion[]
}

export type SubscriptionTemplatePreview = Pick<
  YAMLTemplateState,
  'presentation' | 'defaults' | 'groups' | 'provider_fields' | 'preview' | 'diagnostics'
>

export interface TutorialAsset {
  kind: 'release' | 'site' | 'external'
  id?: string
  url?: string
}

export interface TutorialStep {
  id: string
  title: string
  body_md: string
  assets?: TutorialAsset[]
  optional?: boolean
}

export interface ConfigSubscriptionTutorial {
  schema_version: number
  id: string
  version: string
  locale: string
  title: string
  steps: TutorialStep[]
}

export interface TutorialOverride {
  step_id: string
  title: string
  body_md: string
  assets?: TutorialAsset[]
  optional?: boolean
  hidden?: boolean
  position: number
}

export interface TutorialCandidate {
  version: string
  tutorial: ConfigSubscriptionTutorial
  conflicts: Array<{ step_id: string; change: 'modified' | 'deleted' }>
}

export interface TutorialAdminState {
  base: ConfigSubscriptionTutorial
  overrides: TutorialOverride[]
  candidate: TutorialCandidate | null
}

const emptyTutorial = (): ConfigSubscriptionTutorial => ({
  schema_version: 1,
  id: 'configuration-subscription-guide-zh-cn',
  version: '0.0.0',
  locale: 'zh-CN',
  title: '配置订阅教程',
  steps: []
})

export function normalizeTutorialAdminState(value: Partial<TutorialAdminState> | null | undefined): TutorialAdminState {
  const rawBase = value?.base
  const base = rawBase && typeof rawBase === 'object'
    ? { ...emptyTutorial(), ...rawBase, steps: Array.isArray(rawBase.steps) ? rawBase.steps : [] }
    : emptyTutorial()
  const rawCandidate = value?.candidate
  const candidate = rawCandidate && typeof rawCandidate === 'object'
    ? {
        ...rawCandidate,
        tutorial: rawCandidate.tutorial && typeof rawCandidate.tutorial === 'object'
          ? { ...emptyTutorial(), ...rawCandidate.tutorial, steps: Array.isArray(rawCandidate.tutorial.steps) ? rawCandidate.tutorial.steps : [] }
          : emptyTutorial(),
        conflicts: Array.isArray(rawCandidate.conflicts) ? rawCandidate.conflicts : []
      }
    : null
  return { base, overrides: Array.isArray(value?.overrides) ? value.overrides : [], candidate }
}

const basePath = '/keys/hamster-switch/subscriptions'

export async function getHamsterSwitchOptions(): Promise<HamsterSwitchOptionsResponse> {
  const { data } = await apiClient.get<HamsterSwitchOptionsResponse>('/keys/hamster-switch/options')
  return data
}

export async function listConfigSubscriptions(
  page = 1,
  pageSize = 10,
  filters?: { search?: string },
  options?: { signal?: AbortSignal }
): Promise<PaginatedResponse<ConfigSubscriptionItem>> {
  const { data } = await apiClient.get<PaginatedResponse<ConfigSubscriptionItem>>(basePath, {
    params: { page, page_size: pageSize, ...filters },
    signal: options?.signal
  })
  return data
}

export async function previewConfigSubscription(
  name: string,
  groupIds: number[]
): Promise<{ providers: HamsterSwitchProviderPreview[]; warnings: string[] }> {
  const { data } = await apiClient.post<{ providers: HamsterSwitchProviderPreview[]; warnings: string[] }>(
    `${basePath}/preview`,
    { name, group_ids: groupIds }
  )
  return data
}

export async function createConfigSubscription(payload: ConfigSubscriptionPayload): Promise<ConfigSubscriptionItem> {
  const { data } = await apiClient.post<ConfigSubscriptionItem>(basePath, payload)
  return data
}

export async function getConfigSubscriptionDetail(id: string): Promise<ConfigSubscriptionItem> {
  const { data } = await apiClient.get<ConfigSubscriptionItem>(`${basePath}/${id}`)
  return data
}

export async function updateConfigSubscription(id: string, payload: ConfigSubscriptionPayload): Promise<ConfigSubscriptionItem> {
  const { data } = await apiClient.put<ConfigSubscriptionItem>(`${basePath}/${id}`, payload)
  return data
}

export async function disableConfigSubscription(id: string): Promise<ConfigSubscriptionItem> {
  const { data } = await apiClient.post<ConfigSubscriptionItem>(`${basePath}/${id}/disable`)
  return data
}

export async function enableConfigSubscription(id: string): Promise<ConfigSubscriptionItem> {
  const { data } = await apiClient.post<ConfigSubscriptionItem>(`${basePath}/${id}/enable`)
  return data
}

export async function deleteConfigSubscription(id: string): Promise<void> {
  await apiClient.delete(`${basePath}/${id}`)
}

export async function getConfigSubscriptionYAML(id: string): Promise<HamsterSwitchYAMLResponse> {
	const { data } = await apiClient.get<HamsterSwitchYAMLResponse>(`/keys/hamster-switch/admin/subscriptions/${id}/yaml`)
	return data
}

export async function getConfigSubscriptionSettings(): Promise<{ hide_api_keys: boolean }> {
  const { data } = await apiClient.get<{ hide_api_keys: boolean }>('/keys/hamster-switch/admin/settings')
  return data
}

export async function updateConfigSubscriptionSettings(hideAPIKeys: boolean): Promise<{ hide_api_keys: boolean }> {
  const { data } = await apiClient.put<{ hide_api_keys: boolean }>('/keys/hamster-switch/admin/settings', {
    hide_api_keys: hideAPIKeys
  })
  return data
}

export async function getYAMLTemplateState(): Promise<YAMLTemplateState> {
  const { data } = await apiClient.get<YAMLTemplateState>('/keys/hamster-switch/admin/subscription-template')
  return data
}

export async function previewYAMLTemplate(
  body: string,
  presentation: SubscriptionTemplatePresentationState
): Promise<SubscriptionTemplatePreview> {
  const { data } = await apiClient.post<SubscriptionTemplatePreview>(
    '/keys/hamster-switch/admin/subscription-template/preview',
    { body, presentation }
  )
  return data
}

export async function saveYAMLTemplateDraft(
  body: string,
  presentation: SubscriptionTemplatePresentationState
): Promise<SubscriptionTemplatePreview> {
  const { data } = await apiClient.put<SubscriptionTemplatePreview>(
    '/keys/hamster-switch/admin/subscription-template/draft',
    { body, presentation }
  )
  return data
}

export async function publishYAMLTemplate(acknowledgeWarnings: boolean): Promise<{ version: YAMLTemplateVersion; diagnostics: TemplateDiagnostic[] }> {
  const { data } = await apiClient.post<{ version: YAMLTemplateVersion; diagnostics: TemplateDiagnostic[] }>(
    '/keys/hamster-switch/admin/subscription-template/publish',
    { acknowledge_warnings: acknowledgeWarnings }
  )
  return data
}

export async function rollbackYAMLTemplate(version: number): Promise<YAMLTemplateVersion> {
  const { data } = await apiClient.post<YAMLTemplateVersion>(
    `/keys/hamster-switch/admin/subscription-template/rollback/${version}`
  )
  return data
}

export async function getConfigSubscriptionTutorial(): Promise<ConfigSubscriptionTutorial> {
  const { data } = await apiClient.get<ConfigSubscriptionTutorial>('/keys/hamster-switch/tutorial')
  return data
}

export async function getTutorialAdminState(): Promise<TutorialAdminState> {
	const { data } = await apiClient.get<Partial<TutorialAdminState> | null>('/keys/hamster-switch/admin/tutorial')
	return normalizeTutorialAdminState(data)
}

export async function checkTutorialUpdate(): Promise<TutorialCandidate & { changed: boolean }> {
  const { data } = await apiClient.post<TutorialCandidate & { changed: boolean }>('/keys/hamster-switch/admin/tutorial/check-update')
  return data
}

export async function adoptTutorialUpdate(version: string, resolutions: Record<string, 'keep_site' | 'use_release'>): Promise<void> {
  await apiClient.post('/keys/hamster-switch/admin/tutorial/adopt', { version, resolutions })
}

export async function rejectTutorialUpdate(version: string): Promise<void> {
  await apiClient.post('/keys/hamster-switch/admin/tutorial/reject', { version })
}

export async function saveTutorialOverride(stepId: string, override: Omit<TutorialOverride, 'step_id'>): Promise<TutorialOverride> {
  const { data } = await apiClient.put<TutorialOverride>(`/keys/hamster-switch/admin/tutorial/overrides/${stepId}`, override)
  return data
}

export async function deleteTutorialOverride(stepId: string): Promise<void> {
  await apiClient.delete(`/keys/hamster-switch/admin/tutorial/overrides/${stepId}`)
}

export async function uploadTutorialImage(file: File): Promise<{ id: string; url: string }> {
  const form = new FormData()
  form.append('file', file)
  const { data } = await apiClient.post<{ id: string; url: string }>('/keys/hamster-switch/admin/tutorial/images', form)
  return data
}

export const hamsterSwitchSubscriptionsAPI = {
  getOptions: getHamsterSwitchOptions,
  list: listConfigSubscriptions,
  get: getConfigSubscriptionDetail,
  preview: previewConfigSubscription,
  create: createConfigSubscription,
  update: updateConfigSubscription,
  disable: disableConfigSubscription,
  enable: enableConfigSubscription,
  delete: deleteConfigSubscription,
  getYAML: getConfigSubscriptionYAML,
  getSettings: getConfigSubscriptionSettings,
  updateSettings: updateConfigSubscriptionSettings,
  getTemplate: getYAMLTemplateState,
  previewTemplate: previewYAMLTemplate,
  saveTemplateDraft: saveYAMLTemplateDraft,
  publishTemplate: publishYAMLTemplate,
  rollbackTemplate: rollbackYAMLTemplate,
  getTutorial: getConfigSubscriptionTutorial,
  getTutorialAdmin: getTutorialAdminState,
  checkTutorialUpdate,
  adoptTutorialUpdate,
  rejectTutorialUpdate,
  saveTutorialOverride,
  deleteTutorialOverride,
  uploadTutorialImage
}

export default hamsterSwitchSubscriptionsAPI
