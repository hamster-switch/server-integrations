export type HamsterSwitchAppType = 'claude' | 'codex' | 'gemini'

const hasOwn = (value: object, key: PropertyKey) => Object.prototype.hasOwnProperty.call(value, key)

export function extractSettingsEndpoint(appType: HamsterSwitchAppType, settings: Record<string, unknown>): string {
  if (appType === 'claude') return String((settings.env as Record<string, unknown> | undefined)?.ANTHROPIC_BASE_URL || '')
  if (appType === 'gemini') {
    const env = settings.env as Record<string, unknown> | undefined
    return String(env?.GOOGLE_GEMINI_BASE_URL || env?.GEMINI_BASE_URL || '')
  }
  const config = typeof settings.config === 'string' ? settings.config : ''
  const provider = config.match(/^\s*model_provider\s*=\s*"([A-Za-z0-9_-]+)"\s*(?:#.*)?$/m)?.[1] || 'custom'
  let inProvider = false
  for (const line of config.split('\n')) {
    const section = line.match(/^\s*\[model_providers\.([A-Za-z0-9_-]+)\]\s*(?:#.*)?$/)
    if (section) inProvider = section[1] === provider
    else if (/^\s*\[/.test(line)) inProvider = false
    if (inProvider) {
      const match = line.match(/^\s*base_url\s*=\s*"((?:[^"\\]|\\.)*)"/)
      if (match) {
        try { return JSON.parse(`"${match[1]}"`) } catch { return '' }
      }
    }
  }
  return ''
}

export function syncSettingsEndpoint(appType: HamsterSwitchAppType, source: Record<string, unknown>, endpoint: string): Record<string, unknown> {
  const settings = structuredClone(source)
  if (appType === 'claude' || appType === 'gemini') {
    const env = { ...((settings.env as Record<string, unknown> | undefined) || {}) }
    if (appType === 'claude') env.ANTHROPIC_BASE_URL = endpoint
    else {
      env.GOOGLE_GEMINI_BASE_URL = endpoint
      if (hasOwn(env, 'GEMINI_BASE_URL')) env.GEMINI_BASE_URL = endpoint
    }
    settings.env = env
    return settings
  }
  const config = typeof settings.config === 'string' ? settings.config : ''
  const provider = config.match(/^\s*model_provider\s*=\s*"([A-Za-z0-9_-]+)"\s*(?:#.*)?$/m)?.[1] || 'custom'
  const escaped = endpoint.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
  let inProvider = false
  settings.config = config.split('\n').map((line) => {
    const section = line.match(/^\s*\[model_providers\.([A-Za-z0-9_-]+)\]\s*(?:#.*)?$/)
    if (section) inProvider = section[1] === provider
    else if (/^\s*\[/.test(line)) inProvider = false
    return inProvider && /^\s*base_url\s*=/.test(line)
      ? line.replace(/^(\s*base_url\s*=\s*)"(?:[^"\\]|\\.)*"/, `$1"${escaped}"`)
      : line
  }).join('\n')
  return settings
}
