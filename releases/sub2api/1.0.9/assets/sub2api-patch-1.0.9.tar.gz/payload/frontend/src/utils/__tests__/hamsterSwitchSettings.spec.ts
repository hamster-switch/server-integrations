import { describe, expect, it } from 'vitest'
import { extractSettingsEndpoint, syncSettingsEndpoint } from '../hamsterSwitchSettings'

describe('Hamster Switch settings endpoint synchronization', () => {
  it.each([
    ['claude', { env: { ANTHROPIC_BASE_URL: 'https://old.example/v1' } }],
    ['gemini', { env: { GOOGLE_GEMINI_BASE_URL: 'https://old.example/v1beta', GEMINI_BASE_URL: 'https://old.example/v1beta' } }]
  ] as const)('synchronizes %s environment settings', (appType, settings) => {
    const updated = syncSettingsEndpoint(appType, settings, 'https://new.example/api')
    expect(extractSettingsEndpoint(appType, updated)).toBe('https://new.example/api')
    if (appType === 'gemini') expect((updated.env as Record<string, unknown>).GEMINI_BASE_URL).toBe('https://new.example/api')
  })

  it('updates only the active Codex provider and preserves TOML content', () => {
    const config = 'model_provider = "custom"\nmodel = "gpt-5.5"\n\n[model_providers.other]\nbase_url = "https://other.example/v1"\n\n[model_providers.custom]\nname = "sub2api"\nbase_url = "https://old.example/v1"\nwire_api = "responses"\n'
    const updated = syncSettingsEndpoint('codex', { config }, 'https://new.example/v1')
    expect(extractSettingsEndpoint('codex', updated)).toBe('https://new.example/v1')
    expect(updated.config).toContain('base_url = "https://other.example/v1"')
    expect(updated.config).toContain('model = "gpt-5.5"')
    expect(updated.config).toContain('wire_api = "responses"')
  })
})
