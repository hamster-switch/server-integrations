package model

import (
	"errors"
	"fmt"
	"sort"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/bytedance/gopkg/util/gopool"
	"gorm.io/gorm"
)

const (
	HamsterSubscriptionActive   = "active"
	HamsterSubscriptionDisabled = "disabled"
)

type HamsterConfigSubscription struct {
	ID            uint                                `json:"id"`
	PublicID      string                              `json:"public_id" gorm:"type:varchar(64);uniqueIndex;not null"`
	DownloadToken string                              `json:"download_token" gorm:"type:varchar(128);uniqueIndex;not null"`
	UserID        int                                 `json:"user_id" gorm:"index;not null"`
	Name          string                              `json:"name" gorm:"type:varchar(128);not null"`
	Status        string                              `json:"status" gorm:"type:varchar(16);index;not null"`
	CreatedTime   int64                               `json:"created_time" gorm:"bigint;not null"`
	UpdatedTime   int64                               `json:"updated_time" gorm:"bigint;not null"`
	Providers     []HamsterConfigSubscriptionProvider `json:"providers,omitempty" gorm:"foreignKey:SubscriptionID"`
	DeletedAt     gorm.DeletedAt                      `json:"-" gorm:"index"`
}

type HamsterConfigSubscriptionProvider struct {
	ID             uint   `json:"id"`
	SubscriptionID uint   `json:"subscription_id" gorm:"uniqueIndex:idx_hamster_subscription_group;index;not null"`
	GroupName      string `json:"group_name" gorm:"type:varchar(64);uniqueIndex:idx_hamster_subscription_group;not null"`
	TokenID        int    `json:"token_id" gorm:"uniqueIndex;not null"`
	Position       int    `json:"position" gorm:"not null"`
}

type HamsterYAMLTemplate struct {
	ID                 uint   `json:"id"`
	Version            int    `json:"version" gorm:"uniqueIndex;not null"`
	Body               string `json:"body" gorm:"type:text;not null"`
	Warnings           string `json:"warnings" gorm:"type:text"`
	Active             bool   `json:"active" gorm:"index;not null"`
	WarningConfirmedBy int    `json:"warning_confirmed_by"`
	WarningConfirmedAt int64  `json:"warning_confirmed_at" gorm:"bigint"`
	CreatedBy          int    `json:"created_by"`
	CreatedTime        int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterYAMLTemplateDraft struct {
	ID          uint   `json:"id" gorm:"primaryKey"`
	Body        string `json:"body" gorm:"type:text;not null"`
	UpdatedBy   int    `json:"updated_by"`
	UpdatedTime int64  `json:"updated_time" gorm:"bigint;not null"`
}

type HamsterTutorialSnapshot struct {
	ID          uint   `json:"id"`
	Version     string `json:"version" gorm:"type:varchar(64);uniqueIndex;not null"`
	Body        string `json:"body" gorm:"type:text;not null"`
	Active      bool   `json:"active" gorm:"index;not null"`
	CreatedBy   int    `json:"created_by"`
	CreatedTime int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterTutorialOverride struct {
	ID          uint   `json:"id"`
	StepID      string `json:"step_id" gorm:"type:varchar(96);uniqueIndex;not null"`
	Body        string `json:"body" gorm:"type:text;not null"`
	BaseVersion string `json:"base_version" gorm:"type:varchar(64);not null"`
	UpdatedBy   int    `json:"updated_by"`
	UpdatedTime int64  `json:"updated_time" gorm:"bigint;not null"`
}

type HamsterTutorialImage struct {
	ID          string `json:"id" gorm:"type:varchar(64);primaryKey"`
	LocalName   string `json:"local_name" gorm:"type:varchar(128);not null"`
	MediaType   string `json:"media_type" gorm:"type:varchar(64);not null"`
	SizeBytes   int64  `json:"size_bytes" gorm:"bigint;not null"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	SourceURL   string `json:"source_url" gorm:"type:text"`
	CreatedBy   int    `json:"created_by"`
	CreatedTime int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterSubscriptionInput struct {
	Name   string
	Groups []string
}

func normalizeHamsterGroups(groups []string) ([]string, error) {
	seen := make(map[string]bool, len(groups))
	result := make([]string, 0, len(groups))
	for _, value := range groups {
		group := strings.TrimSpace(value)
		if group == "" || group == "auto" || seen[group] {
			continue
		}
		if len(group) > 64 {
			return nil, errors.New("分组名称不能超过 64 个字符")
		}
		seen[group] = true
		result = append(result, group)
	}
	if len(result) == 0 {
		return nil, errors.New("至少选择一个分组")
	}
	sort.Strings(result)
	return result, nil
}

func validateHamsterSubscriptionInput(input HamsterSubscriptionInput) (string, []string, error) {
	name := strings.TrimSpace(input.Name)
	if name == "" {
		return "", nil, errors.New("订阅名称不能为空")
	}
	if len(name) > 128 {
		return "", nil, errors.New("订阅名称不能超过 128 个字符")
	}
	groups, err := normalizeHamsterGroups(input.Groups)
	return name, groups, err
}

func newHamsterDedicatedToken(userID int, subscriptionName, group string, status int) (*Token, error) {
	key, err := common.GenerateKey()
	if err != nil {
		return nil, err
	}
	return &Token{
		UserId: userID, Key: key, Status: status,
		Name: fmt.Sprintf("%s - %s", subscriptionName, group), CreatedTime: common.GetTimestamp(),
		ExpiredTime: -1, UnlimitedQuota: true, Group: group,
	}, nil
}

func CreateHamsterConfigSubscription(userID int, input HamsterSubscriptionInput) (*HamsterConfigSubscription, error) {
	name, groups, err := validateHamsterSubscriptionInput(input)
	if err != nil {
		return nil, err
	}
	now := common.GetTimestamp()
	subscription := &HamsterConfigSubscription{
		PublicID: common.GetUUID(), DownloadToken: common.GetRandomString(48), UserID: userID,
		Name: name, Status: HamsterSubscriptionActive, CreatedTime: now, UpdatedTime: now,
	}
	err = DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(subscription).Error; err != nil {
			return err
		}
		for position, group := range groups {
			token, err := newHamsterDedicatedToken(userID, name, group, common.TokenStatusEnabled)
			if err != nil {
				return err
			}
			if err := tx.Create(token).Error; err != nil {
				return err
			}
			provider := HamsterConfigSubscriptionProvider{SubscriptionID: subscription.ID, GroupName: group, TokenID: token.Id, Position: position}
			if err := tx.Create(&provider).Error; err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return GetHamsterConfigSubscription(userID, subscription.PublicID)
}

func ListHamsterConfigSubscriptions(userID, offset, limit int, search string) ([]HamsterConfigSubscription, int64, error) {
	if offset < 0 {
		offset = 0
	}
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	query := DB.Model(&HamsterConfigSubscription{}).Where("user_id = ?", userID)
	if search = strings.TrimSpace(search); search != "" {
		query = query.Where("name LIKE ?", "%"+strings.ReplaceAll(strings.ReplaceAll(search, "%", "\\%"), "_", "\\_")+"%")
	}
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	var items []HamsterConfigSubscription
	err := query.Preload("Providers", func(db *gorm.DB) *gorm.DB { return db.Order("position asc") }).Order("id desc").Offset(offset).Limit(limit).Find(&items).Error
	return items, total, err
}

func GetHamsterConfigSubscription(userID int, publicID string) (*HamsterConfigSubscription, error) {
	var item HamsterConfigSubscription
	err := DB.Preload("Providers", func(db *gorm.DB) *gorm.DB { return db.Order("position asc") }).Where("user_id = ? AND public_id = ?", userID, strings.TrimSpace(publicID)).First(&item).Error
	return &item, err
}

func GetHamsterConfigSubscriptionByDownloadToken(downloadToken string) (*HamsterConfigSubscription, error) {
	var item HamsterConfigSubscription
	err := DB.Preload("Providers", func(db *gorm.DB) *gorm.DB { return db.Order("position asc") }).Where("download_token = ?", strings.TrimSpace(downloadToken)).First(&item).Error
	return &item, err
}

func GetHamsterSubscriptionTokens(item *HamsterConfigSubscription) (map[int]*Token, error) {
	ids := make([]int, 0, len(item.Providers))
	for _, provider := range item.Providers {
		ids = append(ids, provider.TokenID)
	}
	var tokens []*Token
	if len(ids) > 0 {
		if err := DB.Where("id IN ?", ids).Find(&tokens).Error; err != nil {
			return nil, err
		}
	}
	result := make(map[int]*Token, len(tokens))
	for _, token := range tokens {
		result[token.Id] = token
	}
	return result, nil
}

func UpdateHamsterConfigSubscription(userID int, publicID string, input HamsterSubscriptionInput) (*HamsterConfigSubscription, error) {
	name, groups, err := validateHamsterSubscriptionInput(input)
	if err != nil {
		return nil, err
	}
	var invalidated []string
	err = DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Providers").Where("user_id = ? AND public_id = ?", userID, publicID).First(&item).Error; err != nil {
			return err
		}
		status := common.TokenStatusEnabled
		if item.Status == HamsterSubscriptionDisabled {
			status = common.TokenStatusDisabled
		}
		existing := make(map[string]HamsterConfigSubscriptionProvider, len(item.Providers))
		for _, provider := range item.Providers {
			existing[provider.GroupName] = provider
		}
		wanted := make(map[string]bool, len(groups))
		for position, group := range groups {
			wanted[group] = true
			if provider, ok := existing[group]; ok {
				if err := tx.Model(&provider).Update("position", position).Error; err != nil {
					return err
				}
				if err := tx.Model(&Token{}).Where("id = ? AND user_id = ?", provider.TokenID, userID).Update("name", fmt.Sprintf("%s - %s", name, group)).Error; err != nil {
					return err
				}
				continue
			}
			token, err := newHamsterDedicatedToken(userID, name, group, status)
			if err != nil {
				return err
			}
			if err := tx.Create(token).Error; err != nil {
				return err
			}
			provider := HamsterConfigSubscriptionProvider{SubscriptionID: item.ID, GroupName: group, TokenID: token.Id, Position: position}
			if err := tx.Create(&provider).Error; err != nil {
				return err
			}
		}
		for group, provider := range existing {
			if wanted[group] {
				continue
			}
			var token Token
			if err := tx.Unscoped().First(&token, provider.TokenID).Error; err == nil {
				invalidated = append(invalidated, token.Key)
			}
			if err := tx.Delete(&Token{}, provider.TokenID).Error; err != nil {
				return err
			}
			if err := tx.Delete(&provider).Error; err != nil {
				return err
			}
		}
		return tx.Model(&HamsterConfigSubscription{}).Where("id = ?", item.ID).Updates(map[string]any{"name": name, "updated_time": common.GetTimestamp()}).Error
	})
	invalidateHamsterTokenKeys(invalidated)
	if err != nil {
		return nil, err
	}
	return GetHamsterConfigSubscription(userID, publicID)
}

func SetHamsterConfigSubscriptionEnabled(userID int, publicID string, enabled bool) (*HamsterConfigSubscription, error) {
	status := HamsterSubscriptionDisabled
	tokenStatus := common.TokenStatusDisabled
	if enabled {
		status = HamsterSubscriptionActive
		tokenStatus = common.TokenStatusEnabled
	}
	var keys []string
	err := DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Providers").Where("user_id = ? AND public_id = ?", userID, publicID).First(&item).Error; err != nil {
			return err
		}
		ids := make([]int, 0, len(item.Providers))
		for _, provider := range item.Providers {
			ids = append(ids, provider.TokenID)
		}
		if len(ids) > 0 {
			var tokens []Token
			if err := tx.Where("id IN ?", ids).Find(&tokens).Error; err != nil {
				return err
			}
			for _, token := range tokens {
				keys = append(keys, token.Key)
			}
			if err := tx.Model(&Token{}).Where("id IN ?", ids).Update("status", tokenStatus).Error; err != nil {
				return err
			}
		}
		return tx.Model(&HamsterConfigSubscription{}).Where("id = ?", item.ID).Updates(map[string]any{"status": status, "updated_time": common.GetTimestamp()}).Error
	})
	invalidateHamsterTokenKeys(keys)
	if err != nil {
		return nil, err
	}
	return GetHamsterConfigSubscription(userID, publicID)
}

func DeleteHamsterConfigSubscription(userID int, publicID string) error {
	var keys []string
	err := DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Providers").Where("user_id = ? AND public_id = ?", userID, publicID).First(&item).Error; err != nil {
			return err
		}
		ids := make([]int, 0, len(item.Providers))
		for _, provider := range item.Providers {
			ids = append(ids, provider.TokenID)
		}
		if len(ids) > 0 {
			var tokens []Token
			if err := tx.Where("id IN ?", ids).Find(&tokens).Error; err != nil {
				return err
			}
			for _, token := range tokens {
				keys = append(keys, token.Key)
			}
			if err := tx.Delete(&Token{}, ids).Error; err != nil {
				return err
			}
		}
		if err := tx.Delete(&HamsterConfigSubscriptionProvider{}, "subscription_id = ?", item.ID).Error; err != nil {
			return err
		}
		return tx.Delete(&item).Error
	})
	invalidateHamsterTokenKeys(keys)
	return err
}

func invalidateHamsterTokenKeys(keys []string) {
	if !common.RedisEnabled {
		return
	}
	for _, key := range keys {
		key := key
		gopool.Go(func() {
			if err := cacheDeleteToken(key); err != nil {
				common.SysLog("failed to invalidate Hamster subscription token: " + err.Error())
			}
		})
	}
}
