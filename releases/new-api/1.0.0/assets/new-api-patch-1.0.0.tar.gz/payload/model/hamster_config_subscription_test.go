package model

import (
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func setupHamsterSubscriptionTestDB(t *testing.T) {
	t.Helper()
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	require.NoError(t, err)
	previousDB := DB
	previousType := common.MainDatabaseType()
	DB = db
	t.Cleanup(func() {
		DB = previousDB
		common.SetMainDatabaseType(previousType)
		initCol()
	})
	sqlDB, err := DB.DB()
	require.NoError(t, err)
	sqlDB.SetMaxOpenConns(1)
	common.SetMainDatabaseType(common.DatabaseTypeSQLite)
	initCol()
	require.NoError(t, DB.AutoMigrate(&Token{}, &HamsterConfigSubscription{}, &HamsterConfigSubscriptionProvider{}))
}

func TestHamsterSubscriptionLifecycleKeepsStableURL(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "初始订阅", Groups: []string{"default", "vip"}})
	require.NoError(t, err)
	require.Len(t, created.Providers, 2)
	originalPublicID, originalDownloadToken := created.PublicID, created.DownloadToken
	originalTokens, err := GetHamsterSubscriptionTokens(created)
	require.NoError(t, err)
	retainedTokenID := 0
	removedTokenID := 0
	for _, provider := range created.Providers {
		if provider.GroupName == "default" {
			retainedTokenID = provider.TokenID
		}
		if provider.GroupName == "vip" {
			removedTokenID = provider.TokenID
		}
	}

	updated, err := UpdateHamsterConfigSubscription(42, created.PublicID, HamsterSubscriptionInput{Name: "更新订阅", Groups: []string{"default", "pro"}})
	require.NoError(t, err)
	assert.Equal(t, originalPublicID, updated.PublicID)
	assert.Equal(t, originalDownloadToken, updated.DownloadToken)
	updatedTokens, err := GetHamsterSubscriptionTokens(updated)
	require.NoError(t, err)
	assert.Equal(t, originalTokens[retainedTokenID].Key, updatedTokens[retainedTokenID].Key)
	var removed Token
	assert.ErrorIs(t, DB.First(&removed, removedTokenID).Error, gorm.ErrRecordNotFound)

	disabled, err := SetHamsterConfigSubscriptionEnabled(42, created.PublicID, false)
	require.NoError(t, err)
	assert.Equal(t, HamsterSubscriptionDisabled, disabled.Status)
	disabledTokens, err := GetHamsterSubscriptionTokens(disabled)
	require.NoError(t, err)
	for _, token := range disabledTokens {
		assert.Equal(t, common.TokenStatusDisabled, token.Status)
	}

	enabled, err := SetHamsterConfigSubscriptionEnabled(42, created.PublicID, true)
	require.NoError(t, err)
	assert.Equal(t, originalDownloadToken, enabled.DownloadToken)
	enabledTokens, err := GetHamsterSubscriptionTokens(enabled)
	require.NoError(t, err)
	for _, token := range enabledTokens {
		assert.Equal(t, common.TokenStatusEnabled, token.Status)
	}

	require.NoError(t, DeleteHamsterConfigSubscription(42, created.PublicID))
	_, err = GetHamsterConfigSubscriptionByDownloadToken(originalDownloadToken)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
}

func TestHamsterSubscriptionOwnershipIsEnforced(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "私有订阅", Groups: []string{"default"}})
	require.NoError(t, err)
	_, err = GetHamsterConfigSubscription(7, created.PublicID)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
	assert.ErrorIs(t, DeleteHamsterConfigSubscription(7, created.PublicID), gorm.ErrRecordNotFound)
}
