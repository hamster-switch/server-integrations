import { useQuery } from '@tanstack/react-query'
import {
  Copy,
  Download,
  ExternalLink,
  FileText,
  Pencil,
  Plus,
  Power,
  PowerOff,
  RefreshCw,
  Trash2,
} from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { SectionPageLayout } from '@/components/layout'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { ROLE } from '@/lib/roles'
import { useAuthStore } from '@/stores/auth-store'

import {
  adoptTutorialUpdate,
  checkTutorialUpdate,
  rejectTutorialUpdate,
  createSubscription,
  deleteSubscription,
  deleteTutorialOverride,
  getOptions,
  getSubscriptionYAML,
  getTemplateState,
  getTutorial,
  getTutorialAdminState,
  listSubscriptions,
  previewSubscription,
  publishTemplate,
  rollbackTemplate,
  saveTemplateDraft,
  saveTutorialOverride,
  setSubscriptionEnabled,
  updateSubscription,
  uploadTutorialImage,
  type ConfigSubscription,
  type ProviderPreview,
  type TemplateDiagnostic,
  type TutorialOverride,
} from './api'

type EditorState = { item?: ConfigSubscription; name: string; groups: string[] }

export function ConfigSubscriptions() {
  const { t } = useTranslation()
  const user = useAuthStore((state) => state.auth.user)
  const isAdmin = Boolean(user?.role && user.role >= ROLE.ADMIN)
  const [search, setSearch] = useState('')
  const [editor, setEditor] = useState<EditorState | null>(null)
  const [yamlItem, setYAMLItem] = useState<ConfigSubscription | null>(null)
  const [tutorialOpen, setTutorialOpen] = useState(false)
  const [deleteItem, setDeleteItem] = useState<ConfigSubscription | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const subscriptions = useQuery({
    queryKey: ['config-subscriptions', search],
    queryFn: () => listSubscriptions(search),
  })
  const options = useQuery({
    queryKey: ['config-subscription-options'],
    queryFn: getOptions,
  })
  const tutorial = useQuery({
    queryKey: ['config-subscription-tutorial'],
    queryFn: getTutorial,
    enabled: tutorialOpen,
  })

  const refresh = async () => subscriptions.refetch()
  const runMutation = async (
    action: () => Promise<{ success: boolean; message?: string }>,
    success: string
  ) => {
    setSubmitting(true)
    try {
      const result = await action()
      if (!result.success) {
        return toast.error(result.message || t('Request failed'))
      }
      toast.success(t(success))
      setEditor(null)
      setDeleteItem(null)
      await refresh()
    } catch {
      // The shared API interceptor displays the concrete error.
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <SectionPageLayout>
      <SectionPageLayout.Title>{t('配置订阅')}</SectionPageLayout.Title>
      <SectionPageLayout.Actions>
        <Button variant='outline' onClick={() => setTutorialOpen(true)}>
          {t('配置订阅教程')}
        </Button>
        <Button
          onClick={() => setEditor({ name: t('我的配置订阅'), groups: [] })}
        >
          <Plus className='mr-2 h-4 w-4' />
          {t('新增配置订阅')}
        </Button>
      </SectionPageLayout.Actions>
      <SectionPageLayout.Content>
        <Tabs defaultValue='subscriptions'>
          <TabsList>
            <TabsTrigger value='subscriptions'>{t('配置订阅')}</TabsTrigger>
            {isAdmin ? (
              <TabsTrigger value='content'>{t('内容维护')}</TabsTrigger>
            ) : null}
          </TabsList>
          <TabsContent value='subscriptions' className='space-y-4 pt-4'>
            <Input
              className='max-w-sm'
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder={t('搜索配置订阅')}
            />
            {subscriptions.isLoading ? (
              <div className='text-muted-foreground py-12 text-center'>
                {t('Loading')}
              </div>
            ) : null}
            {!subscriptions.isLoading &&
            (subscriptions.data?.items.length ?? 0) === 0 ? (
              <Card>
                <CardContent className='text-muted-foreground py-12 text-center'>
                  {t(
                    '还没有配置订阅，创建后即可复制 URL 或导入 Hamster Switch。'
                  )}
                </CardContent>
              </Card>
            ) : null}
            <div className='grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
              {subscriptions.data?.items.map((item) => (
                <SubscriptionCard
                  key={item.id}
                  item={item}
                  onEdit={() =>
                    setEditor({ item, name: item.name, groups: item.groups })
                  }
                  onYAML={() => setYAMLItem(item)}
                  onDelete={() => setDeleteItem(item)}
                  onToggle={() =>
                    runMutation(
                      () =>
                        setSubscriptionEnabled(
                          item.id,
                          item.status !== 'active'
                        ),
                      item.status === 'active'
                        ? '配置订阅已禁用'
                        : '配置订阅已启用'
                    )
                  }
                />
              ))}
            </div>
          </TabsContent>
          {isAdmin ? (
            <TabsContent value='content' className='pt-4'>
              <ContentMaintenance />
            </TabsContent>
          ) : null}
        </Tabs>
      </SectionPageLayout.Content>

      <SubscriptionEditor
        open={editor !== null}
        state={editor}
        groups={options.data?.groups ?? []}
        submitting={submitting}
        onClose={() => setEditor(null)}
        onChange={setEditor}
        onSubmit={() =>
          editor &&
          runMutation(
            () =>
              editor.item
                ? updateSubscription(editor.item.id, {
                    name: editor.name,
                    groups: editor.groups,
                  })
                : createSubscription({
                    name: editor.name,
                    groups: editor.groups,
                  }),
            editor.item ? '配置订阅已更新' : '配置订阅已创建'
          )
        }
      />
      <YAMLDialog item={yamlItem} onClose={() => setYAMLItem(null)} />
      <TutorialDialog
        open={tutorialOpen}
        onClose={() => setTutorialOpen(false)}
        tutorial={tutorial.data}
        loading={tutorial.isLoading}
      />
      <AlertDialog
        open={deleteItem !== null}
        onOpenChange={(open) => !open && setDeleteItem(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('删除配置订阅')}</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteItem
                ? `确定要删除'${deleteItem.name}'吗？此操作无法撤销。`
                : ''}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>
              {t('Cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              variant='destructive'
              disabled={submitting}
              onClick={() =>
                deleteItem &&
                runMutation(
                  () => deleteSubscription(deleteItem.id),
                  '配置订阅已删除'
                )
              }
            >
              {submitting ? t('Deleting...') : t('Delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SectionPageLayout>
  )
}

function SubscriptionCard({
  item,
  onEdit,
  onYAML,
  onDelete,
  onToggle,
}: {
  item: ConfigSubscription
  onEdit: () => void
  onYAML: () => void
  onDelete: () => void
  onToggle: () => void
}) {
  const { t } = useTranslation()
  const copy = async (value: string, message: string) => {
    await navigator.clipboard.writeText(value)
    toast.success(t(message))
  }
  const importURL = `hamster-switch://subscription/import?v=1&url=${encodeURIComponent(item.url)}&name=${encodeURIComponent(item.name)}`
  return (
    <Card>
      <CardHeader>
        <div className='flex items-start justify-between gap-3'>
          <div>
            <CardTitle>{item.name}</CardTitle>
            <CardDescription>
              {new Date(item.updated_at * 1000).toLocaleString()}
            </CardDescription>
          </div>
          <Badge variant={item.status === 'active' ? 'default' : 'secondary'}>
            {item.status === 'active' ? t('已启用') : t('已禁用')}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className='space-y-3'>
        <div className='flex flex-wrap gap-1'>
          {item.groups.map((group) => (
            <Badge key={group} variant='outline'>
              {group}
            </Badge>
          ))}
        </div>
        {item.keys.map((key) => (
          <div key={key.token_id} className='bg-muted rounded-md p-2 text-xs'>
            <div className='font-medium'>{key.group_name}</div>
            <div className='font-mono'>{maskToken(key.token)}</div>
          </div>
        ))}
        <div className='text-muted-foreground text-xs break-all'>
          {item.url}
        </div>
        {item.warnings.map((warning) => (
          <div key={warning} className='text-xs text-amber-600'>
            {warning}
          </div>
        ))}
      </CardContent>
      <CardFooter className='flex flex-wrap gap-2'>
        <Button
          size='sm'
          variant='outline'
          onClick={() => copy(item.url, '订阅 URL 已复制')}
        >
          <Copy className='mr-1 h-3.5 w-3.5' />
          {t('复制 URL')}
        </Button>
        <Button
          size='sm'
          variant='outline'
          onClick={() => {
            window.location.href = importURL
          }}
          disabled={item.status !== 'active'}
        >
          <ExternalLink className='mr-1 h-3.5 w-3.5' />
          {t('导入 Hamster Switch')}
        </Button>
        <Button size='sm' variant='outline' onClick={onYAML}>
          <FileText className='mr-1 h-3.5 w-3.5' />
          YAML
        </Button>
        <Button size='sm' variant='outline' onClick={onEdit}>
          <Pencil className='h-3.5 w-3.5' />
        </Button>
        <Button size='sm' variant='outline' onClick={onToggle}>
          {item.status === 'active' ? (
            <PowerOff className='h-3.5 w-3.5' />
          ) : (
            <Power className='h-3.5 w-3.5' />
          )}
        </Button>
        <Button size='sm' variant='destructive' onClick={onDelete}>
          <Trash2 className='h-3.5 w-3.5' />
        </Button>
      </CardFooter>
    </Card>
  )
}

function SubscriptionEditor({
  open,
  state,
  groups,
  submitting,
  onClose,
  onChange,
  onSubmit,
}: {
  open: boolean
  state: EditorState | null
  groups: string[]
  submitting: boolean
  onClose: () => void
  onChange: (state: EditorState | null) => void
  onSubmit: () => void
}) {
  const { t } = useTranslation()
  const preview = useQuery({
    queryKey: ['config-subscription-preview', state?.name, state?.groups],
    queryFn: () =>
      previewSubscription({
        name: state?.name ?? '',
        groups: state?.groups ?? [],
      }),
    enabled:
      open && Boolean(state?.name.trim()) && (state?.groups.length ?? 0) > 0,
  })
  const toggle = (group: string, checked: boolean) =>
    state &&
    onChange({
      ...state,
      groups: checked
        ? [...state.groups, group]
        : state.groups.filter((value) => value !== group),
    })
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className='max-h-[90vh] overflow-y-auto sm:max-w-2xl'>
        <DialogHeader>
          <DialogTitle>
            {state?.item ? t('编辑配置订阅') : t('新增配置订阅')}
          </DialogTitle>
          <DialogDescription>
            {t(
              '编辑后原订阅 URL 保持有效；Hamster Switch 刷新即可获取新内容。'
            )}
          </DialogDescription>
        </DialogHeader>
        <div className='space-y-4'>
          <div className='space-y-2'>
            <Label>{t('名称')}</Label>
            <Input
              value={state?.name ?? ''}
              onChange={(event) =>
                state && onChange({ ...state, name: event.target.value })
              }
            />
          </div>
          <div className='space-y-2'>
            <Label>{t('分组')}</Label>
            <div className='grid gap-2 rounded-md border p-3 sm:grid-cols-2'>
              {groups.map((group) => (
                <label key={group} className='flex items-center gap-2'>
                  <Checkbox
                    checked={state?.groups.includes(group)}
                    onCheckedChange={(checked) =>
                      toggle(group, checked === true)
                    }
                  />
                  {group}
                </label>
              ))}
            </div>
          </div>
          <ProviderCards providers={preview.data?.providers ?? []} />
          {preview.data?.warnings.map((warning) => (
            <div key={warning} className='text-sm text-amber-600'>
              {warning}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant='outline' onClick={onClose}>
            {t('Cancel')}
          </Button>
          <Button
            disabled={
              submitting ||
              !state?.name.trim() ||
              !state.groups.length ||
              preview.isError
            }
            onClick={onSubmit}
          >
            {submitting ? t('Saving...') : t('Save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function ProviderCards({ providers }: { providers: ProviderPreview[] }) {
  if (!providers.length) return null
  return (
    <div className='grid gap-2 sm:grid-cols-2'>
      {providers.map((provider) => (
        <div key={provider.id} className='rounded-md border p-3 text-sm'>
          <div className='font-medium'>{provider.name}</div>
          <div className='text-muted-foreground text-xs'>
            {provider.group_name} · {provider.app_type} ·{' '}
            {provider.models_count} models
          </div>
          <div className='text-muted-foreground mt-1 text-xs break-all'>
            {provider.base_url}
          </div>
        </div>
      ))}
    </div>
  )
}

function YAMLDialog({
  item,
  onClose,
}: {
  item: ConfigSubscription | null
  onClose: () => void
}) {
  const { t } = useTranslation()
  const yaml = useQuery({
    queryKey: ['config-subscription-yaml', item?.id],
    queryFn: () => {
      if (!item) {
        throw new Error('subscription is required')
      }
      return getSubscriptionYAML(item.id)
    },
    enabled: Boolean(item),
  })
  const copy = async () => {
    if (!yaml.data?.yaml) return
    await navigator.clipboard.writeText(yaml.data.yaml)
    toast.success(t('YAML 已复制'))
  }
  const download = () => {
    if (!yaml.data?.yaml || !item) return
    const anchor = document.createElement('a')
    anchor.href = URL.createObjectURL(
      new Blob([yaml.data.yaml], { type: 'application/yaml' })
    )
    anchor.download = `${item.name}.yaml`
    anchor.click()
    URL.revokeObjectURL(anchor.href)
  }
  return (
    <Dialog open={Boolean(item)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className='sm:max-w-3xl'>
        <DialogHeader>
          <DialogTitle>{t('YAML 预览')}</DialogTitle>
          <DialogDescription>
            {t('复制和下载内容包含完整专用 Token。')}
          </DialogDescription>
        </DialogHeader>
        <Textarea
          className='min-h-[420px] font-mono text-xs'
          readOnly
          value={yaml.data?.yaml ?? ''}
        />
        <DialogFooter>
          <Button variant='outline' onClick={copy}>
            <Copy className='mr-2 h-4 w-4' />
            {t('Copy')}
          </Button>
          <Button onClick={download}>
            <Download className='mr-2 h-4 w-4' />
            {t('Download')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function TutorialDialog({
  open,
  onClose,
  tutorial,
  loading,
}: {
  open: boolean
  onClose: () => void
  tutorial?: Awaited<ReturnType<typeof getTutorial>>
  loading: boolean
}) {
  const { t } = useTranslation()
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className='max-h-[90vh] overflow-y-auto sm:max-w-3xl'>
        <DialogHeader>
          <DialogTitle>{t('配置订阅教程')}</DialogTitle>
          <DialogDescription>
            {tutorial ? `v${tutorial.version}` : ''}
          </DialogDescription>
        </DialogHeader>
        {loading
          ? t('Loading')
          : tutorial?.steps.map((step, index) => (
              <Card key={step.id}>
                <CardHeader>
                  <CardTitle>
                    {index + 1}. {step.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className='space-y-3'>
                  <p className='text-sm whitespace-pre-wrap'>{step.body_md}</p>
                  {step.assets?.map((asset) =>
                    asset.url ? (
                      <img
                        key={`${asset.kind}-${asset.id ?? asset.url}`}
                        className='max-h-96 rounded-md border object-contain'
                        src={asset.url}
                        alt={step.title}
                      />
                    ) : null
                  )}
                </CardContent>
              </Card>
            ))}
      </DialogContent>
    </Dialog>
  )
}

function ContentMaintenance() {
  const { t } = useTranslation()
  const template = useQuery({
    queryKey: ['hamster-yaml-template'],
    queryFn: getTemplateState,
  })
  const [body, setBody] = useState('')
  const [diagnostics, setDiagnostics] = useState<TemplateDiagnostic[]>([])
  const [acknowledged, setAcknowledged] = useState(false)
  const [busy, setBusy] = useState(false)
  const [candidate, setCandidate] = useState<Awaited<
    ReturnType<typeof checkTutorialUpdate>
  > | null>(null)
  const [resolutions, setResolutions] = useState<
    Record<string, 'keep_site' | 'use_release'>
  >({})
  useEffect(() => {
    if (template.data) {
      setBody(template.data.draft)
      setDiagnostics(template.data.diagnostics)
    }
  }, [template.data])
  const act = async (action: () => Promise<void>) => {
    setBusy(true)
    try {
      await action()
    } finally {
      setBusy(false)
    }
  }
  const save = () =>
    act(async () => {
      const result = await saveTemplateDraft(body)
      setDiagnostics(result.diagnostics)
      toast.success(t('模板草稿已保存'))
    })
  const publish = () =>
    act(async () => {
      const result = await publishTemplate(acknowledged)
      if (result.success) {
        toast.success(t('模板已发布'))
        setAcknowledged(false)
        await template.refetch()
      }
    })
  const checkUpdate = () =>
    act(async () => {
      setCandidate(await checkTutorialUpdate())
      setResolutions({})
    })
  const adopt = () =>
    candidate &&
    act(async () => {
      const result = await adoptTutorialUpdate(candidate.version, resolutions)
      if (result.success) {
        toast.success(t('教程快照已更新'))
        setCandidate(null)
        setResolutions({})
      }
    })
  const reject = () =>
    act(async () => {
      const result = await rejectTutorialUpdate()
      if (result.success) {
        toast.success(t('已拒绝本次教程更新'))
        setCandidate(null)
        setResolutions({})
      }
    })
  const warnings = diagnostics.filter((item) => item.level === 'warning')
  const errors = diagnostics.filter((item) => item.level === 'error')
  return (
    <div className='grid gap-4 xl:grid-cols-2'>
      <Card>
        <CardHeader>
          <CardTitle>{t('YAML 通用模板')}</CardTitle>
          <CardDescription>
            {t(
              '允许 providers/models 循环、简单条件和闭合安全变量集；硬错误不可发布。'
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className='space-y-3'>
          <Textarea
            className='min-h-[520px] font-mono text-xs'
            value={body}
            onChange={(event) => setBody(event.target.value)}
          />
          {diagnostics.map((item) => (
            <div
              key={`${item.code}-${item.message}`}
              className={
                item.level === 'error'
                  ? 'text-destructive text-sm'
                  : 'text-sm text-amber-600'
              }
            >
              {item.code}: {item.message}
            </div>
          ))}
          {warnings.length ? (
            <label className='flex items-center gap-2 text-sm'>
              <Checkbox
                checked={acknowledged}
                onCheckedChange={(checked) => setAcknowledged(checked === true)}
              />
              {t('我已阅读并确认上述警告')}
            </label>
          ) : null}
        </CardContent>
        <CardFooter className='flex flex-wrap gap-2'>
          <Button variant='outline' disabled={busy} onClick={save}>
            {t('保存草稿')}
          </Button>
          <Button
            disabled={
              busy ||
              errors.length > 0 ||
              (warnings.length > 0 && !acknowledged)
            }
            onClick={publish}
          >
            {t('发布')}
          </Button>
          {template.data?.history
            .filter((item) => !item.active)
            .slice(0, 3)
            .map((version) => (
              <Button
                key={version.version}
                size='sm'
                variant='ghost'
                disabled={busy}
                onClick={() =>
                  act(async () => {
                    const result = await rollbackTemplate(version.version)
                    if (result.success) {
                      toast.success(t('模板已回滚为新版本'))
                      await template.refetch()
                    }
                  })
                }
              >
                {t('回滚')} v{version.version}
              </Button>
            ))}
        </CardFooter>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>{t('配置订阅教程')}</CardTitle>
          <CardDescription>
            {t('只检查正式签名 Release；站点覆盖冲突不会自动合并。')}
          </CardDescription>
        </CardHeader>
        <CardContent className='space-y-3'>
          {candidate ? (
            <>
              <div>
                {candidate.changed
                  ? `${t('发现版本')} ${candidate.version}`
                  : t('已是最新版本')}
              </div>
              {candidate.conflicts.map((conflict) => (
                <div
                  key={conflict.step_id}
                  className='space-y-2 rounded-md border border-amber-300 p-2 text-sm'
                >
                  <div className='text-amber-600'>
                    {conflict.step_id}: {conflict.change}
                  </div>
                  <div className='flex gap-2'>
                    <Button
                      size='sm'
                      variant={
                        resolutions[conflict.step_id] === 'keep_site'
                          ? 'default'
                          : 'outline'
                      }
                      onClick={() =>
                        setResolutions((current) => ({
                          ...current,
                          [conflict.step_id]: 'keep_site',
                        }))
                      }
                    >
                      {t('保留本站覆盖')}
                    </Button>
                    <Button
                      size='sm'
                      variant={
                        resolutions[conflict.step_id] === 'use_release'
                          ? 'default'
                          : 'outline'
                      }
                      onClick={() =>
                        setResolutions((current) => ({
                          ...current,
                          [conflict.step_id]: 'use_release',
                        }))
                      }
                    >
                      {t('采用 Release')}
                    </Button>
                  </div>
                </div>
              ))}
            </>
          ) : (
            <div className='text-muted-foreground text-sm'>
              {t('尚未检查更新')}
            </div>
          )}
        </CardContent>
        <CardFooter className='gap-2'>
          <Button variant='outline' disabled={busy} onClick={checkUpdate}>
            <RefreshCw className='mr-2 h-4 w-4' />
            {t('检查更新')}
          </Button>
          {candidate?.changed ? (
            <>
              <Button variant='outline' disabled={busy} onClick={reject}>
                {t('拒绝本次更新')}
              </Button>
              <Button
                disabled={
                  busy ||
                  candidate.conflicts.some(
                    (conflict) => !resolutions[conflict.step_id]
                  )
                }
                onClick={adopt}
              >
                {t('采用 Release 快照')}
              </Button>
            </>
          ) : null}
        </CardFooter>
      </Card>
      <TutorialOverrideEditor />
    </div>
  )
}

function TutorialOverrideEditor() {
  const { t } = useTranslation()
  const state = useQuery({
    queryKey: ['hamster-tutorial-admin'],
    queryFn: getTutorialAdminState,
  })
  const [selectedID, setSelectedID] = useState('')
  const [draft, setDraft] = useState<TutorialOverride | null>(null)
  const [externalURL, setExternalURL] = useState('')
  const steps = useMemo(() => state.data?.base.steps ?? [], [state.data])
  useEffect(() => {
    if (!selectedID && steps[0]) setSelectedID(steps[0].id)
  }, [selectedID, steps])
  useEffect(() => {
    const base = steps.find((step) => step.id === selectedID)
    const override = state.data?.overrides.find(
      (item) => item.step_id === selectedID
    )
    if (override) {
      setDraft(override)
    } else if (base) {
      setDraft({
        step_id: base.id,
        title: base.title,
        body_md: base.body_md,
        assets: base.assets ?? [],
        optional: base.optional,
        hidden: false,
        position: steps.findIndex((step) => step.id === base.id) * 100,
      })
    }
  }, [selectedID, state.data, steps])
  const save = async () => {
    if (!draft) return
    const assets = [...(draft.assets ?? [])]
    if (externalURL.trim()) {
      assets.push({ kind: 'external', url: externalURL.trim() })
    }
    const result = await saveTutorialOverride(draft.step_id, {
      title: draft.title,
      body_md: draft.body_md,
      assets,
      optional: draft.optional,
      hidden: draft.hidden,
      position: draft.position,
    })
    if (result.success) {
      toast.success(t('教程站点覆盖已保存'))
      setExternalURL('')
      await state.refetch()
    }
  }
  const remove = async () => {
    if (!draft) return
    const result = await deleteTutorialOverride(draft.step_id)
    if (result.success) {
      toast.success(t('教程站点覆盖已删除'))
      await state.refetch()
    }
  }
  const upload = async (file?: File) => {
    if (!file || !draft) return
    const result = await uploadTutorialImage(file)
    if (result.success) {
      setDraft({
        ...draft,
        assets: [...(draft.assets ?? []), { kind: 'site', id: result.data.id }],
      })
    }
  }
  return (
    <Card className='xl:col-span-2'>
      <CardHeader>
        <CardTitle>{t('教程站点覆盖')}</CardTitle>
        <CardDescription>
          {t(
            '可编辑、隐藏、排序通用步骤，也可新增稳定步骤 ID；外链会由服务器校验并缓存。'
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className='grid gap-4 lg:grid-cols-[240px_1fr]'>
        {state.isLoading ? (
          t('Loading')
        ) : (
          <>
            <div className='space-y-2'>
              {steps.map((step) => (
                <Button
                  key={step.id}
                  variant={selectedID === step.id ? 'default' : 'outline'}
                  className='w-full justify-start'
                  onClick={() => setSelectedID(step.id)}
                >
                  {step.title}
                </Button>
              ))}
              <Button
                variant='outline'
                className='w-full'
                onClick={() => {
                  const id = `site-step-${Date.now()}`
                  setSelectedID(id)
                  setDraft({
                    step_id: id,
                    title: '',
                    body_md: '',
                    assets: [],
                    hidden: false,
                    optional: false,
                    position: steps.length * 100,
                  })
                }}
              >
                {t('新增站点步骤')}
              </Button>
            </div>
            {draft ? (
              <div className='space-y-3'>
                <div>
                  <Label>{t('步骤 ID')}</Label>
                  <Input
                    value={draft.step_id}
                    onChange={(event) =>
                      setDraft({ ...draft, step_id: event.target.value })
                    }
                  />
                </div>
                <div>
                  <Label>{t('标题')}</Label>
                  <Input
                    value={draft.title}
                    onChange={(event) =>
                      setDraft({ ...draft, title: event.target.value })
                    }
                  />
                </div>
                <div>
                  <Label>{t('内容')}</Label>
                  <Textarea
                    className='min-h-48'
                    value={draft.body_md}
                    onChange={(event) =>
                      setDraft({ ...draft, body_md: event.target.value })
                    }
                  />
                </div>
                <div className='grid gap-3 sm:grid-cols-2'>
                  <div>
                    <Label>{t('排序位置')}</Label>
                    <Input
                      type='number'
                      value={draft.position}
                      onChange={(event) =>
                        setDraft({
                          ...draft,
                          position: Number(event.target.value),
                        })
                      }
                    />
                  </div>
                  <label className='flex items-end gap-2 pb-2'>
                    <Checkbox
                      checked={draft.hidden}
                      onCheckedChange={(checked) =>
                        setDraft({ ...draft, hidden: checked === true })
                      }
                    />
                    {t('隐藏步骤')}
                  </label>
                </div>
                <div>
                  <Label>{t('HTTPS 外链图片')}</Label>
                  <Input
                    value={externalURL}
                    onChange={(event) => setExternalURL(event.target.value)}
                    placeholder='https://...'
                  />
                </div>
                <div>
                  <Label>{t('上传本站图片')}</Label>
                  <Input
                    type='file'
                    accept='image/png,image/jpeg,image/gif'
                    onChange={(event) => upload(event.target.files?.[0])}
                  />
                </div>
                <div className='flex gap-2'>
                  <Button onClick={save}>{t('保存覆盖')}</Button>
                  <Button variant='destructive' onClick={remove}>
                    {t('删除覆盖')}
                  </Button>
                </div>
              </div>
            ) : null}
          </>
        )}
      </CardContent>
    </Card>
  )
}

function maskToken(token: string) {
  if (token.length <= 10) return '*'.repeat(token.length)
  return `${token.slice(0, 6)}${'*'.repeat(Math.max(6, token.length - 10))}${token.slice(-4)}`
}
