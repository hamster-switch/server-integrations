import { createFileRoute } from '@tanstack/react-router'

import { ConfigSubscriptions } from '@/features/config-subscriptions'

export const Route = createFileRoute('/_authenticated/config-subscriptions/')({
  component: ConfigSubscriptions,
})
