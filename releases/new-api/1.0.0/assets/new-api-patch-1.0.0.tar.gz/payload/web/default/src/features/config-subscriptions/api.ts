import { api } from '@/lib/api'

export interface ProviderPreview {
  id: string
  app_type: string
  group_name: string
  name: string
  models: string[]
  models_count: number
  default_model: string
  base_url: string
  warnings: string[]
}

export interface SubscriptionKey {
  token_id: number
  group_name: string
  token: string
}

export interface ConfigSubscription {
  id: string
  name: string
  url: string
  status: 'active' | 'disabled'
  groups: string[]
  keys: SubscriptionKey[]
  providers: ProviderPreview[]
  warnings: string[]
  yaml?: string
  created_at: number
  updated_at: number
}

export interface TutorialAsset {
  kind: 'release' | 'site' | 'external'
  id?: string
  url?: string
}

export interface TutorialStep {
  id: string
  title: string
  body_md: string
  assets?: TutorialAsset[]
  optional?: boolean
}

export interface Tutorial {
  schema_version: number
  id: string
  version: string
  locale: string
  title: string
  steps: TutorialStep[]
}

export interface TemplateDiagnostic {
  level: 'error' | 'warning'
  code: string
  message: string
}

export interface TemplateVersion {
  version: number
  body: string
  warnings: TemplateDiagnostic[]
  warning_confirmed_by?: number
  warning_confirmed_at?: number
  created_by?: number
  created_at: number
  active: boolean
}

interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
}

const basePath = '/api/hamster-switch/config-subscriptions'

export async function getOptions() {
  const response = await api.get<
    ApiResponse<{ groups: string[]; base_url: string }>
  >(`${basePath}/options`)
  return response.data.data
}

export async function listSubscriptions(search = '') {
  const response = await api.get<
    ApiResponse<{ items: ConfigSubscription[]; total: number }>
  >(basePath, { params: { page: 1, page_size: 100, search } })
  return response.data.data
}

export async function previewSubscription(payload: {
  name: string
  groups: string[]
}) {
  const response = await api.post<
    ApiResponse<{ providers: ProviderPreview[]; warnings: string[] }>
  >(`${basePath}/preview`, payload)
  return response.data.data
}

export async function createSubscription(payload: {
  name: string
  groups: string[]
}) {
  const response = await api.post<ApiResponse<ConfigSubscription>>(
    basePath,
    payload
  )
  return response.data
}

export async function updateSubscription(
  id: string,
  payload: { name: string; groups: string[] }
) {
  const response = await api.put<ApiResponse<ConfigSubscription>>(
    `${basePath}/${id}`,
    payload
  )
  return response.data
}

export async function setSubscriptionEnabled(id: string, enabled: boolean) {
  const response = await api.post<ApiResponse<ConfigSubscription>>(
    `${basePath}/${id}/${enabled ? 'enable' : 'disable'}`
  )
  return response.data
}

export async function deleteSubscription(id: string) {
  const response = await api.delete<ApiResponse<null>>(`${basePath}/${id}`)
  return response.data
}

export async function getSubscriptionYAML(id: string) {
  const response = await api.get<
    ApiResponse<{ yaml: string; warnings: string[] }>
  >(`${basePath}/${id}/yaml`)
  return response.data.data
}

export async function getTutorial() {
  const response = await api.get<ApiResponse<Tutorial>>(`${basePath}/tutorial`)
  return response.data.data
}

export async function getTemplateState() {
  const response = await api.get<
    ApiResponse<{
      draft: string
      diagnostics: TemplateDiagnostic[]
      current?: TemplateVersion
      history: TemplateVersion[]
    }>
  >('/api/hamster-switch/admin/yaml-template')
  return response.data.data
}

export async function saveTemplateDraft(body: string) {
  const response = await api.put<
    ApiResponse<{ diagnostics: TemplateDiagnostic[] }>
  >('/api/hamster-switch/admin/yaml-template/draft', { body })
  return response.data.data
}

export async function publishTemplate(acknowledgeWarnings: boolean) {
  const response = await api.post<
    ApiResponse<{ version: TemplateVersion; diagnostics: TemplateDiagnostic[] }>
  >('/api/hamster-switch/admin/yaml-template/publish', {
    acknowledge_warnings: acknowledgeWarnings,
  })
  return response.data
}

export async function rollbackTemplate(version: number) {
  const response = await api.post<ApiResponse<TemplateVersion>>(
    `/api/hamster-switch/admin/yaml-template/rollback/${version}`
  )
  return response.data
}

export async function checkTutorialUpdate() {
  const response = await api.post<
    ApiResponse<{
      changed: boolean
      version: string
      tutorial: Tutorial
      conflicts: Array<{ step_id: string; change: string }>
    }>
  >('/api/hamster-switch/admin/tutorial/check-update')
  return response.data.data
}

export async function adoptTutorialUpdate(
  version: string,
  resolutions: Record<string, 'keep_site' | 'use_release'>
) {
  const response = await api.post<ApiResponse<null>>(
    '/api/hamster-switch/admin/tutorial/adopt',
    { version, resolutions }
  )
  return response.data
}

export async function rejectTutorialUpdate() {
  const response = await api.post<ApiResponse<null>>(
    '/api/hamster-switch/admin/tutorial/reject'
  )
  return response.data
}

export interface TutorialOverride {
  step_id: string
  title: string
  body_md: string
  assets?: TutorialAsset[]
  optional?: boolean
  hidden?: boolean
  position: number
}

export async function getTutorialAdminState() {
  const response = await api.get<
    ApiResponse<{ base: Tutorial; overrides: TutorialOverride[] }>
  >('/api/hamster-switch/admin/tutorial')
  return response.data.data
}

export async function saveTutorialOverride(
  stepId: string,
  override: Omit<TutorialOverride, 'step_id'>
) {
  const response = await api.put<ApiResponse<TutorialOverride>>(
    `/api/hamster-switch/admin/tutorial/overrides/${encodeURIComponent(stepId)}`,
    override
  )
  return response.data
}

export async function deleteTutorialOverride(stepId: string) {
  const response = await api.delete<ApiResponse<null>>(
    `/api/hamster-switch/admin/tutorial/overrides/${encodeURIComponent(stepId)}`
  )
  return response.data
}

export async function uploadTutorialImage(file: File) {
  const form = new FormData()
  form.append('file', file)
  const response = await api.post<ApiResponse<{ id: string; url: string }>>(
    '/api/hamster-switch/admin/tutorial/images',
    form
  )
  return response.data
}
