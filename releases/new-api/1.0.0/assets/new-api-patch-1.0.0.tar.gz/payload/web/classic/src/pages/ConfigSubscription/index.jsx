import React, { useEffect, useMemo, useState } from 'react';
import {
  Banner,
  Button,
  Card,
  Checkbox,
  Input,
  Modal,
  Space,
  Spin,
  TabPane,
  Tabs,
  Tag,
  TextArea,
  Typography,
} from '@douyinfe/semi-ui';
import {
  IconCopy,
  IconDelete,
  IconDownload,
  IconEdit,
  IconExternalOpen,
  IconPlus,
  IconRefresh,
} from '@douyinfe/semi-icons';
import { useTranslation } from 'react-i18next';

import { API, copy, isAdmin, showError, showSuccess } from '../../helpers';

const { Text, Title } = Typography;
const basePath = '/api/hamster-switch/config-subscriptions';

const unwrap = (response) => {
  if (!response?.data?.success)
    throw new Error(response?.data?.message || 'Request failed');
  return response.data.data;
};

const maskToken = (token) => {
  if (!token || token.length <= 10) return '*'.repeat(token?.length || 0);
  return `${token.slice(0, 6)}${'*'.repeat(Math.max(6, token.length - 10))}${token.slice(-4)}`;
};

const ConfigSubscription = () => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState([]);
  const [groups, setGroups] = useState([]);
  const [search, setSearch] = useState('');
  const [editor, setEditor] = useState(null);
  const [preview, setPreview] = useState({ providers: [], warnings: [] });
  const [yamlItem, setYamlItem] = useState(null);
  const [yaml, setYaml] = useState('');
  const [tutorial, setTutorial] = useState(null);
  const [tutorialVisible, setTutorialVisible] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [listResponse, optionsResponse] = await Promise.all([
        API.get(basePath, { params: { page: 1, page_size: 100, search } }),
        API.get(`${basePath}/options`),
      ]);
      setItems(unwrap(listResponse).items || []);
      setGroups(unwrap(optionsResponse).groups || []);
    } catch (error) {
      showError(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [search]);

  useEffect(() => {
    if (!editor?.name?.trim() || !editor?.groups?.length) {
      setPreview({ providers: [], warnings: [] });
      return;
    }
    const timeout = window.setTimeout(async () => {
      try {
        const response = await API.post(`${basePath}/preview`, {
          name: editor.name,
          groups: editor.groups,
        });
        setPreview(unwrap(response));
      } catch (error) {
        setPreview({ providers: [], warnings: [error.message] });
      }
    }, 250);
    return () => window.clearTimeout(timeout);
  }, [editor?.name, editor?.groups]);

  const submit = async () => {
    try {
      const payload = { name: editor.name, groups: editor.groups };
      const response = editor.item
        ? await API.put(`${basePath}/${editor.item.id}`, payload)
        : await API.post(basePath, payload);
      unwrap(response);
      showSuccess(t(editor.item ? '配置订阅已更新' : '配置订阅已创建'));
      setEditor(null);
      await load();
    } catch (error) {
      showError(error.message);
      throw error;
    }
  };

  const toggle = async (item) => {
    try {
      unwrap(
        await API.post(
          `${basePath}/${item.id}/${item.status === 'active' ? 'disable' : 'enable'}`,
        ),
      );
      showSuccess(
        t(item.status === 'active' ? '配置订阅已禁用' : '配置订阅已启用'),
      );
      await load();
    } catch (error) {
      showError(error.message);
    }
  };

  const confirmDelete = (item) => {
    Modal.confirm({
      title: t('删除配置订阅'),
      content: `确定要删除'${item.name}'吗？此操作无法撤销。`,
      type: 'warning',
      okType: 'danger',
      onOk: async () => {
        try {
          unwrap(await API.delete(`${basePath}/${item.id}`));
          showSuccess(t('配置订阅已删除'));
          await load();
        } catch (error) {
          showError(error.message);
          throw error;
        }
      },
    });
  };

  const openYAML = async (item) => {
    setYamlItem(item);
    setYaml('');
    try {
      const response = await API.get(`${basePath}/${item.id}/yaml`);
      setYaml(unwrap(response).yaml);
    } catch (error) {
      showError(error.message);
    }
  };

  const openTutorial = async () => {
    setTutorialVisible(true);
    try {
      setTutorial(unwrap(await API.get(`${basePath}/tutorial`)));
    } catch (error) {
      showError(error.message);
    }
  };

  return (
    <div className='mt-[60px] px-4 pb-8'>
      <div className='mb-4 flex flex-wrap items-center justify-between gap-3'>
        <div>
          <Title heading={3}>{t('配置订阅')}</Title>
          <Text type='tertiary'>
            {t('创建稳定 URL，编辑后可由 Hamster Switch 刷新获取最新内容。')}
          </Text>
        </div>
        <Space>
          <Button theme='light' onClick={openTutorial}>
            {t('配置订阅教程')}
          </Button>
          <Button
            type='primary'
            icon={<IconPlus />}
            onClick={() => setEditor({ name: t('我的配置订阅'), groups: [] })}
          >
            {t('新增配置订阅')}
          </Button>
        </Space>
      </div>
      <Tabs type='line'>
        <TabPane tab={t('配置订阅')} itemKey='subscriptions'>
          <Input
            className='mb-4 max-w-md'
            value={search}
            onChange={setSearch}
            placeholder={t('搜索配置订阅')}
            showClear
          />
          <Spin spinning={loading}>
            {!loading && items.length === 0 ? (
              <Card>
                <div className='py-12 text-center'>
                  {t(
                    '还没有配置订阅，创建后即可复制 URL 或导入 Hamster Switch。',
                  )}
                </div>
              </Card>
            ) : null}
            <div className='grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
              {items.map((item) => (
                <SubscriptionCard
                  key={item.id}
                  item={item}
                  t={t}
                  onEdit={() =>
                    setEditor({ item, name: item.name, groups: item.groups })
                  }
                  onToggle={() => toggle(item)}
                  onDelete={() => confirmDelete(item)}
                  onYAML={() => openYAML(item)}
                />
              ))}
            </div>
          </Spin>
        </TabPane>
        {isAdmin() ? (
          <TabPane tab={t('内容维护')} itemKey='content'>
            <ContentMaintenance t={t} />
          </TabPane>
        ) : null}
      </Tabs>

      <Modal
        title={editor?.item ? t('编辑配置订阅') : t('新增配置订阅')}
        visible={Boolean(editor)}
        onCancel={() => setEditor(null)}
        onOk={submit}
        okButtonProps={{
          disabled: !editor?.name?.trim() || !editor?.groups?.length,
        }}
        width={720}
      >
        <div className='space-y-4'>
          <Banner
            type='info'
            description={t(
              '编辑后原订阅 URL 保持有效；Hamster Switch 刷新即可获取新内容。',
            )}
          />
          <div>
            <Text strong>{t('名称')}</Text>
            <Input
              className='mt-2'
              value={editor?.name || ''}
              onChange={(name) =>
                setEditor((current) => ({ ...current, name }))
              }
            />
          </div>
          <div>
            <Text strong>{t('分组')}</Text>
            <Checkbox.Group
              className='mt-2 grid grid-cols-2 gap-2'
              value={editor?.groups || []}
              options={groups.map((group) => ({ label: group, value: group }))}
              onChange={(selected) =>
                setEditor((current) => ({ ...current, groups: selected }))
              }
            />
          </div>
          <div className='grid gap-2 sm:grid-cols-2'>
            {preview.providers.map((provider) => (
              <Card key={provider.id} title={provider.name}>
                <Text size='small' type='tertiary'>
                  {provider.group_name} · {provider.app_type} ·{' '}
                  {provider.models_count} models
                </Text>
                <div className='mt-1 break-all text-xs'>
                  {provider.base_url}
                </div>
              </Card>
            ))}
          </div>
          {preview.warnings.map((warning) => (
            <Banner key={warning} type='warning' description={warning} />
          ))}
        </div>
      </Modal>

      <Modal
        title={t('YAML 预览')}
        visible={Boolean(yamlItem)}
        onCancel={() => setYamlItem(null)}
        footer={
          <Space>
            <Button
              onClick={() => {
                copy(yaml);
                showSuccess(t('YAML 已复制'));
              }}
              icon={<IconCopy />}
            >
              {t('复制')}
            </Button>
            <Button
              type='primary'
              onClick={() => downloadYAML(yamlItem, yaml)}
              icon={<IconDownload />}
            >
              {t('下载')}
            </Button>
          </Space>
        }
        width={800}
      >
        <Banner
          type='warning'
          description={t('复制和下载内容包含完整专用 Token。')}
          className='mb-3'
        />
        <TextArea
          value={yaml}
          autosize={{ minRows: 18, maxRows: 28 }}
          readOnly
          style={{ fontFamily: 'monospace' }}
        />
      </Modal>

      <Modal
        title={t('配置订阅教程')}
        visible={tutorialVisible}
        onCancel={() => setTutorialVisible(false)}
        footer={null}
        width={800}
      >
        {tutorial ? (
          <div className='space-y-3'>
            <Text type='tertiary'>v{tutorial.version}</Text>
            {tutorial.steps.map((step, index) => (
              <Card key={step.id} title={`${index + 1}. ${step.title}`}>
                <p className='whitespace-pre-wrap'>{step.body_md}</p>
                {step.assets?.map((asset) =>
                  asset.url ? (
                    <img
                      key={`${asset.kind}-${asset.id || asset.url}`}
                      src={asset.url}
                      alt={step.title}
                      className='mt-3 max-h-96 rounded border object-contain'
                    />
                  ) : null,
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Spin />
        )}
      </Modal>
    </div>
  );
};

const SubscriptionCard = ({ item, t, onEdit, onToggle, onDelete, onYAML }) => {
  const importURL = `hamster-switch://subscription/import?v=1&url=${encodeURIComponent(item.url)}&name=${encodeURIComponent(item.name)}`;
  return (
    <Card
      title={
        <Space>
          <span>{item.name}</span>
          <Tag color={item.status === 'active' ? 'green' : 'grey'}>
            {item.status === 'active' ? t('已启用') : t('已禁用')}
          </Tag>
        </Space>
      }
      footerLine
      footerStyle={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}
      footer={
        <>
          <Button
            size='small'
            theme='light'
            icon={<IconCopy />}
            onClick={() => {
              copy(item.url);
              showSuccess(t('订阅 URL 已复制'));
            }}
          >
            {t('复制 URL')}
          </Button>
          <Button
            size='small'
            theme='light'
            icon={<IconExternalOpen />}
            disabled={item.status !== 'active'}
            onClick={() => {
              window.location.href = importURL;
            }}
          >
            {t('导入 Hamster Switch')}
          </Button>
          <Button size='small' theme='light' onClick={onYAML}>
            YAML
          </Button>
          <Button
            size='small'
            theme='light'
            icon={<IconEdit />}
            onClick={onEdit}
          />
          <Button
            size='small'
            theme='light'
            type={item.status === 'active' ? 'warning' : 'primary'}
            onClick={onToggle}
          >
            {item.status === 'active' ? t('禁用') : t('启用')}
          </Button>
          <Button
            size='small'
            theme='light'
            type='danger'
            icon={<IconDelete />}
            onClick={onDelete}
          />
        </>
      }
    >
      <div className='space-y-3'>
        <Space wrap>
          {item.groups.map((group) => (
            <Tag key={group}>{group}</Tag>
          ))}
        </Space>
        {item.keys.map((key) => (
          <div
            key={key.token_id}
            className='rounded bg-semi-color-fill-0 p-2 text-xs'
          >
            <div>{key.group_name}</div>
            <code>{maskToken(key.token)}</code>
          </div>
        ))}
        <Text size='small' type='tertiary' ellipsis={{ showTooltip: true }}>
          {item.url}
        </Text>
        {item.warnings.map((warning) => (
          <Banner key={warning} type='warning' description={warning} />
        ))}
      </div>
    </Card>
  );
};

const ContentMaintenance = ({ t }) => {
  const [state, setState] = useState(null);
  const [body, setBody] = useState('');
  const [diagnostics, setDiagnostics] = useState([]);
  const [acknowledged, setAcknowledged] = useState(false);
  const [candidate, setCandidate] = useState(null);
  const [resolutions, setResolutions] = useState({});
  const loadTemplate = async () => {
    try {
      const data = unwrap(
        await API.get('/api/hamster-switch/admin/yaml-template'),
      );
      setState(data);
      setBody(data.draft);
      setDiagnostics(data.diagnostics || []);
    } catch (error) {
      showError(error.message);
    }
  };
  useEffect(() => {
    loadTemplate();
  }, []);
  const save = async () => {
    try {
      const data = unwrap(
        await API.put('/api/hamster-switch/admin/yaml-template/draft', {
          body,
        }),
      );
      setDiagnostics(data.diagnostics || []);
      showSuccess(t('模板草稿已保存'));
    } catch (error) {
      showError(error.message);
    }
  };
  const publish = async () => {
    try {
      unwrap(
        await API.post('/api/hamster-switch/admin/yaml-template/publish', {
          acknowledge_warnings: acknowledged,
        }),
      );
      showSuccess(t('模板已发布'));
      setAcknowledged(false);
      await loadTemplate();
    } catch (error) {
      showError(error.message);
    }
  };
  const check = async () => {
    try {
      setCandidate(
        unwrap(
          await API.post('/api/hamster-switch/admin/tutorial/check-update'),
        ),
      );
      setResolutions({});
    } catch (error) {
      showError(error.message);
    }
  };
  const adopt = async () => {
    try {
      unwrap(
        await API.post('/api/hamster-switch/admin/tutorial/adopt', {
          version: candidate.version,
          resolutions,
        }),
      );
      showSuccess(t('教程快照已更新'));
      setCandidate(null);
      setResolutions({});
    } catch (error) {
      showError(error.message);
    }
  };
  const reject = async () => {
    try {
      unwrap(await API.post('/api/hamster-switch/admin/tutorial/reject'));
      showSuccess(t('已拒绝本次教程更新'));
      setCandidate(null);
      setResolutions({});
    } catch (error) {
      showError(error.message);
    }
  };
  const errors = diagnostics.filter((item) => item.level === 'error');
  const warnings = diagnostics.filter((item) => item.level === 'warning');
  return (
    <div className='grid gap-4 xl:grid-cols-2'>
      <Card title={t('YAML 通用模板')}>
        <TextArea
          value={body}
          onChange={setBody}
          autosize={{ minRows: 22, maxRows: 34 }}
          style={{ fontFamily: 'monospace' }}
        />
        {diagnostics.map((item) => (
          <Banner
            key={`${item.code}-${item.message}`}
            className='mt-2'
            type={item.level === 'error' ? 'danger' : 'warning'}
            description={`${item.code}: ${item.message}`}
          />
        ))}
        {warnings.length ? (
          <Checkbox
            className='mt-3'
            checked={acknowledged}
            onChange={(event) => setAcknowledged(event.target.checked)}
          >
            {t('我已阅读并确认上述警告')}
          </Checkbox>
        ) : null}
        <Space className='mt-3' wrap>
          <Button onClick={save}>{t('保存草稿')}</Button>
          <Button
            type='primary'
            disabled={
              errors.length > 0 || (warnings.length > 0 && !acknowledged)
            }
            onClick={publish}
          >
            {t('发布')}
          </Button>
          {state?.history
            ?.filter((version) => !version.active)
            .slice(0, 3)
            .map((version) => (
              <Button
                key={version.version}
                theme='borderless'
                onClick={async () => {
                  try {
                    unwrap(
                      await API.post(
                        `/api/hamster-switch/admin/yaml-template/rollback/${version.version}`,
                      ),
                    );
                    showSuccess(t('模板已回滚为新版本'));
                    await loadTemplate();
                  } catch (error) {
                    showError(error.message);
                  }
                }}
              >
                {t('回滚')} v{version.version}
              </Button>
            ))}
        </Space>
      </Card>
      <Card title={t('配置订阅教程')}>
        <Text type='tertiary'>
          {t('只检查正式签名 Release；站点覆盖冲突不会自动合并。')}
        </Text>
        {candidate ? (
          <div className='my-3'>
            {candidate.changed
              ? `${t('发现版本')} ${candidate.version}`
              : t('已是最新版本')}
            {candidate.conflicts.map((conflict) => (
              <div
                key={conflict.step_id}
                className='mt-2 rounded border border-semi-color-warning p-2'
              >
                <Banner
                  type='warning'
                  description={`${conflict.step_id}: ${conflict.change}`}
                />
                <Space className='mt-2'>
                  <Button
                    size='small'
                    theme={
                      resolutions[conflict.step_id] === 'keep_site'
                        ? 'solid'
                        : 'light'
                    }
                    onClick={() =>
                      setResolutions((current) => ({
                        ...current,
                        [conflict.step_id]: 'keep_site',
                      }))
                    }
                  >
                    {t('保留本站覆盖')}
                  </Button>
                  <Button
                    size='small'
                    theme={
                      resolutions[conflict.step_id] === 'use_release'
                        ? 'solid'
                        : 'light'
                    }
                    onClick={() =>
                      setResolutions((current) => ({
                        ...current,
                        [conflict.step_id]: 'use_release',
                      }))
                    }
                  >
                    {t('采用 Release')}
                  </Button>
                </Space>
              </div>
            ))}
          </div>
        ) : null}
        <Space className='mt-3'>
          <Button icon={<IconRefresh />} onClick={check}>
            {t('检查更新')}
          </Button>
          {candidate?.changed ? (
            <>
              <Button onClick={reject}>{t('拒绝本次更新')}</Button>
              <Button
                type='primary'
                disabled={candidate.conflicts.some(
                  (conflict) => !resolutions[conflict.step_id],
                )}
                onClick={adopt}
              >
                {t('采用 Release 快照')}
              </Button>
            </>
          ) : null}
        </Space>
      </Card>
      <TutorialOverrideEditor t={t} />
    </div>
  );
};

const TutorialOverrideEditor = ({ t }) => {
  const [state, setState] = useState(null);
  const [selectedID, setSelectedID] = useState('');
  const [draft, setDraft] = useState(null);
  const [externalURL, setExternalURL] = useState('');
  const load = async () => {
    try {
      const data = unwrap(await API.get('/api/hamster-switch/admin/tutorial'));
      setState(data);
      if (!selectedID && data.base.steps[0])
        setSelectedID(data.base.steps[0].id);
    } catch (error) {
      showError(error.message);
    }
  };
  useEffect(() => {
    load();
  }, []);
  useEffect(() => {
    const steps = state?.base?.steps || [];
    const base = steps.find((step) => step.id === selectedID);
    const override = state?.overrides?.find(
      (item) => item.step_id === selectedID,
    );
    if (override) setDraft(override);
    else if (base)
      setDraft({
        step_id: base.id,
        title: base.title,
        body_md: base.body_md,
        assets: base.assets || [],
        optional: base.optional || false,
        hidden: false,
        position: steps.findIndex((step) => step.id === base.id) * 100,
      });
  }, [selectedID, state]);
  const save = async () => {
    if (!draft) return;
    try {
      const assets = [...(draft.assets || [])];
      if (externalURL.trim())
        assets.push({ kind: 'external', url: externalURL.trim() });
      unwrap(
        await API.put(
          `/api/hamster-switch/admin/tutorial/overrides/${encodeURIComponent(draft.step_id)}`,
          { ...draft, assets },
        ),
      );
      showSuccess(t('教程站点覆盖已保存'));
      setExternalURL('');
      await load();
    } catch (error) {
      showError(error.message);
    }
  };
  const remove = async () => {
    if (!draft) return;
    try {
      unwrap(
        await API.delete(
          `/api/hamster-switch/admin/tutorial/overrides/${encodeURIComponent(draft.step_id)}`,
        ),
      );
      showSuccess(t('教程站点覆盖已删除'));
      await load();
    } catch (error) {
      showError(error.message);
    }
  };
  const upload = async (file) => {
    if (!file || !draft) return;
    try {
      const form = new FormData();
      form.append('file', file);
      const data = unwrap(
        await API.post('/api/hamster-switch/admin/tutorial/images', form),
      );
      setDraft({
        ...draft,
        assets: [...(draft.assets || []), { kind: 'site', id: data.id }],
      });
    } catch (error) {
      showError(error.message);
    }
  };
  const steps = state?.base?.steps || [];
  return (
    <Card className='xl:col-span-2' title={t('教程站点覆盖')}>
      <Text type='tertiary'>
        {t(
          '可编辑、隐藏、排序通用步骤，也可新增稳定步骤 ID；外链会由服务器校验并缓存。',
        )}
      </Text>
      <div className='mt-4 grid gap-4 lg:grid-cols-[240px_1fr]'>
        <div className='space-y-2'>
          {steps.map((step) => (
            <Button
              key={step.id}
              block
              theme={selectedID === step.id ? 'solid' : 'light'}
              onClick={() => setSelectedID(step.id)}
            >
              {step.title}
            </Button>
          ))}
          <Button
            block
            theme='light'
            icon={<IconPlus />}
            onClick={() => {
              const id = `site-step-${Date.now()}`;
              setSelectedID(id);
              setDraft({
                step_id: id,
                title: '',
                body_md: '',
                assets: [],
                optional: false,
                hidden: false,
                position: steps.length * 100,
              });
            }}
          >
            {t('新增站点步骤')}
          </Button>
        </div>
        {draft ? (
          <div className='space-y-3'>
            <div>
              <Text strong>{t('步骤 ID')}</Text>
              <Input
                className='mt-1'
                value={draft.step_id}
                onChange={(step_id) => setDraft({ ...draft, step_id })}
              />
            </div>
            <div>
              <Text strong>{t('标题')}</Text>
              <Input
                className='mt-1'
                value={draft.title}
                onChange={(title) => setDraft({ ...draft, title })}
              />
            </div>
            <div>
              <Text strong>{t('内容')}</Text>
              <TextArea
                className='mt-1'
                value={draft.body_md}
                onChange={(body_md) => setDraft({ ...draft, body_md })}
                autosize={{ minRows: 8, maxRows: 18 }}
              />
            </div>
            <div>
              <Text strong>{t('排序位置')}</Text>
              <Input
                className='mt-1'
                type='number'
                value={draft.position}
                onChange={(value) =>
                  setDraft({ ...draft, position: Number(value) })
                }
              />
            </div>
            <Checkbox
              checked={draft.hidden}
              onChange={(event) =>
                setDraft({ ...draft, hidden: event.target.checked })
              }
            >
              {t('隐藏步骤')}
            </Checkbox>
            <div>
              <Text strong>{t('HTTPS 外链图片')}</Text>
              <Input
                className='mt-1'
                value={externalURL}
                onChange={setExternalURL}
                placeholder='https://...'
              />
            </div>
            <div>
              <Text strong>{t('上传本站图片')}</Text>
              <input
                className='mt-1 block'
                type='file'
                accept='image/png,image/jpeg,image/gif'
                onChange={(event) => upload(event.target.files?.[0])}
              />
            </div>
            <Space>
              <Button type='primary' onClick={save}>
                {t('保存覆盖')}
              </Button>
              <Button type='danger' onClick={remove}>
                {t('删除覆盖')}
              </Button>
            </Space>
          </div>
        ) : null}
      </div>
    </Card>
  );
};

const downloadYAML = (item, yaml) => {
  if (!item || !yaml) return;
  const anchor = document.createElement('a');
  anchor.href = URL.createObjectURL(
    new Blob([yaml], { type: 'application/yaml' }),
  );
  anchor.download = `${item.name}.yaml`;
  anchor.click();
  URL.revokeObjectURL(anchor.href);
};

export default ConfigSubscription;
