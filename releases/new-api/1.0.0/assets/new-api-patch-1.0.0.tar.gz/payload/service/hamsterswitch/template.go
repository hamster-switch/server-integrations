package hamsterswitch

import (
	"errors"
	"fmt"
	"regexp"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"gopkg.in/yaml.v3"
)

const DefaultTemplate = `format_version: 1
name: {{subscription.name}}
updated_at: {{subscription.updated_at}}
providers:
{{#providers}}
  - id: {{provider.id}}
    app_type: {{provider.app_type}}
    group_name: {{provider.group_name}}
    name: {{provider.name}}
    models: {{provider.models}}
    base_url: {{provider.base_url}}
    default_model: {{provider.default_model}}
    settings_config: {{provider.settings_config}}
    endpoints: {{provider.endpoints}}
    meta: {{provider.meta}}
{{/providers}}
`

type TemplateDiagnostic struct {
	Level   string `json:"level"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

var templateToken = regexp.MustCompile(`\{\{\s*([^{}]+?)\s*\}\}`)
var templateIfBlock = regexp.MustCompile(`(?s)\{\{#if\s+([a-z0-9_.]+)\}\}(.*?)\{\{/if\}\}`)
var templateModelsBlock = regexp.MustCompile(`(?s)\{\{#models\}\}(.*?)\{\{/models\}\}`)

var allowedVariables = map[string]bool{
	"subscription.name": true, "subscription.updated_at": true,
	"provider.id": true, "provider.app_type": true, "provider.group_name": true,
	"provider.name": true, "provider.models": true, "provider.base_url": true,
	"provider.default_model": true, "provider.settings_config": true,
	"provider.endpoints": true, "provider.meta": true, "model": true,
}

func ValidateTemplate(body string) []TemplateDiagnostic {
	body = strings.TrimSpace(body)
	var diagnostics []TemplateDiagnostic
	errorDiagnostic := func(code, message string) {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "error", Code: code, Message: message})
	}
	if body == "" {
		return []TemplateDiagnostic{{Level: "error", Code: "EMPTY_TEMPLATE", Message: "模板内容不能为空"}}
	}
	if len(body) > 256<<10 {
		errorDiagnostic("TEMPLATE_TOO_LARGE", "模板不能超过 256 KiB")
	}
	if strings.Count(body, "{{#providers}}") != 1 || strings.Count(body, "{{/providers}}") != 1 {
		errorDiagnostic("PROVIDERS_LOOP", "模板必须包含一个闭合的 providers 循环")
	}
	start, end := strings.Index(body, "{{#providers}}"), strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		errorDiagnostic("PROVIDERS_LOOP_ORDER", "providers 循环未正确闭合")
	}
	if strings.Count(body, "{{#if ") != strings.Count(body, "{{/if}}") || len(templateIfBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#if ") {
		errorDiagnostic("CONDITION_BLOCK", "条件必须闭合且不能嵌套")
	}
	if strings.Count(body, "{{#models}}") != strings.Count(body, "{{/models}}") || len(templateModelsBlock.FindAllStringSubmatch(body, -1)) != strings.Count(body, "{{#models}}") {
		errorDiagnostic("MODELS_LOOP", "models 循环必须闭合且不能嵌套")
	}
	for _, match := range templateIfBlock.FindAllStringSubmatch(body, -1) {
		if !allowedVariables[match[1]] {
			errorDiagnostic("INVALID_CONDITION", fmt.Sprintf("条件变量 %q 不在安全变量集中", match[1]))
		}
	}
	for _, match := range templateToken.FindAllStringSubmatch(body, -1) {
		token := strings.TrimSpace(match[1])
		if token == "#providers" || token == "/providers" || token == "#models" || token == "/models" || token == "/if" || strings.HasPrefix(token, "#if ") || allowedVariables[token] {
			continue
		}
		errorDiagnostic("UNKNOWN_TOKEN", fmt.Sprintf("模板变量 %q 不在安全变量集中", token))
	}
	for _, required := range []string{"subscription.name", "provider.id", "provider.app_type", "provider.base_url", "provider.settings_config"} {
		if !strings.Contains(body, "{{"+required+"}}") {
			errorDiagnostic("MISSING_REQUIRED_TOKEN", fmt.Sprintf("缺少必需变量 %q", required))
		}
	}
	if !strings.Contains(body, "{{provider.models}}") && !strings.Contains(body, "{{#models}}") {
		errorDiagnostic("MISSING_REQUIRED_TOKEN", "缺少 provider.models 或 models 循环")
	}
	if !strings.Contains(body, "{{subscription.updated_at}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_UPDATED_AT", Message: "模板未输出订阅更新时间"})
	}
	if !strings.Contains(body, "{{provider.meta}}") {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "MISSING_PROVIDER_META", Message: "模板未输出 provider 元数据"})
	}
	if hasTemplateErrors(diagnostics) {
		return diagnostics
	}
	sample := subscriptionExport{FormatVersion: 1, Name: "模板校验", UpdatedAt: "1970-01-01T00:00:00Z", Providers: []providerExport{{
		ID: "sample", AppType: "codex", GroupName: "default", Name: "sample", Models: []string{"sample-model"},
		BaseURL: "https://example.invalid/v1", DefaultModel: "sample-model",
		SettingsConfig: map[string]any{"auth": map[string]string{"OPENAI_API_KEY": "sk-template-validation"}},
		Endpoints:      []endpointExport{{URL: "https://example.invalid/v1"}}, Meta: map[string]any{"gateway_type": "new-api"},
	}}}
	rendered, err := renderTemplate(body, sample)
	if err != nil {
		errorDiagnostic("RENDER_FAILED", err.Error())
		return diagnostics
	}
	var decoded map[string]any
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		errorDiagnostic("INVALID_YAML", fmt.Sprintf("渲染结果不是有效 YAML：%v", err))
		return diagnostics
	}
	if fmt.Sprint(decoded["format_version"]) != "1" {
		errorDiagnostic("FORMAT_VERSION", "渲染结果必须包含 format_version: 1")
	}
	providers, ok := decoded["providers"].([]any)
	if !ok || len(providers) != 1 {
		errorDiagnostic("PROVIDERS_SHAPE", "providers 循环必须为每个 provider 输出一个对象")
	}
	return diagnostics
}

func RenderTemplate(body string, subscription subscriptionExport) ([]byte, []TemplateDiagnostic, error) {
	diagnostics := ValidateTemplate(body)
	if hasTemplateErrors(diagnostics) {
		return nil, diagnostics, errors.New("模板存在不可绕过的硬错误")
	}
	rendered, err := renderTemplate(body, subscription)
	if err != nil {
		return nil, diagnostics, err
	}
	var decoded map[string]any
	if err := yaml.Unmarshal(rendered, &decoded); err != nil {
		return nil, diagnostics, fmt.Errorf("渲染后的 YAML 无效：%w", err)
	}
	return rendered, diagnostics, nil
}

func renderTemplate(body string, subscription subscriptionExport) ([]byte, error) {
	start, end := strings.Index(body, "{{#providers}}"), strings.Index(body, "{{/providers}}")
	if start < 0 || end < start {
		return nil, errors.New("providers 循环未正确闭合")
	}
	loop := body[start+len("{{#providers}}") : end]
	var renderedProviders strings.Builder
	for _, provider := range subscription.Providers {
		values := map[string]any{
			"provider.id": provider.ID, "provider.app_type": provider.AppType, "provider.group_name": provider.GroupName,
			"provider.name": provider.Name, "provider.models": provider.Models, "provider.base_url": provider.BaseURL,
			"provider.default_model": provider.DefaultModel, "provider.settings_config": provider.SettingsConfig,
			"provider.endpoints": provider.Endpoints, "provider.meta": provider.Meta,
		}
		part, err := renderIfBlocks(loop, values)
		if err != nil {
			return nil, err
		}
		part, err = renderModelsBlocks(part, provider.Models, values)
		if err != nil {
			return nil, err
		}
		part, err = replaceVariables(part, values)
		if err != nil {
			return nil, err
		}
		renderedProviders.WriteString(part)
	}
	combined := body[:start] + renderedProviders.String() + body[end+len("{{/providers}}"):]
	values := map[string]any{"subscription.name": subscription.Name, "subscription.updated_at": subscription.UpdatedAt}
	combined, err := renderIfBlocks(combined, values)
	if err != nil {
		return nil, err
	}
	combined, err = replaceVariables(combined, values)
	if err != nil {
		return nil, err
	}
	return []byte(combined), nil
}

func renderIfBlocks(body string, values map[string]any) (string, error) {
	var renderErr error
	result := templateIfBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := templateIfBlock.FindStringSubmatch(block)
		if len(match) != 3 {
			renderErr = errors.New("条件块无效")
			return block
		}
		if truthy(values[match[1]]) {
			return match[2]
		}
		return ""
	})
	return result, renderErr
}

func renderModelsBlocks(body string, models []string, values map[string]any) (string, error) {
	var renderErr error
	result := templateModelsBlock.ReplaceAllStringFunc(body, func(block string) string {
		match := templateModelsBlock.FindStringSubmatch(block)
		if len(match) != 2 {
			renderErr = errors.New("models 循环无效")
			return block
		}
		var builder strings.Builder
		for _, modelName := range models {
			copyValues := make(map[string]any, len(values)+1)
			for key, value := range values {
				copyValues[key] = value
			}
			copyValues["model"] = modelName
			part, err := replaceVariables(match[1], copyValues)
			if err != nil {
				renderErr = err
				return block
			}
			builder.WriteString(part)
		}
		return builder.String()
	})
	return result, renderErr
}

func replaceVariables(body string, values map[string]any) (string, error) {
	var renderErr error
	result := templateToken.ReplaceAllStringFunc(body, func(token string) string {
		match := templateToken.FindStringSubmatch(token)
		if len(match) != 2 {
			renderErr = errors.New("模板变量无效")
			return token
		}
		name := strings.TrimSpace(match[1])
		value, ok := values[name]
		if !ok {
			renderErr = fmt.Errorf("模板变量 %q 在当前作用域不可用", name)
			return token
		}
		encoded, err := common.Marshal(value)
		if err != nil {
			renderErr = err
			return token
		}
		return string(encoded)
	})
	return result, renderErr
}

func truthy(value any) bool {
	switch typed := value.(type) {
	case nil:
		return false
	case string:
		return strings.TrimSpace(typed) != ""
	case bool:
		return typed
	case []string:
		return len(typed) > 0
	case []endpointExport:
		return len(typed) > 0
	case map[string]any:
		return len(typed) > 0
	default:
		return true
	}
}
func hasTemplateErrors(diagnostics []TemplateDiagnostic) bool {
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "error" {
			return true
		}
	}
	return false
}
func HasTemplateErrors(diagnostics []TemplateDiagnostic) bool { return hasTemplateErrors(diagnostics) }
func HasTemplateWarnings(diagnostics []TemplateDiagnostic) bool {
	for _, diagnostic := range diagnostics {
		if diagnostic.Level == "warning" {
			return true
		}
	}
	return false
}
