package hamsterswitch

import (
	"strings"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDefaultTemplateIsValid(t *testing.T) {
	diagnostics := ValidateTemplate(DefaultTemplate)
	assert.False(t, HasTemplateErrors(diagnostics))
}

func TestTemplateRejectsVariablesOutsideClosedSet(t *testing.T) {
	body := strings.Replace(DefaultTemplate, "{{subscription.name}}", "{{env.HOME}}", 1)
	diagnostics := ValidateTemplate(body)
	require.True(t, HasTemplateErrors(diagnostics))
	assert.Contains(t, diagnostics, TemplateDiagnostic{Level: "error", Code: "UNKNOWN_TOKEN", Message: `模板变量 "env.HOME" 不在安全变量集中`})
}

func TestBuildYAMLIncludesDedicatedTokenButNotChannelSecret(t *testing.T) {
	modelName := "gpt-5"
	channel := &model.Channel{
		Id: 7, Type: constant.ChannelTypeOpenAI, Key: "UPSTREAM_CHANNEL_SECRET",
		Status: common.ChannelStatusEnabled, Name: "OpenAI", Models: modelName,
		Group: "default", TestModel: &modelName,
	}
	body, diagnostics, err := BuildYAML(
		[]*model.Channel{channel}, "测试订阅", "https://gateway.example.com", time.Unix(1, 0),
		[]ProviderAccess{{GroupName: "default", Token: "sk-dedicated-client-token"}}, DefaultTemplate,
	)
	require.NoError(t, err)
	assert.False(t, HasTemplateErrors(diagnostics))
	assert.Contains(t, string(body), "sk-dedicated-client-token")
	assert.NotContains(t, string(body), "UPSTREAM_CHANNEL_SECRET")
}
