package hamsterswitch

import (
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"gopkg.in/yaml.v3"
)

type ProviderPreview struct {
	ID           string   `json:"id" yaml:"-"`
	AppType      string   `json:"app_type" yaml:"-"`
	GroupName    string   `json:"group_name" yaml:"-"`
	Name         string   `json:"name" yaml:"-"`
	Models       []string `json:"models" yaml:"-"`
	ModelsCount  int      `json:"models_count" yaml:"-"`
	DefaultModel string   `json:"default_model" yaml:"-"`
	BaseURL      string   `json:"base_url" yaml:"-"`
	Warnings     []string `json:"warnings" yaml:"-"`
}

type ProviderAccess struct {
	GroupName string
	Token     string
}

type subscriptionExport struct {
	FormatVersion int              `yaml:"format_version"`
	Name          string           `yaml:"name"`
	UpdatedAt     string           `yaml:"updated_at"`
	Providers     []providerExport `yaml:"providers"`
}

type providerExport struct {
	ID             string           `yaml:"id"`
	AppType        string           `yaml:"app_type"`
	GroupName      string           `yaml:"group_name"`
	Name           string           `yaml:"name"`
	Models         []string         `yaml:"models"`
	BaseURL        string           `yaml:"base_url"`
	DefaultModel   string           `yaml:"default_model"`
	SettingsConfig map[string]any   `yaml:"settings_config"`
	Endpoints      []endpointExport `yaml:"endpoints"`
	Meta           map[string]any   `yaml:"meta"`
}

type endpointExport struct {
	URL string `json:"url" yaml:"url"`
}

func LoadCompatibleChannels() ([]*model.Channel, error) {
	var channels []*model.Channel
	err := model.DB.Where("status = ?", common.ChannelStatusEnabled).Order("id asc").Find(&channels).Error
	return channels, err
}

func Preview(channels []*model.Channel, baseURL string, groups []string) ([]ProviderPreview, []string, error) {
	providers, warnings, err := buildProviders(channels, baseURL, groups, nil)
	if err != nil {
		return nil, warnings, err
	}
	result := make([]ProviderPreview, 0, len(providers))
	for _, provider := range providers {
		result = append(result, ProviderPreview{
			ID: provider.ID, AppType: provider.AppType, GroupName: provider.GroupName,
			Name: provider.Name, Models: provider.Models, ModelsCount: len(provider.Models),
			DefaultModel: provider.DefaultModel, BaseURL: provider.BaseURL, Warnings: []string{},
		})
	}
	return result, warnings, nil
}

func BuildYAML(channels []*model.Channel, name, baseURL string, updatedAt time.Time, accesses []ProviderAccess, template string) ([]byte, []TemplateDiagnostic, error) {
	groups := make([]string, 0, len(accesses))
	tokens := make(map[string]string, len(accesses))
	for _, access := range accesses {
		group := strings.TrimSpace(access.GroupName)
		groups = append(groups, group)
		tokens[group] = fullAPIKey(access.Token)
	}
	providers, warnings, err := buildProviders(channels, baseURL, groups, tokens)
	if err != nil {
		return nil, nil, err
	}
	subscription := subscriptionExport{
		FormatVersion: 1, Name: strings.TrimSpace(name), UpdatedAt: updatedAt.UTC().Format(time.RFC3339), Providers: providers,
	}
	if subscription.Name == "" {
		subscription.Name = "new-api 配置订阅"
	}
	if strings.TrimSpace(template) == "" {
		body, err := yaml.Marshal(subscription)
		return body, warningDiagnostics(warnings), err
	}
	body, diagnostics, err := RenderTemplate(template, subscription)
	for _, warning := range warnings {
		diagnostics = append(diagnostics, TemplateDiagnostic{Level: "warning", Code: "CHANNEL_WARNING", Message: warning})
	}
	return body, diagnostics, err
}

func buildProviders(channels []*model.Channel, baseURL string, groups []string, tokens map[string]string) ([]providerExport, []string, error) {
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	if baseURL == "" {
		return nil, nil, fmt.Errorf("无法确定站点外部地址")
	}
	groups = cleanValues(groups)
	if len(groups) == 0 {
		return nil, nil, fmt.Errorf("至少选择一个分组")
	}
	sort.Strings(groups)
	var providers []providerExport
	var warnings []string
	for _, group := range groups {
		for _, channel := range channels {
			if channel == nil || channel.Status != common.ChannelStatusEnabled || !channelIncludesGroup(channel, group) {
				continue
			}
			appType, ok := exportAppType(channel.Type)
			if !ok {
				warnings = append(warnings, fmt.Sprintf("渠道 %d（%s）的类型暂不支持导出", channel.Id, channel.Name))
				continue
			}
			models := cleanValues(channel.GetModels())
			defaultModel := ""
			if channel.TestModel != nil {
				defaultModel = strings.TrimSpace(*channel.TestModel)
			}
			models = orderModels(models, defaultModel)
			if len(models) == 0 {
				warnings = append(warnings, fmt.Sprintf("渠道 %d（%s）没有可导出的模型", channel.Id, channel.Name))
				continue
			}
			name := strings.TrimSpace(channel.Name)
			if name == "" {
				name = fmt.Sprintf("new-api channel %d", channel.Id)
			}
			apiBaseURL := joinURL(baseURL, exportAPIPath(appType))
			clientToken := tokens[group]
			providers = append(providers, providerExport{
				ID: fmt.Sprintf("new-api-%s-channel-%d", idPart(group), channel.Id), AppType: appType,
				GroupName: group, Name: name, Models: models, BaseURL: apiBaseURL, DefaultModel: models[0],
				SettingsConfig: settingsConfig(appType, clientToken, apiBaseURL, models[0]),
				Endpoints:      []endpointExport{{URL: apiBaseURL}},
				Meta:           map[string]any{"gateway_type": "new-api", "issuer": "new-api", "auth_mode": "api_key", "gateway_group": group, "capabilities": capabilities(appType)},
			})
		}
	}
	if len(providers) == 0 {
		return nil, warnings, fmt.Errorf("所选分组没有可导出的已启用渠道和模型")
	}
	return providers, warnings, nil
}

func exportAppType(channelType int) (string, bool) {
	switch channelType {
	case constant.ChannelTypeAnthropic:
		return "claude", true
	case constant.ChannelTypeGemini:
		return "gemini", true
	case constant.ChannelTypeOpenAI, constant.ChannelTypeCodex:
		return "codex", true
	default:
		return "", false
	}
}

func exportAPIPath(appType string) string {
	if appType == "gemini" {
		return "/v1beta"
	}
	return "/v1"
}

func settingsConfig(appType, token, baseURL, defaultModel string) map[string]any {
	switch appType {
	case "claude":
		return map[string]any{"env": map[string]string{"ANTHROPIC_API_KEY": token, "ANTHROPIC_BASE_URL": baseURL, "ANTHROPIC_MODEL": defaultModel}}
	case "gemini":
		return map[string]any{"env": map[string]string{"GEMINI_API_KEY": token, "GOOGLE_GEMINI_BASE_URL": baseURL, "GEMINI_MODEL": defaultModel}}
	default:
		return map[string]any{
			"auth":   map[string]string{"OPENAI_API_KEY": token},
			"config": fmt.Sprintf("model_provider = \"custom\"\nmodel = %q\n\n[model_providers.custom]\nname = \"new-api\"\nbase_url = %q\nwire_api = \"responses\"\nrequires_openai_auth = true\n", defaultModel, baseURL),
		}
	}
}

func capabilities(appType string) []string {
	switch appType {
	case "claude":
		return []string{"anthropic-messages"}
	case "gemini":
		return []string{"gemini-native"}
	default:
		return []string{"responses"}
	}
}

func channelIncludesGroup(channel *model.Channel, group string) bool {
	groups := channel.GetGroups()
	if len(groups) == 0 {
		return group == "default"
	}
	for _, value := range groups {
		if strings.TrimSpace(value) == group {
			return true
		}
	}
	return false
}

func orderModels(models []string, defaultModel string) []string {
	models = cleanValues(models)
	defaultModel = strings.TrimSpace(defaultModel)
	if defaultModel == "" {
		return models
	}
	result := make([]string, 0, len(models)+1)
	found := false
	for _, value := range models {
		if value == defaultModel {
			result = append(result, value)
			found = true
			break
		}
	}
	if !found {
		result = append(result, defaultModel)
	}
	for _, value := range models {
		if value != defaultModel {
			result = append(result, value)
		}
	}
	return result
}

func cleanValues(values []string) []string {
	seen := make(map[string]bool, len(values))
	result := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" && !seen[value] {
			seen[value] = true
			result = append(result, value)
		}
	}
	return result
}

func fullAPIKey(key string) string {
	key = strings.TrimSpace(key)
	if key == "" || strings.HasPrefix(key, "sk-") {
		return key
	}
	return "sk-" + key
}
func joinURL(baseURL, path string) string {
	return strings.TrimRight(baseURL, "/") + "/" + strings.TrimLeft(path, "/")
}
func idPart(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	var b strings.Builder
	dash := false
	for _, r := range value {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
			dash = false
		} else if !dash {
			b.WriteByte('-')
			dash = true
		}
	}
	result := strings.Trim(b.String(), "-")
	if result == "" {
		return "group"
	}
	return result
}
func warningDiagnostics(warnings []string) []TemplateDiagnostic {
	result := make([]TemplateDiagnostic, 0, len(warnings))
	for _, value := range warnings {
		result = append(result, TemplateDiagnostic{Level: "warning", Code: "CHANNEL_WARNING", Message: value})
	}
	return result
}
