package controller

import (
	"errors"
	"fmt"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	rootservice "github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/service/hamsterswitch"
	"github.com/QuantumNous/new-api/setting/ratio_setting"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type hamsterSubscriptionRequest struct {
	Name   string   `json:"name"`
	Groups []string `json:"groups"`
}

type hamsterSubscriptionKeyDTO struct {
	TokenID   int    `json:"token_id"`
	GroupName string `json:"group_name"`
	Token     string `json:"token"`
}

type hamsterSubscriptionDTO struct {
	ID        string                          `json:"id"`
	Name      string                          `json:"name"`
	URL       string                          `json:"url"`
	Status    string                          `json:"status"`
	Groups    []string                        `json:"groups"`
	Keys      []hamsterSubscriptionKeyDTO     `json:"keys"`
	Providers []hamsterswitch.ProviderPreview `json:"providers"`
	Warnings  []string                        `json:"warnings"`
	YAML      string                          `json:"yaml,omitempty"`
	CreatedAt int64                           `json:"created_at"`
	UpdatedAt int64                           `json:"updated_at"`
}

func hamsterUserGroups(userID int) map[string]bool {
	userGroup, _ := model.GetUserGroup(userID, false)
	usable := rootservice.GetUserUsableGroups(userGroup)
	result := make(map[string]bool)
	for group := range ratio_setting.GetGroupRatioCopy() {
		if _, ok := usable[group]; ok && group != "auto" {
			result[group] = true
		}
	}
	return result
}

func validateHamsterGroupsForUser(userID int, groups []string) error {
	usable := hamsterUserGroups(userID)
	for _, group := range groups {
		group = strings.TrimSpace(group)
		if group == "" || group == "auto" {
			continue
		}
		if !usable[group] {
			return fmt.Errorf("无权使用分组 %q", group)
		}
	}
	return nil
}

func GetHamsterConfigSubscriptionOptions(c *gin.Context) {
	groups := make([]string, 0)
	for group := range hamsterUserGroups(c.GetInt("id")) {
		groups = append(groups, group)
	}
	sort.Strings(groups)
	common.ApiSuccess(c, gin.H{"groups": groups, "base_url": hamsterExternalBaseURL(c)})
}

func PreviewHamsterConfigSubscription(c *gin.Context) {
	var request hamsterSubscriptionRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	if err := validateHamsterGroupsForUser(c.GetInt("id"), request.Groups); err != nil {
		common.ApiError(c, err)
		return
	}
	channels, err := hamsterswitch.LoadCompatibleChannels()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	providers, warnings, err := hamsterswitch.Preview(channels, hamsterExternalBaseURL(c), request.Groups)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"providers": providers, "warnings": warnings})
}

func ListHamsterConfigSubscriptions(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "20"))
	if page < 1 {
		page = 1
	}
	if pageSize < 1 || pageSize > 100 {
		pageSize = 20
	}
	items, total, err := model.ListHamsterConfigSubscriptions(c.GetInt("id"), (page-1)*pageSize, pageSize, c.Query("search"))
	if err != nil {
		common.ApiError(c, err)
		return
	}
	result := make([]hamsterSubscriptionDTO, 0, len(items))
	for index := range items {
		dto, err := buildHamsterSubscriptionDTO(c, &items[index], false)
		if err != nil {
			common.ApiError(c, err)
			return
		}
		result = append(result, dto)
	}
	common.ApiSuccess(c, gin.H{"items": result, "total": total, "page": page, "page_size": pageSize})
}

func GetHamsterConfigSubscription(c *gin.Context) {
	item, err := model.GetHamsterConfigSubscription(c.GetInt("id"), c.Param("id"))
	if err != nil {
		hamsterRecordError(c, err)
		return
	}
	dto, err := buildHamsterSubscriptionDTO(c, item, true)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, dto)
}

func CreateHamsterConfigSubscription(c *gin.Context) {
	var request hamsterSubscriptionRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	if err := validateHamsterGroupsForUser(c.GetInt("id"), request.Groups); err != nil {
		common.ApiError(c, err)
		return
	}
	item, err := model.CreateHamsterConfigSubscription(c.GetInt("id"), model.HamsterSubscriptionInput{Name: request.Name, Groups: request.Groups})
	if err != nil {
		common.ApiError(c, err)
		return
	}
	dto, err := buildHamsterSubscriptionDTO(c, item, true)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, dto)
}

func UpdateHamsterConfigSubscription(c *gin.Context) {
	var request hamsterSubscriptionRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	if err := validateHamsterGroupsForUser(c.GetInt("id"), request.Groups); err != nil {
		common.ApiError(c, err)
		return
	}
	item, err := model.UpdateHamsterConfigSubscription(c.GetInt("id"), c.Param("id"), model.HamsterSubscriptionInput{Name: request.Name, Groups: request.Groups})
	if err != nil {
		hamsterRecordError(c, err)
		return
	}
	dto, err := buildHamsterSubscriptionDTO(c, item, true)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, dto)
}

func DisableHamsterConfigSubscription(c *gin.Context) { setHamsterSubscriptionEnabled(c, false) }
func EnableHamsterConfigSubscription(c *gin.Context)  { setHamsterSubscriptionEnabled(c, true) }

func setHamsterSubscriptionEnabled(c *gin.Context, enabled bool) {
	item, err := model.SetHamsterConfigSubscriptionEnabled(c.GetInt("id"), c.Param("id"), enabled)
	if err != nil {
		hamsterRecordError(c, err)
		return
	}
	dto, err := buildHamsterSubscriptionDTO(c, item, false)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, dto)
}

func DeleteHamsterConfigSubscription(c *gin.Context) {
	if err := model.DeleteHamsterConfigSubscription(c.GetInt("id"), c.Param("id")); err != nil {
		hamsterRecordError(c, err)
		return
	}
	common.ApiSuccess(c, nil)
}

func GetHamsterConfigSubscriptionYAML(c *gin.Context) {
	item, err := model.GetHamsterConfigSubscription(c.GetInt("id"), c.Param("id"))
	if err != nil {
		hamsterRecordError(c, err)
		return
	}
	dto, err := buildHamsterSubscriptionDTO(c, item, true)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"id": dto.ID, "name": dto.Name, "url": dto.URL, "yaml": dto.YAML, "warnings": dto.Warnings})
}

func DownloadHamsterConfigSubscription(c *gin.Context) {
	token := strings.TrimSuffix(strings.TrimSpace(c.Param("token")), ".yaml")
	if strings.HasPrefix(token, "hs_") {
		c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "配置订阅不存在"})
		return
	}
	item, err := model.GetHamsterConfigSubscriptionByDownloadToken(token)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "配置订阅不存在"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"success": false, "message": "读取配置订阅失败"})
		return
	}
	if item.Status == model.HamsterSubscriptionDisabled {
		c.JSON(http.StatusGone, gin.H{"success": false, "message": "配置订阅已禁用"})
		return
	}
	body, _, err := renderHamsterSubscription(c, item)
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": err.Error()})
		return
	}
	c.Header("Content-Type", "application/yaml; charset=utf-8")
	c.Header("Content-Disposition", fmt.Sprintf("inline; filename=%q", safeHamsterFilename(item.Name)+".yaml"))
	c.Header("Cache-Control", "no-store")
	c.Data(http.StatusOK, "application/yaml; charset=utf-8", body)
}

func buildHamsterSubscriptionDTO(c *gin.Context, item *model.HamsterConfigSubscription, includeYAML bool) (hamsterSubscriptionDTO, error) {
	tokens, err := model.GetHamsterSubscriptionTokens(item)
	if err != nil {
		return hamsterSubscriptionDTO{}, err
	}
	keys := make([]hamsterSubscriptionKeyDTO, 0, len(item.Providers))
	groups := make([]string, 0, len(item.Providers))
	accesses := make([]hamsterswitch.ProviderAccess, 0, len(item.Providers))
	for _, provider := range item.Providers {
		token := tokens[provider.TokenID]
		if token == nil {
			return hamsterSubscriptionDTO{}, fmt.Errorf("订阅分组 %q 的专用 Token 不存在", provider.GroupName)
		}
		full := token.GetFullKey()
		if !strings.HasPrefix(full, "sk-") {
			full = "sk-" + full
		}
		groups = append(groups, provider.GroupName)
		keys = append(keys, hamsterSubscriptionKeyDTO{TokenID: token.Id, GroupName: provider.GroupName, Token: full})
		accesses = append(accesses, hamsterswitch.ProviderAccess{GroupName: provider.GroupName, Token: full})
	}
	channels, err := hamsterswitch.LoadCompatibleChannels()
	if err != nil {
		return hamsterSubscriptionDTO{}, err
	}
	providers, warnings, previewErr := hamsterswitch.Preview(channels, hamsterExternalBaseURL(c), groups)
	if previewErr != nil {
		warnings = append(warnings, previewErr.Error())
		providers = []hamsterswitch.ProviderPreview{}
	}
	dto := hamsterSubscriptionDTO{ID: item.PublicID, Name: item.Name, URL: hamsterDownloadURL(c, item.DownloadToken), Status: item.Status, Groups: groups, Keys: keys, Providers: providers, Warnings: warnings, CreatedAt: item.CreatedTime, UpdatedAt: item.UpdatedTime}
	if includeYAML {
		body, diagnostics, err := renderHamsterSubscriptionWithAccess(c, item, accesses)
		if err != nil {
			return dto, err
		}
		dto.YAML = string(body)
		for _, diagnostic := range diagnostics {
			if diagnostic.Level == "warning" {
				dto.Warnings = append(dto.Warnings, diagnostic.Message)
			}
		}
	}
	return dto, nil
}

func renderHamsterSubscription(c *gin.Context, item *model.HamsterConfigSubscription) ([]byte, []hamsterswitch.TemplateDiagnostic, error) {
	tokens, err := model.GetHamsterSubscriptionTokens(item)
	if err != nil {
		return nil, nil, err
	}
	accesses := make([]hamsterswitch.ProviderAccess, 0, len(item.Providers))
	for _, provider := range item.Providers {
		token := tokens[provider.TokenID]
		if token == nil {
			return nil, nil, fmt.Errorf("订阅专用 Token 不存在")
		}
		accesses = append(accesses, hamsterswitch.ProviderAccess{GroupName: provider.GroupName, Token: token.Key})
	}
	return renderHamsterSubscriptionWithAccess(c, item, accesses)
}

func renderHamsterSubscriptionWithAccess(c *gin.Context, item *model.HamsterConfigSubscription, accesses []hamsterswitch.ProviderAccess) ([]byte, []hamsterswitch.TemplateDiagnostic, error) {
	channels, err := hamsterswitch.LoadCompatibleChannels()
	if err != nil {
		return nil, nil, err
	}
	templateBody, err := activeHamsterTemplate()
	if err != nil {
		return nil, nil, err
	}
	return hamsterswitch.BuildYAML(channels, item.Name, hamsterExternalBaseURL(c), time.Unix(item.UpdatedTime, 0), accesses, templateBody)
}

func activeHamsterTemplate() (string, error) {
	var template model.HamsterYAMLTemplate
	err := model.DB.Where("active = ?", true).Order("version desc").First(&template).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return hamsterswitch.DefaultTemplate, nil
	}
	return template.Body, err
}

func hamsterRecordError(c *gin.Context, err error) {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "配置订阅不存在"})
		return
	}
	common.ApiError(c, err)
}
func hamsterDownloadURL(c *gin.Context, token string) string {
	return strings.TrimRight(hamsterExternalBaseURL(c), "/") + "/api/hamster-switch/config-subscription/" + token + ".yaml"
}
func hamsterExternalBaseURL(c *gin.Context) string {
	if value := strings.TrimRight(strings.TrimSpace(os.Getenv("HAMSTER_SWITCH_BASE_URL")), "/"); value != "" {
		return value
	}
	scheme := strings.TrimSpace(strings.Split(c.GetHeader("X-Forwarded-Proto"), ",")[0])
	if scheme == "" {
		if c.Request != nil && c.Request.TLS != nil {
			scheme = "https"
		} else {
			scheme = "http"
		}
	}
	host := strings.TrimSpace(strings.Split(c.GetHeader("X-Forwarded-Host"), ",")[0])
	if host == "" && c.Request != nil {
		host = c.Request.Host
	}
	return scheme + "://" + host
}
func safeHamsterFilename(name string) string {
	replacer := strings.NewReplacer("<", "_", ">", "_", ":", "_", "\"", "_", "/", "_", "\\", "_", "|", "_", "?", "_", "*", "_")
	name = strings.TrimSpace(replacer.Replace(name))
	if name == "" {
		return "config-subscription"
	}
	return name
}
