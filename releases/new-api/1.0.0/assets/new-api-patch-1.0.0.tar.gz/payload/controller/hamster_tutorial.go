package controller

import (
	"bytes"
	"errors"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service/hamsterswitch"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type tutorialAdoptRequest struct {
	Version     string            `json:"version"`
	Resolutions map[string]string `json:"resolutions"`
}

func GetHamsterConfigSubscriptionTutorial(c *gin.Context) {
	base, err := currentHamsterTutorial()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	overrides, err := hamsterTutorialOverrides()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, hamsterswitch.MergeTutorial(base, overrides, func(id string) string { return "/api/hamster-switch/tutorial/images/" + id }))
}

func GetHamsterTutorialAdminState(c *gin.Context) {
	base, err := currentHamsterTutorial()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	overrides, err := hamsterTutorialOverrides()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"base": base, "overrides": overrides})
}

func CheckHamsterTutorialUpdate(c *gin.Context) {
	current, err := currentHamsterTutorial()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	overrides, err := hamsterTutorialOverrides()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	snapshot, err := hamsterswitch.FetchLatestTutorialRelease(c.Request.Context())
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"changed": snapshot.Version != current.Version, "version": snapshot.Version, "tutorial": snapshot.Tutorial, "conflicts": hamsterswitch.TutorialConflicts(current, snapshot.Tutorial, overrides)})
}

func AdoptHamsterTutorialUpdate(c *gin.Context) {
	var request tutorialAdoptRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	current, err := currentHamsterTutorial()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	overrides, err := hamsterTutorialOverrides()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	snapshot, err := hamsterswitch.FetchLatestTutorialRelease(c.Request.Context())
	if err != nil {
		common.ApiError(c, err)
		return
	}
	if snapshot.Version != request.Version {
		c.JSON(http.StatusConflict, gin.H{"success": false, "message": "候选版本已变化，请重新检查更新"})
		return
	}
	conflicts := hamsterswitch.TutorialConflicts(current, snapshot.Tutorial, overrides)
	for _, conflict := range conflicts {
		resolution := request.Resolutions[conflict.StepID]
		if resolution != "keep_site" && resolution != "use_release" {
			c.JSON(http.StatusConflict, gin.H{"success": false, "message": "必须逐项处理教程冲突", "data": gin.H{"conflicts": conflicts}})
			return
		}
	}
	if err := storeHamsterReleaseImages(c, snapshot); err != nil {
		common.ApiError(c, err)
		return
	}
	body, err := common.Marshal(snapshot.Tutorial)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	err = model.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&model.HamsterTutorialSnapshot{}).Where("active = ?", true).Update("active", false).Error; err != nil {
			return err
		}
		entry := model.HamsterTutorialSnapshot{Version: snapshot.Version, Body: string(body), Active: true, CreatedBy: c.GetInt("id"), CreatedTime: common.GetTimestamp()}
		if err := tx.Create(&entry).Error; err != nil {
			return err
		}
		for stepID, resolution := range request.Resolutions {
			if resolution == "use_release" {
				if err := tx.Where("step_id = ?", stepID).Delete(&model.HamsterTutorialOverride{}).Error; err != nil {
					return err
				}
			}
		}
		return nil
	})
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, nil)
}

func RejectHamsterTutorialUpdate(c *gin.Context) { common.ApiSuccess(c, nil) }

func SaveHamsterTutorialOverride(c *gin.Context) {
	var override hamsterswitch.TutorialOverride
	if err := c.ShouldBindJSON(&override); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	override.StepID = c.Param("stepId")
	for index, asset := range override.Assets {
		if asset.Kind != "external" {
			continue
		}
		entry, err := cacheHamsterTutorialExternalImage(c, asset.URL)
		if err != nil {
			c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": err.Error()})
			return
		}
		override.Assets[index] = hamsterswitch.TutorialAsset{Kind: "site", ID: entry.ID}
	}
	if err := hamsterswitch.ValidateTutorialOverride(override); err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": err.Error()})
		return
	}
	base, err := currentHamsterTutorial()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	body, err := common.Marshal(override)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	var existing model.HamsterTutorialOverride
	err = model.DB.Where("step_id = ?", override.StepID).First(&existing).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		existing = model.HamsterTutorialOverride{StepID: override.StepID}
	} else if err != nil {
		common.ApiError(c, err)
		return
	}
	existing.Body, existing.BaseVersion, existing.UpdatedBy, existing.UpdatedTime = string(body), base.Version, c.GetInt("id"), common.GetTimestamp()
	if err := model.DB.Save(&existing).Error; err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, override)
}

func DeleteHamsterTutorialOverride(c *gin.Context) {
	if err := model.DB.Where("step_id = ?", c.Param("stepId")).Delete(&model.HamsterTutorialOverride{}).Error; err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, nil)
}

func UploadHamsterTutorialImage(c *gin.Context) {
	c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, 9<<20)
	file, err := c.FormFile("file")
	if err != nil {
		common.ApiError(c, errors.New("必须选择图片文件"))
		return
	}
	opened, err := file.Open()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	defer opened.Close()
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	entry, err := cache.Store(opened, file.Header.Get("Content-Type"))
	if err != nil {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": err.Error()})
		return
	}
	if err := recordHamsterTutorialImage(entry.ID, entry, "", c.GetInt("id")); err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"id": entry.ID, "url": "/api/hamster-switch/tutorial/images/" + entry.ID})
}

func GetHamsterTutorialImage(c *gin.Context) {
	var image model.HamsterTutorialImage
	if err := model.DB.First(&image, "id = ?", c.Param("id")).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.Status(http.StatusNotFound)
		} else {
			common.ApiError(c, err)
		}
		return
	}
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	path, err := cache.Path(image.LocalName)
	if err != nil {
		c.Status(http.StatusNotFound)
		return
	}
	c.Header("Cache-Control", "public, max-age=31536000, immutable")
	c.Header("Content-Type", image.MediaType)
	c.File(path)
}

func currentHamsterTutorial() (hamsterswitch.Tutorial, error) {
	var snapshot model.HamsterTutorialSnapshot
	err := model.DB.Where("active = ?", true).Order("id desc").First(&snapshot).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return hamsterswitch.BuiltinTutorial(), nil
	}
	if err != nil {
		return hamsterswitch.Tutorial{}, err
	}
	var tutorial hamsterswitch.Tutorial
	if err := common.Unmarshal([]byte(snapshot.Body), &tutorial); err != nil {
		return tutorial, err
	}
	return tutorial, tutorial.Validate()
}

func hamsterTutorialOverrides() ([]hamsterswitch.TutorialOverride, error) {
	var rows []model.HamsterTutorialOverride
	if err := model.DB.Order("step_id asc").Find(&rows).Error; err != nil {
		return nil, err
	}
	result := make([]hamsterswitch.TutorialOverride, 0, len(rows))
	for _, row := range rows {
		var override hamsterswitch.TutorialOverride
		if err := common.Unmarshal([]byte(row.Body), &override); err != nil {
			return nil, err
		}
		result = append(result, override)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].StepID < result[j].StepID })
	return result, nil
}

func hamsterTutorialImageCache() (*hamsterswitch.ImageCache, error) {
	root := strings.TrimSpace(os.Getenv("HAMSTER_SWITCH_CONTENT_DIR"))
	if root == "" {
		root = filepath.Join("data", "hamster-switch")
	}
	return hamsterswitch.NewImageCache(filepath.Join(root, "tutorial-images"))
}
func recordHamsterTutorialImage(id string, entry hamsterswitch.ImageEntry, source string, userID int) error {
	image := model.HamsterTutorialImage{ID: id, LocalName: entry.LocalName, MediaType: entry.MediaType, SizeBytes: entry.Size, Width: entry.Width, Height: entry.Height, SourceURL: source, CreatedBy: userID, CreatedTime: common.GetTimestamp()}
	return model.DB.Save(&image).Error
}
func cacheHamsterTutorialExternalImage(c *gin.Context, source string) (hamsterswitch.ImageEntry, error) {
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		return hamsterswitch.ImageEntry{}, err
	}
	entry, err := cache.Fetch(c.Request.Context(), source)
	if err != nil {
		return entry, err
	}
	return entry, recordHamsterTutorialImage(entry.ID, entry, source, c.GetInt("id"))
}
func storeHamsterReleaseImages(c *gin.Context, snapshot hamsterswitch.TutorialSnapshot) error {
	cache, err := hamsterTutorialImageCache()
	if err != nil {
		return err
	}
	for id, image := range snapshot.Images {
		entry, err := cache.Store(bytes.NewReader(image.Body), image.MediaType)
		if err != nil {
			return err
		}
		if err := recordHamsterTutorialImage(id, entry, "", c.GetInt("id")); err != nil {
			return err
		}
	}
	return nil
}
