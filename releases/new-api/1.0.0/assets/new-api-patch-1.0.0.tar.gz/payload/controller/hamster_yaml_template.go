package controller

import (
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service/hamsterswitch"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type hamsterTemplateBodyRequest struct {
	Body string `json:"body"`
}
type hamsterTemplatePublishRequest struct {
	AcknowledgeWarnings bool `json:"acknowledge_warnings"`
}

type hamsterTemplateVersionDTO struct {
	Version            int                                `json:"version"`
	Body               string                             `json:"body"`
	Warnings           []hamsterswitch.TemplateDiagnostic `json:"warnings"`
	WarningConfirmedBy int                                `json:"warning_confirmed_by,omitempty"`
	WarningConfirmedAt int64                              `json:"warning_confirmed_at,omitempty"`
	CreatedBy          int                                `json:"created_by,omitempty"`
	CreatedAt          int64                              `json:"created_at"`
	Active             bool                               `json:"active"`
}

func GetHamsterYAMLTemplateState(c *gin.Context) {
	draft, err := ensureHamsterTemplateDraft()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	var versions []model.HamsterYAMLTemplate
	if err := model.DB.Order("version desc").Find(&versions).Error; err != nil {
		common.ApiError(c, err)
		return
	}
	history := make([]hamsterTemplateVersionDTO, 0, len(versions))
	var current *hamsterTemplateVersionDTO
	for _, version := range versions {
		dto := hamsterTemplateDTO(version)
		history = append(history, dto)
		if version.Active {
			copyDTO := dto
			current = &copyDTO
		}
	}
	common.ApiSuccess(c, gin.H{"draft": draft.Body, "diagnostics": hamsterswitch.ValidateTemplate(draft.Body), "current": current, "history": history})
}

func SaveHamsterYAMLTemplateDraft(c *gin.Context) {
	var request hamsterTemplateBodyRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	diagnostics := hamsterswitch.ValidateTemplate(request.Body)
	draft := model.HamsterYAMLTemplateDraft{ID: 1, Body: request.Body, UpdatedBy: c.GetInt("id"), UpdatedTime: common.GetTimestamp()}
	if err := model.DB.Save(&draft).Error; err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"diagnostics": diagnostics})
}

func PublishHamsterYAMLTemplate(c *gin.Context) {
	var request hamsterTemplatePublishRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		common.ApiError(c, errors.New("请求参数无效"))
		return
	}
	draft, err := ensureHamsterTemplateDraft()
	if err != nil {
		common.ApiError(c, err)
		return
	}
	diagnostics := hamsterswitch.ValidateTemplate(draft.Body)
	if hamsterswitch.HasTemplateErrors(diagnostics) {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": "模板存在不可绕过的硬错误", "data": gin.H{"diagnostics": diagnostics}})
		return
	}
	if hamsterswitch.HasTemplateWarnings(diagnostics) && !request.AcknowledgeWarnings {
		c.JSON(http.StatusConflict, gin.H{"success": false, "message": "发布前必须确认全部警告", "data": gin.H{"diagnostics": diagnostics}})
		return
	}
	version, err := createHamsterTemplateVersion(c.GetInt("id"), draft.Body, diagnostics, request.AcknowledgeWarnings)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"version": hamsterTemplateDTO(*version), "diagnostics": diagnostics})
}

func RollbackHamsterYAMLTemplate(c *gin.Context) {
	targetVersion, err := strconv.Atoi(c.Param("version"))
	if err != nil {
		common.ApiError(c, errors.New("版本号无效"))
		return
	}
	var target model.HamsterYAMLTemplate
	if err := model.DB.Where("version = ?", targetVersion).First(&target).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"success": false, "message": "模板版本不存在"})
		} else {
			common.ApiError(c, err)
		}
		return
	}
	diagnostics := hamsterswitch.ValidateTemplate(target.Body)
	if hamsterswitch.HasTemplateErrors(diagnostics) {
		c.JSON(http.StatusUnprocessableEntity, gin.H{"success": false, "message": "目标版本已无法通过当前硬校验", "data": gin.H{"diagnostics": diagnostics}})
		return
	}
	version, err := createHamsterTemplateVersion(c.GetInt("id"), target.Body, diagnostics, true)
	if err != nil {
		common.ApiError(c, err)
		return
	}
	draft := model.HamsterYAMLTemplateDraft{ID: 1, Body: target.Body, UpdatedBy: c.GetInt("id"), UpdatedTime: common.GetTimestamp()}
	_ = model.DB.Save(&draft).Error
	common.ApiSuccess(c, hamsterTemplateDTO(*version))
}

func ensureHamsterTemplateDraft() (*model.HamsterYAMLTemplateDraft, error) {
	var draft model.HamsterYAMLTemplateDraft
	err := model.DB.First(&draft, 1).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		draft = model.HamsterYAMLTemplateDraft{ID: 1, Body: hamsterswitch.DefaultTemplate, UpdatedTime: common.GetTimestamp()}
		err = model.DB.Create(&draft).Error
	}
	return &draft, err
}

func createHamsterTemplateVersion(userID int, body string, diagnostics []hamsterswitch.TemplateDiagnostic, acknowledge bool) (*model.HamsterYAMLTemplate, error) {
	warningsJSON, err := common.Marshal(diagnostics)
	if err != nil {
		return nil, err
	}
	var created model.HamsterYAMLTemplate
	err = model.DB.Transaction(func(tx *gorm.DB) error {
		var maxVersion int
		if err := tx.Model(&model.HamsterYAMLTemplate{}).Select("COALESCE(MAX(version), 0)").Scan(&maxVersion).Error; err != nil {
			return err
		}
		if err := tx.Model(&model.HamsterYAMLTemplate{}).Where("active = ?", true).Update("active", false).Error; err != nil {
			return err
		}
		created = model.HamsterYAMLTemplate{Version: maxVersion + 1, Body: body, Warnings: string(warningsJSON), Active: true, CreatedBy: userID, CreatedTime: common.GetTimestamp()}
		if acknowledge && hamsterswitch.HasTemplateWarnings(diagnostics) {
			created.WarningConfirmedBy = userID
			created.WarningConfirmedAt = time.Now().Unix()
		}
		return tx.Create(&created).Error
	})
	return &created, err
}

func hamsterTemplateDTO(version model.HamsterYAMLTemplate) hamsterTemplateVersionDTO {
	warnings := []hamsterswitch.TemplateDiagnostic{}
	if version.Warnings != "" {
		_ = common.Unmarshal([]byte(version.Warnings), &warnings)
	}
	return hamsterTemplateVersionDTO{Version: version.Version, Body: version.Body, Warnings: warnings, WarningConfirmedBy: version.WarningConfirmedBy, WarningConfirmedAt: version.WarningConfirmedAt, CreatedBy: version.CreatedBy, CreatedAt: version.CreatedTime, Active: version.Active}
}
