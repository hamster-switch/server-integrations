package controller

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func setupHamsterDownloadTestDB(t *testing.T) {
	t.Helper()
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	require.NoError(t, err)
	previousDB := model.DB
	previousType := common.MainDatabaseType()
	model.DB = db
	common.SetMainDatabaseType(common.DatabaseTypeSQLite)
	t.Cleanup(func() {
		model.DB = previousDB
		common.SetMainDatabaseType(previousType)
	})
	require.NoError(t, model.DB.AutoMigrate(
		&model.Token{},
		&model.HamsterConfigSubscription{},
		&model.HamsterConfigSubscriptionProvider{},
	))
}

func invokeHamsterDownload(token string) *httptest.ResponseRecorder {
	recorder := httptest.NewRecorder()
	context, _ := gin.CreateTestContext(recorder)
	context.Request = httptest.NewRequest(http.MethodGet, "/api/hamster-switch/config-subscription/"+token, nil)
	context.Params = gin.Params{{Key: "token", Value: token}}
	DownloadHamsterConfigSubscription(context)
	return recorder
}

func TestHamsterDownloadRejectsLegacyDisabledAndDeletedURLs(t *testing.T) {
	gin.SetMode(gin.TestMode)
	setupHamsterDownloadTestDB(t)

	assert.Equal(t, http.StatusNotFound, invokeHamsterDownload("hs_legacy.signature").Code)

	created, err := model.CreateHamsterConfigSubscription(42, model.HamsterSubscriptionInput{
		Name:   "生命周期测试",
		Groups: []string{"default"},
	})
	require.NoError(t, err)
	_, err = model.SetHamsterConfigSubscriptionEnabled(42, created.PublicID, false)
	require.NoError(t, err)
	assert.Equal(t, http.StatusGone, invokeHamsterDownload(created.DownloadToken+".yaml").Code)

	_, err = model.SetHamsterConfigSubscriptionEnabled(42, created.PublicID, true)
	require.NoError(t, err)
	require.NoError(t, model.DeleteHamsterConfigSubscription(42, created.PublicID))
	assert.Equal(t, http.StatusNotFound, invokeHamsterDownload(created.DownloadToken+".yaml").Code)
}
