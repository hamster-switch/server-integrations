package controller

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/setting/system_setting"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"

	"github.com/QuantumNous/new-api/service/hamsterswitch"
)

func setupHamsterControllerTest(t *testing.T) *model.HamsterConfigSubscription {
	t.Helper()
	previousDB := model.DB
	previousLogDB := model.LOG_DB
	previousMainType := common.MainDatabaseType()
	previousLogType := common.LogDatabaseType()
	previousSQLitePath := common.SQLitePath
	previousServerAddress := system_setting.ServerAddress
	previousMaster := common.IsMasterNode
	previousRedis := common.RedisEnabled
	previousMemoryCache := common.MemoryCacheEnabled
	common.SQLitePath = filepath.Join(t.TempDir(), "hamster-controller.db")
	common.IsMasterNode = true
	common.RedisEnabled = false
	common.MemoryCacheEnabled = false
	system_setting.ServerAddress = "https://new-api.example.com/"
	t.Setenv("SQL_DSN", "local")
	t.Setenv("LOG_SQL_DSN", "")
	require.NoError(t, model.InitDB())
	db := model.DB
	model.LOG_DB = db
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		model.DB = previousDB
		model.LOG_DB = previousLogDB
		common.SetDatabaseTypes(previousMainType, previousLogType)
		common.SQLitePath = previousSQLitePath
		common.IsMasterNode = previousMaster
		common.RedisEnabled = previousRedis
		common.MemoryCacheEnabled = previousMemoryCache
		system_setting.ServerAddress = previousServerAddress
	})
	require.NoError(t, db.Create(&model.User{
		Id: 42, Username: "hamster-controller", Password: "unused-password",
		Role: common.RoleAdminUser, Status: common.UserStatusEnabled, Group: "default",
	}).Error)
	item, err := model.CreateHamsterConfigSubscription(42, model.HamsterSubscriptionInput{
		Name: "Controller subscription", Groups: []string{"default"},
	})
	require.NoError(t, err)
	require.NoError(t, db.Create(&model.Channel{
		Id: 17, Name: "controller-channel", Status: common.ChannelStatusEnabled,
		Group: "default", Models: "gpt-controller",
	}).Error)
	require.NoError(t, db.Create(&model.Ability{
		Group: "default", Model: "gpt-controller", ChannelId: 17, Enabled: true,
	}).Error)
	return item
}

func performHamsterControllerRequest(method, path string, handler gin.HandlerFunc, userID int, params gin.Params) *httptest.ResponseRecorder {
	return performHamsterControllerRequestWithBody(method, path, nil, handler, userID, params)
}

func performHamsterControllerRequestWithBody(method, path string, body []byte, handler gin.HandlerFunc, userID int, params gin.Params) *httptest.ResponseRecorder {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Handle(method, path, func(c *gin.Context) {
		c.Params = params
		c.Set("id", userID)
		c.Set("username", "hamster-controller")
		c.Set("role", common.RoleAdminUser)
		handler(c)
	})
	request := httptest.NewRequest(method, path, bytes.NewReader(body))
	if len(body) > 0 {
		request.Header.Set("Content-Type", "application/json")
	}
	recorder := httptest.NewRecorder()
	router.ServeHTTP(recorder, request)
	return recorder
}

func TestHamsterTemplatePublishRequiresWarningConfirmationAndRollbackCreatesVersion(t *testing.T) {
	setupHamsterControllerTest(t)
	body := strings.Replace(hamsterswitch.DefaultTemplate, "{{subscription.updated_at}}", "", 1)
	requestBody, err := common.Marshal(map[string]any{
		"body":             body,
		"presentation":     map[string]any{"subscription": map[string]any{}, "providers": map[string]any{}},
		"confirm_warnings": false,
	})
	require.NoError(t, err)

	rejected := performHamsterControllerRequestWithBody(http.MethodPost, "/template/publish", requestBody, PublishHamsterTemplate, 42, nil)
	assert.Equal(t, http.StatusConflict, rejected.Code)
	assert.Contains(t, rejected.Body.String(), "HAMSTER_TEMPLATE_WARNING_CONFIRMATION_REQUIRED")

	requestBody, err = common.Marshal(map[string]any{
		"body":             body,
		"presentation":     map[string]any{"subscription": map[string]any{}, "providers": map[string]any{}},
		"confirm_warnings": true,
	})
	require.NoError(t, err)
	published := performHamsterControllerRequestWithBody(http.MethodPost, "/template/publish", requestBody, PublishHamsterTemplate, 42, nil)
	require.Equal(t, http.StatusOK, published.Code)

	rolledBack := performHamsterControllerRequest(http.MethodPost, "/template/rollback/1", RollbackHamsterTemplate, 42, gin.Params{{Key: "version", Value: "1"}})
	require.Equal(t, http.StatusOK, rolledBack.Code)
	var response map[string]any
	require.NoError(t, common.Unmarshal(rolledBack.Body.Bytes(), &response))
	data := response["data"].(map[string]any)
	assert.Equal(t, float64(2), data["version"])
	assert.Equal(t, float64(1), data["rollback_from"])
	assert.Equal(t, true, data["active"])
}

func TestHamsterTutorialRejectPersistsVersion(t *testing.T) {
	setupHamsterControllerTest(t)
	body, err := common.Marshal(map[string]string{"version": "1.2.3"})
	require.NoError(t, err)
	recorder := performHamsterControllerRequestWithBody(http.MethodPost, "/tutorial/reject", body, RejectHamsterTutorialUpdate, 42, nil)
	require.Equal(t, http.StatusOK, recorder.Code)

	var rejection model.HamsterTutorialRejection
	require.NoError(t, model.DB.Where("version = ?", "1.2.3").First(&rejection).Error)
	assert.Equal(t, 42, rejection.RejectedBy)
}

func TestHamsterUserDTOContainsSummaryAndStableURLWithoutProviderSecrets(t *testing.T) {
	item := setupHamsterControllerTest(t)
	path := "/subscriptions/" + item.PublicID
	recorder := performHamsterControllerRequest(http.MethodGet, path, GetHamsterConfigSubscription, 42, gin.Params{{Key: "public_id", Value: item.PublicID}})
	require.Equal(t, http.StatusOK, recorder.Code)

	var response map[string]any
	require.NoError(t, common.Unmarshal(recorder.Body.Bytes(), &response))
	data, ok := response["data"].(map[string]any)
	require.True(t, ok)
	assert.Equal(t, item.PublicID, data["public_id"])
	assert.Equal(t, "https://new-api.example.com/api/hamster-switch/public/"+item.DownloadToken+"/subscription.yaml", data["download_url"])
	providers, ok := data["providers"].([]any)
	require.True(t, ok)
	require.Len(t, providers, 1)
	provider, ok := providers[0].(map[string]any)
	require.True(t, ok)
	assert.NotContains(t, provider, "api_key")
	assert.NotContains(t, provider, "settings_config")
	assert.NotContains(t, provider, "meta")
	assert.NotContains(t, recorder.Body.String(), "sk-hsp")
	assert.NotContains(t, recorder.Body.String(), "token_id")

	otherUser := performHamsterControllerRequest(http.MethodGet, path, GetHamsterConfigSubscription, 99, gin.Params{{Key: "public_id", Value: item.PublicID}})
	assert.Equal(t, http.StatusNotFound, otherUser.Code)
}

func TestHamsterPublicDownloadHonorsDisabledAndDeletedStates(t *testing.T) {
	item := setupHamsterControllerTest(t)
	path := "/public/" + item.DownloadToken + "/subscription.yaml"

	params := gin.Params{{Key: "download_token", Value: item.DownloadToken}}
	download := performHamsterControllerRequest(http.MethodGet, path, DownloadHamsterConfigSubscription, 0, params)
	require.Equal(t, http.StatusOK, download.Code)
	assert.Contains(t, download.Header().Get("Cache-Control"), "no-store")
	assert.Equal(t, "application/yaml; charset=utf-8", download.Header().Get("Content-Type"))
	var document map[string]any
	require.NoError(t, yaml.Unmarshal(download.Body.Bytes(), &document))
	providers, ok := document["providers"].([]any)
	require.True(t, ok)
	require.Len(t, providers, 1)
	provider, ok := providers[0].(map[string]any)
	require.True(t, ok)
	assert.True(t, strings.HasPrefix(provider["api_key"].(string), "sk-hsp"))

	_, err := model.SetHamsterConfigSubscriptionEnabled(42, item.PublicID, false)
	require.NoError(t, err)
	disabled := performHamsterControllerRequest(http.MethodGet, path, DownloadHamsterConfigSubscription, 0, params)
	assert.Equal(t, http.StatusGone, disabled.Code)

	reenabled, err := model.SetHamsterConfigSubscriptionEnabled(42, item.PublicID, true)
	require.NoError(t, err)
	assert.Equal(t, item.DownloadToken, reenabled.DownloadToken)
	restored := performHamsterControllerRequest(http.MethodGet, path, DownloadHamsterConfigSubscription, 0, params)
	assert.Equal(t, http.StatusOK, restored.Code)

	require.NoError(t, model.DeleteHamsterConfigSubscription(42, item.PublicID))
	deleted := performHamsterControllerRequest(http.MethodGet, path, DownloadHamsterConfigSubscription, 0, params)
	assert.Equal(t, http.StatusNotFound, deleted.Code)
}

func TestHamsterAdminYAMLIsNoStoreAndContainsRealProviderCredential(t *testing.T) {
	item := setupHamsterControllerTest(t)
	path := "/admin/subscriptions/" + item.PublicID + "/yaml"
	recorder := performHamsterControllerRequest(http.MethodGet, path, AdminDownloadHamsterConfigSubscription, 42, gin.Params{{Key: "public_id", Value: item.PublicID}})
	require.Equal(t, http.StatusOK, recorder.Code)
	assert.Contains(t, recorder.Header().Get("Cache-Control"), "no-store")
	assert.Contains(t, recorder.Body.String(), "sk-hsp")
	assert.NotContains(t, recorder.Body.String(), item.DownloadToken)
}
