package controller

import (
	"errors"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	hamsterswitch "github.com/QuantumNous/new-api/service/hamsterswitch"
	"github.com/QuantumNous/new-api/setting/system_setting"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type hamsterSubscriptionRequest struct {
	Name   string   `json:"name"`
	Groups []string `json:"groups"`
}

type hamsterSubscriptionGroupResponse struct {
	GroupName string `json:"group_name"`
	Position  int    `json:"position"`
}

type hamsterSubscriptionResponse struct {
	PublicID      string                             `json:"public_id"`
	Name          string                             `json:"name"`
	Status        string                             `json:"status"`
	Groups        []hamsterSubscriptionGroupResponse `json:"groups"`
	DownloadURL   string                             `json:"download_url"`
	Providers     []hamsterswitch.ProviderSummary    `json:"providers"`
	ProviderCount int                                `json:"provider_count"`
	CreatedTime   int64                              `json:"created_time"`
	UpdatedTime   int64                              `json:"updated_time"`
}

func hamsterBaseURL() (string, error) {
	baseURL := strings.TrimRight(strings.TrimSpace(system_setting.ServerAddress), "/")
	parsed, err := url.Parse(baseURL)
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil {
		return "", errors.New("ServerAddress must be an absolute HTTP(S) URL without credentials")
	}
	return baseURL, nil
}

func buildHamsterSubscriptionResponse(item *model.HamsterConfigSubscription) (*hamsterSubscriptionResponse, error) {
	baseURL, err := hamsterBaseURL()
	if err != nil {
		return nil, err
	}
	export, _, err := hamsterswitch.BuildSubscription(item, baseURL, hamsterswitch.BuildPreview)
	if err != nil {
		return nil, err
	}
	groups := make([]hamsterSubscriptionGroupResponse, 0, len(item.Groups))
	for _, group := range item.Groups {
		groups = append(groups, hamsterSubscriptionGroupResponse{
			GroupName: group.GroupName,
			Position:  group.Position,
		})
	}
	providers := hamsterswitch.SummarizeProviders(export)
	return &hamsterSubscriptionResponse{
		PublicID:      item.PublicID,
		Name:          item.Name,
		Status:        item.Status,
		Groups:        groups,
		DownloadURL:   baseURL + "/api/hamster-switch/public/" + url.PathEscape(item.DownloadToken) + "/subscription.yaml",
		Providers:     providers,
		ProviderCount: len(providers),
		CreatedTime:   item.CreatedTime,
		UpdatedTime:   item.UpdatedTime,
	}, nil
}

func writeHamsterError(c *gin.Context, status int, code string, err error) {
	message := "request failed"
	if err != nil {
		message = err.Error()
	}
	c.JSON(status, gin.H{"success": false, "code": code, "message": message})
}

func writeHamsterModelError(c *gin.Context, err error) {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		writeHamsterError(c, http.StatusNotFound, "HAMSTER_SUBSCRIPTION_NOT_FOUND", errors.New("subscription not found"))
		return
	}
	writeHamsterError(c, http.StatusInternalServerError, "HAMSTER_SUBSCRIPTION_FAILED", err)
}

func ListHamsterConfigSubscriptions(c *gin.Context) {
	pageInfo := common.GetPageQuery(c)
	items, total, err := model.ListHamsterConfigSubscriptions(
		c.GetInt("id"), pageInfo.GetStartIdx(), pageInfo.GetPageSize(), c.Query("search"),
	)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	responses := make([]*hamsterSubscriptionResponse, 0, len(items))
	for index := range items {
		response, err := buildHamsterSubscriptionResponse(&items[index])
		if err != nil {
			writeHamsterModelError(c, err)
			return
		}
		responses = append(responses, response)
	}
	pageInfo.SetTotal(int(total))
	pageInfo.SetItems(responses)
	common.ApiSuccess(c, pageInfo)
}

func GetHamsterConfigSubscription(c *gin.Context) {
	item, err := model.GetHamsterConfigSubscription(c.GetInt("id"), c.Param("public_id"))
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	response, err := buildHamsterSubscriptionResponse(item)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	common.ApiSuccess(c, response)
}

func CreateHamsterConfigSubscription(c *gin.Context) {
	var request hamsterSubscriptionRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SUBSCRIPTION_INVALID", err)
		return
	}
	item, err := model.CreateHamsterConfigSubscription(c.GetInt("id"), model.HamsterSubscriptionInput{
		Name: request.Name, Groups: request.Groups,
	})
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SUBSCRIPTION_INVALID", err)
		return
	}
	response, err := buildHamsterSubscriptionResponse(item)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	c.JSON(http.StatusCreated, gin.H{"success": true, "message": "", "data": response})
}

func UpdateHamsterConfigSubscription(c *gin.Context) {
	var request hamsterSubscriptionRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SUBSCRIPTION_INVALID", err)
		return
	}
	item, err := model.UpdateHamsterConfigSubscription(c.GetInt("id"), c.Param("public_id"), model.HamsterSubscriptionInput{
		Name: request.Name, Groups: request.Groups,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			writeHamsterModelError(c, err)
		} else {
			writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SUBSCRIPTION_INVALID", err)
		}
		return
	}
	response, err := buildHamsterSubscriptionResponse(item)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	common.ApiSuccess(c, response)
}

func SetHamsterConfigSubscriptionEnabled(c *gin.Context) {
	action := c.Param("action")
	if action != "enable" && action != "disable" {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SUBSCRIPTION_ACTION_INVALID", errors.New("action must be enable or disable"))
		return
	}
	enabled := action == "enable"
	item, err := model.SetHamsterConfigSubscriptionEnabled(c.GetInt("id"), c.Param("public_id"), enabled)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	response, err := buildHamsterSubscriptionResponse(item)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	common.ApiSuccess(c, response)
}

func DeleteHamsterConfigSubscription(c *gin.Context) {
	if err := model.DeleteHamsterConfigSubscription(c.GetInt("id"), c.Param("public_id")); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"deleted": true})
}

func DownloadHamsterConfigSubscription(c *gin.Context) {
	item, err := model.GetHamsterConfigSubscriptionByDownloadToken(c.Param("download_token"))
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			writeHamsterError(c, http.StatusNotFound, "HAMSTER_SUBSCRIPTION_NOT_FOUND", errors.New("subscription not found"))
		} else {
			writeHamsterError(c, http.StatusInternalServerError, "HAMSTER_SUBSCRIPTION_FAILED", errors.New("subscription download failed"))
		}
		return
	}
	if item.Status != model.HamsterSubscriptionActive {
		writeHamsterError(c, http.StatusGone, "HAMSTER_SUBSCRIPTION_DISABLED", errors.New("subscription is disabled"))
		return
	}
	baseURL, err := hamsterBaseURL()
	if err != nil {
		writeHamsterError(c, http.StatusInternalServerError, "HAMSTER_SUBSCRIPTION_FAILED", err)
		return
	}
	body, _, err := hamsterswitch.BuildYAML(item, baseURL)
	if err != nil {
		writeHamsterError(c, http.StatusInternalServerError, "HAMSTER_SUBSCRIPTION_FAILED", errors.New("subscription rendering failed"))
		return
	}
	c.Header("Cache-Control", "no-store")
	c.Header("Content-Disposition", "attachment; filename=hamster-switch-subscription.yaml")
	c.Data(http.StatusOK, "application/yaml; charset=utf-8", body)
}

func AdminDownloadHamsterConfigSubscription(c *gin.Context) {
	item, err := model.GetHamsterConfigSubscriptionByPublicID(c.Param("public_id"))
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	baseURL, err := hamsterBaseURL()
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	body, _, err := hamsterswitch.BuildYAML(item, baseURL)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	recordManageAudit(c, "hamster.subscription_yaml_view", map[string]interface{}{
		"subscription_public_id": item.PublicID,
		"subscription_user_id":   item.UserID,
	})
	c.Header("Cache-Control", "no-store")
	c.Data(http.StatusOK, "application/yaml; charset=utf-8", body)
}

func GetHamsterChannelApps(c *gin.Context) {
	channelID, err := strconv.Atoi(c.Param("channel_id"))
	if err != nil || channelID <= 0 {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_CHANNEL_INVALID", errors.New("invalid channel id"))
		return
	}
	if _, err := model.GetChannelById(channelID, false); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	apps, err := model.GetHamsterChannelApps(channelID)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	common.ApiSuccess(c, gin.H{"channel_id": channelID, "apps": apps, "is_default": len(apps) == len(model.DefaultHamsterChannelApps)})
}

func UpdateHamsterChannelApps(c *gin.Context) {
	channelID, err := strconv.Atoi(c.Param("channel_id"))
	if err != nil || channelID <= 0 {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_CHANNEL_INVALID", errors.New("invalid channel id"))
		return
	}
	if _, err := model.GetChannelById(channelID, false); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	var request struct {
		Apps []string `json:"apps"`
	}
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_CHANNEL_APPS_INVALID", err)
		return
	}
	apps, err := model.SetHamsterChannelApps(channelID, c.GetInt("id"), request.Apps)
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_CHANNEL_APPS_INVALID", err)
		return
	}
	recordManageAudit(c, "hamster.channel_apps_update", map[string]interface{}{"channel_id": channelID, "apps": strings.Join(apps, ",")})
	common.ApiSuccess(c, gin.H{"channel_id": channelID, "apps": apps, "is_default": false})
}

func ResetHamsterChannelApps(c *gin.Context) {
	channelID, err := strconv.Atoi(c.Param("channel_id"))
	if err != nil || channelID <= 0 {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_CHANNEL_INVALID", errors.New("invalid channel id"))
		return
	}
	if _, err := model.GetChannelById(channelID, false); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	if err := model.ResetHamsterChannelApps(channelID); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	recordManageAudit(c, "hamster.channel_apps_reset", map[string]interface{}{"channel_id": channelID})
	common.ApiSuccess(c, gin.H{"channel_id": channelID, "apps": append([]string(nil), model.DefaultHamsterChannelApps...), "is_default": true})
}

func GetHamsterSettings(c *gin.Context) {
	common.ApiSuccess(c, gin.H{"managed_tokens_visible": common.HamsterManagedTokensVisible})
}

func UpdateHamsterSettings(c *gin.Context) {
	var request struct {
		ManagedTokensVisible *bool `json:"managed_tokens_visible"`
	}
	if err := c.ShouldBindJSON(&request); err != nil || request.ManagedTokensVisible == nil {
		if err == nil {
			err = errors.New("managed_tokens_visible is required")
		}
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_SETTINGS_INVALID", err)
		return
	}
	value := strconv.FormatBool(*request.ManagedTokensVisible)
	if err := model.UpdateOption("HamsterManagedTokensVisible", value); err != nil {
		writeHamsterModelError(c, err)
		return
	}
	recordManageAudit(c, "hamster.settings_update", map[string]interface{}{"managed_tokens_visible": *request.ManagedTokensVisible})
	common.ApiSuccess(c, gin.H{"managed_tokens_visible": common.HamsterManagedTokensVisible})
}
