package controller

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	hamsterswitch "github.com/QuantumNous/new-api/service/hamsterswitch"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type hamsterTemplateRequest struct {
	Body            string                             `json:"body"`
	Presentation    hamsterswitch.TemplatePresentation `json:"presentation"`
	ConfirmWarnings bool                               `json:"confirm_warnings"`
	SubscriptionID  string                             `json:"subscription_public_id"`
}

func hamsterTemplateDraftResponse(draft *model.HamsterYAMLTemplateDraft) (gin.H, error) {
	presentation, err := hamsterswitch.DecodeTemplatePresentation(draft.PresentationJSON)
	if err != nil {
		return nil, err
	}
	return gin.H{
		"body": draft.Body, "presentation": presentation,
		"updated_by": draft.UpdatedBy, "updated_time": draft.UpdatedTime,
	}, nil
}

func hamsterTemplateVersionResponse(item model.HamsterYAMLTemplate) (gin.H, error) {
	presentation, err := hamsterswitch.DecodeTemplatePresentation(item.PresentationJSON)
	if err != nil {
		return nil, err
	}
	var warnings []hamsterswitch.TemplateDiagnostic
	if item.WarningsJSON != "" {
		if err := common.Unmarshal([]byte(item.WarningsJSON), &warnings); err != nil {
			return nil, err
		}
	}
	return gin.H{
		"version": item.Version, "body": item.Body, "presentation": presentation,
		"warnings": warnings, "active": item.Active, "rollback_from": item.RollbackFrom,
		"warning_confirmed_by": item.WarningConfirmedBy, "warning_confirmed_at": item.WarningConfirmedAt,
		"created_by": item.CreatedBy, "created_time": item.CreatedTime,
	}, nil
}

func GetHamsterTemplateState(c *gin.Context) {
	draft, err := model.GetHamsterYAMLTemplateDraft(hamsterswitch.DefaultTemplate, hamsterswitch.DefaultPresentationJSON)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	draftResponse, err := hamsterTemplateDraftResponse(draft)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	history, err := model.ListHamsterYAMLTemplates()
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	versions := make([]gin.H, 0, len(history))
	for _, item := range history {
		response, err := hamsterTemplateVersionResponse(item)
		if err != nil {
			writeHamsterModelError(c, err)
			return
		}
		versions = append(versions, response)
	}
	common.ApiSuccess(c, gin.H{"draft": draftResponse, "versions": versions})
}

func SaveHamsterTemplateDraft(c *gin.Context) {
	var request hamsterTemplateRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_INVALID", err)
		return
	}
	diagnostics := hamsterswitch.ValidateTemplate(request.Body)
	presentation, err := hamsterswitch.EncodeTemplatePresentation(request.Presentation)
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_PRESENTATION_INVALID", err)
		return
	}
	draft, err := model.SaveHamsterYAMLTemplateDraft(request.Body, presentation, c.GetInt("id"))
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	response, err := hamsterTemplateDraftResponse(draft)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	response["diagnostics"] = diagnostics
	recordManageAudit(c, "hamster.template_draft_save", nil)
	common.ApiSuccess(c, response)
}

func PreviewHamsterTemplate(c *gin.Context) {
	var request hamsterTemplateRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_INVALID", err)
		return
	}
	if request.SubscriptionID == "" {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_SUBSCRIPTION_REQUIRED", errors.New("subscription_public_id is required"))
		return
	}
	if err := hamsterswitch.ValidateTemplatePresentation(request.Presentation); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_PRESENTATION_INVALID", err)
		return
	}
	item, err := model.GetHamsterConfigSubscriptionByPublicID(request.SubscriptionID)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	baseURL, err := hamsterBaseURL()
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	export, skipped, err := hamsterswitch.BuildSubscriptionWithPresentation(item, baseURL, hamsterswitch.BuildPreview, request.Presentation)
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_PRESENTATION_INVALID", err)
		return
	}
	body, diagnostics, err := hamsterswitch.RenderTemplate(request.Body, *export)
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_INVALID", err)
		return
	}
	c.Header("Cache-Control", "no-store")
	common.ApiSuccess(c, gin.H{"yaml": string(body), "diagnostics": diagnostics, "skipped": skipped})
}

func PublishHamsterTemplate(c *gin.Context) {
	var request hamsterTemplateRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_INVALID", err)
		return
	}
	diagnostics := hamsterswitch.ValidateTemplate(request.Body)
	if hamsterswitch.HasTemplateErrors(diagnostics) {
		c.JSON(http.StatusBadRequest, gin.H{"success": false, "code": "HAMSTER_TEMPLATE_INVALID", "message": "template contains hard errors", "diagnostics": diagnostics})
		return
	}
	if hamsterswitch.HasTemplateWarnings(diagnostics) && !request.ConfirmWarnings {
		c.JSON(http.StatusConflict, gin.H{"success": false, "code": "HAMSTER_TEMPLATE_WARNING_CONFIRMATION_REQUIRED", "message": "template warnings require confirmation", "diagnostics": diagnostics})
		return
	}
	presentation, err := hamsterswitch.EncodeTemplatePresentation(request.Presentation)
	if err != nil {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_PRESENTATION_INVALID", err)
		return
	}
	warnings, err := common.Marshal(diagnostics)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	published, err := model.PublishHamsterYAMLTemplate(request.Body, presentation, string(warnings), c.GetInt("id"), request.ConfirmWarnings)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	response, err := hamsterTemplateVersionResponse(*published)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	recordManageAudit(c, "hamster.template_publish", map[string]interface{}{"version": published.Version})
	common.ApiSuccess(c, response)
}

func RollbackHamsterTemplate(c *gin.Context) {
	version, err := strconv.Atoi(c.Param("version"))
	if err != nil || version <= 0 {
		writeHamsterError(c, http.StatusBadRequest, "HAMSTER_TEMPLATE_VERSION_INVALID", errors.New("invalid template version"))
		return
	}
	published, err := model.RollbackHamsterYAMLTemplate(version, c.GetInt("id"))
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			writeHamsterError(c, http.StatusNotFound, "HAMSTER_TEMPLATE_NOT_FOUND", errors.New("template version not found"))
		} else {
			writeHamsterModelError(c, err)
		}
		return
	}
	response, err := hamsterTemplateVersionResponse(*published)
	if err != nil {
		writeHamsterModelError(c, err)
		return
	}
	recordManageAudit(c, "hamster.template_rollback", map[string]interface{}{"from_version": version, "version": published.Version})
	common.ApiSuccess(c, response)
}
