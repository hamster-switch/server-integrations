package model

import (
	"errors"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"gorm.io/gorm"
)

type HamsterYAMLTemplate struct {
	ID                 uint   `json:"id"`
	Version            int    `json:"version" gorm:"uniqueIndex;not null"`
	Body               string `json:"body" gorm:"type:text;not null"`
	PresentationJSON   string `json:"-" gorm:"column:presentation;type:text;not null"`
	WarningsJSON       string `json:"-" gorm:"column:warnings;type:text;not null"`
	Active             bool   `json:"active" gorm:"index;not null"`
	RollbackFrom       int    `json:"rollback_from"`
	WarningConfirmedBy int    `json:"warning_confirmed_by"`
	WarningConfirmedAt int64  `json:"warning_confirmed_at" gorm:"bigint"`
	CreatedBy          int    `json:"created_by"`
	CreatedTime        int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterYAMLTemplateDraft struct {
	ID               uint   `json:"id" gorm:"primaryKey;autoIncrement:false"`
	Body             string `json:"body" gorm:"type:text;not null"`
	PresentationJSON string `json:"-" gorm:"column:presentation;type:text;not null"`
	UpdatedBy        int    `json:"updated_by"`
	UpdatedTime      int64  `json:"updated_time" gorm:"bigint;not null"`
}

func GetActiveHamsterYAMLTemplate() (*HamsterYAMLTemplate, error) {
	var item HamsterYAMLTemplate
	err := DB.Where("active = ?", true).Order("version desc").First(&item).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &item, err
}

func GetHamsterYAMLTemplateDraft(defaultBody, defaultPresentation string) (*HamsterYAMLTemplateDraft, error) {
	var draft HamsterYAMLTemplateDraft
	err := DB.First(&draft, "id = ?", 1).Error
	if err == nil {
		return &draft, nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}
	draft = HamsterYAMLTemplateDraft{
		ID: 1, Body: defaultBody, PresentationJSON: defaultPresentation, UpdatedTime: common.GetTimestamp(),
	}
	if err := DB.Create(&draft).Error; err != nil {
		if readErr := DB.First(&draft, "id = ?", 1).Error; readErr == nil {
			return &draft, nil
		}
		return nil, err
	}
	return &draft, nil
}

func SaveHamsterYAMLTemplateDraft(body, presentation string, updatedBy int) (*HamsterYAMLTemplateDraft, error) {
	body = strings.TrimSpace(body)
	if body == "" {
		return nil, errors.New("template body is required")
	}
	var draft HamsterYAMLTemplateDraft
	err := DB.First(&draft, "id = ?", 1).Error
	now := common.GetTimestamp()
	if errors.Is(err, gorm.ErrRecordNotFound) {
		draft = HamsterYAMLTemplateDraft{ID: 1, Body: body, PresentationJSON: presentation, UpdatedBy: updatedBy, UpdatedTime: now}
		err = DB.Create(&draft).Error
	} else if err == nil {
		err = DB.Model(&draft).Updates(map[string]any{
			"body": body, "presentation": presentation, "updated_by": updatedBy, "updated_time": now,
		}).Error
		draft.Body, draft.PresentationJSON, draft.UpdatedBy, draft.UpdatedTime = body, presentation, updatedBy, now
	}
	return &draft, err
}

func ListHamsterYAMLTemplates() ([]HamsterYAMLTemplate, error) {
	var items []HamsterYAMLTemplate
	err := DB.Order("version desc").Find(&items).Error
	return items, err
}

func PublishHamsterYAMLTemplate(body, presentation, warnings string, createdBy int, warningConfirmed bool) (*HamsterYAMLTemplate, error) {
	var published HamsterYAMLTemplate
	err := DB.Transaction(func(tx *gorm.DB) error {
		return publishHamsterYAMLTemplate(tx, &published, body, presentation, warnings, createdBy, warningConfirmed, 0)
	})
	return &published, err
}

func RollbackHamsterYAMLTemplate(version, createdBy int) (*HamsterYAMLTemplate, error) {
	var published HamsterYAMLTemplate
	err := DB.Transaction(func(tx *gorm.DB) error {
		var source HamsterYAMLTemplate
		if err := tx.Where("version = ?", version).First(&source).Error; err != nil {
			return err
		}
		return publishHamsterYAMLTemplate(tx, &published, source.Body, source.PresentationJSON, source.WarningsJSON, createdBy, true, source.Version)
	})
	return &published, err
}

func publishHamsterYAMLTemplate(tx *gorm.DB, published *HamsterYAMLTemplate, body, presentation, warnings string, createdBy int, warningConfirmed bool, rollbackFrom int) error {
	var latest HamsterYAMLTemplate
	err := lockForUpdate(tx).Order("version desc").First(&latest).Error
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	version := 1
	if err == nil {
		version = latest.Version + 1
	}
	if err := tx.Model(&HamsterYAMLTemplate{}).Where("active = ?", true).Update("active", false).Error; err != nil {
		return err
	}
	now := common.GetTimestamp()
	*published = HamsterYAMLTemplate{
		Version: version, Body: strings.TrimSpace(body), PresentationJSON: presentation,
		WarningsJSON: warnings, Active: true, RollbackFrom: rollbackFrom, CreatedBy: createdBy, CreatedTime: now,
	}
	if warningConfirmed {
		published.WarningConfirmedBy = createdBy
		published.WarningConfirmedAt = now
	}
	return tx.Create(published).Error
}
