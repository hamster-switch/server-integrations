package model

import (
	"errors"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/driver/mysql"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

func hamsterMigrationModels() []any {
	return []any{
		&Token{},
		&HamsterConfigSubscription{},
		&HamsterConfigSubscriptionGroup{},
		&HamsterProviderCredential{},
		&HamsterChannelExport{},
		&HamsterYAMLTemplate{},
		&HamsterYAMLTemplateDraft{},
		&HamsterTutorialSnapshot{},
		&HamsterTutorialOverride{},
		&HamsterTutorialImage{},
		&HamsterTutorialRejection{},
	}
}

func setupHamsterSubscriptionTestDB(t *testing.T) {
	t.Helper()
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	require.NoError(t, err)
	previousDB := DB
	previousType := common.MainDatabaseType()
	previousVisibility := common.HamsterManagedTokensVisible
	common.HamsterManagedTokensVisible = false
	DB = db
	t.Cleanup(func() {
		DB = previousDB
		common.HamsterManagedTokensVisible = previousVisibility
		common.SetMainDatabaseType(previousType)
		initCol()
	})
	sqlDB, err := DB.DB()
	require.NoError(t, err)
	sqlDB.SetMaxOpenConns(1)
	common.SetMainDatabaseType(common.DatabaseTypeSQLite)
	initCol()
	require.NoError(t, DB.AutoMigrate(
		&Token{},
		&HamsterConfigSubscription{},
		&HamsterConfigSubscriptionGroup{},
		&HamsterProviderCredential{},
		&HamsterChannelExport{},
	))
}

func TestHamsterSubscriptionLifecyclePreservesStableBindings(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{
		Name: "Initial", Groups: []string{"vip", "default"},
	})
	require.NoError(t, err)
	require.Len(t, created.Groups, 2)
	originalPublicID := created.PublicID
	originalDownloadToken := created.DownloadToken

	var retained HamsterConfigSubscriptionGroup
	var removed HamsterConfigSubscriptionGroup
	for _, group := range created.Groups {
		if group.GroupName == "default" {
			retained = group
		} else {
			removed = group
		}
	}
	require.NotZero(t, retained.ID)
	require.NotZero(t, removed.ID)
	require.NoError(t, DB.Create(&HamsterProviderCredential{
		GroupID: removed.ID, ChannelID: 17, AccessKey: "hspRemoved", Status: HamsterProviderCredentialActive,
		CreatedTime: common.GetTimestamp(), UpdatedTime: common.GetTimestamp(),
	}).Error)

	updated, err := UpdateHamsterConfigSubscription(42, created.PublicID, HamsterSubscriptionInput{
		Name: "Updated", Groups: []string{"default", "pro"},
	})
	require.NoError(t, err)
	assert.Equal(t, originalPublicID, updated.PublicID)
	assert.Equal(t, originalDownloadToken, updated.DownloadToken)
	require.Len(t, updated.Groups, 2)

	var retainedAfter HamsterConfigSubscriptionGroup
	for _, group := range updated.Groups {
		if group.GroupName == "default" {
			retainedAfter = group
		}
	}
	assert.Equal(t, retained.ID, retainedAfter.ID)
	assert.Equal(t, retained.BindingID, retainedAfter.BindingID)
	assert.Equal(t, retained.TokenID, retainedAfter.TokenID)

	var removedToken Token
	assert.ErrorIs(t, DB.First(&removedToken, removed.TokenID).Error, gorm.ErrRecordNotFound)
	var removedCredential HamsterProviderCredential
	assert.ErrorIs(t, DB.Where("access_key = ?", "hspRemoved").First(&removedCredential).Error, gorm.ErrRecordNotFound)

	var managedCount int64
	require.NoError(t, DB.Model(&Token{}).Where("user_id = ? AND hamster_managed = ?", 42, true).Count(&managedCount).Error)
	assert.EqualValues(t, 2, managedCount)
	for _, group := range updated.Groups {
		var token Token
		require.NoError(t, DB.First(&token, group.TokenID).Error)
		assert.True(t, token.HamsterManaged)
		assert.True(t, token.UnlimitedQuota)
		assert.Equal(t, group.GroupName, token.Group)
	}
}

func TestHamsterSubscriptionDisableAndDeleteRevokeManagedResources(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "Private", Groups: []string{"default"}})
	require.NoError(t, err)
	require.Len(t, created.Groups, 1)
	group := created.Groups[0]
	require.NoError(t, DB.Create(&HamsterProviderCredential{
		GroupID: group.ID, ChannelID: 11, AccessKey: "hspActive", Status: HamsterProviderCredentialActive,
		CreatedTime: common.GetTimestamp(), UpdatedTime: common.GetTimestamp(),
	}).Error)

	disabled, err := SetHamsterConfigSubscriptionEnabled(42, created.PublicID, false)
	require.NoError(t, err)
	assert.Equal(t, HamsterSubscriptionDisabled, disabled.Status)
	var token Token
	require.NoError(t, DB.First(&token, group.TokenID).Error)
	assert.Equal(t, common.TokenStatusDisabled, token.Status)
	var credential HamsterProviderCredential
	require.NoError(t, DB.Where("access_key = ?", "hspActive").First(&credential).Error)
	assert.Equal(t, HamsterProviderCredentialDisabled, credential.Status)

	enabled, err := SetHamsterConfigSubscriptionEnabled(42, created.PublicID, true)
	require.NoError(t, err)
	assert.Equal(t, created.DownloadToken, enabled.DownloadToken)
	require.NoError(t, DB.First(&token, group.TokenID).Error)
	assert.Equal(t, common.TokenStatusEnabled, token.Status)
	require.NoError(t, DB.Where("access_key = ?", "hspActive").First(&credential).Error)
	assert.Equal(t, HamsterProviderCredentialActive, credential.Status)

	require.NoError(t, DeleteHamsterConfigSubscription(42, created.PublicID))
	_, err = GetHamsterConfigSubscriptionByDownloadToken(created.DownloadToken)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
	assert.ErrorIs(t, DB.First(&token, group.TokenID).Error, gorm.ErrRecordNotFound)
	assert.ErrorIs(t, DB.Where("access_key = ?", "hspActive").First(&credential).Error, gorm.ErrRecordNotFound)
}

func TestHamsterProviderCredentialResolvesOnlyWhileSubscriptionIsActive(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "Bound", Groups: []string{"default"}})
	require.NoError(t, err)
	credential, err := GetOrCreateHamsterProviderCredential(created.Groups[0].ID, 17)
	require.NoError(t, err)
	assert.Contains(t, credential.AccessKey, "hsp")

	sameCredential, err := GetOrCreateHamsterProviderCredential(created.Groups[0].ID, 17)
	require.NoError(t, err)
	assert.Equal(t, credential.ID, sameCredential.ID)
	assert.Equal(t, credential.AccessKey, sameCredential.AccessKey)

	access, err := ResolveHamsterProviderCredential("sk-" + credential.AccessKey)
	require.NoError(t, err)
	assert.Equal(t, 17, access.Credential.ChannelID)
	assert.Equal(t, "default", access.Group.GroupName)
	assert.Equal(t, created.Groups[0].TokenID, access.Token.Id)
	assert.True(t, access.Token.HamsterManaged)

	_, err = SetHamsterConfigSubscriptionEnabled(42, created.PublicID, false)
	require.NoError(t, err)
	_, err = ResolveHamsterProviderCredential(credential.AccessKey)
	assert.ErrorIs(t, err, ErrHamsterProviderCredentialInvalid)
}

func TestHamsterManagedTokensAreHiddenFromUserTokenQueries(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	require.NoError(t, DB.Create(&Token{UserId: 42, Key: "ordinary", Name: "ordinary", Status: common.TokenStatusEnabled}).Error)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "Hidden", Groups: []string{"default"}})
	require.NoError(t, err)

	tokens, err := GetAllUserTokens(42, 0, 20)
	require.NoError(t, err)
	require.Len(t, tokens, 1)
	assert.Equal(t, "ordinary", tokens[0].Key)

	_, err = GetTokenByIds(created.Groups[0].TokenID, 42)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
	visible, err := GetTokenByIds(tokens[0].Id, 42)
	require.NoError(t, err)
	assert.Equal(t, "ordinary", visible.Key)

	count, err := CountUserTokens(42)
	require.NoError(t, err)
	assert.EqualValues(t, 1, count)
	common.HamsterManagedTokensVisible = true
	visibleTokens, err := GetAllUserTokens(42, 0, 20)
	require.NoError(t, err)
	require.Len(t, visibleTokens, 2)
	count, err = CountUserTokens(42)
	require.NoError(t, err)
	assert.EqualValues(t, 2, count)
	_, err = GetTokenByIds(created.Groups[0].TokenID, 42)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
	keys, err := GetTokenKeysByIds([]int{tokens[0].Id, created.Groups[0].TokenID}, 42)
	require.NoError(t, err)
	require.Len(t, keys, 1)
	assert.Equal(t, "ordinary", keys[0].Key)
	deleted, err := BatchDeleteTokens([]int{created.Groups[0].TokenID}, 42)
	require.NoError(t, err)
	assert.Zero(t, deleted)
	var managed Token
	require.NoError(t, DB.First(&managed, created.Groups[0].TokenID).Error)
	assert.True(t, managed.HamsterManaged)
	assert.ErrorIs(t, DeleteTokenById(created.Groups[0].TokenID, 42), gorm.ErrRecordNotFound)
}

func TestHamsterSubscriptionOwnershipIsEnforced(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{Name: "Private", Groups: []string{"default"}})
	require.NoError(t, err)
	_, err = GetHamsterConfigSubscription(7, created.PublicID)
	assert.ErrorIs(t, err, gorm.ErrRecordNotFound)
	assert.ErrorIs(t, DeleteHamsterConfigSubscription(7, created.PublicID), gorm.ErrRecordNotFound)
}

func TestHamsterChannelAppsDefaultOverrideAndReset(t *testing.T) {
	setupHamsterSubscriptionTestDB(t)
	apps, err := GetHamsterChannelApps(17)
	require.NoError(t, err)
	assert.Equal(t, DefaultHamsterChannelApps, apps)

	apps, err = SetHamsterChannelApps(17, 1, []string{"gemini", "claude", "gemini"})
	require.NoError(t, err)
	assert.Equal(t, []string{"claude", "gemini"}, apps)
	stored, err := GetHamsterChannelApps(17)
	require.NoError(t, err)
	assert.Equal(t, apps, stored)

	_, err = SetHamsterChannelApps(17, 1, nil)
	assert.Error(t, err)
	_, err = SetHamsterChannelApps(17, 1, []string{"unknown"})
	assert.Error(t, err)

	require.NoError(t, ResetHamsterChannelApps(17))
	reset, err := GetHamsterChannelApps(17)
	require.NoError(t, err)
	assert.Equal(t, DefaultHamsterChannelApps, reset)
}

func TestHamsterMigrationConfiguredDatabases(t *testing.T) {
	tests := []struct {
		name      string
		env       string
		dbType    common.DatabaseType
		dialector func(string) gorm.Dialector
	}{
		{
			name:   "mysql",
			env:    "TEST_MYSQL_DSN",
			dbType: common.DatabaseTypeMySQL,
			dialector: func(dsn string) gorm.Dialector {
				return mysql.Open(dsn)
			},
		},
		{
			name:   "postgres",
			env:    "TEST_POSTGRES_DSN",
			dbType: common.DatabaseTypePostgreSQL,
			dialector: func(dsn string) gorm.Dialector {
				return postgres.New(postgres.Config{DSN: dsn, PreferSimpleProtocol: true})
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			dsn := strings.TrimSpace(os.Getenv(test.env))
			if dsn == "" {
				t.Skip(test.env + " is not configured")
			}

			prefix := "hsit_" + strconv.FormatInt(time.Now().UnixNano(), 36) + "_"
			db, err := gorm.Open(test.dialector(dsn), &gorm.Config{
				NamingStrategy: schema.NamingStrategy{TablePrefix: prefix},
			})
			require.NoError(t, err)
			sqlDB, err := db.DB()
			require.NoError(t, err)
			t.Cleanup(func() { _ = sqlDB.Close() })

			models := hamsterMigrationModels()
			require.NoError(t, db.AutoMigrate(models...))
			t.Cleanup(func() {
				for index := len(models) - 1; index >= 0; index-- {
					_ = db.Migrator().DropTable(models[index])
				}
			})

			for _, model := range models {
				assert.True(t, db.Migrator().HasTable(model))
			}
			assert.True(t, db.Migrator().HasIndex(&HamsterConfigSubscriptionGroup{}, "idx_hamster_subscription_group"))
			assert.True(t, db.Migrator().HasIndex(&HamsterProviderCredential{}, "idx_hamster_group_channel"))

			previousDB := DB
			previousType := common.MainDatabaseType()
			DB = db
			common.SetMainDatabaseType(test.dbType)
			initCol()
			t.Cleanup(func() {
				DB = previousDB
				common.SetMainDatabaseType(previousType)
				initCol()
			})

			created, err := CreateHamsterConfigSubscription(42, HamsterSubscriptionInput{
				Name:   "Database contract",
				Groups: []string{"default"},
			})
			require.NoError(t, err)
			require.Len(t, created.Groups, 1)

			duplicatePublicID := HamsterConfigSubscription{
				PublicID:      created.PublicID,
				DownloadToken: "download-duplicate-public-id",
				UserID:        42,
				Name:          "Duplicate public ID",
				Status:        HamsterSubscriptionActive,
				CreatedTime:   common.GetTimestamp(),
				UpdatedTime:   common.GetTimestamp(),
			}
			assert.Error(t, db.Create(&duplicatePublicID).Error)

			duplicateGroup := HamsterConfigSubscriptionGroup{
				SubscriptionID: created.ID,
				BindingID:      "binding-duplicate-composite",
				GroupName:      created.Groups[0].GroupName,
				TokenID:        created.Groups[0].TokenID + 1000,
				CreatedTime:    common.GetTimestamp(),
				UpdatedTime:    common.GetTimestamp(),
			}
			assert.Error(t, db.Create(&duplicateGroup).Error)

			credential, err := GetOrCreateHamsterProviderCredential(created.Groups[0].ID, 17)
			require.NoError(t, err)
			duplicateCredential := HamsterProviderCredential{
				GroupID:     credential.GroupID,
				ChannelID:   credential.ChannelID,
				AccessKey:   "hspDuplicateComposite",
				Status:      HamsterProviderCredentialActive,
				CreatedTime: common.GetTimestamp(),
				UpdatedTime: common.GetTimestamp(),
			}
			assert.Error(t, db.Create(&duplicateCredential).Error)

			require.NoError(t, db.Delete(&created).Error)
			var visibleCount int64
			require.NoError(t, db.Model(&HamsterConfigSubscription{}).Where("id = ?", created.ID).Count(&visibleCount).Error)
			assert.Zero(t, visibleCount)
			require.NoError(t, db.Unscoped().Model(&HamsterConfigSubscription{}).Where("id = ?", created.ID).Count(&visibleCount).Error)
			assert.EqualValues(t, 1, visibleCount)

			rollbackPublicID := "rollback-" + strconv.FormatInt(time.Now().UnixNano(), 36)
			err = db.Transaction(func(tx *gorm.DB) error {
				if err := tx.Create(&HamsterConfigSubscription{
					PublicID:      rollbackPublicID,
					DownloadToken: rollbackPublicID + "-download",
					UserID:        42,
					Name:          "Rollback",
					Status:        HamsterSubscriptionActive,
					CreatedTime:   common.GetTimestamp(),
					UpdatedTime:   common.GetTimestamp(),
				}).Error; err != nil {
					return err
				}
				return errors.New("force rollback")
			})
			require.EqualError(t, err, "force rollback")
			require.NoError(t, db.Unscoped().Model(&HamsterConfigSubscription{}).Where("public_id = ?", rollbackPublicID).Count(&visibleCount).Error)
			assert.Zero(t, visibleCount)
		})
	}
}
