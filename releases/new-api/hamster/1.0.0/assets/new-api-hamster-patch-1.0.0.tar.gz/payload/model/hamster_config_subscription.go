package model

import (
	"errors"
	"fmt"
	"sort"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/bytedance/gopkg/util/gopool"
	"gorm.io/gorm"
)

const (
	HamsterSubscriptionActive   = "active"
	HamsterSubscriptionDisabled = "disabled"

	HamsterProviderCredentialActive   = "active"
	HamsterProviderCredentialDisabled = "disabled"
)

var DefaultHamsterChannelApps = []string{"claude", "claude-desktop", "codex", "gemini"}

var ErrHamsterProviderCredentialInvalid = errors.New("invalid Hamster provider credential")

type HamsterConfigSubscription struct {
	ID            uint                             `json:"id"`
	PublicID      string                           `json:"public_id" gorm:"type:varchar(64);uniqueIndex;not null"`
	DownloadToken string                           `json:"-" gorm:"type:varchar(128);uniqueIndex;not null"`
	UserID        int                              `json:"user_id" gorm:"index;not null"`
	Name          string                           `json:"name" gorm:"type:varchar(128);not null"`
	Status        string                           `json:"status" gorm:"type:varchar(16);index;not null"`
	CreatedTime   int64                            `json:"created_time" gorm:"bigint;not null"`
	UpdatedTime   int64                            `json:"updated_time" gorm:"bigint;not null"`
	Groups        []HamsterConfigSubscriptionGroup `json:"groups,omitempty" gorm:"foreignKey:SubscriptionID"`
	DeletedAt     gorm.DeletedAt                   `json:"-" gorm:"index"`
}

type HamsterConfigSubscriptionGroup struct {
	ID             uint           `json:"id"`
	SubscriptionID uint           `json:"subscription_id" gorm:"uniqueIndex:idx_hamster_subscription_group;index;not null"`
	BindingID      string         `json:"binding_id" gorm:"type:varchar(64);uniqueIndex;not null"`
	GroupName      string         `json:"group_name" gorm:"type:varchar(64);uniqueIndex:idx_hamster_subscription_group;not null"`
	TokenID        int            `json:"-" gorm:"uniqueIndex;not null"`
	Position       int            `json:"position" gorm:"not null"`
	CreatedTime    int64          `json:"created_time" gorm:"bigint;not null"`
	UpdatedTime    int64          `json:"updated_time" gorm:"bigint;not null"`
	DeletedAt      gorm.DeletedAt `json:"-" gorm:"index"`
}

type HamsterProviderCredential struct {
	ID          uint           `json:"id"`
	GroupID     uint           `json:"group_id" gorm:"uniqueIndex:idx_hamster_group_channel;index;not null"`
	ChannelID   int            `json:"channel_id" gorm:"uniqueIndex:idx_hamster_group_channel;index;not null"`
	AccessKey   string         `json:"-" gorm:"type:varchar(128);uniqueIndex;not null"`
	Status      string         `json:"status" gorm:"type:varchar(16);index;not null"`
	CreatedTime int64          `json:"created_time" gorm:"bigint;not null"`
	UpdatedTime int64          `json:"updated_time" gorm:"bigint;not null"`
	DeletedAt   gorm.DeletedAt `json:"-" gorm:"index"`
}

type HamsterChannelExport struct {
	ChannelID   int    `json:"channel_id" gorm:"primaryKey;autoIncrement:false"`
	AppsJSON    string `json:"-" gorm:"column:apps;type:text;not null"`
	UpdatedBy   int    `json:"updated_by"`
	UpdatedTime int64  `json:"updated_time" gorm:"bigint;not null"`
}

type HamsterSubscriptionInput struct {
	Name   string
	Groups []string
}

type HamsterProviderAccess struct {
	Credential   HamsterProviderCredential
	Subscription HamsterConfigSubscription
	Group        HamsterConfigSubscriptionGroup
	Token        Token
}

func normalizeHamsterGroups(groups []string) ([]string, error) {
	seen := make(map[string]struct{}, len(groups))
	result := make([]string, 0, len(groups))
	for _, value := range groups {
		group := strings.TrimSpace(value)
		if group == "" || group == "auto" {
			continue
		}
		if len(group) > 64 {
			return nil, errors.New("group name cannot exceed 64 characters")
		}
		if _, ok := seen[group]; ok {
			continue
		}
		seen[group] = struct{}{}
		result = append(result, group)
	}
	if len(result) == 0 {
		return nil, errors.New("at least one group is required")
	}
	sort.Strings(result)
	return result, nil
}

func NormalizeHamsterChannelApps(apps []string) ([]string, error) {
	allowed := map[string]int{
		"claude": 0, "claude-desktop": 1, "codex": 2, "gemini": 3,
	}
	seen := make(map[string]struct{}, len(apps))
	result := make([]string, 0, len(apps))
	for _, value := range apps {
		app := strings.ToLower(strings.TrimSpace(value))
		if _, ok := allowed[app]; !ok {
			return nil, fmt.Errorf("unsupported Hamster application %q", value)
		}
		if _, ok := seen[app]; ok {
			continue
		}
		seen[app] = struct{}{}
		result = append(result, app)
	}
	if len(result) == 0 {
		return nil, errors.New("at least one Hamster application is required")
	}
	sort.Slice(result, func(i, j int) bool {
		return allowed[result[i]] < allowed[result[j]]
	})
	return result, nil
}

func GetHamsterChannelApps(channelID int) ([]string, error) {
	var export HamsterChannelExport
	err := DB.First(&export, "channel_id = ?", channelID).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return append([]string(nil), DefaultHamsterChannelApps...), nil
	}
	if err != nil {
		return nil, err
	}
	var apps []string
	if err := common.Unmarshal([]byte(export.AppsJSON), &apps); err != nil {
		return nil, fmt.Errorf("decode Hamster channel apps: %w", err)
	}
	return NormalizeHamsterChannelApps(apps)
}

func SetHamsterChannelApps(channelID, updatedBy int, apps []string) ([]string, error) {
	if channelID <= 0 {
		return nil, errors.New("channel id must be positive")
	}
	normalized, err := NormalizeHamsterChannelApps(apps)
	if err != nil {
		return nil, err
	}
	encoded, err := common.Marshal(normalized)
	if err != nil {
		return nil, err
	}
	now := common.GetTimestamp()
	var export HamsterChannelExport
	err = DB.First(&export, "channel_id = ?", channelID).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		export = HamsterChannelExport{
			ChannelID: channelID, AppsJSON: string(encoded), UpdatedBy: updatedBy, UpdatedTime: now,
		}
		err = DB.Create(&export).Error
	} else if err == nil {
		err = DB.Model(&export).Updates(map[string]any{
			"apps": string(encoded), "updated_by": updatedBy, "updated_time": now,
		}).Error
	}
	if err != nil {
		return nil, err
	}
	return normalized, nil
}

func ResetHamsterChannelApps(channelID int) error {
	return DB.Delete(&HamsterChannelExport{}, "channel_id = ?", channelID).Error
}

func validateHamsterSubscriptionInput(input HamsterSubscriptionInput) (string, []string, error) {
	name := strings.TrimSpace(input.Name)
	if name == "" {
		return "", nil, errors.New("subscription name is required")
	}
	if len(name) > 128 {
		return "", nil, errors.New("subscription name cannot exceed 128 characters")
	}
	groups, err := normalizeHamsterGroups(input.Groups)
	return name, groups, err
}

func newHamsterDedicatedToken(userID int, subscriptionName, group string, status int) (*Token, error) {
	key, err := common.GenerateKey()
	if err != nil {
		return nil, err
	}
	return &Token{
		UserId: userID, Key: key, Status: status,
		Name: fmt.Sprintf("%s - %s", subscriptionName, group), CreatedTime: common.GetTimestamp(),
		ExpiredTime: -1, UnlimitedQuota: true, Group: group, HamsterManaged: true,
	}, nil
}

func CreateHamsterConfigSubscription(userID int, input HamsterSubscriptionInput) (*HamsterConfigSubscription, error) {
	name, groups, err := validateHamsterSubscriptionInput(input)
	if err != nil {
		return nil, err
	}
	publicID, err := common.GenerateRandomCharsKey(32)
	if err != nil {
		return nil, err
	}
	downloadToken, err := common.GenerateRandomCharsKey(64)
	if err != nil {
		return nil, err
	}
	now := common.GetTimestamp()
	subscription := &HamsterConfigSubscription{
		PublicID: publicID, DownloadToken: downloadToken, UserID: userID,
		Name: name, Status: HamsterSubscriptionActive, CreatedTime: now, UpdatedTime: now,
	}
	err = DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(subscription).Error; err != nil {
			return err
		}
		for position, group := range groups {
			bindingID, err := common.GenerateRandomCharsKey(24)
			if err != nil {
				return err
			}
			token, err := newHamsterDedicatedToken(userID, name, group, common.TokenStatusEnabled)
			if err != nil {
				return err
			}
			if err := tx.Create(token).Error; err != nil {
				return err
			}
			binding := HamsterConfigSubscriptionGroup{
				SubscriptionID: subscription.ID, BindingID: bindingID, GroupName: group,
				TokenID: token.Id, Position: position, CreatedTime: now, UpdatedTime: now,
			}
			if err := tx.Create(&binding).Error; err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return GetHamsterConfigSubscription(userID, subscription.PublicID)
}

func ListHamsterConfigSubscriptions(userID, offset, limit int, search string) ([]HamsterConfigSubscription, int64, error) {
	if offset < 0 {
		offset = 0
	}
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	query := DB.Model(&HamsterConfigSubscription{}).Where("user_id = ?", userID)
	if search = strings.TrimSpace(search); search != "" {
		pattern := strings.NewReplacer("!", "!!", "%", "!%", "_", "!_").Replace(search)
		query = query.Where("name LIKE ? ESCAPE '!'", "%"+pattern+"%")
	}
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	var items []HamsterConfigSubscription
	err := query.Preload("Groups", func(db *gorm.DB) *gorm.DB {
		return db.Order("position asc")
	}).Order("id desc").Offset(offset).Limit(limit).Find(&items).Error
	return items, total, err
}

func GetHamsterConfigSubscription(userID int, publicID string) (*HamsterConfigSubscription, error) {
	var item HamsterConfigSubscription
	err := DB.Preload("Groups", func(db *gorm.DB) *gorm.DB {
		return db.Order("position asc")
	}).Where("user_id = ? AND public_id = ?", userID, strings.TrimSpace(publicID)).First(&item).Error
	return &item, err
}

func GetHamsterConfigSubscriptionByPublicID(publicID string) (*HamsterConfigSubscription, error) {
	var item HamsterConfigSubscription
	err := DB.Preload("Groups", func(db *gorm.DB) *gorm.DB {
		return db.Order("position asc")
	}).Where("public_id = ?", strings.TrimSpace(publicID)).First(&item).Error
	return &item, err
}

func GetHamsterConfigSubscriptionByDownloadToken(downloadToken string) (*HamsterConfigSubscription, error) {
	var item HamsterConfigSubscription
	err := DB.Preload("Groups", func(db *gorm.DB) *gorm.DB {
		return db.Order("position asc")
	}).Where("download_token = ?", strings.TrimSpace(downloadToken)).First(&item).Error
	return &item, err
}

func GetHamsterSubscriptionTokens(item *HamsterConfigSubscription) (map[int]*Token, error) {
	ids := make([]int, 0, len(item.Groups))
	for _, group := range item.Groups {
		ids = append(ids, group.TokenID)
	}
	var tokens []*Token
	if len(ids) > 0 {
		if err := DB.Where("id IN ?", ids).Find(&tokens).Error; err != nil {
			return nil, err
		}
	}
	result := make(map[int]*Token, len(tokens))
	for _, token := range tokens {
		result[token.Id] = token
	}
	return result, nil
}

func GetOrCreateHamsterProviderCredential(groupID uint, channelID int) (*HamsterProviderCredential, error) {
	if groupID == 0 || channelID <= 0 {
		return nil, ErrHamsterProviderCredentialInvalid
	}
	var group HamsterConfigSubscriptionGroup
	if err := DB.First(&group, groupID).Error; err != nil {
		return nil, err
	}
	var subscription HamsterConfigSubscription
	if err := DB.Where("id = ? AND status = ?", group.SubscriptionID, HamsterSubscriptionActive).First(&subscription).Error; err != nil {
		return nil, err
	}
	var credential HamsterProviderCredential
	err := DB.Where("group_id = ? AND channel_id = ?", groupID, channelID).First(&credential).Error
	if err == nil {
		if credential.Status != HamsterProviderCredentialActive {
			credential.Status = HamsterProviderCredentialActive
			credential.UpdatedTime = common.GetTimestamp()
			if err := DB.Model(&credential).Updates(map[string]any{
				"status": credential.Status, "updated_time": credential.UpdatedTime,
			}).Error; err != nil {
				return nil, err
			}
		}
		return &credential, nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}
	key, err := common.GenerateRandomCharsKey(48)
	if err != nil {
		return nil, err
	}
	now := common.GetTimestamp()
	credential = HamsterProviderCredential{
		GroupID: groupID, ChannelID: channelID, AccessKey: "hsp" + key,
		Status: HamsterProviderCredentialActive, CreatedTime: now, UpdatedTime: now,
	}
	if err := DB.Create(&credential).Error; err == nil {
		return &credential, nil
	} else {
		createErr := err
		if err := DB.Where("group_id = ? AND channel_id = ?", groupID, channelID).First(&credential).Error; err != nil {
			return nil, createErr
		}
		return &credential, nil
	}
}

func ResolveHamsterProviderCredential(accessKey string) (*HamsterProviderAccess, error) {
	accessKey = strings.TrimSpace(strings.TrimPrefix(accessKey, "sk-"))
	if !strings.HasPrefix(accessKey, "hsp") {
		return nil, ErrHamsterProviderCredentialInvalid
	}
	var credential HamsterProviderCredential
	if err := DB.Where("access_key = ? AND status = ?", accessKey, HamsterProviderCredentialActive).First(&credential).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrHamsterProviderCredentialInvalid
		}
		return nil, fmt.Errorf("%w: %v", ErrDatabase, err)
	}
	var group HamsterConfigSubscriptionGroup
	if err := DB.First(&group, credential.GroupID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrHamsterProviderCredentialInvalid
		}
		return nil, fmt.Errorf("%w: %v", ErrDatabase, err)
	}
	var subscription HamsterConfigSubscription
	if err := DB.Where("id = ? AND status = ?", group.SubscriptionID, HamsterSubscriptionActive).First(&subscription).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrHamsterProviderCredentialInvalid
		}
		return nil, fmt.Errorf("%w: %v", ErrDatabase, err)
	}
	var token Token
	if err := DB.Where("id = ? AND user_id = ? AND hamster_managed = ?", group.TokenID, subscription.UserID, true).First(&token).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrHamsterProviderCredentialInvalid
		}
		return nil, fmt.Errorf("%w: %v", ErrDatabase, err)
	}
	if token.Status != common.TokenStatusEnabled ||
		(token.ExpiredTime != -1 && token.ExpiredTime < common.GetTimestamp()) ||
		(!token.UnlimitedQuota && token.RemainQuota <= 0) {
		return nil, ErrHamsterProviderCredentialInvalid
	}
	return &HamsterProviderAccess{
		Credential: credential, Subscription: subscription, Group: group, Token: token,
	}, nil
}

func UpdateHamsterConfigSubscription(userID int, publicID string, input HamsterSubscriptionInput) (*HamsterConfigSubscription, error) {
	name, groups, err := validateHamsterSubscriptionInput(input)
	if err != nil {
		return nil, err
	}
	var invalidated []string
	err = DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Groups").Where("user_id = ? AND public_id = ?", userID, strings.TrimSpace(publicID)).First(&item).Error; err != nil {
			return err
		}
		now := common.GetTimestamp()
		tokenStatus := common.TokenStatusEnabled
		credentialStatus := HamsterProviderCredentialActive
		if item.Status == HamsterSubscriptionDisabled {
			tokenStatus = common.TokenStatusDisabled
			credentialStatus = HamsterProviderCredentialDisabled
		}
		existing := make(map[string]HamsterConfigSubscriptionGroup, len(item.Groups))
		for _, group := range item.Groups {
			existing[group.GroupName] = group
		}
		wanted := make(map[string]struct{}, len(groups))
		for position, groupName := range groups {
			wanted[groupName] = struct{}{}
			if group, ok := existing[groupName]; ok {
				if err := tx.Model(&group).Updates(map[string]any{"position": position, "updated_time": now}).Error; err != nil {
					return err
				}
				if err := tx.Model(&Token{}).Where("id = ? AND user_id = ? AND hamster_managed = ?", group.TokenID, userID, true).
					Updates(map[string]any{"name": fmt.Sprintf("%s - %s", name, groupName), "status": tokenStatus}).Error; err != nil {
					return err
				}
				if err := tx.Model(&HamsterProviderCredential{}).Where("group_id = ?", group.ID).
					Updates(map[string]any{"status": credentialStatus, "updated_time": now}).Error; err != nil {
					return err
				}
				continue
			}
			bindingID, err := common.GenerateRandomCharsKey(24)
			if err != nil {
				return err
			}
			token, err := newHamsterDedicatedToken(userID, name, groupName, tokenStatus)
			if err != nil {
				return err
			}
			if err := tx.Create(token).Error; err != nil {
				return err
			}
			group := HamsterConfigSubscriptionGroup{
				SubscriptionID: item.ID, BindingID: bindingID, GroupName: groupName,
				TokenID: token.Id, Position: position, CreatedTime: now, UpdatedTime: now,
			}
			if err := tx.Create(&group).Error; err != nil {
				return err
			}
		}
		for groupName, group := range existing {
			if _, ok := wanted[groupName]; ok {
				continue
			}
			var token Token
			if err := tx.Unscoped().First(&token, group.TokenID).Error; err == nil {
				invalidated = append(invalidated, token.Key)
			}
			if err := tx.Where("group_id = ?", group.ID).Delete(&HamsterProviderCredential{}).Error; err != nil {
				return err
			}
			if err := tx.Where("id = ? AND user_id = ? AND hamster_managed = ?", group.TokenID, userID, true).Delete(&Token{}).Error; err != nil {
				return err
			}
			if err := tx.Delete(&group).Error; err != nil {
				return err
			}
		}
		return tx.Model(&HamsterConfigSubscription{}).Where("id = ?", item.ID).
			Updates(map[string]any{"name": name, "updated_time": now}).Error
	})
	if err != nil {
		return nil, err
	}
	invalidateHamsterTokenKeys(invalidated)
	return GetHamsterConfigSubscription(userID, publicID)
}

func SetHamsterConfigSubscriptionEnabled(userID int, publicID string, enabled bool) (*HamsterConfigSubscription, error) {
	status := HamsterSubscriptionDisabled
	tokenStatus := common.TokenStatusDisabled
	credentialStatus := HamsterProviderCredentialDisabled
	if enabled {
		status = HamsterSubscriptionActive
		tokenStatus = common.TokenStatusEnabled
		credentialStatus = HamsterProviderCredentialActive
	}
	var keys []string
	err := DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Groups").Where("user_id = ? AND public_id = ?", userID, strings.TrimSpace(publicID)).First(&item).Error; err != nil {
			return err
		}
		ids := make([]int, 0, len(item.Groups))
		groupIDs := make([]uint, 0, len(item.Groups))
		for _, group := range item.Groups {
			ids = append(ids, group.TokenID)
			groupIDs = append(groupIDs, group.ID)
		}
		if len(ids) > 0 {
			var tokens []Token
			if err := tx.Where("id IN ? AND hamster_managed = ?", ids, true).Find(&tokens).Error; err != nil {
				return err
			}
			for _, token := range tokens {
				keys = append(keys, token.Key)
			}
			if err := tx.Model(&Token{}).Where("id IN ? AND hamster_managed = ?", ids, true).Update("status", tokenStatus).Error; err != nil {
				return err
			}
			if err := tx.Model(&HamsterProviderCredential{}).Where("group_id IN ?", groupIDs).
				Updates(map[string]any{"status": credentialStatus, "updated_time": common.GetTimestamp()}).Error; err != nil {
				return err
			}
		}
		return tx.Model(&HamsterConfigSubscription{}).Where("id = ?", item.ID).
			Updates(map[string]any{"status": status, "updated_time": common.GetTimestamp()}).Error
	})
	if err != nil {
		return nil, err
	}
	invalidateHamsterTokenKeys(keys)
	return GetHamsterConfigSubscription(userID, publicID)
}

func DeleteHamsterConfigSubscription(userID int, publicID string) error {
	var keys []string
	err := DB.Transaction(func(tx *gorm.DB) error {
		var item HamsterConfigSubscription
		if err := tx.Preload("Groups").Where("user_id = ? AND public_id = ?", userID, strings.TrimSpace(publicID)).First(&item).Error; err != nil {
			return err
		}
		tokenIDs := make([]int, 0, len(item.Groups))
		groupIDs := make([]uint, 0, len(item.Groups))
		for _, group := range item.Groups {
			tokenIDs = append(tokenIDs, group.TokenID)
			groupIDs = append(groupIDs, group.ID)
		}
		if len(tokenIDs) > 0 {
			var tokens []Token
			if err := tx.Where("id IN ? AND hamster_managed = ?", tokenIDs, true).Find(&tokens).Error; err != nil {
				return err
			}
			for _, token := range tokens {
				keys = append(keys, token.Key)
			}
			if err := tx.Where("group_id IN ?", groupIDs).Delete(&HamsterProviderCredential{}).Error; err != nil {
				return err
			}
			if err := tx.Where("id IN ? AND hamster_managed = ?", tokenIDs, true).Delete(&Token{}).Error; err != nil {
				return err
			}
			if err := tx.Where("id IN ?", groupIDs).Delete(&HamsterConfigSubscriptionGroup{}).Error; err != nil {
				return err
			}
		}
		return tx.Delete(&item).Error
	})
	if err == nil {
		invalidateHamsterTokenKeys(keys)
	}
	return err
}

func invalidateHamsterTokenKeys(keys []string) {
	if !common.RedisEnabled {
		return
	}
	for _, key := range keys {
		key := key
		gopool.Go(func() {
			if err := cacheDeleteToken(key); err != nil {
				common.SysLog("failed to invalidate Hamster subscription token: " + err.Error())
			}
		})
	}
}
