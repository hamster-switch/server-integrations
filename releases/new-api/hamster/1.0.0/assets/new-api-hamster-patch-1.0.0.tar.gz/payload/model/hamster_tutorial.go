package model

type HamsterTutorialSnapshot struct {
	ID          uint   `json:"id"`
	Version     string `json:"version" gorm:"type:varchar(64);uniqueIndex;not null"`
	Body        string `json:"body" gorm:"type:text;not null"`
	Active      bool   `json:"active" gorm:"index;not null"`
	CreatedBy   int    `json:"created_by"`
	CreatedTime int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterTutorialOverride struct {
	ID          uint   `json:"id"`
	StepID      string `json:"step_id" gorm:"type:varchar(96);uniqueIndex;not null"`
	Body        string `json:"body" gorm:"type:text;not null"`
	BaseVersion string `json:"base_version" gorm:"type:varchar(64);not null"`
	UpdatedBy   int    `json:"updated_by"`
	UpdatedTime int64  `json:"updated_time" gorm:"bigint;not null"`
}

type HamsterTutorialImage struct {
	ID          string `json:"id" gorm:"type:varchar(64);primaryKey"`
	LocalName   string `json:"local_name" gorm:"type:varchar(128);not null"`
	MediaType   string `json:"media_type" gorm:"type:varchar(64);not null"`
	SizeBytes   int64  `json:"size_bytes" gorm:"bigint;not null"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	SourceURL   string `json:"source_url" gorm:"type:text"`
	CreatedBy   int    `json:"created_by"`
	CreatedTime int64  `json:"created_time" gorm:"bigint;not null"`
}

type HamsterTutorialRejection struct {
	ID           uint   `json:"id"`
	Version      string `json:"version" gorm:"type:varchar(64);uniqueIndex;not null"`
	RejectedBy   int    `json:"rejected_by"`
	RejectedTime int64  `json:"rejected_time" gorm:"bigint;not null"`
}
