/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Loader2, Plus, Search } from 'lucide-react'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { SectionPageLayout } from '@/components/layout'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ROLE } from '@/lib/roles'
import { useAuthStore } from '@/stores/auth-store'

import {
  createHamsterSubscription,
  deleteHamsterSubscription,
  getHamsterUserGroups,
  listHamsterSubscriptions,
  setHamsterSubscriptionEnabled,
  updateHamsterSubscription,
} from './api'
import { HamsterAdminPanel } from './components/admin-panel'
import { HamsterSubscriptionCard } from './components/subscription-card'
import { HamsterSubscriptionDialog } from './components/subscription-dialog'
import { HamsterTutorialPanel } from './components/tutorial-panel'
import type { HamsterSubscription, HamsterSubscriptionInput } from './types'

function responseError(response: { success: boolean; message: string }) {
  if (!response.success) throw new Error(response.message)
  return response
}

export function HamsterSubscriptions() {
  const { t } = useTranslation()
  const queryClient = useQueryClient()
  const user = useAuthStore((state) => state.auth.user)
  const isAdmin = (user?.role ?? ROLE.GUEST) >= ROLE.ADMIN
  const [search, setSearch] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<HamsterSubscription>()
  const [deleting, setDeleting] = useState<HamsterSubscription>()

  const subscriptionsQuery = useQuery({
    queryKey: ['hamster-subscriptions', search],
    queryFn: () => listHamsterSubscriptions(search),
  })
  const groupsQuery = useQuery({
    queryKey: ['hamster-user-groups'],
    queryFn: getHamsterUserGroups,
  })
  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ['hamster-subscriptions'] })

  const saveMutation = useMutation({
    mutationFn: (input: HamsterSubscriptionInput) => {
      if (editing) return updateHamsterSubscription(editing.public_id, input)
      return createHamsterSubscription(input)
    },
    onSuccess: (response) => {
      responseError(response)
      toast.success(
        editing ? t('Subscription updated') : t('Subscription created')
      )
      setDialogOpen(false)
      setEditing(undefined)
      invalidate()
    },
    onError: (error: Error) => toast.error(error.message),
  })
  const toggleMutation = useMutation({
    mutationFn: (subscription: HamsterSubscription) =>
      setHamsterSubscriptionEnabled(
        subscription.public_id,
        subscription.status !== 'active'
      ),
    onSuccess: (response) => {
      responseError(response)
      toast.success(t('Subscription status updated'))
      invalidate()
    },
    onError: (error: Error) => toast.error(error.message),
  })
  const deleteMutation = useMutation({
    mutationFn: (subscription: HamsterSubscription) =>
      deleteHamsterSubscription(subscription.public_id),
    onSuccess: (response) => {
      responseError(response)
      toast.success(t('Subscription deleted'))
      setDeleting(undefined)
      invalidate()
    },
    onError: (error: Error) => toast.error(error.message),
  })

  const subscriptions = subscriptionsQuery.data?.data?.items ?? []
  const copyUrl = async (subscription: HamsterSubscription) => {
    try {
      await navigator.clipboard.writeText(subscription.download_url)
      toast.success(t('Subscription URL copied'))
    } catch {
      toast.error(t('Failed to copy subscription URL.'))
    }
  }

  const subscriptionsContent = () => {
    if (subscriptionsQuery.isPending) {
      return (
        <div className='text-muted-foreground flex items-center justify-center gap-2 py-20'>
          <Loader2 className='animate-spin' />
          {t('Loading subscriptions...')}
        </div>
      )
    }
    if (subscriptionsQuery.isError || !subscriptionsQuery.data?.success) {
      return (
        <div className='border-destructive/40 text-destructive rounded-lg border p-8 text-center text-sm'>
          {subscriptionsQuery.data?.message ||
            t('Failed to load subscriptions.')}
        </div>
      )
    }
    if (subscriptions.length === 0) {
      return (
        <div className='rounded-xl border border-dashed px-6 py-16 text-center'>
          <h2 className='font-medium'>
            {t('No configuration subscriptions yet')}
          </h2>
          <p className='text-muted-foreground mt-1 text-sm'>
            {search
              ? t('No subscriptions match your search.')
              : t(
                  'Create one to import fixed-channel providers into Hamster Switch.'
                )}
          </p>
        </div>
      )
    }
    return (
      <div className='grid gap-4'>
        {subscriptions.map((subscription) => (
          <HamsterSubscriptionCard
            key={subscription.public_id}
            subscription={subscription}
            busy={toggleMutation.isPending || deleteMutation.isPending}
            onCopy={() => copyUrl(subscription)}
            onEdit={() => {
              setEditing(subscription)
              setDialogOpen(true)
            }}
            onToggle={() => toggleMutation.mutate(subscription)}
            onDelete={() => setDeleting(subscription)}
          />
        ))}
      </div>
    )
  }

  return (
    <>
      <SectionPageLayout>
        <SectionPageLayout.Title>
          {t('Configuration subscriptions')}
        </SectionPageLayout.Title>
        <SectionPageLayout.Actions>
          <Button
            onClick={() => {
              setEditing(undefined)
              setDialogOpen(true)
            }}
          >
            <Plus />
            {t('Create subscription')}
          </Button>
        </SectionPageLayout.Actions>
        <SectionPageLayout.Content>
          <Tabs defaultValue='subscriptions' className='min-h-0 gap-4'>
            <TabsList className='max-w-full flex-wrap justify-start group-data-horizontal/tabs:h-auto'>
              <TabsTrigger value='subscriptions'>
                {t('Subscriptions')}
              </TabsTrigger>
              <TabsTrigger value='tutorial'>{t('Tutorial')}</TabsTrigger>
              {isAdmin ? (
                <TabsTrigger value='admin'>{t('Administration')}</TabsTrigger>
              ) : null}
            </TabsList>
            <TabsContent value='subscriptions' className='space-y-4'>
              <div className='relative max-w-md'>
                <Search className='text-muted-foreground pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2' />
                <Input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder={t('Search configuration subscriptions...')}
                  aria-label={t('Search configuration subscriptions')}
                  className='pl-9'
                />
              </div>
              {subscriptionsContent()}
            </TabsContent>
            <TabsContent value='tutorial'>
              <HamsterTutorialPanel />
            </TabsContent>
            {isAdmin ? (
              <TabsContent value='admin'>
                <HamsterAdminPanel subscriptions={subscriptions} />
              </TabsContent>
            ) : null}
          </Tabs>
        </SectionPageLayout.Content>
      </SectionPageLayout>

      <HamsterSubscriptionDialog
        open={dialogOpen}
        current={editing}
        groups={groupsQuery.data?.data ?? {}}
        submitting={saveMutation.isPending}
        onOpenChange={(open) => {
          setDialogOpen(open)
          if (!open) setEditing(undefined)
        }}
        onSubmit={(input) => saveMutation.mutate(input)}
      />

      <AlertDialog
        open={Boolean(deleting)}
        onOpenChange={(open) => !open && setDeleting(undefined)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {t('Delete configuration subscription?')}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t(
                'This permanently revokes its billing tokens, provider credentials, and stable download URL.'
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('Cancel')}</AlertDialogCancel>
            <AlertDialogAction
              variant='destructive'
              disabled={deleteMutation.isPending}
              onClick={() => deleting && deleteMutation.mutate(deleting)}
            >
              {t('Delete permanently')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
