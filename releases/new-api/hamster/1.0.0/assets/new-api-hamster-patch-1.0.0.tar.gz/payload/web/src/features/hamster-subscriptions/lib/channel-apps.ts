/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

export const DEFAULT_HAMSTER_APPS = [
  'claude',
  'claude-desktop',
  'codex',
  'gemini',
] as const

export function toggleHamsterApp(
  current: string[],
  app: string,
  checked: boolean
): string[] {
  if (checked) {
    return DEFAULT_HAMSTER_APPS.filter(
      (candidate) => candidate === app || current.includes(candidate)
    )
  }
  return current.filter((candidate) => candidate !== app)
}
