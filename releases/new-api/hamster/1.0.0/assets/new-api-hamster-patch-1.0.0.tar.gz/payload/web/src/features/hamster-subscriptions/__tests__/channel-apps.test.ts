/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import assert from 'node:assert/strict'
import { describe, test } from 'node:test'

import { DEFAULT_HAMSTER_APPS, toggleHamsterApp } from '../lib/channel-apps'

describe('Hamster channel app selection', () => {
  test('keeps the four supported apps in stable order', () => {
    assert.deepEqual(DEFAULT_HAMSTER_APPS, [
      'claude',
      'claude-desktop',
      'codex',
      'gemini',
    ])
  })

  test('adds an app once and restores canonical ordering', () => {
    assert.deepEqual(toggleHamsterApp(['gemini'], 'claude', true), [
      'claude',
      'gemini',
    ])
  })

  test('allows the UI to expose an empty invalid selection', () => {
    assert.deepEqual(toggleHamsterApp(['codex'], 'codex', false), [])
  })
})
