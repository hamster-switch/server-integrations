/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { History, Save, Send, Settings2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'

import {
  getHamsterSettings,
  getHamsterTemplateState,
  previewHamsterTemplate,
  publishHamsterTemplate,
  rollbackHamsterTemplate,
  saveHamsterTemplateDraft,
  updateHamsterSettings,
} from '../api'
import type { HamsterSubscription, TemplatePresentation } from '../types'
import { HamsterTutorialAdminPanel } from './tutorial-admin-panel'

const EMPTY_PRESENTATION = '{\n  "subscription": {},\n  "providers": {}\n}'

type Props = {
  subscriptions: HamsterSubscription[]
}

export function HamsterAdminPanel(props: Props) {
  const { t } = useTranslation()
  const queryClient = useQueryClient()
  const [body, setBody] = useState('')
  const [presentationText, setPresentationText] = useState('')
  const [confirmWarnings, setConfirmWarnings] = useState(false)
  const [preview, setPreview] = useState('')

  const templateQuery = useQuery({
    queryKey: ['hamster-template'],
    queryFn: getHamsterTemplateState,
  })
  const settingsQuery = useQuery({
    queryKey: ['hamster-settings'],
    queryFn: getHamsterSettings,
  })

  useEffect(() => {
    const draft = templateQuery.data?.data?.draft
    if (!draft) return
    setBody(draft.body)
    setPresentationText(JSON.stringify(draft.presentation, null, 2))
  }, [templateQuery.data])

  const parsePresentation = (): TemplatePresentation | null => {
    try {
      const value: unknown = JSON.parse(
        presentationText.trim() || EMPTY_PRESENTATION
      )
      if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new Error('presentation must be an object')
      }
      return value as TemplatePresentation
    } catch {
      toast.error(t('Presentation must be valid JSON.'))
      return null
    }
  }

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ['hamster-template'] })

  const saveMutation = useMutation({
    mutationFn: saveHamsterTemplateDraft,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Draft saved'))
      invalidate()
    },
  })
  const publishMutation = useMutation({
    mutationFn: publishHamsterTemplate,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Template published'))
      invalidate()
      queryClient.invalidateQueries({ queryKey: ['hamster-subscriptions'] })
    },
  })
  const previewMutation = useMutation({
    mutationFn: previewHamsterTemplate,
    onSuccess: (response) => {
      if (!response.success || !response.data) {
        toast.error(response.message)
        return
      }
      setPreview(response.data.yaml)
    },
  })
  const rollbackMutation = useMutation({
    mutationFn: rollbackHamsterTemplate,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Template rolled back'))
      invalidate()
      queryClient.invalidateQueries({ queryKey: ['hamster-subscriptions'] })
    },
  })
  const settingsMutation = useMutation({
    mutationFn: updateHamsterSettings,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      queryClient.invalidateQueries({ queryKey: ['hamster-settings'] })
      queryClient.invalidateQueries({ queryKey: ['keys'] })
    },
  })

  const handleSave = () => {
    const presentation = parsePresentation()
    if (presentation) saveMutation.mutate({ body, presentation })
  }
  const handlePublish = () => {
    const presentation = parsePresentation()
    if (presentation) {
      publishMutation.mutate({
        body,
        presentation,
        confirm_warnings: confirmWarnings,
      })
    }
  }
  const handlePreview = () => {
    const presentation = parsePresentation()
    const first = props.subscriptions[0]
    if (!first) {
      toast.error(t('Create a subscription before previewing the template.'))
      return
    }
    if (presentation) {
      previewMutation.mutate({
        body,
        presentation,
        subscription_public_id: first.public_id,
      })
    }
  }

  return (
    <div className='space-y-6'>
      <div className='grid gap-4 xl:grid-cols-[minmax(0,1fr)_22rem]'>
        <Card>
          <CardHeader>
            <CardTitle>{t('Configuration template')}</CardTitle>
          </CardHeader>
          <CardContent className='space-y-4'>
            <div className='space-y-2'>
              <Label htmlFor='hamster-template-body'>
                {t('YAML template')}
              </Label>
              <Textarea
                id='hamster-template-body'
                className='min-h-64 font-mono text-xs'
                value={body}
                onChange={(event) => setBody(event.target.value)}
              />
            </div>
            <div className='space-y-2'>
              <Label htmlFor='hamster-template-presentation'>
                {t('Presentation JSON')}
              </Label>
              <Textarea
                id='hamster-template-presentation'
                className='min-h-48 font-mono text-xs'
                value={presentationText}
                onFocus={() => {
                  if (!presentationText.trim()) {
                    setPresentationText(EMPTY_PRESENTATION)
                  }
                }}
                onChange={(event) => setPresentationText(event.target.value)}
                aria-describedby='hamster-presentation-help'
              />
              <p
                id='hamster-presentation-help'
                className='text-muted-foreground text-xs'
              >
                {t(
                  'Provider keys use the form group:channelId. Clearing an override restores its dynamic default.'
                )}
              </p>
            </div>
            <Label className='flex items-center gap-2'>
              <Checkbox
                checked={confirmWarnings}
                onCheckedChange={(value) => setConfirmWarnings(value === true)}
              />
              {t('I reviewed and accept template warnings')}
            </Label>
            <div className='flex flex-wrap gap-2'>
              <Button
                variant='outline'
                onClick={handleSave}
                disabled={saveMutation.isPending}
              >
                <Save />
                {t('Save draft')}
              </Button>
              <Button
                variant='outline'
                onClick={handlePreview}
                disabled={previewMutation.isPending}
              >
                {t('Preview')}
              </Button>
              <Button
                onClick={handlePublish}
                disabled={publishMutation.isPending}
              >
                <Send />
                {t('Publish')}
              </Button>
            </div>
            {preview ? (
              <div className='space-y-2'>
                <Label>{t('YAML preview')}</Label>
                <pre className='bg-muted max-h-96 overflow-auto rounded-lg p-3 text-xs whitespace-pre-wrap'>
                  {preview}
                </pre>
              </div>
            ) : null}
          </CardContent>
        </Card>

        <div className='space-y-4'>
          <Card>
            <CardHeader>
              <CardTitle className='flex items-center gap-2'>
                <Settings2 />
                {t('Settings')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Label className='flex items-center justify-between gap-4'>
                <span>{t('Show managed billing tokens in API key lists')}</span>
                <Switch
                  checked={
                    settingsQuery.data?.data?.managed_tokens_visible ?? false
                  }
                  onCheckedChange={(value) => settingsMutation.mutate(value)}
                />
              </Label>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className='flex items-center gap-2'>
                <History />
                {t('Template history')}
              </CardTitle>
            </CardHeader>
            <CardContent className='space-y-2'>
              {(templateQuery.data?.data?.versions ?? []).map((version) => (
                <div
                  key={version.version}
                  className='flex items-center justify-between gap-2 rounded-lg border p-2 text-sm'
                >
                  <span>
                    v{version.version}
                    {version.active ? ` · ${t('Active')}` : ''}
                  </span>
                  {!version.active ? (
                    <Button
                      size='xs'
                      variant='outline'
                      onClick={() => rollbackMutation.mutate(version.version)}
                    >
                      {t('Rollback')}
                    </Button>
                  ) : null}
                </div>
              ))}
              {templateQuery.data?.data?.versions.length === 0 ? (
                <Alert>
                  <AlertDescription>
                    {t('No published template versions yet.')}
                  </AlertDescription>
                </Alert>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>
      <HamsterTutorialAdminPanel />
    </div>
  )
}
