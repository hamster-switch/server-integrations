/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { ImageUp, RefreshCw, Save, Trash2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { toast } from 'sonner'

import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'

import {
  adoptHamsterTutorialUpdate,
  checkHamsterTutorialUpdate,
  deleteHamsterTutorialOverride,
  getHamsterTutorialAdminState,
  rejectHamsterTutorialUpdate,
  saveHamsterTutorialOverride,
  uploadHamsterTutorialImage,
} from '../api'
import type {
  TutorialAsset,
  TutorialOverride,
  TutorialUpdateCandidate,
} from '../types'

const EMPTY_OVERRIDE: TutorialOverride = {
  step_id: '',
  id: '',
  title: '',
  body_md: '',
  assets: [],
  optional: false,
  hidden: false,
  position: 0,
}

export function HamsterTutorialAdminPanel() {
  const { t } = useTranslation()
  const queryClient = useQueryClient()
  const [override, setOverride] = useState<TutorialOverride>(EMPTY_OVERRIDE)
  const [assetsText, setAssetsText] = useState('[]')
  const [candidate, setCandidate] = useState<TutorialUpdateCandidate>()
  const [resolutions, setResolutions] = useState<
    Record<string, 'keep_site' | 'use_release'>
  >({})

  const stateQuery = useQuery({
    queryKey: ['hamster-tutorial-admin'],
    queryFn: getHamsterTutorialAdminState,
  })
  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['hamster-tutorial-admin'] })
    queryClient.invalidateQueries({ queryKey: ['hamster-tutorial'] })
  }

  useEffect(() => {
    if (override.step_id) return
    const first = stateQuery.data?.data?.base.steps[0]
    if (!first) return
    setOverride({
      ...EMPTY_OVERRIDE,
      ...first,
      step_id: first.id,
      position: 0,
    })
    setAssetsText(JSON.stringify(first.assets ?? [], null, 2))
  }, [override.step_id, stateQuery.data])

  const checkMutation = useMutation({
    mutationFn: checkHamsterTutorialUpdate,
    onSuccess: (response) => {
      if (!response.success || !response.data) {
        return toast.error(response.message)
      }
      setCandidate(response.data)
      setResolutions(
        Object.fromEntries(
          response.data.conflicts.map((conflict) => [
            conflict.step_id,
            'keep_site',
          ])
        )
      )
      if (!response.data.changed) toast.success(t('Tutorial is up to date'))
    },
  })
  const adoptMutation = useMutation({
    mutationFn: adoptHamsterTutorialUpdate,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Tutorial update adopted'))
      setCandidate(undefined)
      invalidate()
    },
  })
  const rejectMutation = useMutation({
    mutationFn: rejectHamsterTutorialUpdate,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Tutorial update rejected'))
      setCandidate(undefined)
      invalidate()
    },
  })
  const overrideMutation = useMutation({
    mutationFn: (input: TutorialOverride) =>
      saveHamsterTutorialOverride(input.step_id, input),
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Tutorial override saved'))
      invalidate()
    },
  })
  const deleteMutation = useMutation({
    mutationFn: deleteHamsterTutorialOverride,
    onSuccess: (response) => {
      if (!response.success) return toast.error(response.message)
      toast.success(t('Tutorial override removed'))
      invalidate()
    },
  })
  const uploadMutation = useMutation({
    mutationFn: uploadHamsterTutorialImage,
    onSuccess: (response) => {
      if (!response.success || !response.data) {
        return toast.error(response.message)
      }
      const assets: TutorialAsset[] = JSON.parse(assetsText || '[]')
      assets.push({ kind: 'site', id: response.data.id })
      setAssetsText(JSON.stringify(assets, null, 2))
      toast.success(t('Tutorial image uploaded'))
    },
  })

  const selectStep = (stepId: string) => {
    const saved = stateQuery.data?.data?.overrides.find(
      (item) => item.step_id === stepId
    )
    const base = stateQuery.data?.data?.base.steps.find(
      (item) => item.id === stepId
    )
    const next =
      saved ??
      (base ? { ...EMPTY_OVERRIDE, ...base, step_id: base.id } : EMPTY_OVERRIDE)
    setOverride(next)
    setAssetsText(JSON.stringify(next.assets ?? [], null, 2))
  }

  const saveOverride = () => {
    try {
      const assets: unknown = JSON.parse(assetsText || '[]')
      if (!Array.isArray(assets)) throw new Error('assets must be an array')
      overrideMutation.mutate({ ...override, id: override.step_id, assets })
    } catch {
      toast.error(t('Tutorial assets must be valid JSON.'))
    }
  }

  const stepIds = [
    ...new Set([
      ...(stateQuery.data?.data?.base.steps.map((step) => step.id) ?? []),
      ...(stateQuery.data?.data?.overrides.map((item) => item.step_id) ?? []),
    ]),
  ]

  return (
    <Card>
      <CardHeader className='gap-3 sm:flex-row sm:items-center sm:justify-between'>
        <CardTitle>{t('Tutorial management')}</CardTitle>
        <Button
          variant='outline'
          onClick={() => checkMutation.mutate()}
          disabled={checkMutation.isPending}
        >
          <RefreshCw
            className={checkMutation.isPending ? 'animate-spin' : undefined}
          />
          {t('Check for tutorial updates')}
        </Button>
      </CardHeader>
      <CardContent className='space-y-5'>
        {candidate?.changed ? (
          <Alert>
            <AlertDescription className='space-y-3'>
              <p>
                {t('Tutorial version {{version}} is available.', {
                  version: candidate.version,
                })}
                {candidate.rejected
                  ? ` ${t('This version was previously rejected.')}`
                  : ''}
              </p>
              {candidate.conflicts.map((conflict) => (
                <Label
                  key={conflict.step_id}
                  className='flex items-center justify-between gap-3'
                >
                  <span>
                    {conflict.step_id} · {t(conflict.change)}
                  </span>
                  <select
                    className='bg-background rounded-md border px-2 py-1'
                    value={resolutions[conflict.step_id] ?? 'keep_site'}
                    onChange={(event) =>
                      setResolutions((current) => ({
                        ...current,
                        [conflict.step_id]: event.target.value as
                          | 'keep_site'
                          | 'use_release',
                      }))
                    }
                  >
                    <option value='keep_site'>{t('Keep site override')}</option>
                    <option value='use_release'>{t('Use release step')}</option>
                  </select>
                </Label>
              ))}
              <div className='flex gap-2'>
                <Button
                  onClick={() =>
                    adoptMutation.mutate({
                      version: candidate.version,
                      resolutions,
                    })
                  }
                >
                  {t('Adopt update')}
                </Button>
                <Button
                  variant='outline'
                  onClick={() => rejectMutation.mutate(candidate.version)}
                >
                  {t('Reject version')}
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        ) : null}

        <div className='grid gap-4 lg:grid-cols-[14rem_minmax(0,1fr)]'>
          <div className='space-y-2'>
            <Label htmlFor='tutorial-step-select'>{t('Tutorial step')}</Label>
            <select
              id='tutorial-step-select'
              className='bg-background w-full rounded-md border px-3 py-2 text-sm'
              value={override.step_id}
              onChange={(event) => selectStep(event.target.value)}
            >
              {stepIds.map((stepId) => (
                <option key={stepId} value={stepId}>
                  {stepId}
                </option>
              ))}
            </select>
            <Button
              variant='outline'
              className='w-full'
              onClick={() => {
                setOverride({ ...EMPTY_OVERRIDE })
                setAssetsText('[]')
              }}
            >
              {t('New site step')}
            </Button>
          </div>
          <div className='grid gap-3 sm:grid-cols-2'>
            <div className='space-y-2'>
              <Label htmlFor='tutorial-step-id'>{t('Step ID')}</Label>
              <Input
                id='tutorial-step-id'
                value={override.step_id}
                onChange={(event) =>
                  setOverride((current) => ({
                    ...current,
                    step_id: event.target.value,
                    id: event.target.value,
                  }))
                }
              />
            </div>
            <div className='space-y-2'>
              <Label htmlFor='tutorial-step-title'>{t('Title')}</Label>
              <Input
                id='tutorial-step-title'
                value={override.title}
                onChange={(event) =>
                  setOverride((current) => ({
                    ...current,
                    title: event.target.value,
                  }))
                }
              />
            </div>
            <div className='space-y-2 sm:col-span-2'>
              <Label htmlFor='tutorial-step-body'>{t('Markdown body')}</Label>
              <Textarea
                id='tutorial-step-body'
                className='min-h-32'
                value={override.body_md}
                onChange={(event) =>
                  setOverride((current) => ({
                    ...current,
                    body_md: event.target.value,
                  }))
                }
              />
            </div>
            <div className='space-y-2 sm:col-span-2'>
              <Label htmlFor='tutorial-step-assets'>{t('Assets JSON')}</Label>
              <Textarea
                id='tutorial-step-assets'
                className='min-h-24 font-mono text-xs'
                value={assetsText}
                onChange={(event) => setAssetsText(event.target.value)}
              />
            </div>
            <div className='space-y-2'>
              <Label htmlFor='tutorial-step-position'>{t('Position')}</Label>
              <Input
                id='tutorial-step-position'
                type='number'
                value={override.position}
                onChange={(event) =>
                  setOverride((current) => ({
                    ...current,
                    position: Number(event.target.value),
                  }))
                }
              />
            </div>
            <div className='flex flex-wrap items-end gap-4 pb-2'>
              <Label className='flex items-center gap-2'>
                <Checkbox
                  checked={override.optional}
                  onCheckedChange={(value) =>
                    setOverride((current) => ({
                      ...current,
                      optional: value === true,
                    }))
                  }
                />
                {t('Optional')}
              </Label>
              <Label className='flex items-center gap-2'>
                <Checkbox
                  checked={override.hidden}
                  onCheckedChange={(value) =>
                    setOverride((current) => ({
                      ...current,
                      hidden: value === true,
                    }))
                  }
                />
                {t('Hidden')}
              </Label>
            </div>
            <div className='flex flex-wrap gap-2 sm:col-span-2'>
              <Button
                onClick={saveOverride}
                disabled={
                  !override.step_id || !override.title || !override.body_md
                }
              >
                <Save />
                {t('Save override')}
              </Button>
              <Label className='inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm'>
                <ImageUp />
                {t('Upload image')}
                <input
                  type='file'
                  accept='image/png,image/jpeg,image/webp,image/gif'
                  className='sr-only'
                  onChange={(event) => {
                    const file = event.target.files?.[0]
                    if (file) uploadMutation.mutate(file)
                    event.target.value = ''
                  }}
                />
              </Label>
              <Button
                variant='destructive'
                disabled={
                  !stateQuery.data?.data?.overrides.some(
                    (item) => item.step_id === override.step_id
                  )
                }
                onClick={() => deleteMutation.mutate(override.step_id)}
              >
                <Trash2 />
                {t('Remove override')}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
