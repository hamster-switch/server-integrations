/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { api } from '@/lib/api'

import type {
  ApiResponse,
  HamsterSubscription,
  HamsterSubscriptionInput,
  HamsterSubscriptionPage,
  HamsterTutorial,
  TemplatePresentation,
  TemplateState,
  UserGroup,
  TutorialAdminState,
  TutorialOverride,
  TutorialUpdateCandidate,
} from './types'

export async function listHamsterSubscriptions(search = '') {
  const response = await api.get<ApiResponse<HamsterSubscriptionPage>>(
    '/api/hamster-switch/subscriptions/',
    { params: { p: 1, page_size: 100, search } }
  )
  return response.data
}

export async function createHamsterSubscription(
  input: HamsterSubscriptionInput
) {
  const response = await api.post<ApiResponse<HamsterSubscription>>(
    '/api/hamster-switch/subscriptions/',
    input
  )
  return response.data
}

export async function updateHamsterSubscription(
  publicId: string,
  input: HamsterSubscriptionInput
) {
  const response = await api.put<ApiResponse<HamsterSubscription>>(
    `/api/hamster-switch/subscriptions/${publicId}`,
    input
  )
  return response.data
}

export async function setHamsterSubscriptionEnabled(
  publicId: string,
  enabled: boolean
) {
  const action = enabled ? 'enable' : 'disable'
  const response = await api.post<ApiResponse<HamsterSubscription>>(
    `/api/hamster-switch/subscriptions/${publicId}/${action}`
  )
  return response.data
}

export async function deleteHamsterSubscription(publicId: string) {
  const response = await api.delete<ApiResponse>(
    `/api/hamster-switch/subscriptions/${publicId}`
  )
  return response.data
}

export async function getHamsterUserGroups() {
  const response = await api.get<ApiResponse<Record<string, UserGroup>>>(
    '/api/user/self/groups'
  )
  return response.data
}

export async function getHamsterTutorial() {
  const response = await api.get<ApiResponse<HamsterTutorial>>(
    '/api/hamster-switch/tutorial'
  )
  return response.data
}

export async function getHamsterTutorialAdminState() {
  const response = await api.get<ApiResponse<TutorialAdminState>>(
    '/api/hamster-switch/admin/tutorial'
  )
  return response.data
}

export async function checkHamsterTutorialUpdate() {
  const response = await api.post<ApiResponse<TutorialUpdateCandidate>>(
    '/api/hamster-switch/admin/tutorial/check-update'
  )
  return response.data
}

export async function adoptHamsterTutorialUpdate(input: {
  version: string
  resolutions: Record<string, 'keep_site' | 'use_release'>
}) {
  const response = await api.post<ApiResponse>(
    '/api/hamster-switch/admin/tutorial/adopt',
    input
  )
  return response.data
}

export async function rejectHamsterTutorialUpdate(version: string) {
  const response = await api.post<ApiResponse>(
    '/api/hamster-switch/admin/tutorial/reject',
    { version }
  )
  return response.data
}

export async function saveHamsterTutorialOverride(
  stepId: string,
  input: TutorialOverride
) {
  const response = await api.put<ApiResponse<TutorialOverride>>(
    `/api/hamster-switch/admin/tutorial/overrides/${stepId}`,
    input
  )
  return response.data
}

export async function deleteHamsterTutorialOverride(stepId: string) {
  const response = await api.delete<ApiResponse>(
    `/api/hamster-switch/admin/tutorial/overrides/${stepId}`
  )
  return response.data
}

export async function uploadHamsterTutorialImage(file: File) {
  const body = new FormData()
  body.append('file', file)
  const response = await api.post<ApiResponse<{ id: string; url: string }>>(
    '/api/hamster-switch/admin/tutorial/images',
    body
  )
  return response.data
}

export async function getHamsterTemplateState() {
  const response = await api.get<ApiResponse<TemplateState>>(
    '/api/hamster-switch/admin/template'
  )
  return response.data
}

export async function saveHamsterTemplateDraft(input: {
  body: string
  presentation: TemplatePresentation
}) {
  const response = await api.put<ApiResponse>(
    '/api/hamster-switch/admin/template/draft',
    input
  )
  return response.data
}

export async function previewHamsterTemplate(input: {
  body: string
  presentation: TemplatePresentation
  subscription_public_id: string
}) {
  const response = await api.post<
    ApiResponse<{ yaml: string; diagnostics: unknown[]; skipped: unknown[] }>
  >('/api/hamster-switch/admin/template/preview', input)
  return response.data
}

export async function publishHamsterTemplate(input: {
  body: string
  presentation: TemplatePresentation
  confirm_warnings: boolean
}) {
  const response = await api.post<ApiResponse>(
    '/api/hamster-switch/admin/template/publish',
    input
  )
  return response.data
}

export async function rollbackHamsterTemplate(version: number) {
  const response = await api.post<ApiResponse>(
    `/api/hamster-switch/admin/template/rollback/${version}`
  )
  return response.data
}

export async function getHamsterSettings() {
  const response = await api.get<
    ApiResponse<{ managed_tokens_visible: boolean }>
  >('/api/hamster-switch/admin/settings')
  return response.data
}

export async function updateHamsterSettings(managedTokensVisible: boolean) {
  const response = await api.put<
    ApiResponse<{ managed_tokens_visible: boolean }>
  >('/api/hamster-switch/admin/settings', {
    managed_tokens_visible: managedTokensVisible,
  })
  return response.data
}
