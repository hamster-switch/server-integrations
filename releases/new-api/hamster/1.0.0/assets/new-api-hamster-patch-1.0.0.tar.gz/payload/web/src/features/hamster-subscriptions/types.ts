/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

export type ApiResponse<T = unknown> = {
  success: boolean
  message: string
  code?: string
  data?: T
}

export type HamsterProviderSummary = {
  id: string
  apps: string[]
  group_name: string
  name: string
  description?: string
  models: string[]
  default_model: string
  base_url: string
  pricing: Record<string, unknown>
}

export type HamsterSubscriptionGroup = {
  group_name: string
  position: number
}

export type HamsterSubscription = {
  public_id: string
  name: string
  status: 'active' | 'disabled'
  groups: HamsterSubscriptionGroup[]
  download_url: string
  providers: HamsterProviderSummary[]
  provider_count: number
  created_time: number
  updated_time: number
}

export type HamsterSubscriptionPage = {
  page: number
  page_size: number
  total: number
  items: HamsterSubscription[]
}

export type HamsterSubscriptionInput = {
  name: string
  groups: string[]
}

export type UserGroup = {
  ratio: number
  desc: string
}

export type TutorialAsset = {
  kind: 'release' | 'site' | 'external'
  id?: string
  url?: string
}

export type TutorialStep = {
  id: string
  title: string
  body_md: string
  assets?: TutorialAsset[]
  optional?: boolean
}

export type HamsterTutorial = {
  schema_version: number
  id: string
  version: string
  locale: string
  title: string
  steps: TutorialStep[]
}

export type TutorialOverride = TutorialStep & {
  step_id: string
  hidden: boolean
  position: number
}

export type TutorialConflict = {
  step_id: string
  change: 'deleted' | 'modified'
}

export type TutorialRejection = {
  id: number
  version: string
  rejected_by: number
  rejected_time: number
}

export type TutorialAdminState = {
  base: HamsterTutorial
  overrides: TutorialOverride[]
  rejections: TutorialRejection[]
}

export type TutorialUpdateCandidate = {
  changed: boolean
  rejected: boolean
  version: string
  tutorial: HamsterTutorial
  conflicts: TutorialConflict[]
}

export type TemplateDiagnostic = {
  level: 'error' | 'warning'
  code: string
  message: string
}

export type TemplatePresentation = {
  subscription: Record<string, unknown>
  providers: Record<string, Record<string, unknown>>
}

export type TemplateDraft = {
  body: string
  presentation: TemplatePresentation
  updated_by: number
  updated_time: number
}

export type TemplateVersion = TemplateDraft & {
  version: number
  warnings: TemplateDiagnostic[]
  active: boolean
  rollback_from: number
  created_by: number
  created_time: number
}

export type TemplateState = {
  draft: TemplateDraft
  versions: TemplateVersion[]
}
