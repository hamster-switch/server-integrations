/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { useQuery } from '@tanstack/react-query'
import { BookOpen, Loader2 } from 'lucide-react'
import { useTranslation } from 'react-i18next'

import { Alert, AlertDescription } from '@/components/ui/alert'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

import { getHamsterTutorial } from '../api'

export function HamsterTutorialPanel() {
  const { t } = useTranslation()
  const tutorialQuery = useQuery({
    queryKey: ['hamster-tutorial'],
    queryFn: getHamsterTutorial,
  })

  if (tutorialQuery.isPending) {
    return (
      <div className='text-muted-foreground flex items-center justify-center gap-2 py-16'>
        <Loader2 className='animate-spin' />
        {t('Loading tutorial...')}
      </div>
    )
  }

  if (tutorialQuery.isError || !tutorialQuery.data?.success) {
    return (
      <Alert variant='destructive'>
        <AlertDescription>
          {tutorialQuery.data?.message || t('Failed to load tutorial.')}
        </AlertDescription>
      </Alert>
    )
  }

  const tutorial = tutorialQuery.data.data
  if (!tutorial) return null

  return (
    <div className='space-y-4'>
      <div>
        <h2 className='flex items-center gap-2 text-xl font-semibold'>
          <BookOpen />
          {tutorial.title}
        </h2>
        <p className='text-muted-foreground mt-1 text-sm'>
          {t('Tutorial version {{version}}', { version: tutorial.version })}
        </p>
      </div>
      <div className='grid gap-4 lg:grid-cols-2'>
        {tutorial.steps.map((step, index) => (
          <Card key={step.id}>
            <CardHeader>
              <CardTitle className='flex items-start gap-3 text-base'>
                <span className='bg-primary text-primary-foreground flex size-7 shrink-0 items-center justify-center rounded-full text-xs'>
                  {index + 1}
                </span>
                <span>{step.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className='space-y-3'>
              <div className='text-muted-foreground text-sm whitespace-pre-wrap'>
                {step.body_md}
              </div>
              {step.assets?.map((asset) => {
                const source = asset.url
                if (!source) return null
                return (
                  <img
                    key={`${step.id}-${source}`}
                    src={source}
                    alt={step.title}
                    loading='lazy'
                    className='max-h-80 w-full rounded-lg border object-contain'
                  />
                )
              })}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
