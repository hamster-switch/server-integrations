/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'

import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

import type {
  HamsterSubscription,
  HamsterSubscriptionInput,
  UserGroup,
} from '../types'

type Props = {
  open: boolean
  current?: HamsterSubscription
  groups: Record<string, UserGroup>
  submitting: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (input: HamsterSubscriptionInput) => void
}

export function HamsterSubscriptionDialog(props: Props) {
  const { t } = useTranslation()
  const [name, setName] = useState('')
  const [selectedGroups, setSelectedGroups] = useState<string[]>([])

  useEffect(() => {
    if (!props.open) return
    setName(props.current?.name ?? '')
    setSelectedGroups(
      props.current?.groups.map((group) => group.group_name) ?? []
    )
  }, [props.current, props.open])

  const toggleGroup = (groupName: string, checked: boolean) => {
    setSelectedGroups((current) => {
      if (checked) return [...new Set([...current, groupName])].sort()
      return current.filter((item) => item !== groupName)
    })
  }

  const valid = name.trim().length > 0 && selectedGroups.length > 0

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className='sm:max-w-lg'>
        <DialogHeader>
          <DialogTitle>
            {props.current
              ? t('Edit configuration subscription')
              : t('Create configuration subscription')}
          </DialogTitle>
          <DialogDescription>
            {t(
              'Each selected group shares one billing token while providers remain bound to individual channels.'
            )}
          </DialogDescription>
        </DialogHeader>
        <div className='space-y-4'>
          <div className='space-y-2'>
            <Label htmlFor='hamster-subscription-name'>{t('Name')}</Label>
            <Input
              id='hamster-subscription-name'
              value={name}
              maxLength={128}
              onChange={(event) => setName(event.target.value)}
              placeholder={t('My configuration subscription')}
            />
          </div>
          <fieldset className='space-y-2'>
            <legend className='text-sm font-medium'>{t('Groups')}</legend>
            <div className='grid gap-2 sm:grid-cols-2'>
              {Object.entries(props.groups).map(([groupName, group]) => {
                const checked = selectedGroups.includes(groupName)
                return (
                  <Label
                    key={groupName}
                    htmlFor={`hamster-group-${groupName}`}
                    className='bg-card hover:bg-muted/50 flex cursor-pointer items-start gap-3 rounded-lg border p-3'
                  >
                    <Checkbox
                      id={`hamster-group-${groupName}`}
                      checked={checked}
                      onCheckedChange={(value) =>
                        toggleGroup(groupName, value === true)
                      }
                    />
                    <span className='min-w-0'>
                      <span className='block truncate text-sm font-medium'>
                        {groupName}
                      </span>
                      <span className='text-muted-foreground block text-xs'>
                        {group.desc ||
                          t('Multiplier {{ratio}}', { ratio: group.ratio })}
                      </span>
                    </span>
                  </Label>
                )
              })}
            </div>
          </fieldset>
        </div>
        <DialogFooter>
          <Button variant='outline' onClick={() => props.onOpenChange(false)}>
            {t('Cancel')}
          </Button>
          <Button
            disabled={!valid || props.submitting}
            onClick={() =>
              props.onSubmit({ name: name.trim(), groups: selectedGroups })
            }
          >
            {props.submitting ? t('Saving...') : t('Save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
