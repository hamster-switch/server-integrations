/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import { Copy, Pencil, Power, PowerOff, Trash2 } from 'lucide-react'
import { useTranslation } from 'react-i18next'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

import type { HamsterSubscription } from '../types'

type Props = {
  subscription: HamsterSubscription
  busy: boolean
  onEdit: () => void
  onToggle: () => void
  onDelete: () => void
  onCopy: () => void
}

export function HamsterSubscriptionCard(props: Props) {
  const { t } = useTranslation()
  const active = props.subscription.status === 'active'

  return (
    <Card className={!active ? 'opacity-70' : undefined}>
      <CardHeader className='gap-3 pb-3 sm:flex-row sm:items-start sm:justify-between'>
        <div className='min-w-0 space-y-1'>
          <CardTitle className='truncate'>{props.subscription.name}</CardTitle>
          <div className='flex flex-wrap gap-1.5'>
            <Badge variant={active ? 'default' : 'secondary'}>
              {active ? t('Active') : t('Disabled')}
            </Badge>
            {props.subscription.groups.map((group) => (
              <Badge key={group.group_name} variant='outline'>
                {group.group_name}
              </Badge>
            ))}
          </div>
        </div>
        <div className='flex shrink-0 gap-1'>
          <Button
            size='icon-sm'
            variant='ghost'
            aria-label={t('Copy URL')}
            onClick={props.onCopy}
          >
            <Copy />
          </Button>
          <Button
            size='icon-sm'
            variant='ghost'
            aria-label={t('Edit')}
            onClick={props.onEdit}
          >
            <Pencil />
          </Button>
          <Button
            size='icon-sm'
            variant='ghost'
            aria-label={active ? t('Disable') : t('Enable')}
            disabled={props.busy}
            onClick={props.onToggle}
          >
            {active ? <PowerOff /> : <Power />}
          </Button>
          <Button
            size='icon-sm'
            variant='destructive'
            aria-label={t('Delete')}
            disabled={props.busy}
            onClick={props.onDelete}
          >
            <Trash2 />
          </Button>
        </div>
      </CardHeader>
      <CardContent className='space-y-3'>
        {props.subscription.providers.length === 0 ? (
          <div className='text-muted-foreground rounded-lg border border-dashed p-4 text-sm'>
            {t(
              'No eligible channels are currently available for this subscription.'
            )}
          </div>
        ) : (
          <div className='grid gap-2 md:grid-cols-2 xl:grid-cols-3'>
            {props.subscription.providers.map((provider) => (
              <div
                key={provider.id}
                className='bg-muted/30 min-w-0 rounded-lg border p-3'
              >
                <div className='truncate text-sm font-medium'>
                  {provider.name}
                </div>
                <div className='text-muted-foreground mt-1 text-xs'>
                  {provider.group_name} · {provider.models.length} {t('models')}{' '}
                  · ×{String(provider.pricing.multiplier ?? 1)}
                </div>
                <div className='mt-2 flex flex-wrap gap-1'>
                  {provider.apps.map((app) => (
                    <Badge key={app} variant='outline'>
                      {app}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
