/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.
*/

import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { describe, test } from 'node:test'

type Locale = { translation: Record<string, string> }

function locale(name: string): Locale {
  return JSON.parse(
    readFileSync(
      new URL(`../../../i18n/locales/${name}.json`, import.meta.url),
      'utf8'
    )
  ) as Locale
}

describe('configuration subscription translations', () => {
  test('switches the sidebar and page title between English and Chinese', () => {
    const english = locale('en')
    const chinese = locale('zh')

    assert.equal(
      english.translation['Configuration subscriptions'],
      'Configuration subscriptions'
    )
    assert.equal(chinese.translation['Configuration subscriptions'], '配置订阅')
  })

  test('includes channel app validation in both primary locales', () => {
    const english = locale('en')
    const chinese = locale('zh')

    assert.equal(
      english.translation['Select at least one Hamster Switch app.'],
      'Select at least one Hamster Switch app.'
    )
    assert.equal(
      chinese.translation['Select at least one Hamster Switch app.'],
      '请至少选择一个 Hamster Switch 应用。'
    )
  })
})
