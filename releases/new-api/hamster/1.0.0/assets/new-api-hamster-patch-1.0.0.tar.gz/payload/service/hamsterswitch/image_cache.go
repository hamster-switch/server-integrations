package hamsterswitch

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"

	rootservice "github.com/QuantumNous/new-api/service"
)

const hamsterImageMaxBytes int64 = 8 << 20
const hamsterImageMaxPixels int64 = 20_000_000

type ImageEntry struct {
	ID, LocalName, MediaType string
	Size                     int64
	Width, Height            int
}

type ImageCache struct{ root string }

func NewImageCache(root string) (*ImageCache, error) {
	absolute, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}
	if err := os.MkdirAll(absolute, 0o700); err != nil {
		return nil, err
	}
	return &ImageCache{root: filepath.Clean(absolute)}, nil
}

func (cache *ImageCache) Store(reader io.Reader, declared string) (ImageEntry, error) {
	body, err := readImageLimited(reader)
	if err != nil {
		return ImageEntry{}, err
	}
	return cache.store(body, declared)
}

func (cache *ImageCache) Fetch(ctx context.Context, rawURL string) (ImageEntry, error) {
	parsed, err := url.Parse(strings.TrimSpace(rawURL))
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" || parsed.User != nil || parsed.Fragment != "" {
		return ImageEntry{}, errors.New("外链图片必须使用无用户信息和片段的绝对 HTTPS URL")
	}
	if err := rootservice.ValidateSSRFProtectedFetchURL(parsed.String()); err != nil {
		return ImageEntry{}, fmt.Errorf("外链图片地址被 SSRF 保护拒绝：%w", err)
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, parsed.String(), nil)
	if err != nil {
		return ImageEntry{}, err
	}
	request.Header.Set("Accept", "image/png,image/jpeg,image/gif")
	request.Header.Set("User-Agent", "new-api-hamster-image-cache")
	response, err := rootservice.GetSSRFProtectedHTTPClient().Do(request)
	if err != nil {
		return ImageEntry{}, fmt.Errorf("获取外链图片失败：%w", err)
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return ImageEntry{}, fmt.Errorf("外链图片返回 HTTP %d", response.StatusCode)
	}
	body, err := readImageLimited(response.Body)
	if err != nil {
		return ImageEntry{}, err
	}
	return cache.store(body, response.Header.Get("Content-Type"))
}

func (cache *ImageCache) Path(localName string) (string, error) {
	if filepath.Base(localName) != localName {
		return "", errors.New("图片文件名无效")
	}
	path := filepath.Join(cache.root, localName)
	relative, err := filepath.Rel(cache.root, path)
	if err != nil || strings.HasPrefix(relative, "..") {
		return "", errors.New("图片路径越界")
	}
	if _, err := os.Stat(path); err != nil {
		return "", err
	}
	return path, nil
}

func (cache *ImageCache) store(body []byte, declared string) (ImageEntry, error) {
	mediaType := http.DetectContentType(body)
	extension := map[string]string{"image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif"}[mediaType]
	if extension == "" {
		return ImageEntry{}, fmt.Errorf("不支持图片类型 %q", mediaType)
	}
	declared = strings.ToLower(strings.TrimSpace(strings.Split(declared, ";")[0]))
	if declared != "" && declared != "application/octet-stream" && declared != mediaType {
		return ImageEntry{}, errors.New("声明的图片 MIME 与实际内容不一致")
	}
	config, _, err := image.DecodeConfig(bytes.NewReader(body))
	if err != nil || config.Width <= 0 || config.Height <= 0 || int64(config.Width) > hamsterImageMaxPixels/int64(config.Height) {
		return ImageEntry{}, errors.New("图片尺寸无效或超过像素限制")
	}
	digest := sha256.Sum256(body)
	id := hex.EncodeToString(digest[:])
	name := id + extension
	path := filepath.Join(cache.root, name)
	if _, err := os.Stat(path); errors.Is(err, os.ErrNotExist) {
		temporary := path + ".tmp"
		if err := os.WriteFile(temporary, body, 0o600); err != nil {
			return ImageEntry{}, err
		}
		if err := os.Rename(temporary, path); err != nil {
			_ = os.Remove(temporary)
			return ImageEntry{}, err
		}
	} else if err != nil {
		return ImageEntry{}, err
	}
	return ImageEntry{ID: id, LocalName: name, MediaType: mediaType, Size: int64(len(body)), Width: config.Width, Height: config.Height}, nil
}

func readImageLimited(reader io.Reader) ([]byte, error) {
	body, err := io.ReadAll(io.LimitReader(reader, hamsterImageMaxBytes+1))
	if err != nil {
		return nil, err
	}
	if int64(len(body)) > hamsterImageMaxBytes {
		return nil, errors.New("图片超过 8 MiB 限制")
	}
	return body, nil
}
