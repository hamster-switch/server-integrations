package hamsterswitch

import (
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"sort"
	"strings"
)

var tutorialIDPattern = regexp.MustCompile(`^[a-z0-9]+(?:[._-][a-z0-9]+)*$`)
var tutorialVersionPattern = regexp.MustCompile(`^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z]+(?:[.-][0-9A-Za-z]+)*)?$`)

type TutorialAsset struct {
	Kind string `json:"kind"`
	ID   string `json:"id,omitempty"`
	URL  string `json:"url,omitempty"`
}

type TutorialStep struct {
	ID       string          `json:"id"`
	Title    string          `json:"title"`
	BodyMD   string          `json:"body_md"`
	Assets   []TutorialAsset `json:"assets,omitempty"`
	Optional bool            `json:"optional,omitempty"`
}

type Tutorial struct {
	SchemaVersion int            `json:"schema_version"`
	ID            string         `json:"id"`
	Version       string         `json:"version"`
	Locale        string         `json:"locale"`
	Title         string         `json:"title"`
	Steps         []TutorialStep `json:"steps"`
}

type TutorialOverride struct {
	StepID   string          `json:"step_id"`
	Title    string          `json:"title"`
	BodyMD   string          `json:"body_md"`
	Assets   []TutorialAsset `json:"assets,omitempty"`
	Optional bool            `json:"optional,omitempty"`
	Hidden   bool            `json:"hidden,omitempty"`
	Position int             `json:"position"`
}

type TutorialConflict struct {
	StepID string `json:"step_id"`
	Change string `json:"change"`
}

func BuiltinTutorial() Tutorial {
	return Tutorial{SchemaVersion: 1, ID: "configuration-subscription-guide-zh-cn", Version: "1.0.0", Locale: "zh-CN", Title: "配置订阅教程", Steps: []TutorialStep{
		{ID: "create-subscription", Title: "创建配置订阅", BodyMD: "在配置订阅页面选择需要使用的分组并创建订阅。"},
		{ID: "import-from-url", Title: "从 URL 导入", BodyMD: "点击“导入 Hamster Switch”，确认预填信息后选择添加或取消。"},
		{ID: "refresh-subscription", Title: "刷新配置", BodyMD: "配置更新后，在 Hamster Switch 中刷新原订阅 URL 即可获取当前内容。"},
	}}
}

func (tutorial Tutorial) Validate() error {
	if tutorial.SchemaVersion != 1 || !tutorialIDPattern.MatchString(tutorial.ID) || !tutorialVersionPattern.MatchString(tutorial.Version) || strings.TrimSpace(tutorial.Title) == "" {
		return errors.New("教程元数据无效")
	}
	if tutorial.Locale != "zh-CN" && tutorial.Locale != "en-US" {
		return fmt.Errorf("不支持教程语言 %q", tutorial.Locale)
	}
	if len(tutorial.Steps) == 0 {
		return errors.New("教程至少需要一个步骤")
	}
	seen := make(map[string]bool, len(tutorial.Steps))
	for _, step := range tutorial.Steps {
		if !tutorialIDPattern.MatchString(step.ID) || strings.TrimSpace(step.Title) == "" || strings.TrimSpace(step.BodyMD) == "" || seen[step.ID] {
			return fmt.Errorf("教程步骤 %q 无效", step.ID)
		}
		seen[step.ID] = true
		for _, asset := range step.Assets {
			switch asset.Kind {
			case "release", "site":
				if !tutorialIDPattern.MatchString(asset.ID) || asset.URL != "" {
					return fmt.Errorf("步骤 %s 的本地图片引用无效", step.ID)
				}
			case "external":
				parsed, err := url.Parse(asset.URL)
				if err != nil || parsed.Scheme != "https" || parsed.Host == "" || parsed.User != nil || asset.ID != "" {
					return fmt.Errorf("步骤 %s 的外链图片无效", step.ID)
				}
			default:
				return fmt.Errorf("步骤 %s 包含不支持的图片来源", step.ID)
			}
		}
	}
	return nil
}

func MergeTutorial(base Tutorial, overrides []TutorialOverride, imageURL func(string) string) Tutorial {
	byID := make(map[string]TutorialOverride, len(overrides))
	for _, override := range overrides {
		byID[override.StepID] = override
	}
	type positionedStep struct {
		step     TutorialStep
		position int
	}
	result := make([]positionedStep, 0, len(base.Steps)+len(overrides))
	seen := make(map[string]bool)
	for index, step := range base.Steps {
		seen[step.ID] = true
		position := index * 100
		if override, ok := byID[step.ID]; ok {
			if override.Hidden {
				continue
			}
			step.Title, step.BodyMD, step.Assets, step.Optional, position = override.Title, override.BodyMD, override.Assets, override.Optional, override.Position
		}
		result = append(result, positionedStep{step: step, position: position})
	}
	for _, override := range overrides {
		if seen[override.StepID] || override.Hidden {
			continue
		}
		result = append(result, positionedStep{step: TutorialStep{ID: override.StepID, Title: override.Title, BodyMD: override.BodyMD, Assets: override.Assets, Optional: override.Optional}, position: override.Position})
	}
	sort.SliceStable(result, func(i, j int) bool { return result[i].position < result[j].position })
	base.Steps = nil
	for _, item := range result {
		for index, asset := range item.step.Assets {
			if asset.Kind == "release" || asset.Kind == "site" {
				item.step.Assets[index].URL = imageURL(asset.ID)
			}
		}
		base.Steps = append(base.Steps, item.step)
	}
	return base
}

func TutorialConflicts(current, next Tutorial, overrides []TutorialOverride) []TutorialConflict {
	oldSteps, newSteps := map[string]TutorialStep{}, map[string]TutorialStep{}
	for _, step := range current.Steps {
		oldSteps[step.ID] = step
	}
	for _, step := range next.Steps {
		newSteps[step.ID] = step
	}
	var result []TutorialConflict
	for _, override := range overrides {
		old, oldOK := oldSteps[override.StepID]
		nextStep, nextOK := newSteps[override.StepID]
		change := ""
		if oldOK && !nextOK {
			change = "deleted"
		} else if oldOK && nextOK && fmt.Sprintf("%#v", old) != fmt.Sprintf("%#v", nextStep) {
			change = "modified"
		}
		if change != "" {
			result = append(result, TutorialConflict{StepID: override.StepID, Change: change})
		}
	}
	sort.Slice(result, func(i, j int) bool { return result[i].StepID < result[j].StepID })
	return result
}

func ValidateTutorialOverride(override TutorialOverride) error {
	if strings.TrimSpace(override.StepID) == "" || strings.TrimSpace(override.Title) == "" || strings.TrimSpace(override.BodyMD) == "" {
		return errors.New("step_id、title 和 body_md 不能为空")
	}
	test := Tutorial{SchemaVersion: 1, ID: "site-override-validation", Version: "1.0.0", Locale: "zh-CN", Title: "validation", Steps: []TutorialStep{{ID: override.StepID, Title: override.Title, BodyMD: override.BodyMD, Assets: override.Assets}}}
	return test.Validate()
}
