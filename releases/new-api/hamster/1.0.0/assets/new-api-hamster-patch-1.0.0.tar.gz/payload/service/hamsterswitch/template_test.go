package hamsterswitch

import (
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

func TestDefaultTemplateIsValidAndRejectsUnknownVariables(t *testing.T) {
	diagnostics := ValidateTemplate(DefaultTemplate)
	assert.False(t, HasTemplateErrors(diagnostics))

	invalid := strings.Replace(DefaultTemplate, "{{subscription.name}}", "{{env.HOME}}", 1)
	diagnostics = ValidateTemplate(invalid)
	assert.True(t, HasTemplateErrors(diagnostics))
}

func TestTemplatePresentationStrictJSONEndpointSyncAndAPIKeyInjection(t *testing.T) {
	subscription := setupSubscriptionTest(t)
	createChannelWithAbility(t, 17, "alpha", "gpt-alpha", 1)
	baseURL := "https://override.example.com"
	settings := defaultGeneralSettings("{{provider.api_key}}", baseURL, "gpt-alpha")
	multiplier := 1.25
	presentation := TemplatePresentation{Providers: map[string]ProviderPresentation{
		"default:17": {
			BaseURL:        &baseURL,
			Pricing:        &map[string]any{"multiplier": multiplier},
			SettingsConfig: &settings,
		},
	}}
	encoded, err := EncodeTemplatePresentation(presentation)
	require.NoError(t, err)
	decoded, err := DecodeTemplatePresentation(encoded)
	require.NoError(t, err)

	export, _, err := BuildSubscriptionWithPresentation(subscription, "https://new-api.example.com", BuildPreview, decoded)
	require.NoError(t, err)
	require.Len(t, export.Providers, 1)
	provider := export.Providers[0]
	assert.Equal(t, baseURL, provider.BaseURL)
	assert.Equal(t, baseURL, provider.Endpoints[0].URL)
	assert.Equal(t, multiplier, provider.Pricing["multiplier"])
	claude := provider.SettingsConfig["claude"].(map[string]any)
	assert.Equal(t, baseURL, claude["env"].(map[string]any)["ANTHROPIC_BASE_URL"])
	assert.Equal(t, "sk-hsp-preview-17", claude["env"].(map[string]any)["ANTHROPIC_AUTH_TOKEN"])
	codex := provider.SettingsConfig["codex"].(map[string]any)
	assert.Contains(t, codex["config"].(string), `base_url = "https://override.example.com/v1"`)

	body, diagnostics, err := RenderTemplate(DefaultTemplate, *export)
	require.NoError(t, err)
	assert.False(t, HasTemplateErrors(diagnostics))
	var rendered map[string]any
	require.NoError(t, yaml.Unmarshal(body, &rendered))
	providers := rendered["providers"].([]any)
	renderedProvider := providers[0].(map[string]any)
	assert.IsType(t, map[string]any{}, renderedProvider["settings_config"])
}

func TestPublishedTemplateAffectsExistingSubscriptionNextDownload(t *testing.T) {
	subscription := setupSubscriptionTest(t)
	createChannelWithAbility(t, 17, "alpha", "gpt-alpha", 1)
	name := "Published name"
	presentation := TemplatePresentation{
		Subscription: SubscriptionPresentation{Name: &name},
		Providers:    map[string]ProviderPresentation{},
	}
	encoded, err := EncodeTemplatePresentation(presentation)
	require.NoError(t, err)
	diagnostics := ValidateTemplate(DefaultTemplate)
	warnings, err := modelJSON(diagnostics)
	require.NoError(t, err)
	_, err = model.PublishHamsterYAMLTemplate(DefaultTemplate, encoded, warnings, 1, true)
	require.NoError(t, err)

	body, _, err := BuildYAML(subscription, "https://new-api.example.com")
	require.NoError(t, err)
	assert.Contains(t, string(body), "name: \"Published name\"")
	assert.Contains(t, string(body), "sk-hsp")
	assert.NotContains(t, string(body), subscription.DownloadToken)
}

func modelJSON(value any) (string, error) {
	body, err := common.Marshal(value)
	return string(body), err
}
