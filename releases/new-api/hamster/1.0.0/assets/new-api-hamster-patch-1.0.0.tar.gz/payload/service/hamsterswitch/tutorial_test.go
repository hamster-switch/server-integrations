package hamsterswitch

import (
	"context"
	"encoding/base64"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestTutorialValidationMergeAndConflictDetection(t *testing.T) {
	base := BuiltinTutorial()
	require.NoError(t, base.Validate())
	override := TutorialOverride{
		StepID: "create-subscription", Title: "Site title", BodyMD: "Site body", Position: 10,
	}
	require.NoError(t, ValidateTutorialOverride(override))
	merged := MergeTutorial(base, []TutorialOverride{override}, func(id string) string { return "/images/" + id })
	require.NotEmpty(t, merged.Steps)
	assert.Equal(t, "Site title", merged.Steps[0].Title)

	next := base
	next.Steps = append([]TutorialStep(nil), base.Steps...)
	next.Version = "1.1.0"
	next.Steps[0].Title = "Release title"
	conflicts := TutorialConflicts(base, next, []TutorialOverride{override})
	require.Len(t, conflicts, 1)
	assert.Equal(t, "modified", conflicts[0].Change)

	invalid := base
	invalid.Steps[0].Assets = []TutorialAsset{{Kind: "external", URL: "http://127.0.0.1/private.png"}}
	assert.Error(t, invalid.Validate())
}

func TestTutorialImageCacheValidatesContentAndSSRF(t *testing.T) {
	cache, err := NewImageCache(t.TempDir())
	require.NoError(t, err)
	pngBody, err := base64.StdEncoding.DecodeString("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=")
	require.NoError(t, err)
	entry, err := cache.Store(strings.NewReader(string(pngBody)), "image/png")
	require.NoError(t, err)
	assert.Equal(t, "image/png", entry.MediaType)
	assert.Equal(t, 1, entry.Width)
	assert.Equal(t, 1, entry.Height)
	_, err = cache.Path(entry.LocalName)
	require.NoError(t, err)
	_, err = cache.Path("../escape.png")
	assert.Error(t, err)
	_, err = cache.Store(strings.NewReader("not an image"), "image/png")
	assert.Error(t, err)
	_, err = cache.Fetch(context.Background(), "https://127.0.0.1/private.png")
	assert.Error(t, err)
}

func TestTutorialManifestRejectsInvalidSignature(t *testing.T) {
	_, err := verifyContentManifest([]byte(`{"schema_version":1}`), []byte("invalid"))
	assert.Error(t, err)
}
