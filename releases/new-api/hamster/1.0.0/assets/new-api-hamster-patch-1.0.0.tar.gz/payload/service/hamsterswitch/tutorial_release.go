package hamsterswitch

import (
	"context"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	rootservice "github.com/QuantumNous/new-api/service"
)

const managedContentPublicKey = "7Hd2E2OF8wLrBrrYJXwBHCE+Y0SfgjzOAZI9VCZ2r2c="
const managedContentReleaseAPI = "https://api.github.com/repos/hamster-switch/managed-content"

type releaseAsset struct {
	Name string `json:"name"`
	URL  string `json:"browser_download_url"`
}
type formalRelease struct {
	Tag        string         `json:"tag_name"`
	Draft      bool           `json:"draft"`
	Prerelease bool           `json:"prerelease"`
	Assets     []releaseAsset `json:"assets"`
}
type contentManifestAsset struct {
	ID          string `json:"id"`
	Path        string `json:"path"`
	ReleaseName string `json:"release_name"`
	Type        string `json:"type"`
	Version     string `json:"version"`
	SHA256      string `json:"sha256"`
	MediaType   string `json:"media_type"`
}
type contentManifest struct {
	SchemaVersion int                    `json:"schema_version"`
	ReleaseID     string                 `json:"release_id"`
	Version       string                 `json:"version"`
	PublishedAt   time.Time              `json:"published_at"`
	DSLVersion    string                 `json:"dsl_version"`
	Assets        []contentManifestAsset `json:"assets"`
}
type TutorialReleaseImage struct {
	ID, MediaType string
	Body          []byte
}
type TutorialSnapshot struct {
	Version  string
	Tutorial Tutorial
	Images   map[string]TutorialReleaseImage
}

func FetchLatestTutorialRelease(ctx context.Context) (TutorialSnapshot, error) {
	body, err := fetchManagedContent(ctx, managedContentReleaseAPI+"/releases?per_page=100", 4<<20)
	if err != nil {
		return TutorialSnapshot{}, err
	}
	var releases []formalRelease
	if err := common.Unmarshal(body, &releases); err != nil {
		return TutorialSnapshot{}, err
	}
	for _, release := range releases {
		if !release.Draft && !release.Prerelease && strings.HasPrefix(release.Tag, "content-v") {
			return fetchTutorialRelease(ctx, release)
		}
	}
	return TutorialSnapshot{}, errors.New("没有可用的正式 content-v Release")
}

func fetchTutorialRelease(ctx context.Context, release formalRelease) (TutorialSnapshot, error) {
	assets := make(map[string]releaseAsset, len(release.Assets))
	for _, asset := range release.Assets {
		assets[asset.Name] = asset
	}
	manifestRef, manifestOK := assets["manifest.json"]
	signatureRef, signatureOK := assets["manifest.json.sig"]
	if !manifestOK || !signatureOK {
		return TutorialSnapshot{}, errors.New("正式 Release 缺少签名目录")
	}
	manifestBody, err := fetchManagedContent(ctx, manifestRef.URL, 4<<20)
	if err != nil {
		return TutorialSnapshot{}, err
	}
	signatureBody, err := fetchManagedContent(ctx, signatureRef.URL, 4096)
	if err != nil {
		return TutorialSnapshot{}, err
	}
	manifest, err := verifyContentManifest(manifestBody, signatureBody)
	if err != nil {
		return TutorialSnapshot{}, err
	}
	if release.Tag != "content-v"+manifest.Version {
		return TutorialSnapshot{}, errors.New("Release 标签与签名目录版本不一致")
	}
	result := TutorialSnapshot{Version: manifest.Version, Images: map[string]TutorialReleaseImage{}}
	found := false
	var total int64
	for _, declared := range manifest.Assets {
		ref, ok := assets[declared.ReleaseName]
		if !ok {
			return TutorialSnapshot{}, fmt.Errorf("Release 缺少技能包文件 %q", declared.ReleaseName)
		}
		limit := int64(32 << 20)
		if declared.Type == "image" {
			limit = 8 << 20
		}
		assetBody, err := fetchManagedContent(ctx, ref.URL, limit)
		if err != nil {
			return TutorialSnapshot{}, err
		}
		digest := sha256.Sum256(assetBody)
		if hex.EncodeToString(digest[:]) != declared.SHA256 {
			return TutorialSnapshot{}, fmt.Errorf("Release 文件 %q 校验失败", declared.ReleaseName)
		}
		total += int64(len(assetBody))
		if total > 256<<20 {
			return TutorialSnapshot{}, errors.New("内容快照超过 256 MiB")
		}
		if declared.Type == "image" {
			result.Images[declared.ID] = TutorialReleaseImage{ID: declared.ID, MediaType: declared.MediaType, Body: assetBody}
			continue
		}
		if declared.Type == "tutorial" {
			var tutorial Tutorial
			if err := common.Unmarshal(assetBody, &tutorial); err != nil {
				return TutorialSnapshot{}, err
			}
			if tutorial.ID == "configuration-subscription-guide-zh-cn" {
				if err := tutorial.Validate(); err != nil {
					return TutorialSnapshot{}, err
				}
				result.Tutorial, found = tutorial, true
			}
		}
	}
	if !found {
		return TutorialSnapshot{}, errors.New("正式 Release 不包含配置订阅教程")
	}
	return result, nil
}

func verifyContentManifest(body, signatureBody []byte) (contentManifest, error) {
	publicKey, err := base64.StdEncoding.DecodeString(managedContentPublicKey)
	if err != nil || len(publicKey) != ed25519.PublicKeySize {
		return contentManifest{}, errors.New("内置内容公钥无效")
	}
	signature, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(signatureBody)))
	if err != nil || len(signature) != ed25519.SignatureSize || !ed25519.Verify(ed25519.PublicKey(publicKey), body, signature) {
		return contentManifest{}, errors.New("内容签名目录验证失败")
	}
	var manifest contentManifest
	if err := common.Unmarshal(body, &manifest); err != nil {
		return manifest, err
	}
	if manifest.SchemaVersion != 1 || manifest.DSLVersion != "hamster-template/v1" || !tutorialIDPattern.MatchString(manifest.ReleaseID) || !tutorialVersionPattern.MatchString(manifest.Version) || manifest.PublishedAt.IsZero() || len(manifest.Assets) == 0 {
		return manifest, errors.New("签名内容目录无效")
	}
	seenID, seenName := map[string]bool{}, map[string]bool{}
	for _, asset := range manifest.Assets {
		validType := asset.Type == "tutorial" || asset.Type == "template-metadata" || asset.Type == "template" || asset.Type == "image"
		if !tutorialIDPattern.MatchString(asset.ID) || strings.TrimSpace(asset.Path) == "" || strings.Contains(asset.Path, "..") || asset.ReleaseName == "" || strings.ContainsAny(asset.ReleaseName, "/\\") || !validType || !tutorialVersionPattern.MatchString(asset.Version) || len(asset.SHA256) != 64 || asset.MediaType == "" || seenID[asset.ID] || seenName[asset.ReleaseName] {
			return manifest, fmt.Errorf("签名内容文件 %q 无效", asset.ID)
		}
		if _, err := hex.DecodeString(asset.SHA256); err != nil {
			return manifest, fmt.Errorf("文件 %q 的摘要无效", asset.ID)
		}
		seenID[asset.ID], seenName[asset.ReleaseName] = true, true
	}
	return manifest, nil
}

func fetchManagedContent(ctx context.Context, endpoint string, limit int64) ([]byte, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Accept", "application/vnd.github+json")
	request.Header.Set("User-Agent", "new-api-hamster-managed-content")
	response, err := rootservice.GetSSRFProtectedHTTPClient().Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return nil, fmt.Errorf("内容 Release 返回 HTTP %d", response.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(body)) > limit {
		return nil, errors.New("内容 Release 文件超过大小限制")
	}
	return body, nil
}
