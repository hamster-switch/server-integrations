package hamsterswitch

import (
	"fmt"
	"net/url"
	"sort"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	coreservice "github.com/QuantumNous/new-api/service"
	"gopkg.in/yaml.v3"
)

type BuildMode int

const (
	BuildPreview BuildMode = iota
	BuildPublic
)

type Diagnostic struct {
	GroupName string `json:"group_name"`
	ChannelID int    `json:"channel_id"`
	Code      string `json:"code"`
	Message   string `json:"message"`
}

type SubscriptionExport struct {
	FormatVersion int        `json:"format_version" yaml:"format_version"`
	Name          string     `json:"name" yaml:"name"`
	Description   string     `json:"description,omitempty" yaml:"description,omitempty"`
	Icon          string     `json:"icon,omitempty" yaml:"icon,omitempty"`
	HomeURL       string     `json:"home_url,omitempty" yaml:"home_url,omitempty"`
	UpdatedAt     string     `json:"updated_at" yaml:"updated_at"`
	Providers     []Provider `json:"providers" yaml:"providers"`
}

type Provider struct {
	ID             string             `json:"id" yaml:"id"`
	AppType        string             `json:"app_type" yaml:"app_type"`
	Apps           []string           `json:"apps" yaml:"apps"`
	GroupName      string             `json:"group_name" yaml:"group_name"`
	Name           string             `json:"name" yaml:"name"`
	Description    string             `json:"description,omitempty" yaml:"description,omitempty"`
	Icon           string             `json:"icon,omitempty" yaml:"icon,omitempty"`
	Models         []string           `json:"models" yaml:"models"`
	DefaultModel   string             `json:"default_model" yaml:"default_model"`
	BaseURL        string             `json:"base_url" yaml:"base_url"`
	APIKey         string             `json:"api_key,omitempty" yaml:"api_key"`
	Pricing        map[string]any     `json:"pricing" yaml:"pricing"`
	SettingsConfig map[string]any     `json:"settings_config" yaml:"settings_config"`
	Endpoints      []ProviderEndpoint `json:"endpoints" yaml:"endpoints"`
	Meta           map[string]any     `json:"meta" yaml:"meta"`
}

type ProviderEndpoint struct {
	URL string `json:"url" yaml:"url"`
}

type ProviderSummary struct {
	ID           string         `json:"id"`
	Apps         []string       `json:"apps"`
	GroupName    string         `json:"group_name"`
	Name         string         `json:"name"`
	Description  string         `json:"description,omitempty"`
	Models       []string       `json:"models"`
	DefaultModel string         `json:"default_model"`
	BaseURL      string         `json:"base_url"`
	Pricing      map[string]any `json:"pricing"`
}

func BuildSubscription(subscription *model.HamsterConfigSubscription, baseURL string, mode BuildMode) (*SubscriptionExport, []Diagnostic, error) {
	return buildSubscription(subscription, baseURL, mode, true)
}

func BuildSubscriptionWithPresentation(subscription *model.HamsterConfigSubscription, baseURL string, mode BuildMode, presentation TemplatePresentation) (*SubscriptionExport, []Diagnostic, error) {
	export, diagnostics, err := buildSubscription(subscription, baseURL, mode, false)
	if err != nil {
		return nil, diagnostics, err
	}
	if err := ApplyTemplatePresentation(export, presentation); err != nil {
		return nil, diagnostics, err
	}
	return export, diagnostics, nil
}

func buildSubscription(subscription *model.HamsterConfigSubscription, baseURL string, mode BuildMode, applyActivePresentation bool) (*SubscriptionExport, []Diagnostic, error) {
	if subscription == nil || subscription.ID == 0 {
		return nil, nil, fmt.Errorf("subscription is required")
	}
	baseURL, err := normalizeBaseURL(baseURL)
	if err != nil {
		return nil, nil, err
	}
	var user model.User
	if err := model.DB.Select("id", "group").First(&user, subscription.UserID).Error; err != nil {
		return nil, nil, err
	}
	export := &SubscriptionExport{
		FormatVersion: 1,
		Name:          strings.TrimSpace(subscription.Name),
		UpdatedAt:     time.Unix(subscription.UpdatedTime, 0).UTC().Format(time.RFC3339),
		Providers:     make([]Provider, 0),
	}
	if export.Name == "" {
		export.Name = "New API Hamster"
	}
	groups := append([]model.HamsterConfigSubscriptionGroup(nil), subscription.Groups...)
	sort.Slice(groups, func(i, j int) bool {
		if groups[i].Position == groups[j].Position {
			return groups[i].ID < groups[j].ID
		}
		return groups[i].Position < groups[j].Position
	})
	diagnostics := make([]Diagnostic, 0)
	for _, group := range groups {
		providers, skipped, err := buildGroupProviders(subscription, &group, user.Group, baseURL, mode)
		if err != nil {
			return nil, diagnostics, err
		}
		export.Providers = append(export.Providers, providers...)
		diagnostics = append(diagnostics, skipped...)
	}
	if applyActivePresentation {
		if err := ApplyActivePresentation(export); err != nil {
			return nil, diagnostics, err
		}
	}
	return export, diagnostics, nil
}

func BuildYAML(subscription *model.HamsterConfigSubscription, baseURL string) ([]byte, []Diagnostic, error) {
	export, diagnostics, err := BuildSubscription(subscription, baseURL, BuildPublic)
	if err != nil {
		return nil, diagnostics, err
	}
	active, err := model.GetActiveHamsterYAMLTemplate()
	if err != nil {
		return nil, diagnostics, err
	}
	if active == nil {
		body, err := yaml.Marshal(export)
		return body, diagnostics, err
	}
	body, _, err := RenderTemplate(active.Body, *export)
	return body, diagnostics, err
}

func SummarizeProviders(export *SubscriptionExport) []ProviderSummary {
	if export == nil {
		return []ProviderSummary{}
	}
	summaries := make([]ProviderSummary, 0, len(export.Providers))
	for _, provider := range export.Providers {
		summaries = append(summaries, ProviderSummary{
			ID: provider.ID, Apps: append([]string(nil), provider.Apps...),
			GroupName: provider.GroupName, Name: provider.Name, Description: provider.Description,
			Models: append([]string(nil), provider.Models...), DefaultModel: provider.DefaultModel,
			BaseURL: provider.BaseURL, Pricing: cloneMap(provider.Pricing),
		})
	}
	return summaries
}

func buildGroupProviders(subscription *model.HamsterConfigSubscription, group *model.HamsterConfigSubscriptionGroup, userGroup, baseURL string, mode BuildMode) ([]Provider, []Diagnostic, error) {
	var channels []*model.Channel
	query := model.ApplyChannelGroupFilter(model.DB.Model(&model.Channel{}), group.GroupName)
	if err := query.Order("id asc").Find(&channels).Error; err != nil {
		return nil, nil, err
	}
	var abilities []model.Ability
	if err := model.DB.Where(&model.Ability{Group: group.GroupName, Enabled: true}).Order("channel_id asc, model asc").Find(&abilities).Error; err != nil {
		return nil, nil, err
	}
	modelsByChannel := make(map[int][]string)
	for _, ability := range abilities {
		modelsByChannel[ability.ChannelId] = append(modelsByChannel[ability.ChannelId], ability.Model)
	}
	providers := make([]Provider, 0, len(channels))
	diagnostics := make([]Diagnostic, 0)
	for _, channel := range channels {
		if channel == nil {
			continue
		}
		if channel.Status != common.ChannelStatusEnabled {
			diagnostics = append(diagnostics, Diagnostic{
				GroupName: group.GroupName, ChannelID: channel.Id, Code: "CHANNEL_DISABLED", Message: "channel is disabled",
			})
			continue
		}
		models := cleanStrings(modelsByChannel[channel.Id])
		if len(models) == 0 {
			diagnostics = append(diagnostics, Diagnostic{
				GroupName: group.GroupName, ChannelID: channel.Id, Code: "NO_ENABLED_MODELS", Message: "channel has no enabled model for this group",
			})
			continue
		}
		apps, err := model.GetHamsterChannelApps(channel.Id)
		if err != nil {
			return nil, diagnostics, err
		}
		apiKey := fmt.Sprintf("sk-hsp-preview-%d", channel.Id)
		if mode == BuildPublic {
			credential, err := model.GetOrCreateHamsterProviderCredential(group.ID, channel.Id)
			if err != nil {
				return nil, diagnostics, err
			}
			apiKey = "sk-" + credential.AccessKey
		}
		name := strings.TrimSpace(channel.Name)
		if name == "" {
			name = fmt.Sprintf("New API channel %d", channel.Id)
		}
		description := ""
		if channel.Remark != nil {
			description = strings.TrimSpace(*channel.Remark)
		}
		providerID := fmt.Sprintf("new-api-hamster:%s:%s:channel:%d", subscription.PublicID, group.BindingID, channel.Id)
		providers = append(providers, Provider{
			ID: providerID, AppType: "general", Apps: apps, GroupName: group.GroupName,
			Name: name, Description: description, Models: models, DefaultModel: models[0], BaseURL: baseURL,
			APIKey: apiKey, Pricing: map[string]any{"multiplier": coreservice.GetUserGroupRatio(userGroup, group.GroupName)},
			SettingsConfig: defaultGeneralSettings(apiKey, baseURL, models[0]),
			Endpoints:      []ProviderEndpoint{{URL: baseURL}},
			Meta: map[string]any{
				"gateway_type": "new-api", "issuer": "new-api", "auth_mode": "hamster_provider",
				"gateway_group": group.GroupName, "channel_id": channel.Id,
			},
		})
	}
	return providers, diagnostics, nil
}

func defaultGeneralSettings(apiKey, baseURL, modelName string) map[string]any {
	claude := map[string]any{"env": map[string]any{
		"ANTHROPIC_AUTH_TOKEN": apiKey, "ANTHROPIC_BASE_URL": baseURL, "ANTHROPIC_MODEL": modelName,
	}}
	return map[string]any{
		"claude":         cloneMap(claude),
		"claude-desktop": cloneMap(claude),
		"codex": map[string]any{
			"auth":   map[string]any{"OPENAI_API_KEY": apiKey},
			"config": fmt.Sprintf("model_provider = \"new_api_hamster\"\nmodel = %q\n\n[model_providers.new_api_hamster]\nname = \"New API Hamster\"\nbase_url = %q\nwire_api = \"responses\"\nrequires_openai_auth = true\n", modelName, baseURL+"/v1"),
		},
		"gemini": map[string]any{"env": map[string]any{
			"GEMINI_API_KEY": apiKey, "GOOGLE_GEMINI_BASE_URL": baseURL, "GEMINI_MODEL": modelName,
		}, "model": modelName},
	}
}

func normalizeBaseURL(value string) (string, error) {
	value = strings.TrimRight(strings.TrimSpace(value), "/")
	parsed, err := url.Parse(value)
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil {
		return "", fmt.Errorf("base URL must be an absolute HTTP(S) URL without credentials")
	}
	return value, nil
}

func cleanStrings(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	result := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		result = append(result, value)
	}
	sort.Strings(result)
	return result
}

func cloneMap(value map[string]any) map[string]any {
	result := make(map[string]any, len(value))
	for key, item := range value {
		switch typed := item.(type) {
		case map[string]any:
			result[key] = cloneMap(typed)
		case []string:
			result[key] = append([]string(nil), typed...)
		default:
			result[key] = item
		}
	}
	return result
}
