package hamsterswitch

import (
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/pelletier/go-toml/v2"
)

const DefaultPresentationJSON = `{"subscription":{},"providers":{}}`

type SubscriptionPresentation struct {
	Name        *string `json:"name,omitempty"`
	Description *string `json:"description,omitempty"`
	Icon        *string `json:"icon,omitempty"`
	HomeURL     *string `json:"home_url,omitempty"`
}

type ProviderPresentation struct {
	Name           *string         `json:"name,omitempty"`
	Description    *string         `json:"description,omitempty"`
	Icon           *string         `json:"icon,omitempty"`
	BaseURL        *string         `json:"base_url,omitempty"`
	Pricing        *map[string]any `json:"pricing,omitempty"`
	SettingsConfig *map[string]any `json:"settings_config,omitempty"`
}

type TemplatePresentation struct {
	Subscription SubscriptionPresentation        `json:"subscription"`
	Providers    map[string]ProviderPresentation `json:"providers"`
}

var codexBaseURLLine = regexp.MustCompile(`(?m)^(\s*base_url\s*=\s*)"(?:[^"\\]|\\.)*"(\s*(?:#.*)?)$`)

func DecodeTemplatePresentation(value string) (TemplatePresentation, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		value = DefaultPresentationJSON
	}
	var presentation TemplatePresentation
	if err := common.Unmarshal([]byte(value), &presentation); err != nil {
		return presentation, fmt.Errorf("presentation must be a JSON object: %w", err)
	}
	if presentation.Providers == nil {
		presentation.Providers = map[string]ProviderPresentation{}
	}
	if err := ValidateTemplatePresentation(presentation); err != nil {
		return presentation, err
	}
	return presentation, nil
}

func EncodeTemplatePresentation(value TemplatePresentation) (string, error) {
	if value.Providers == nil {
		value.Providers = map[string]ProviderPresentation{}
	}
	if err := ValidateTemplatePresentation(value); err != nil {
		return "", err
	}
	body, err := common.Marshal(value)
	return string(body), err
}

func ValidateTemplatePresentation(value TemplatePresentation) error {
	if value.Subscription.HomeURL != nil && strings.TrimSpace(*value.Subscription.HomeURL) != "" {
		if _, err := normalizePresentationURL(*value.Subscription.HomeURL); err != nil {
			return fmt.Errorf("subscription.home_url: %w", err)
		}
	}
	for key, provider := range value.Providers {
		if strings.TrimSpace(key) == "" {
			return errors.New("provider presentation key cannot be empty")
		}
		if provider.BaseURL != nil && strings.TrimSpace(*provider.BaseURL) != "" {
			if _, err := normalizePresentationURL(*provider.BaseURL); err != nil {
				return fmt.Errorf("providers.%s.base_url: %w", key, err)
			}
		}
		if provider.Pricing != nil {
			if multiplier, ok := (*provider.Pricing)["multiplier"]; ok {
				if _, ok := positiveNumber(multiplier); !ok {
					return fmt.Errorf("providers.%s.pricing.multiplier must be positive", key)
				}
			}
		}
		if provider.SettingsConfig != nil {
			if err := validateGeneralSettings(*provider.SettingsConfig); err != nil {
				return fmt.Errorf("providers.%s.settings_config: %w", key, err)
			}
		}
	}
	return nil
}

func ApplyActivePresentation(export *SubscriptionExport) error {
	active, err := model.GetActiveHamsterYAMLTemplate()
	if err != nil || active == nil {
		return err
	}
	presentation, err := DecodeTemplatePresentation(active.PresentationJSON)
	if err != nil {
		return err
	}
	return ApplyTemplatePresentation(export, presentation)
}

func ApplyTemplatePresentation(export *SubscriptionExport, value TemplatePresentation) error {
	if export == nil {
		return errors.New("subscription export is required")
	}
	applyPresentationString(value.Subscription.Name, &export.Name)
	applyPresentationString(value.Subscription.Description, &export.Description)
	applyPresentationString(value.Subscription.Icon, &export.Icon)
	applyPresentationString(value.Subscription.HomeURL, &export.HomeURL)
	for index := range export.Providers {
		provider := &export.Providers[index]
		channelID, ok := provider.Meta["channel_id"]
		if !ok {
			continue
		}
		key := fmt.Sprintf("%s:%v", provider.GroupName, channelID)
		override, ok := value.Providers[key]
		if !ok {
			continue
		}
		applyPresentationString(override.Name, &provider.Name)
		applyPresentationString(override.Description, &provider.Description)
		applyPresentationString(override.Icon, &provider.Icon)
		if override.Pricing != nil {
			provider.Pricing = mergePresentationMaps(provider.Pricing, *override.Pricing)
		}
		if override.SettingsConfig != nil {
			provider.SettingsConfig = clonePresentationMap(*override.SettingsConfig)
			if override.BaseURL == nil {
				baseURL, err := generalSettingsBaseURL(provider.SettingsConfig)
				if err != nil {
					return fmt.Errorf("provider %s: %w", key, err)
				}
				provider.BaseURL = baseURL
			}
		}
		if override.BaseURL != nil {
			baseURL, err := normalizePresentationURL(*override.BaseURL)
			if err != nil {
				return fmt.Errorf("provider %s: %w", key, err)
			}
			provider.BaseURL = baseURL
			settings, err := syncGeneralSettingsBaseURL(provider.SettingsConfig, baseURL)
			if err != nil {
				return fmt.Errorf("provider %s: %w", key, err)
			}
			provider.SettingsConfig = settings
		}
		provider.Endpoints = []ProviderEndpoint{{URL: provider.BaseURL}}
		provider.SettingsConfig = replacePresentationAPIKey(provider.SettingsConfig, provider.APIKey).(map[string]any)
	}
	return nil
}

func normalizePresentationURL(value string) (string, error) {
	value = strings.TrimRight(strings.TrimSpace(value), "/")
	parsed, err := url.Parse(value)
	if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" || parsed.User != nil {
		return "", errors.New("must be an absolute HTTP(S) URL without credentials")
	}
	return value, nil
}

func validateGeneralSettings(settings map[string]any) error {
	for _, app := range []string{"claude", "claude-desktop", "codex", "gemini"} {
		if _, ok := settings[app].(map[string]any); !ok {
			return fmt.Errorf("%s must be an object", app)
		}
	}
	baseURL, err := generalSettingsBaseURL(settings)
	if err != nil {
		return err
	}
	_, err = syncGeneralSettingsBaseURL(settings, baseURL)
	return err
}

func generalSettingsBaseURL(settings map[string]any) (string, error) {
	claude, _ := settings["claude"].(map[string]any)
	env, _ := claude["env"].(map[string]any)
	value, ok := env["ANTHROPIC_BASE_URL"].(string)
	if !ok {
		return "", errors.New("claude.env.ANTHROPIC_BASE_URL must be a string")
	}
	return normalizePresentationURL(value)
}

func syncGeneralSettingsBaseURL(settings map[string]any, baseURL string) (map[string]any, error) {
	baseURL, err := normalizePresentationURL(baseURL)
	if err != nil {
		return nil, err
	}
	result := clonePresentationMap(settings)
	for _, app := range []string{"claude", "claude-desktop"} {
		config, ok := result[app].(map[string]any)
		if !ok {
			return nil, fmt.Errorf("%s must be an object", app)
		}
		env, ok := config["env"].(map[string]any)
		if !ok {
			return nil, fmt.Errorf("%s.env must be an object", app)
		}
		env["ANTHROPIC_BASE_URL"] = baseURL
	}
	gemini, ok := result["gemini"].(map[string]any)
	if !ok {
		return nil, errors.New("gemini must be an object")
	}
	geminiEnv, ok := gemini["env"].(map[string]any)
	if !ok {
		return nil, errors.New("gemini.env must be an object")
	}
	geminiEnv["GOOGLE_GEMINI_BASE_URL"] = baseURL
	if _, exists := geminiEnv["GEMINI_BASE_URL"]; exists {
		geminiEnv["GEMINI_BASE_URL"] = baseURL
	}
	codex, ok := result["codex"].(map[string]any)
	if !ok {
		return nil, errors.New("codex must be an object")
	}
	config, ok := codex["config"].(string)
	if !ok || strings.TrimSpace(config) == "" {
		return nil, errors.New("codex.config must be a non-empty TOML string")
	}
	if err := toml.Unmarshal([]byte(config), &map[string]any{}); err != nil {
		return nil, fmt.Errorf("codex.config must contain valid TOML: %w", err)
	}
	if !codexBaseURLLine.MatchString(config) {
		return nil, errors.New("codex.config must define base_url")
	}
	codex["config"] = codexBaseURLLine.ReplaceAllString(config, `${1}`+strconv.Quote(baseURL+"/v1")+`${2}`)
	return result, nil
}

func applyPresentationString(source *string, target *string) {
	if source != nil {
		*target = strings.TrimSpace(*source)
	}
}

func positiveNumber(value any) (float64, bool) {
	switch typed := value.(type) {
	case float64:
		return typed, typed > 0
	case int:
		return float64(typed), typed > 0
	default:
		return 0, false
	}
}

func mergePresentationMaps(defaults, overrides map[string]any) map[string]any {
	result := clonePresentationMap(defaults)
	for key, value := range overrides {
		result[key] = value
	}
	return result
}

func clonePresentationMap(value map[string]any) map[string]any {
	result := make(map[string]any, len(value))
	for key, item := range value {
		switch typed := item.(type) {
		case map[string]any:
			result[key] = clonePresentationMap(typed)
		case []any:
			result[key] = append([]any(nil), typed...)
		default:
			result[key] = item
		}
	}
	return result
}

func replacePresentationAPIKey(value any, apiKey string) any {
	switch typed := value.(type) {
	case string:
		return strings.ReplaceAll(typed, "{{provider.api_key}}", apiKey)
	case map[string]any:
		result := make(map[string]any, len(typed))
		for key, item := range typed {
			result[key] = replacePresentationAPIKey(item, apiKey)
		}
		return result
	case []any:
		result := make([]any, len(typed))
		for index, item := range typed {
			result[index] = replacePresentationAPIKey(item, apiKey)
		}
		return result
	default:
		return value
	}
}
