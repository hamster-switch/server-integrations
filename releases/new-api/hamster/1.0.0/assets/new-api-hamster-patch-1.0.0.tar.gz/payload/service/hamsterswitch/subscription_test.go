package hamsterswitch

import (
	"path/filepath"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

func setupSubscriptionTest(t *testing.T) *model.HamsterConfigSubscription {
	t.Helper()
	previousDB := model.DB
	previousMainType := common.MainDatabaseType()
	previousLogType := common.LogDatabaseType()
	previousSQLitePath := common.SQLitePath
	previousMaster := common.IsMasterNode
	common.SQLitePath = filepath.Join(t.TempDir(), "hamster-subscription.db")
	common.IsMasterNode = true
	t.Setenv("SQL_DSN", "local")
	t.Setenv("LOG_SQL_DSN", "")
	require.NoError(t, model.InitDB())
	db := model.DB
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		model.DB = previousDB
		common.SetDatabaseTypes(previousMainType, previousLogType)
		common.SQLitePath = previousSQLitePath
		common.IsMasterNode = previousMaster
	})
	require.NoError(t, db.Create(&model.User{
		Id: 42, Username: "hamster-yaml", Password: "unused-password",
		Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: "default",
	}).Error)
	subscription, err := model.CreateHamsterConfigSubscription(42, model.HamsterSubscriptionInput{
		Name: "Dynamic", Groups: []string{"default"},
	})
	require.NoError(t, err)
	return subscription
}

func createChannelWithAbility(t *testing.T, channelID int, name, modelName string, status int) {
	t.Helper()
	require.NoError(t, model.DB.Create(&model.Channel{
		Id: channelID, Name: name, Status: status, Group: "default", Models: modelName,
	}).Error)
	if modelName != "" {
		require.NoError(t, model.DB.Create(&model.Ability{
			Group: "default", Model: modelName, ChannelId: channelID, Enabled: true,
		}).Error)
	}
}

func TestBuildSubscriptionUsesDynamicChannelsStableIDsAndStructuredSettings(t *testing.T) {
	subscription := setupSubscriptionTest(t)
	createChannelWithAbility(t, 17, "alpha", "gpt-alpha", common.ChannelStatusEnabled)
	createChannelWithAbility(t, 18, "beta", "gpt-beta", common.ChannelStatusEnabled)
	createChannelWithAbility(t, 19, "disabled", "gpt-disabled", common.ChannelStatusManuallyDisabled)
	_, err := model.SetHamsterChannelApps(17, 1, []string{"claude", "codex"})
	require.NoError(t, err)

	preview, diagnostics, err := BuildSubscription(subscription, "https://new-api.example.com/", BuildPreview)
	require.NoError(t, err)
	require.Len(t, preview.Providers, 2)
	assert.Len(t, diagnostics, 1)
	assert.Equal(t, []string{"claude", "codex"}, preview.Providers[0].Apps)
	assert.Equal(t, float64(1), preview.Providers[0].Pricing["multiplier"])
	assert.Contains(t, preview.Providers[0].ID, subscription.Groups[0].BindingID)
	var credentialCount int64
	require.NoError(t, model.DB.Model(&model.HamsterProviderCredential{}).Count(&credentialCount).Error)
	assert.Zero(t, credentialCount)

	body, _, err := BuildYAML(subscription, "https://new-api.example.com")
	require.NoError(t, err)
	var decoded map[string]any
	require.NoError(t, yaml.Unmarshal(body, &decoded))
	providers, ok := decoded["providers"].([]any)
	require.True(t, ok)
	require.Len(t, providers, 2)
	first, ok := providers[0].(map[string]any)
	require.True(t, ok)
	settings, ok := first["settings_config"].(map[string]any)
	require.True(t, ok)
	assert.Contains(t, settings, "claude")
	assert.Contains(t, settings, "claude-desktop")
	assert.Contains(t, settings, "codex")
	assert.Contains(t, settings, "gemini")
	pricing, ok := first["pricing"].(map[string]any)
	require.True(t, ok)
	assert.EqualValues(t, 1, pricing["multiplier"])
	require.NoError(t, model.DB.Model(&model.HamsterProviderCredential{}).Count(&credentialCount).Error)
	assert.EqualValues(t, 2, credentialCount)

	originalIDs := []string{preview.Providers[0].ID, preview.Providers[1].ID}
	createChannelWithAbility(t, 20, "gamma", "gpt-gamma", common.ChannelStatusEnabled)
	refreshed, _, err := BuildSubscription(subscription, "https://new-api.example.com", BuildPreview)
	require.NoError(t, err)
	require.Len(t, refreshed.Providers, 3)
	assert.Equal(t, originalIDs, []string{refreshed.Providers[0].ID, refreshed.Providers[1].ID})
}

func TestBuildSubscriptionAllowsEmptyProviderList(t *testing.T) {
	subscription := setupSubscriptionTest(t)
	export, diagnostics, err := BuildSubscription(subscription, "https://new-api.example.com", BuildPreview)
	require.NoError(t, err)
	assert.Empty(t, export.Providers)
	assert.Empty(t, diagnostics)
	body, _, err := BuildYAML(subscription, "https://new-api.example.com")
	require.NoError(t, err)
	assert.Contains(t, string(body), "providers: []")
}
