package router

import (
	"net/http"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestRetiredFrontendAPIRoutes(t *testing.T) {
	gin.SetMode(gin.TestMode)
	engine := gin.New()
	SetApiRouter(engine)

	routes := make(map[string]struct{}, len(engine.Routes()))
	for _, route := range engine.Routes() {
		routes[route.Method+" "+route.Path] = struct{}{}
	}
	_, hasAsyncCleanup := routes[http.MethodPost+" /api/system-task/log-cleanup"]
	_, hasDirectDelete := routes[http.MethodDelete+" /api/log/"]
	_, hasConsoleMigration := routes[http.MethodPost+" /api/option/migrate_console_setting"]
	_, hasHamsterPublicDownload := routes[http.MethodGet+" /api/hamster-switch/public/:download_token/subscription.yaml"]
	_, hasHamsterUserSubscriptions := routes[http.MethodGet+" /api/hamster-switch/subscriptions/"]
	_, hasHamsterAdminYAML := routes[http.MethodGet+" /api/hamster-switch/admin/subscriptions/:public_id/yaml"]
	assert.True(t, hasAsyncCleanup)
	assert.False(t, hasDirectDelete)
	assert.False(t, hasConsoleMigration)
	assert.True(t, hasHamsterPublicDownload)
	assert.True(t, hasHamsterUserSubscriptions)
	assert.True(t, hasHamsterAdminYAML)
}
