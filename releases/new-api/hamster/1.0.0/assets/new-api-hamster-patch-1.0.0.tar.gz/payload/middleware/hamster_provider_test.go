package middleware

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/i18n"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func setupHamsterProviderMiddlewareTest(t *testing.T) string {
	t.Helper()
	previousDB := model.DB
	previousMainType := common.MainDatabaseType()
	previousLogType := common.LogDatabaseType()
	previousRedis := common.RedisEnabled
	previousMemoryCache := common.MemoryCacheEnabled
	previousSQLitePath := common.SQLitePath
	previousMaster := common.IsMasterNode
	common.SQLitePath = filepath.Join(t.TempDir(), "hamster-provider.db")
	common.IsMasterNode = true
	common.RedisEnabled = false
	common.MemoryCacheEnabled = false
	require.NoError(t, i18n.Init())
	t.Setenv("SQL_DSN", "local")
	t.Setenv("LOG_SQL_DSN", "")
	require.NoError(t, model.InitDB())
	db := model.DB
	t.Cleanup(func() {
		if sqlDB, err := db.DB(); err == nil {
			_ = sqlDB.Close()
		}
		model.DB = previousDB
		common.SetDatabaseTypes(previousMainType, previousLogType)
		common.RedisEnabled = previousRedis
		common.MemoryCacheEnabled = previousMemoryCache
		common.SQLitePath = previousSQLitePath
		common.IsMasterNode = previousMaster
	})
	require.NoError(t, db.Create(&model.User{
		Id: 42, Username: "hamster-provider", Password: "unused-password",
		Role: common.RoleCommonUser, Status: common.UserStatusEnabled, Group: "default",
	}).Error)
	created, err := model.CreateHamsterConfigSubscription(42, model.HamsterSubscriptionInput{
		Name: "Bound provider", Groups: []string{"default"},
	})
	require.NoError(t, err)
	require.Len(t, created.Groups, 1)
	channelOne := model.Channel{Id: 17, Name: "bound", Status: common.ChannelStatusEnabled, Group: "default", Models: "bound-model"}
	channelTwo := model.Channel{Id: 18, Name: "fallback", Status: common.ChannelStatusEnabled, Group: "default", Models: "fallback-model"}
	require.NoError(t, db.Create(&channelOne).Error)
	require.NoError(t, db.Create(&channelTwo).Error)
	require.NoError(t, db.Create(&model.Ability{Group: "default", Model: "bound-model", ChannelId: 17, Enabled: true}).Error)
	require.NoError(t, db.Create(&model.Ability{Group: "default", Model: "fallback-model", ChannelId: 18, Enabled: true}).Error)
	credential, err := model.GetOrCreateHamsterProviderCredential(created.Groups[0].ID, channelOne.Id)
	require.NoError(t, err)
	return credential.AccessKey
}

func requestHamsterProvider(t *testing.T, accessKey, modelName string) *httptest.ResponseRecorder {
	t.Helper()
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.POST("/v1beta/models/*path", TokenAuth(), Distribute(), func(c *gin.Context) {
		c.Status(http.StatusNoContent)
	})
	request := httptest.NewRequest(http.MethodPost, "/v1beta/models/"+modelName+":generateContent", nil)
	request.Header.Set("Authorization", "Bearer sk-"+accessKey)
	recorder := httptest.NewRecorder()
	router.ServeHTTP(recorder, request)
	return recorder
}

func TestHamsterProviderCredentialUsesOnlyItsBoundChannel(t *testing.T) {
	accessKey := setupHamsterProviderMiddlewareTest(t)

	allowed := requestHamsterProvider(t, accessKey, "bound-model")
	assert.Equal(t, http.StatusNoContent, allowed.Code)

	noFallback := requestHamsterProvider(t, accessKey, "fallback-model")
	assert.Equal(t, http.StatusForbidden, noFallback.Code)

	tampered := requestHamsterProvider(t, accessKey+"x", "bound-model")
	assert.Equal(t, http.StatusUnauthorized, tampered.Code)
}
