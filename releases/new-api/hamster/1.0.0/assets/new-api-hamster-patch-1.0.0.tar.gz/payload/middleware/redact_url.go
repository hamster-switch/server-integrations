package middleware

import "github.com/gin-gonic/gin"

// RedactRequestURLPath marks a stable replacement for a secret-bearing path.
// Gin's logger captures the raw path before route middleware runs, so the
// formatter must consume this override instead of reading Request.URL later.
func RedactRequestURLPath(redactedPath string) gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Set(LogPathOverrideKey, redactedPath)
		c.Next()
	}
}
