package middleware

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestRedactRequestURLPathHidesSecretWithoutLosingRouteParam(t *testing.T) {
	gin.SetMode(gin.TestMode)
	engine := gin.New()
	observedPath := ""
	engine.Use(func(c *gin.Context) {
		c.Next()
		observedPath = c.GetString(LogPathOverrideKey)
	})
	observedToken := ""
	engine.GET("/public/:token/subscription.yaml", RedactRequestURLPath("/public/[redacted]/subscription.yaml"), func(c *gin.Context) {
		observedToken = c.Param("token")
		c.Status(http.StatusNoContent)
	})

	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/public/bearer-secret/subscription.yaml", nil)
	engine.ServeHTTP(recorder, request)

	assert.Equal(t, http.StatusNoContent, recorder.Code)
	assert.Equal(t, "bearer-secret", observedToken)
	assert.Equal(t, "/public/[redacted]/subscription.yaml", observedPath)
	assert.Equal(t, "/public/bearer-secret/subscription.yaml", request.URL.Path)
}

func TestSetUpLoggerUsesRedactedPathOverride(t *testing.T) {
	gin.SetMode(gin.TestMode)
	previousWriter := gin.DefaultWriter
	var output bytes.Buffer
	gin.DefaultWriter = &output
	t.Cleanup(func() { gin.DefaultWriter = previousWriter })

	engine := gin.New()
	SetUpLogger(engine)
	engine.GET("/public/:token/subscription.yaml", RedactRequestURLPath("/public/[redacted]/subscription.yaml"), func(c *gin.Context) {
		c.Status(http.StatusNoContent)
	})
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/public/bearer-secret/subscription.yaml", nil)
	engine.ServeHTTP(recorder, request)

	assert.NotContains(t, output.String(), "bearer-secret")
	assert.Contains(t, output.String(), "/public/[redacted]/subscription.yaml")
}
