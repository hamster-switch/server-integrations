package smoke

const Signed = true
